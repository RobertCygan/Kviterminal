"""Export folder on the local file system (Phase 10, ADR-0036).

Layout below the store root (``<data>/exports``)::

    <entity_hex>/fakturaeksport-00001-20261024-093400.xlsx   finished files, read-only
    <entity_hex>/.<uuid>.part                                files being written

A file is written to a temporary name, flushed to disk and renamed: the final
name exists only with complete content. Names are fixed by the service and
checked here again; they never come from invoice or user text.
"""

import contextlib
import hashlib
import os
import re
import stat
import sys
import threading
import time
from collections.abc import Callable
from pathlib import Path
from uuid import UUID, uuid4

from invoiceflow.application.ports import StorageError

MAX_EXPORT_BYTES = 1024 * 1024 * 1024
_NAME = re.compile(r"fakturaeksport-[0-9]{5,}-[0-9]{8}-[0-9]{6}\.(xlsx|csv)")
_TEMPORARY = re.compile(r"\.[0-9a-f]{32}\.part")
_READ_ONLY = stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH
_REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
_LOCK = threading.Lock()
# Antivirus or indexing software can hold a new file open for a moment on Windows.
_LOCK_RETRY_DELAYS = (0.05, 0.1, 0.2, 0.4, 0.8)


def _is_link(info: os.stat_result) -> bool:
    if stat.S_ISLNK(info.st_mode):
        return True
    return bool((getattr(info, "st_file_attributes", 0) or 0) & _REPARSE_POINT)


def _fsync_directory(directory: Path) -> None:
    # Windows cannot open directories for fsync; NTFS journals the rename.
    if sys.platform == "win32":
        return
    descriptor = os.open(directory, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


class FileExportStore:
    """Implements :class:`invoiceflow.application.ports.ExportFileStore`."""

    def __init__(
        self,
        root: Path,
        *,
        new_id: Callable[[], UUID] = uuid4,
        fsync: Callable[[int], None] = os.fsync,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.root = root
        self._new_id = new_id
        self._fsync = fsync
        self._sleep = sleep

    def _directory(self, entity_id: UUID) -> Path:
        directory = self.root / entity_id.hex
        directory.mkdir(parents=True, exist_ok=True)
        if _is_link(os.lstat(directory)) or not directory.resolve().is_relative_to(
            self.root.resolve()
        ):
            msg = "export directory is a link"
            raise StorageError(msg)
        return directory

    def _final(self, entity_id: UUID, name: str) -> Path:
        if not _NAME.fullmatch(name):
            msg = "invalid export file name"
            raise StorageError(msg)
        return self._directory(entity_id) / name

    def _retry(self, operation: Callable[[], None]) -> None:
        for delay in _LOCK_RETRY_DELAYS:
            try:
                operation()
            except PermissionError:
                self._sleep(delay)
            else:
                return
        operation()

    def write(self, entity_id: UUID, name: str, data: bytes) -> str:
        """Store a new file atomically; an existing name is never replaced."""
        temporary: Path | None = None
        try:
            final = self._final(entity_id, name)
            temporary = final.parent / f".{self._new_id().hex}.part"
            with _LOCK:
                if os.path.lexists(final):
                    msg = "export file exists"
                    raise StorageError(msg)
                with temporary.open("xb") as handle:
                    handle.write(data)
                    handle.flush()
                    self._fsync(handle.fileno())
                self._retry(lambda: os.replace(temporary, final))
                os.chmod(final, _READ_ONLY)
                _fsync_directory(final.parent)
        except OSError as exc:
            if temporary is not None:
                with contextlib.suppress(OSError):
                    temporary.unlink(missing_ok=True)
            msg = "export file could not be written"
            raise StorageError(msg) from exc
        return hashlib.sha256(data).hexdigest()

    def read(self, entity_id: UUID, name: str) -> bytes | None:
        """Content of a finished file; None if it is missing or not a plain file."""
        final = self._final(entity_id, name)
        try:
            info = os.lstat(final)
            if _is_link(info) or not stat.S_ISREG(info.st_mode) or info.st_size > MAX_EXPORT_BYTES:
                return None
            return final.read_bytes()
        except FileNotFoundError:
            return None
        except OSError as exc:
            msg = "export file could not be read"
            raise StorageError(msg) from exc

    def discard_temporary(self, entity_id: UUID) -> int:
        """Remove files left by an interrupted write (startup recovery)."""
        removed = 0
        directory = self._directory(entity_id)
        for path in directory.iterdir():
            if _TEMPORARY.fullmatch(path.name) and not _is_link(os.lstat(path)):
                with contextlib.suppress(OSError):
                    path.unlink()
                    removed += 1
        return removed

    def save_copy(self, data: bytes, destination: Path) -> None:
        """Write a copy where the person chose; replaces an existing file there."""
        directory = destination.parent
        temporary = directory / f".{self._new_id().hex}.part"
        try:
            with temporary.open("xb") as handle:
                handle.write(data)
                handle.flush()
                self._fsync(handle.fileno())
            self._retry(lambda: os.replace(temporary, destination))
        except OSError as exc:
            with contextlib.suppress(OSError):
                temporary.unlink(missing_ok=True)
            msg = "export copy could not be written"
            raise StorageError(msg) from exc
