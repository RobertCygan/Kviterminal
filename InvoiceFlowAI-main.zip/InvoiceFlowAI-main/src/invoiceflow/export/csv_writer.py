"""CSV writer: UTF-8 with BOM, semicolon, Norwegian decimal comma (Phase 10, ADR-0036).

Excel opens such a file directly in a Norwegian locale. Every text cell passes
:func:`neutralize`, so invoice content can never become a formula.
"""

import csv
import datetime as dt
import io
from decimal import Decimal

from invoiceflow.application.export.model import Cell, ExportSheet, neutralize


def csv_text(value: Cell) -> str:
    if value is None:
        return ""
    if isinstance(value, Decimal):
        # Exact digits from the approved revision; never rounded or a float.
        return format(value, "f").replace(".", ",")
    if isinstance(value, dt.date):
        return value.strftime("%d.%m.%Y")
    if isinstance(value, int):
        return str(value)
    return neutralize(value)


class CsvWriter:
    """Implements :class:`invoiceflow.application.ports.ExportWriter`."""

    def render(self, sheet: ExportSheet) -> bytes:
        buffer = io.StringIO(newline="")
        writer = csv.writer(buffer, delimiter=";", lineterminator="\r\n")
        writer.writerow([neutralize(header) for header in sheet.headers])
        for row in sheet.rows:
            writer.writerow([csv_text(value) for value in row])
        return buffer.getvalue().encode("utf-8-sig")
