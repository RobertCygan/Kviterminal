"""Excel writer with openpyxl (Phase 10, ADR-0036).

Text is always written as a text cell (never a formula), and text that starts
like a formula also gets Excel's quote prefix, so it stays text when someone
edits the cell. Amounts are numbers from ``Decimal`` and dates are date cells.
"""

import datetime as dt
import io
from decimal import Decimal

from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter
from openpyxl.worksheet._write_only import WriteOnlyWorksheet

from invoiceflow.application.export.model import FORMULA_PREFIXES, Cell, ExportSheet

MONEY_FORMAT = "#,##0.00"
DATE_FORMAT = "DD.MM.YYYY"
_BOLD = Font(bold=True)


def _cell(sheet: WriteOnlyWorksheet, value: Cell, *, bold: bool = False) -> WriteOnlyCell:
    cell = WriteOnlyCell(sheet, value=value)
    if isinstance(value, str):
        cell.data_type = "s"
        if value.startswith(FORMULA_PREFIXES):
            cell.quotePrefix = True
    elif isinstance(value, Decimal):
        cell.number_format = MONEY_FORMAT
    elif isinstance(value, dt.date):
        cell.number_format = DATE_FORMAT
    if bold:
        cell.font = _BOLD
    return cell


class XlsxWriter:
    """Implements :class:`invoiceflow.application.ports.ExportWriter`."""

    def render(self, sheet: ExportSheet) -> bytes:
        workbook = Workbook(write_only=True)
        workbook.properties.creator = "InvoiceFlow AI"
        data = workbook.create_sheet(sheet.sheet_name)
        data.freeze_panes = "A2"
        for index, header in enumerate(sheet.headers, start=1):
            data.column_dimensions[get_column_letter(index)].width = min(
                max(len(header) + 2, 12), 40
            )
        data.append([_cell(data, header, bold=True) for header in sheet.headers])
        for row in sheet.rows:
            data.append([_cell(data, value) for value in row])
        summary = workbook.create_sheet(sheet.summary_name)
        summary.column_dimensions["A"].width = 32
        summary.column_dimensions["B"].width = 70
        for label, value in sheet.summary:
            summary.append([_cell(summary, label, bold=True), _cell(summary, value)])
        buffer = io.BytesIO()
        workbook.save(buffer)
        return buffer.getvalue()
