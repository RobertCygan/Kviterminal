"""Canonical serialisation and hashing (docs/DATA_MODEL.md §4.4).

One definition of "the same content" for the whole application: invoices,
revision snapshots and audit events are hashed from these bytes only.
"""

import datetime as dt
import hashlib
import json
import re
from typing import Any

from invoiceflow.domain.invoice import CanonicalInvoice

_UTC_TEXT = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{6}Z")


def canonical_json_bytes(data: Any) -> bytes:
    """Serialise JSON-compatible data with sorted keys and no insignificant whitespace."""
    return json.dumps(
        data, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")


def invoice_canonical_json(invoice: CanonicalInvoice) -> bytes:
    """Canonical bytes of an invoice; workflow state is not part of the contract."""
    return canonical_json_bytes(invoice.model_dump(mode="json"))


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def content_sha256(invoice: CanonicalInvoice) -> str:
    """Hash that binds revisions and (later) approvals to exact invoice content."""
    return sha256_hex(invoice_canonical_json(invoice))


def format_utc(value: dt.datetime) -> str:
    """Fixed-width UTC text with microseconds, e.g. ``2026-10-20T10:00:00.000000Z``.

    The format sorts chronologically as text. Naive datetimes are rejected
    because their instant is ambiguous.
    """
    if not isinstance(value, dt.datetime):
        msg = "expected a datetime"
        raise TypeError(msg)
    if value.tzinfo is None or value.utcoffset() is None:
        msg = "naive datetimes are not allowed"
        raise ValueError(msg)
    v = value.astimezone(dt.UTC)
    # Explicit fields: strftime("%Y") is not zero-padded on every platform.
    return (
        f"{v.year:04d}-{v.month:02d}-{v.day:02d}T"
        f"{v.hour:02d}:{v.minute:02d}:{v.second:02d}.{v.microsecond:06d}Z"
    )


def parse_utc(text: str) -> dt.datetime:
    """Inverse of :func:`format_utc`; any other representation is rejected."""
    if not isinstance(text, str) or not _UTC_TEXT.fullmatch(text):
        msg = "invalid UTC timestamp text"
        raise ValueError(msg)
    return dt.datetime(
        int(text[0:4]),
        int(text[5:7]),
        int(text[8:10]),
        int(text[11:13]),
        int(text[14:16]),
        int(text[17:19]),
        int(text[20:26]),
        tzinfo=dt.UTC,
    )
