"""Check digits of Norwegian and international payment identifiers (Phase 08).

The canonical model checks only the shape of these values, so that a
mis-read value can still be stored and corrected. The accounting engine uses
these functions to flag values whose check digit is wrong. Pure functions on
digit strings; no rounding, no I/O.
"""

_ORG_WEIGHTS = (3, 2, 7, 6, 5, 4, 3, 2)
_ACCOUNT_WEIGHTS = (5, 4, 3, 2, 7, 6, 5, 4, 3, 2)


def _mod11_check_digit(digits: str, weights: tuple[int, ...]) -> str | None:
    """The MOD11 check digit as a string; ``None`` when the remainder gives 10."""
    total = sum(int(digit) * weight for digit, weight in zip(digits, weights, strict=True))
    check = 11 - total % 11
    if check == 11:
        return "0"
    if check == 10:
        return None
    return str(check)


def valid_org_number(value: str) -> bool:
    """Organisasjonsnummer: 9 digits, MOD11 with weights 3,2,7,6,5,4,3,2."""
    if len(value) != 9 or not value.isascii() or not value.isdigit():
        return False
    return _mod11_check_digit(value[:8], _ORG_WEIGHTS) == value[8]


def valid_bank_account(value: str) -> bool:
    """Norwegian account number: 11 digits, MOD11 with weights 5,4,3,2,7,6,5,4,3,2."""
    if len(value) != 11 or not value.isascii() or not value.isdigit():
        return False
    return _mod11_check_digit(value[:10], _ACCOUNT_WEIGHTS) == value[10]


def _luhn_valid(value: str) -> bool:
    total = 0
    for position, digit in enumerate(reversed(value)):
        number = int(digit)
        if position % 2 == 1:
            number *= 2
            if number > 9:
                number -= 9
        total += number
    return total % 10 == 0


def _kid_mod11_valid(value: str) -> bool:
    # Weights 2..7 repeating from the right; a remainder of 10 is written "-".
    body, check = value[:-1], value[-1]
    total = sum(int(digit) * (2 + position % 6) for position, digit in enumerate(reversed(body)))
    expected = 11 - total % 11
    if expected == 11:
        return check == "0"
    if expected == 10:
        return check == "-"
    return check == str(expected)


def valid_kid(value: str) -> bool:
    """KID: 2-25 characters, valid under MOD10 (Luhn) or MOD11."""
    if not 2 <= len(value) <= 25 or not value.isascii():
        return False
    if not value[:-1].isdigit() or not (value[-1].isdigit() or value[-1] == "-"):
        return False
    if value[-1] == "-":
        return _kid_mod11_valid(value)
    return _luhn_valid(value) or _kid_mod11_valid(value)


def valid_iban(value: str) -> bool:
    """IBAN: ISO 13616 MOD97 over the rearranged, letter-converted value."""
    if not 15 <= len(value) <= 34 or not value.isascii() or not value.isalnum():
        return False
    if not value[:2].isalpha() or not value[:2].isupper() or not value[2:4].isdigit():
        return False
    if any(char.islower() for char in value):
        return False
    rearranged = value[4:] + value[:4]
    number = "".join(str(int(char, 36)) for char in rearranged)
    return int(number) % 97 == 1
