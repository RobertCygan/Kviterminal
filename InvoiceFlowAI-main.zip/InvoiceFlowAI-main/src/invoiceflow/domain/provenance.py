"""Provenance contracts: where every canonical value came from.

Each value in the canonical invoice is wrapped in :class:`FieldValue`, which
pairs the value with a :class:`Provenance` record. Provenance is always set by
deterministic application code - never by an AI model's own claims.
"""

from enum import StrEnum
from typing import Self

from pydantic import Field, model_validator

from invoiceflow.domain.base import ContractModel
from invoiceflow.domain.types import (
    Confidence,
    Position,
    ReferenceText,
    UnitInterval,
    UtcTimestamp,
)


class ValueSource(StrEnum):
    """Origin of a value (see docs/DATA_MODEL.md, "Proveniens")."""

    EXTRACTED = "extracted"  # read directly from the document (text layer, OCR, XML)
    AI_SUGGESTED = "ai_suggested"  # suggested or inferred by an AI provider
    CALCULATED = "calculated"  # computed by deterministic code
    MANUAL = "manual"  # entered or corrected by a user


class BoundingBox(ContractModel):
    """Region on a page, normalised to 0..1 with origin at the top-left corner.

    Normalised coordinates are independent of render DPI and page size.
    """

    x0: UnitInterval
    y0: UnitInterval
    x1: UnitInterval
    y1: UnitInterval

    @model_validator(mode="after")
    def _check_order(self) -> Self:
        if self.x0 > self.x1 or self.y0 > self.y1:
            msg = "bounding box requires x0 <= x1 and y0 <= y1"
            raise ValueError(msg)
        return self


class Evidence(ContractModel):
    """Pointer to where in the source document a value was found."""

    page_number: Position | None = None
    bbox: BoundingBox | None = None
    # Engine-specific reference, e.g. an OCR block id or an XPath in an EHF file.
    source_ref: ReferenceText | None = None
    # The raw text exactly as found, before normalisation. It is evidence, so it
    # is not cleaned: it may contain control characters and must be displayed as
    # escaped plain text. Sensitive: never log it.
    raw_text: str | None = Field(default=None, max_length=2000)

    @model_validator(mode="after")
    def _check_location(self) -> Self:
        if self.page_number is None and self.source_ref is None:
            msg = "evidence requires page_number or source_ref"
            raise ValueError(msg)
        if self.bbox is not None and self.page_number is None:
            msg = "bbox requires page_number"
            raise ValueError(msg)
        return self


class Provenance(ContractModel):
    """Who or what produced a value, and on which evidence."""

    source: ValueSource
    # Producer id, e.g. "tesseract/5.5", "regel/linje-mva/1", "bruker/lokal".
    producer: ReferenceText | None = None
    confidence: Confidence | None = None
    evidence: Evidence | None = None
    recorded_at: UtcTimestamp | None = None

    @model_validator(mode="after")
    def _check_source_rules(self) -> Self:
        if self.source is ValueSource.EXTRACTED and self.evidence is None:
            msg = "extracted values require evidence"
            raise ValueError(msg)
        if self.source is not ValueSource.EXTRACTED and self.producer is None:
            msg = f"{self.source.value} values require a producer"
            raise ValueError(msg)
        if self.source in (ValueSource.CALCULATED, ValueSource.MANUAL) and (
            self.confidence is not None
        ):
            msg = f"{self.source.value} values must not carry a confidence score"
            raise ValueError(msg)
        return self


class FieldValue[T](ContractModel):
    """A canonical value together with its provenance.

    ``value`` is ``None`` when a value was looked for but could not be parsed
    into a valid normalised form; the raw text is then kept in
    ``provenance.evidence.raw_text`` and validation flags the field for review.
    A field that was not found at all is represented by the field itself being
    ``None`` on the parent model. Missing values are never fabricated.
    """

    value: T | None
    provenance: Provenance
