"""Domain layer: canonical contracts and pure business types.

This package must not import UI, persistence, OCR, AI or other infrastructure
code (enforced by tests/architecture/test_import_rules.py).
"""

from invoiceflow.domain.invoice import (
    SCHEMA_VERSION,
    AccountingLine,
    CanonicalInvoice,
    InvoiceLine,
    InvoiceTotals,
    InvoiceType,
    Party,
    PaymentDetails,
    PostalAddress,
    VatBreakdownEntry,
)
from invoiceflow.domain.provenance import (
    BoundingBox,
    Evidence,
    FieldValue,
    Provenance,
    ValueSource,
)

__all__ = [
    "SCHEMA_VERSION",
    "AccountingLine",
    "BoundingBox",
    "CanonicalInvoice",
    "Evidence",
    "FieldValue",
    "InvoiceLine",
    "InvoiceTotals",
    "InvoiceType",
    "Party",
    "PaymentDetails",
    "PostalAddress",
    "Provenance",
    "ValueSource",
    "VatBreakdownEntry",
]
