"""Canonical invoice contract.

The canonical invoice is independent of OCR engines, AI providers and ERP
adapters: every adapter maps *to* or *from* this structure. It describes the
content of one invoice or credit note. Workflow state (validation results,
approvals, exports) is stored separately so that the content can be hashed and
bound to an approval (see docs/DATA_MODEL.md).

This module validates *shape* only. Business rules such as totals, VAT,
checksums and duplicates belong to the accounting engine.
"""

from enum import StrEnum
from typing import Literal, Self
from uuid import UUID

from pydantic import Field, model_validator

from invoiceflow.domain.base import ContractModel
from invoiceflow.domain.provenance import FieldValue
from invoiceflow.domain.types import (
    BankAccount,
    Bic,
    CountryCode,
    CurrencyCode,
    DimensionCode,
    ExplanationText,
    Flag,
    ForeignVatId,
    Iban,
    Identifier,
    IsoDate,
    Kid,
    LongText,
    Money,
    OrgNumber,
    Position,
    PostalCode,
    Quantity,
    ShortText,
    UnitPrice,
    UnitText,
    VatRate,
)

SCHEMA_VERSION = "1.0"

# Hard upper bounds that protect against resource exhaustion from hostile
# input. Lower, configurable limits are applied earlier in the pipeline.
MAX_INVOICE_LINES = 5000
MAX_ACCOUNTING_LINES = 1000
MAX_VAT_BREAKDOWN_ENTRIES = 20


class InvoiceType(StrEnum):
    INVOICE = "invoice"  # Faktura
    CREDIT_NOTE = "credit_note"  # Kreditnota


class PostalAddress(ContractModel):
    street: FieldValue[ShortText] | None = None
    postal_code: FieldValue[PostalCode] | None = None
    city: FieldValue[ShortText] | None = None
    country_code: FieldValue[CountryCode] | None = None


class Party(ContractModel):
    """Supplier (leverandør) or customer (kunde) as stated on the invoice."""

    name: FieldValue[ShortText] | None = None
    org_number: FieldValue[OrgNumber] | None = None
    # True when the document marks the party as VAT registered ("MVA" suffix).
    vat_registered: FieldValue[Flag] | None = None
    foreign_vat_id: FieldValue[ForeignVatId] | None = None
    address: PostalAddress | None = None


class PaymentDetails(ContractModel):
    kid: FieldValue[Kid] | None = None
    bank_account: FieldValue[BankAccount] | None = None
    iban: FieldValue[Iban] | None = None
    bic: FieldValue[Bic] | None = None


class InvoiceLine(ContractModel):
    line_number: Position
    description: FieldValue[LongText] | None = None
    quantity: FieldValue[Quantity] | None = None
    unit: FieldValue[UnitText] | None = None
    unit_price: FieldValue[UnitPrice] | None = None
    net_amount: FieldValue[Money] | None = None
    vat_rate: FieldValue[VatRate] | None = None
    vat_amount: FieldValue[Money] | None = None


class VatBreakdownEntry(ContractModel):
    """One row of the VAT summary (MVA-spesifikasjon) per rate."""

    vat_rate: FieldValue[VatRate] | None = None
    taxable_amount: FieldValue[Money] | None = None
    vat_amount: FieldValue[Money] | None = None


class InvoiceTotals(ContractModel):
    net_amount: FieldValue[Money] | None = None  # Sum eks. MVA
    vat_amount: FieldValue[Money] | None = None  # MVA
    rounding_amount: FieldValue[Money] | None = None  # Øreavrunding
    gross_amount: FieldValue[Money] | None = None  # Å betale / sum inkl. MVA


class AccountingLine(ContractModel):
    """One posting suggestion (konteringslinje) distributing the net amount."""

    line_number: Position
    account: FieldValue[DimensionCode] | None = None  # Konto i kontoplanen
    vat_code: FieldValue[DimensionCode] | None = None  # MVA-kode
    net_amount: FieldValue[Money] | None = None
    cost_center: FieldValue[DimensionCode] | None = None  # Kostnadssted
    department: FieldValue[DimensionCode] | None = None  # Avdeling
    project: FieldValue[DimensionCode] | None = None  # Prosjekt
    source_line_numbers: tuple[Position, ...] = Field(default=(), max_length=MAX_INVOICE_LINES)
    explanation: ExplanationText | None = None


class CanonicalInvoice(ContractModel):
    """Provider-independent representation of one invoice or credit note."""

    schema_version: Literal["1.0"] = SCHEMA_VERSION
    document_id: UUID
    # Page range in the source document; one scanned batch may hold several invoices.
    first_page: Position = 1
    last_page: Position | None = None

    invoice_type: FieldValue[InvoiceType] | None = None
    invoice_number: FieldValue[Identifier] | None = None
    invoice_date: FieldValue[IsoDate] | None = None
    due_date: FieldValue[IsoDate] | None = None
    currency: FieldValue[CurrencyCode] | None = None
    referenced_invoice_number: FieldValue[Identifier] | None = None  # For kreditnota
    buyer_reference: FieldValue[ShortText] | None = None  # "Deres ref."

    supplier: Party
    customer: Party | None = None
    payment: PaymentDetails | None = None

    lines: tuple[InvoiceLine, ...] = Field(default=(), max_length=MAX_INVOICE_LINES)
    vat_breakdown: tuple[VatBreakdownEntry, ...] = Field(
        default=(), max_length=MAX_VAT_BREAKDOWN_ENTRIES
    )
    totals: InvoiceTotals
    accounting_lines: tuple[AccountingLine, ...] = Field(
        default=(), max_length=MAX_ACCOUNTING_LINES
    )

    @model_validator(mode="after")
    def _check_structure(self) -> Self:
        if self.last_page is not None and self.last_page < self.first_page:
            msg = "last_page must not be before first_page"
            raise ValueError(msg)
        line_numbers = [line.line_number for line in self.lines]
        if len(set(line_numbers)) != len(line_numbers):
            msg = "invoice line numbers must be unique"
            raise ValueError(msg)
        accounting_numbers = [line.line_number for line in self.accounting_lines]
        if len(set(accounting_numbers)) != len(accounting_numbers):
            msg = "accounting line numbers must be unique"
            raise ValueError(msg)
        known = set(line_numbers)
        for accounting_line in self.accounting_lines:
            references = accounting_line.source_line_numbers
            if len(set(references)) != len(references):
                msg = "accounting line refers to the same invoice line more than once"
                raise ValueError(msg)
            unknown = set(references) - known
            if unknown:
                msg = f"accounting line refers to unknown invoice lines: {sorted(unknown)}"
                raise ValueError(msg)
        return self
