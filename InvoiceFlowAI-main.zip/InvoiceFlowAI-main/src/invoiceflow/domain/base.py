"""Shared base class for all canonical data contracts."""

from pydantic import BaseModel, ConfigDict


class ContractModel(BaseModel):
    """Immutable, strict-shape base model for canonical contracts.

    * ``extra="forbid"`` rejects unexpected fields. This is a security control:
      output from OCR/AI adapters may never smuggle in fields the contract
      does not define (see docs/SECURITY.md, prompt injection).
    * ``frozen=True`` makes instances immutable; changes create new instances,
      which keeps provenance and approval hashes trustworthy.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, validate_default=True)
