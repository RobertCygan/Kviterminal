"""Constrained scalar types used by the canonical contracts.

Monetary values are always :class:`decimal.Decimal`. Floats are rejected at the
boundary instead of being converted, so precision errors cannot enter the
domain silently. In JSON, decimal values must be encoded as strings
(e.g. ``"1234.50"``); pydantic serialises ``Decimal`` back to strings.

Values are validated, never rounded: a value with too many decimals is an
error, not something to fix quietly. Pydantic rejects NaN and Infinity for
``Decimal`` by default (covered by tests).

Accepted values are normalised to one canonical form (fixed-point decimals,
ISO dates) so that equal content always serialises identically. The content
hash that binds an approval depends on this.

Integers, booleans and floats are strict: ``True`` is not a line number and
``"yes"`` is not a boolean.
"""

import datetime as dt
import re
import unicodedata
from decimal import Decimal
from typing import Annotated, Any

from pydantic import AfterValidator, AwareDatetime, BeforeValidator, Field, StringConstraints


def _reject_float(value: Any) -> Any:
    # bool is a subclass of int and must not be accepted as a number either.
    if isinstance(value, float | bool):
        msg = "decimal values must be given as str, int or Decimal, never float or bool"
        raise ValueError(msg)
    return value


def fixed_point(value: Decimal, min_places: int) -> Decimal:
    """Normalise to fixed-point notation with at least ``min_places`` decimals.

    Trailing zeros beyond ``min_places`` are removed and negative zero becomes
    zero, so ``"1E+2"``, ``"100"`` and ``"100.000"`` share one representation.
    The conversion is exact; the value itself never changes. Shared with the
    persistence layer so that numbers have a single canonical text form.
    """
    if not value.is_finite():
        raise ValueError("only finite decimals can be normalised")
    sign, digits, exponent = value.as_tuple()
    if value.is_zero():
        return Decimal((0, (0,), -min_places))
    # Tuple construction is exact and independent of the active Decimal context.
    digits = list(digits)
    while len(digits) > 1 and digits[-1] == 0 and exponent < -min_places:
        digits.pop()
        exponent += 1
    if exponent > -min_places:
        digits.extend([0] * (exponent + min_places))
        exponent = -min_places
    return Decimal((sign, tuple(digits), exponent))


def _fixed_point(min_places: int) -> AfterValidator:
    return AfterValidator(lambda value: fixed_point(value, min_places))


_NoFloat = BeforeValidator(_reject_float)

# Amount in a currency, e.g. NOK with two decimals. Negative values are allowed
# (discount lines, rounding); sign rules are business validation, not shape.
Money = Annotated[Decimal, _NoFloat, Field(max_digits=15, decimal_places=2), _fixed_point(2)]

# Unit prices and quantities may carry more decimals (e.g. kWh, øre per unit).
UnitPrice = Annotated[Decimal, _NoFloat, Field(max_digits=18, decimal_places=6), _fixed_point(2)]
Quantity = Annotated[Decimal, _NoFloat, Field(max_digits=18, decimal_places=6), _fixed_point(0)]

# VAT (MVA) rate in percent, e.g. Decimal("25") or Decimal("12").
VatRate = Annotated[
    Decimal,
    _NoFloat,
    Field(ge=0, le=100, max_digits=5, decimal_places=2),
    _fixed_point(0),
]

# Model scores and normalised page coordinates are not money, so float is
# acceptable here.
UnitInterval = Annotated[
    float,
    Field(strict=True, ge=0.0, le=1.0, allow_inf_nan=False),
    # -0.0 serialises differently from 0.0; adding 0.0 maps it to 0.0.
    AfterValidator(lambda value: value + 0.0),
]
Confidence = UnitInterval

# 1-based positions (line and page numbers).
Position = Annotated[int, Field(strict=True, ge=1)]
Flag = Annotated[bool, Field(strict=True)]

_ISO_DATE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")


def _iso_date_only(value: Any) -> Any:
    # datetime is a subclass of date; a timestamp is not an invoice date.
    if isinstance(value, dt.datetime):
        msg = "dates must be plain dates, not datetimes"
        raise ValueError(msg)
    if isinstance(value, dt.date):
        return value
    if isinstance(value, str) and _ISO_DATE.fullmatch(value):
        return value
    msg = "dates must be ISO 8601 strings in the form YYYY-MM-DD"
    raise ValueError(msg)


IsoDate = Annotated[dt.date, BeforeValidator(_iso_date_only)]


def _to_utc(value: dt.datetime) -> dt.datetime:
    return value.astimezone(dt.UTC)


# Timestamps keep their instant but are normalised to UTC, so the same moment
# always serialises identically (e.g. "+02:00" and "Z" forms of one instant).
UtcTimestamp = Annotated[AwareDatetime, AfterValidator(_to_utc)]


def _text_checker(*, allow_line_breaks: bool):
    allowed = {"\n", "\t"} if allow_line_breaks else set()

    def check(value: str) -> str:
        if not value.strip():
            msg = "text must contain at least one visible character"
            raise ValueError(msg)
        for char in value:
            # Cc: control characters (incl. NUL); Cf: invisible format characters
            # such as bidirectional overrides that can disguise displayed text.
            if char not in allowed and unicodedata.category(char) in ("Cc", "Cf"):
                msg = f"text must not contain control or format characters (U+{ord(char):04X})"
                raise ValueError(msg)
        return value

    return AfterValidator(check)


_SingleLine = _text_checker(allow_line_breaks=False)
_MultiLine = _text_checker(allow_line_breaks=True)

ShortText = Annotated[str, StringConstraints(min_length=1, max_length=300), _SingleLine]
LongText = Annotated[str, StringConstraints(min_length=1, max_length=2000), _MultiLine]
Identifier = Annotated[str, StringConstraints(min_length=1, max_length=64), _SingleLine]
UnitText = Annotated[str, StringConstraints(min_length=1, max_length=32), _SingleLine]
ReferenceText = Annotated[str, StringConstraints(min_length=1, max_length=200), _SingleLine]
ExplanationText = Annotated[str, StringConstraints(min_length=1, max_length=1000), _MultiLine]
DimensionCode = Annotated[str, StringConstraints(pattern=r"^[0-9A-Za-z._-]{1,20}$")]

CurrencyCode = Annotated[str, StringConstraints(pattern=r"^[A-Z]{3}$")]  # ISO 4217
CountryCode = Annotated[str, StringConstraints(pattern=r"^[A-Z]{2}$")]  # ISO 3166-1
PostalCode = Annotated[str, StringConstraints(min_length=1, max_length=16), _SingleLine]

# Norwegian identifiers, normalised to digits only. The canonical model checks
# shape only; checksum rules (MOD11/MOD10) belong to the accounting engine so
# that a mis-read value can still be stored and corrected during review.
OrgNumber = Annotated[str, StringConstraints(pattern=r"^\d{9}$")]
BankAccount = Annotated[str, StringConstraints(pattern=r"^\d{11}$")]
# KID: 2-25 characters; MOD11 KIDs use "-" as check digit when the remainder is 10.
Kid = Annotated[str, StringConstraints(pattern=r"^\d{1,24}[0-9-]$")]
Iban = Annotated[str, StringConstraints(pattern=r"^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$")]
Bic = Annotated[str, StringConstraints(pattern=r"^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$")]
ForeignVatId = Annotated[str, StringConstraints(pattern=r"^[A-Z0-9]{4,20}$")]
