"""Exact column types for SQLite (ADR-0004).

SQLite has no decimal type, and SQLAlchemy's ``Numeric`` passes values through
float on SQLite. These types store canonical text instead and never touch
float.
"""

import datetime as dt
import re
from decimal import Decimal

from sqlalchemy import String
from sqlalchemy.engine import Dialect
from sqlalchemy.types import TypeDecorator

from invoiceflow.domain.canonical import format_utc, parse_utc
from invoiceflow.domain.types import fixed_point

_DECIMAL_TEXT = re.compile(r"-?[0-9]+(\.[0-9]+)?")


class DecimalText(TypeDecorator[Decimal]):
    """``Decimal`` stored as canonical fixed-point TEXT (e.g. ``"1234.50"``).

    The text form is produced by the same normaliser as the domain contracts,
    so a value read back is equal and identically formatted.
    """

    impl = String(40)
    cache_ok = True

    def __init__(self, min_places: int = 2) -> None:
        super().__init__()
        self.min_places = min_places

    def process_bind_param(self, value: object, dialect: Dialect) -> str | None:
        if value is None:
            return None
        # bool is an int subclass; float is inexact. Both are refused outright.
        if isinstance(value, bool) or not isinstance(value, Decimal | int):
            msg = "DecimalText accepts only Decimal or int"
            raise TypeError(msg)
        number = Decimal(value)
        if not number.is_finite():
            msg = "DecimalText accepts only finite values"
            raise ValueError(msg)
        # Bound expansion before rendering exponent notation to a fixed string.
        if abs(number.adjusted()) > 40 or len(number.as_tuple().digits) > 40:
            raise ValueError("decimal exceeds the storage limit")
        text = format(fixed_point(number, self.min_places), "f")
        if len(text) > 40:
            raise ValueError("decimal exceeds the storage limit")
        return text

    def process_result_value(self, value: object, dialect: Dialect) -> Decimal | None:
        if value is None:
            return None
        if not isinstance(value, str) or not _DECIMAL_TEXT.fullmatch(value):
            msg = "stored decimal is not in canonical text form"
            raise ValueError(msg)
        return Decimal(value)


class UtcDateTime(TypeDecorator[dt.datetime]):
    """Timezone-aware ``datetime`` stored as fixed-width UTC text.

    Example: ``2026-10-20T10:00:00.000000Z`` (microsecond precision). Naive
    datetimes are rejected; the text sorts chronologically.
    """

    impl = String(27)
    cache_ok = True

    def process_bind_param(self, value: object, dialect: Dialect) -> str | None:
        if value is None:
            return None
        return format_utc(value)

    def process_result_value(self, value: object, dialect: Dialect) -> dt.datetime | None:
        if value is None:
            return None
        return parse_utc(value)
