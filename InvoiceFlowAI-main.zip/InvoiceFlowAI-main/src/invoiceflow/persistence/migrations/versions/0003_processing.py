"""Phase 04: processing jobs, document pages and derived files.

Revision ID: 0003_processing
Revises: 0002_documents
Create Date: 2026-10-23

* ``processing_jobs`` records every isolated worker run for one stored
  document (ADR-0010, ADR-0031). The idempotency key covers the document, the
  step, the engine and its version and the output settings; there is at most
  one successful and at most one unfinished job per key and entity.
* ``document_pages`` and ``derived_files`` belong to exactly one job and can
  only be added while that job is running, so a job is reported as succeeded
  in the same transaction that stores its pages and files - never half.
* Everything is entity-scoped with composite foreign keys, append-only except
  for the single transition of a job from running to finished, and
  ``documents`` is not changed.

The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0003_processing"
down_revision = "0002_documents"
branch_labels = None
depends_on = None

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


_FINISHED = "'succeeded', 'failed', 'timed_out', 'cancelled'"
_ERROR_CODES = (
    "'encrypted', 'corrupt', 'no_pages', 'too_many_pages', 'page_too_large', 'too_much_text',"
    " 'output_too_large', 'unsupported_format', 'timed_out', 'memory_limit', 'worker_crashed',"
    " 'invalid_result', 'source_changed', 'source_missing', 'storage_failed', 'interrupted',"
    " 'cancelled'"
)

_STATEMENTS = [
    f"""
    CREATE TABLE processing_jobs (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        document_id CHAR(32) NOT NULL,
        step VARCHAR(32) NOT NULL CHECK (step IN ('page_analysis')),
        idempotency_key VARCHAR(64) NOT NULL CHECK {_hex64("idempotency_key")},
        attempt INTEGER NOT NULL CHECK (attempt BETWEEN 1 AND 1000),
        status VARCHAR(16) NOT NULL CHECK (status IN ('queued', 'running', {_FINISHED})),
        engine VARCHAR(16) NOT NULL CHECK (length(engine) BETWEEN 1 AND 16
            AND engine NOT GLOB '*[^a-z0-9]*'),
        engine_version VARCHAR(32) NOT NULL CHECK (length(engine_version) BETWEEN 1 AND 32
            AND engine_version NOT GLOB '*[^0-9A-Za-z.+-]*'),
        settings_hash VARCHAR(64) NOT NULL CHECK {_hex64("settings_hash")},
        queued_at VARCHAR(27) NOT NULL CHECK {_utc("queued_at")},
        started_at VARCHAR(27) CHECK (started_at IS NULL OR {_utc("started_at")}),
        finished_at VARCHAR(27) CHECK (finished_at IS NULL OR {_utc("finished_at")}),
        error_code VARCHAR(32) CHECK (error_code IS NULL OR error_code IN ({_ERROR_CODES})),
        page_count INTEGER CHECK (page_count IS NULL OR page_count BETWEEN 1 AND 1000),
        active_content BOOLEAN CHECK (active_content IS NULL OR active_content IN (0, 1)),
        CONSTRAINT pk_processing_jobs PRIMARY KEY (id),
        CONSTRAINT uq_processing_jobs_entity_id UNIQUE (entity_id, id),
        CONSTRAINT uq_processing_jobs_entity_document_id UNIQUE (entity_id, document_id, id),
        CONSTRAINT uq_processing_jobs_attempt UNIQUE (entity_id, idempotency_key, attempt),
        CONSTRAINT ck_processing_jobs_state CHECK (
            (status = 'queued' AND started_at IS NULL AND finished_at IS NULL
                AND error_code IS NULL AND page_count IS NULL AND active_content IS NULL)
            OR (status = 'running' AND started_at IS NOT NULL AND finished_at IS NULL
                AND error_code IS NULL AND page_count IS NULL AND active_content IS NULL)
            OR (status = 'succeeded' AND started_at IS NOT NULL AND finished_at IS NOT NULL
                AND error_code IS NULL AND page_count IS NOT NULL
                AND active_content IS NOT NULL)
            OR (status IN ('failed', 'timed_out', 'cancelled') AND finished_at IS NOT NULL
                AND error_code IS NOT NULL AND page_count IS NULL)),
        CONSTRAINT fk_processing_jobs_document FOREIGN KEY (entity_id, document_id)
            REFERENCES documents (entity_id, id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE UNIQUE INDEX uq_processing_jobs_succeeded ON processing_jobs
        (entity_id, idempotency_key) WHERE status = 'succeeded'
    """,
    """
    CREATE UNIQUE INDEX uq_processing_jobs_unfinished ON processing_jobs
        (entity_id, idempotency_key) WHERE status IN ('queued', 'running')
    """,
    "CREATE INDEX ix_processing_jobs_document ON processing_jobs (entity_id, document_id)",
    # Quarantined files are never opened again, so they never get a job.
    """
    CREATE TRIGGER processing_jobs_stored_document BEFORE INSERT ON processing_jobs
    WHEN NOT EXISTS (
        SELECT 1 FROM documents d
        WHERE d.id = NEW.document_id AND d.entity_id = NEW.entity_id AND d.status = 'stored')
    BEGIN SELECT RAISE(ABORT, 'only stored documents can be processed'); END
    """,
    """
    CREATE TRIGGER processing_jobs_no_delete BEFORE DELETE ON processing_jobs
    BEGIN SELECT RAISE(ABORT, 'processing_jobs cannot be deleted'); END
    """,
    f"""
    CREATE TRIGGER processing_jobs_transition BEFORE UPDATE ON processing_jobs
    WHEN NEW.id IS NOT OLD.id OR NEW.entity_id IS NOT OLD.entity_id
      OR NEW.document_id IS NOT OLD.document_id OR NEW.step IS NOT OLD.step
      OR NEW.idempotency_key IS NOT OLD.idempotency_key OR NEW.attempt IS NOT OLD.attempt
      OR NEW.engine IS NOT OLD.engine OR NEW.engine_version IS NOT OLD.engine_version
      OR NEW.settings_hash IS NOT OLD.settings_hash OR NEW.queued_at IS NOT OLD.queued_at
      OR OLD.status IN ({_FINISHED})
      OR (OLD.status = 'running' AND NEW.status NOT IN ({_FINISHED}))
      OR (OLD.status = 'running' AND NEW.started_at IS NOT OLD.started_at)
    BEGIN SELECT RAISE(ABORT, 'a job only moves forward and is final once finished'); END
    """,
    """
    CREATE TABLE document_pages (
        entity_id CHAR(32) NOT NULL,
        document_id CHAR(32) NOT NULL,
        job_id CHAR(32) NOT NULL,
        page_number INTEGER NOT NULL CHECK (page_number BETWEEN 1 AND 1000),
        width_px INTEGER NOT NULL CHECK (width_px BETWEEN 1 AND 100000),
        height_px INTEGER NOT NULL CHECK (height_px BETWEEN 1 AND 100000),
        rotation_degrees INTEGER NOT NULL CHECK (rotation_degrees IN (0, 90, 180, 270)),
        has_text_layer BOOLEAN NOT NULL CHECK (has_text_layer IN (0, 1)),
        text_layer_chars INTEGER NOT NULL CHECK (text_layer_chars BETWEEN 0 AND 1000000),
        CONSTRAINT pk_document_pages PRIMARY KEY (job_id, page_number),
        CONSTRAINT uq_document_pages_entity_job_page UNIQUE (entity_id, job_id, page_number),
        CONSTRAINT ck_document_pages_text CHECK (has_text_layer = (text_layer_chars > 0)),
        CONSTRAINT fk_document_pages_job FOREIGN KEY (entity_id, document_id, job_id)
            REFERENCES processing_jobs (entity_id, document_id, id) ON DELETE RESTRICT
    )
    """,
    f"""
    CREATE TABLE derived_files (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        document_id CHAR(32) NOT NULL,
        job_id CHAR(32) NOT NULL,
        page_number INTEGER NOT NULL,
        kind VARCHAR(16) NOT NULL CHECK (kind IN ('page_render', 'text_layer')),
        storage_path VARCHAR(200) NOT NULL CHECK (length(storage_path) BETWEEN 1 AND 200
            AND storage_path GLOB '[0-9a-f]*/derived/*'
            AND storage_path NOT GLOB '*..*' AND storage_path NOT GLOB '*\\*'
            AND storage_path NOT GLOB '*//*'),
        sha256 VARCHAR(64) NOT NULL CHECK {_hex64("sha256")},
        size_bytes INTEGER NOT NULL CHECK (size_bytes >= 1),
        producer VARCHAR(48) NOT NULL CHECK (length(producer) BETWEEN 3 AND 48
            AND producer NOT GLOB '*[^0-9A-Za-z./+-]*' AND producer GLOB '[a-z]*/*'),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        CONSTRAINT pk_derived_files PRIMARY KEY (id),
        CONSTRAINT uq_derived_files_storage_path UNIQUE (storage_path),
        CONSTRAINT uq_derived_files_job_page_kind UNIQUE (job_id, page_number, kind),
        CONSTRAINT fk_derived_files_job FOREIGN KEY (entity_id, document_id, job_id)
            REFERENCES processing_jobs (entity_id, document_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_derived_files_page FOREIGN KEY (entity_id, job_id, page_number)
            REFERENCES document_pages (entity_id, job_id, page_number) ON DELETE RESTRICT
    )
    """,
    # Pages and files are added only by the transaction that finishes the job.
    """
    CREATE TRIGGER document_pages_running_job BEFORE INSERT ON document_pages
    WHEN NOT EXISTS (
        SELECT 1 FROM processing_jobs j
        WHERE j.id = NEW.job_id AND j.entity_id = NEW.entity_id AND j.status = 'running')
    BEGIN SELECT RAISE(ABORT, 'pages can only be added to a running job'); END
    """,
    """
    CREATE TRIGGER derived_files_running_job BEFORE INSERT ON derived_files
    WHEN NOT EXISTS (
        SELECT 1 FROM processing_jobs j
        WHERE j.id = NEW.job_id AND j.entity_id = NEW.entity_id AND j.status = 'running')
    BEGIN SELECT RAISE(ABORT, 'files can only be added to a running job'); END
    """,
    """
    CREATE TRIGGER document_pages_no_update BEFORE UPDATE ON document_pages
    BEGIN SELECT RAISE(ABORT, 'document_pages is append-only'); END
    """,
    """
    CREATE TRIGGER document_pages_no_delete BEFORE DELETE ON document_pages
    BEGIN SELECT RAISE(ABORT, 'document_pages is append-only'); END
    """,
    """
    CREATE TRIGGER derived_files_no_update BEFORE UPDATE ON derived_files
    BEGIN SELECT RAISE(ABORT, 'derived_files is append-only'); END
    """,
    """
    CREATE TRIGGER derived_files_no_delete BEFORE DELETE ON derived_files
    BEGIN SELECT RAISE(ABORT, 'derived_files is append-only'); END
    """,
]


def upgrade() -> None:
    for statement in _STATEMENTS:
        op.execute(statement)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
