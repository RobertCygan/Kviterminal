"""Phase 15: EHF documents, the EHF extraction step and invoice findings.

Revision ID: 0004_ehf
Revises: 0003_processing
Create Date: 2026-10-23

* ``documents`` accepts the format ``xml`` and the source ``ehf_attachment``.
* ``processing_jobs`` accepts the step ``ehf_extraction`` and its error codes;
  a successful EHF job has no page count.
* ``invoice_findings`` holds stable codes for deviations found when an
  invoice revision was registered (arithmetic, recipient, duplicate).

SQLite cannot change a CHECK constraint in place, so ``documents`` and
``processing_jobs`` are rebuilt with SQLite's twelve-step procedure (ADR-0032):
the migrator switches ``foreign_keys`` off for this migration, every row is
copied unchanged, and ``PRAGMA foreign_key_check`` must be empty before the
transaction commits. ``legacy_alter_table`` is on only for the renames, so the
triggers of other tables that name these tables are not re-parsed while the
old table is gone.

The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0004_ehf"
down_revision = "0003_processing"
branch_labels = None
depends_on = None

# Read by the migrator: this migration rebuilds parent tables (ADR-0032).
FOREIGN_KEYS_OFF = True

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


def _actor(column: str) -> str:
    return (
        f"(length({column}) BETWEEN 1 AND 81 AND {column} NOT GLOB '*[^A-Za-z0-9._/-]*'"
        f" AND {column} GLOB '[a-z]*')"
    )


_DOCUMENT_TYPES = (
    "'unclassified', 'invoice', 'credit_note', 'receipt', 'contract',"
    " 'payment_confirmation', 'correspondence', 'other'"
)
_FINISHED = "'succeeded', 'failed', 'timed_out', 'cancelled'"
_ERROR_CODES = (
    "'encrypted', 'corrupt', 'no_pages', 'too_many_pages', 'page_too_large', 'too_much_text',"
    " 'output_too_large', 'unsupported_format', 'timed_out', 'memory_limit', 'worker_crashed',"
    " 'invalid_result', 'source_changed', 'source_missing', 'storage_failed', 'interrupted',"
    " 'cancelled', 'invalid_xml', 'unsupported_version', 'too_many_lines',"
    " 'too_many_attachments', 'attachment_too_large'"
)

_DOCUMENTS = f"""
    CREATE TABLE documents_0004 (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        document_type VARCHAR(32) NOT NULL CHECK (document_type IN ({_DOCUMENT_TYPES})),
        sha256 VARCHAR(64) NOT NULL CHECK {_hex64("sha256")},
        size_bytes INTEGER NOT NULL CHECK (size_bytes BETWEEN 1 AND 52428800),
        detected_format VARCHAR(8) CHECK (detected_format IS NULL
            OR detected_format IN ('pdf', 'png', 'jpeg', 'tiff', 'xml')),
        display_name VARCHAR(255) NOT NULL CHECK (length(display_name) BETWEEN 1 AND 255),
        storage_path VARCHAR(200) NOT NULL CHECK (length(storage_path) BETWEEN 1 AND 200
            AND storage_path GLOB '[0-9a-f]*/*'
            AND storage_path NOT GLOB '*..*' AND storage_path NOT GLOB '*\\*'
            AND storage_path NOT GLOB '*//*'),
        source VARCHAR(16) NOT NULL CHECK (source IN ('file_import', 'inbox', 'ehf_attachment')),
        status VARCHAR(16) NOT NULL CHECK (status IN ('stored', 'quarantined')),
        imported_at VARCHAR(27) NOT NULL CHECK {_utc("imported_at")},
        imported_by VARCHAR(81) NOT NULL CHECK {_actor("imported_by")},
        integrity_checked_at VARCHAR(27) CHECK (integrity_checked_at IS NULL
            OR {_utc("integrity_checked_at")}),
        integrity_status VARCHAR(16) CHECK (integrity_status IS NULL
            OR integrity_status IN ('ok', 'mismatch', 'missing')),
        CONSTRAINT pk_documents PRIMARY KEY (id),
        CONSTRAINT uq_documents_entity_id UNIQUE (entity_id, id),
        CONSTRAINT uq_documents_entity_sha256 UNIQUE (entity_id, sha256),
        CONSTRAINT uq_documents_storage_path UNIQUE (storage_path),
        CONSTRAINT ck_documents_stored_format CHECK (
            (status = 'stored' AND detected_format IS NOT NULL)
            OR (status = 'quarantined' AND detected_format IS NULL)),
        CONSTRAINT fk_documents_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT
    )
"""

_DOCUMENT_TRIGGERS = [
    "CREATE INDEX ix_documents_entity_imported ON documents (entity_id, imported_at)",
    """
    CREATE TRIGGER documents_no_delete BEFORE DELETE ON documents
    BEGIN SELECT RAISE(ABORT, 'documents cannot be deleted'); END
    """,
    """
    CREATE TRIGGER documents_immutable BEFORE UPDATE ON documents
    WHEN NEW.id IS NOT OLD.id OR NEW.entity_id IS NOT OLD.entity_id
      OR NEW.sha256 IS NOT OLD.sha256 OR NEW.size_bytes IS NOT OLD.size_bytes
      OR NEW.detected_format IS NOT OLD.detected_format
      OR NEW.storage_path IS NOT OLD.storage_path OR NEW.source IS NOT OLD.source
      OR NEW.status IS NOT OLD.status OR NEW.imported_at IS NOT OLD.imported_at
      OR NEW.imported_by IS NOT OLD.imported_by OR NEW.display_name IS NOT OLD.display_name
    BEGIN SELECT RAISE(ABORT, 'document identity and original are immutable'); END
    """,
]

_JOBS = f"""
    CREATE TABLE processing_jobs_0004 (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        document_id CHAR(32) NOT NULL,
        step VARCHAR(32) NOT NULL CHECK (step IN ('page_analysis', 'ehf_extraction')),
        idempotency_key VARCHAR(64) NOT NULL CHECK {_hex64("idempotency_key")},
        attempt INTEGER NOT NULL CHECK (attempt BETWEEN 1 AND 1000),
        status VARCHAR(16) NOT NULL CHECK (status IN ('queued', 'running', {_FINISHED})),
        engine VARCHAR(16) NOT NULL CHECK (length(engine) BETWEEN 1 AND 16
            AND engine NOT GLOB '*[^a-z0-9]*'),
        engine_version VARCHAR(32) NOT NULL CHECK (length(engine_version) BETWEEN 1 AND 32
            AND engine_version NOT GLOB '*[^0-9A-Za-z.+-]*'),
        settings_hash VARCHAR(64) NOT NULL CHECK {_hex64("settings_hash")},
        queued_at VARCHAR(27) NOT NULL CHECK {_utc("queued_at")},
        started_at VARCHAR(27) CHECK (started_at IS NULL OR {_utc("started_at")}),
        finished_at VARCHAR(27) CHECK (finished_at IS NULL OR {_utc("finished_at")}),
        error_code VARCHAR(32) CHECK (error_code IS NULL OR error_code IN ({_ERROR_CODES})),
        page_count INTEGER CHECK (page_count IS NULL OR page_count BETWEEN 1 AND 1000),
        active_content BOOLEAN CHECK (active_content IS NULL OR active_content IN (0, 1)),
        CONSTRAINT pk_processing_jobs PRIMARY KEY (id),
        CONSTRAINT uq_processing_jobs_entity_id UNIQUE (entity_id, id),
        CONSTRAINT uq_processing_jobs_entity_document_id UNIQUE (entity_id, document_id, id),
        CONSTRAINT uq_processing_jobs_attempt UNIQUE (entity_id, idempotency_key, attempt),
        CONSTRAINT ck_processing_jobs_state CHECK (
            (status = 'queued' AND started_at IS NULL AND finished_at IS NULL
                AND error_code IS NULL AND page_count IS NULL AND active_content IS NULL)
            OR (status = 'running' AND started_at IS NOT NULL AND finished_at IS NULL
                AND error_code IS NULL AND page_count IS NULL AND active_content IS NULL)
            OR (status = 'succeeded' AND started_at IS NOT NULL AND finished_at IS NOT NULL
                AND error_code IS NULL AND active_content IS NOT NULL
                AND (page_count IS NOT NULL OR step <> 'page_analysis'))
            OR (status IN ('failed', 'timed_out', 'cancelled') AND finished_at IS NOT NULL
                AND error_code IS NOT NULL AND page_count IS NULL)),
        CONSTRAINT fk_processing_jobs_document FOREIGN KEY (entity_id, document_id)
            REFERENCES documents (entity_id, id) ON DELETE RESTRICT
    )
"""

_JOB_TRIGGERS = [
    """
    CREATE UNIQUE INDEX uq_processing_jobs_succeeded ON processing_jobs
        (entity_id, idempotency_key) WHERE status = 'succeeded'
    """,
    """
    CREATE UNIQUE INDEX uq_processing_jobs_unfinished ON processing_jobs
        (entity_id, idempotency_key) WHERE status IN ('queued', 'running')
    """,
    "CREATE INDEX ix_processing_jobs_document ON processing_jobs (entity_id, document_id)",
    """
    CREATE TRIGGER processing_jobs_stored_document BEFORE INSERT ON processing_jobs
    WHEN NOT EXISTS (
        SELECT 1 FROM documents d
        WHERE d.id = NEW.document_id AND d.entity_id = NEW.entity_id AND d.status = 'stored')
    BEGIN SELECT RAISE(ABORT, 'only stored documents can be processed'); END
    """,
    """
    CREATE TRIGGER processing_jobs_no_delete BEFORE DELETE ON processing_jobs
    BEGIN SELECT RAISE(ABORT, 'processing_jobs cannot be deleted'); END
    """,
    f"""
    CREATE TRIGGER processing_jobs_transition BEFORE UPDATE ON processing_jobs
    WHEN NEW.id IS NOT OLD.id OR NEW.entity_id IS NOT OLD.entity_id
      OR NEW.document_id IS NOT OLD.document_id OR NEW.step IS NOT OLD.step
      OR NEW.idempotency_key IS NOT OLD.idempotency_key OR NEW.attempt IS NOT OLD.attempt
      OR NEW.engine IS NOT OLD.engine OR NEW.engine_version IS NOT OLD.engine_version
      OR NEW.settings_hash IS NOT OLD.settings_hash OR NEW.queued_at IS NOT OLD.queued_at
      OR OLD.status IN ({_FINISHED})
      OR (OLD.status = 'running' AND NEW.status NOT IN ({_FINISHED}))
      OR (OLD.status = 'running' AND NEW.started_at IS NOT OLD.started_at)
    BEGIN SELECT RAISE(ABORT, 'a job only moves forward and is final once finished'); END
    """,
]

_FINDINGS = [
    f"""
    CREATE TABLE invoice_findings (
        entity_id CHAR(32) NOT NULL,
        invoice_id CHAR(32) NOT NULL,
        revision INTEGER NOT NULL CHECK (revision >= 1),
        code VARCHAR(32) NOT NULL CHECK (length(code) BETWEEN 1 AND 32
            AND code NOT GLOB '*[^a-z0-9_]*'),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        CONSTRAINT pk_invoice_findings PRIMARY KEY (invoice_id, revision, code),
        CONSTRAINT fk_invoice_findings_invoice FOREIGN KEY (entity_id, invoice_id)
            REFERENCES invoices (entity_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_invoice_findings_revision FOREIGN KEY (invoice_id, revision)
            REFERENCES invoice_revisions (invoice_id, revision) ON DELETE RESTRICT
    )
    """,
    """
    CREATE TRIGGER invoice_findings_no_update BEFORE UPDATE ON invoice_findings
    BEGIN SELECT RAISE(ABORT, 'invoice_findings is append-only'); END
    """,
    """
    CREATE TRIGGER invoice_findings_no_delete BEFORE DELETE ON invoice_findings
    BEGIN SELECT RAISE(ABORT, 'invoice_findings is append-only'); END
    """,
]


def _rename(statement: str) -> None:
    op.execute("PRAGMA legacy_alter_table = ON")
    op.execute(statement)
    op.execute("PRAGMA legacy_alter_table = OFF")


def _count(connection) -> tuple[int, int]:
    return (
        connection.exec_driver_sql("SELECT COUNT(*) FROM documents").scalar(),
        connection.exec_driver_sql("SELECT COUNT(*) FROM processing_jobs").scalar(),
    )


def upgrade() -> None:
    connection = op.get_bind()
    if connection.exec_driver_sql("PRAGMA foreign_keys").scalar() != 0:
        msg = "migration 0004 must run with foreign keys off (ADR-0032)"
        raise RuntimeError(msg)
    before = _count(connection)

    op.execute(_DOCUMENTS)
    op.execute("INSERT INTO documents_0004 SELECT * FROM documents")
    op.execute("DROP TABLE documents")
    _rename("ALTER TABLE documents_0004 RENAME TO documents")
    for statement in _DOCUMENT_TRIGGERS:
        op.execute(statement)

    op.execute(_JOBS)
    op.execute("INSERT INTO processing_jobs_0004 SELECT * FROM processing_jobs")
    op.execute("DROP TABLE processing_jobs")
    _rename("ALTER TABLE processing_jobs_0004 RENAME TO processing_jobs")
    for statement in _JOB_TRIGGERS:
        op.execute(statement)

    for statement in _FINDINGS:
        op.execute(statement)
    if _count(connection) != before:
        msg = "rows changed while rebuilding"
        raise RuntimeError(msg)
    if connection.exec_driver_sql("PRAGMA foreign_key_check").fetchall():
        msg = "foreign key check failed after rebuilding"
        raise RuntimeError(msg)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
