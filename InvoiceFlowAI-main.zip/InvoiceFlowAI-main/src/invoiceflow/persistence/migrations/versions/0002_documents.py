"""Phase 03: generic documents, document links and document audit events.

Revision ID: 0002_documents
Revises: 0001_initial
Create Date: 2026-10-22

* ``documents`` is a generic, entity-scoped document (invoice, receipt,
  contract ...) without invoice fields (docs/DOCUMENT_ARCHIVE_SCOPE.md).
* ``document_links`` relates two documents of the same entity.
* Invoices must reference a stored document of their own entity. SQLite cannot
  add a foreign key to an existing parent table inside a transaction with
  foreign keys enabled, so a trigger enforces it on insert; document
  identity and ownership are immutable and documents cannot be deleted
  (ADR-0029).
* ``audit_events`` is rebuilt (a child table, so this is safe in the
  transaction) to allow the subject type ``document``; every stored row and
  hash is copied unchanged and the chain is verified before commit.

The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0002_documents"
down_revision = "0001_initial"
branch_labels = None
depends_on = None

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


def _actor(column: str) -> str:
    return (
        f"(length({column}) BETWEEN 1 AND 81 AND {column} NOT GLOB '*[^A-Za-z0-9._/-]*'"
        f" AND {column} GLOB '[a-z]*')"
    )


_DOCUMENT_TYPES = (
    "'unclassified', 'invoice', 'credit_note', 'receipt', 'contract',"
    " 'payment_confirmation', 'correspondence', 'other'"
)

_STATEMENTS = [
    f"""
    CREATE TABLE documents (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        document_type VARCHAR(32) NOT NULL CHECK (document_type IN ({_DOCUMENT_TYPES})),
        sha256 VARCHAR(64) NOT NULL CHECK {_hex64("sha256")},
        size_bytes INTEGER NOT NULL CHECK (size_bytes BETWEEN 1 AND 52428800),
        detected_format VARCHAR(8) CHECK (detected_format IS NULL
            OR detected_format IN ('pdf', 'png', 'jpeg', 'tiff')),
        display_name VARCHAR(255) NOT NULL CHECK (length(display_name) BETWEEN 1 AND 255),
        storage_path VARCHAR(200) NOT NULL CHECK (length(storage_path) BETWEEN 1 AND 200
            AND storage_path GLOB '[0-9a-f]*/*'
            AND storage_path NOT GLOB '*..*' AND storage_path NOT GLOB '*\\*'
            AND storage_path NOT GLOB '*//*'),
        source VARCHAR(16) NOT NULL CHECK (source IN ('file_import', 'inbox')),
        status VARCHAR(16) NOT NULL CHECK (status IN ('stored', 'quarantined')),
        imported_at VARCHAR(27) NOT NULL CHECK {_utc("imported_at")},
        imported_by VARCHAR(81) NOT NULL CHECK {_actor("imported_by")},
        integrity_checked_at VARCHAR(27) CHECK (integrity_checked_at IS NULL
            OR {_utc("integrity_checked_at")}),
        integrity_status VARCHAR(16) CHECK (integrity_status IS NULL
            OR integrity_status IN ('ok', 'mismatch', 'missing')),
        CONSTRAINT pk_documents PRIMARY KEY (id),
        CONSTRAINT uq_documents_entity_id UNIQUE (entity_id, id),
        CONSTRAINT uq_documents_entity_sha256 UNIQUE (entity_id, sha256),
        CONSTRAINT uq_documents_storage_path UNIQUE (storage_path),
        CONSTRAINT ck_documents_stored_format CHECK (
            (status = 'stored' AND detected_format IS NOT NULL)
            OR (status = 'quarantined' AND detected_format IS NULL)),
        CONSTRAINT fk_documents_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT
    )
    """,
    "CREATE INDEX ix_documents_entity_imported ON documents (entity_id, imported_at)",
    f"""
    CREATE TABLE document_links (
        entity_id CHAR(32) NOT NULL,
        from_document_id CHAR(32) NOT NULL,
        to_document_id CHAR(32) NOT NULL,
        link_type VARCHAR(16) NOT NULL CHECK (link_type IN
            ('attachment', 'supersedes', 'related')),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        created_by VARCHAR(81) NOT NULL CHECK {_actor("created_by")},
        CONSTRAINT pk_document_links PRIMARY KEY
            (entity_id, from_document_id, to_document_id, link_type),
        CONSTRAINT ck_document_links_distinct CHECK (from_document_id != to_document_id),
        CONSTRAINT fk_document_links_from FOREIGN KEY (entity_id, from_document_id)
            REFERENCES documents (entity_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_document_links_to FOREIGN KEY (entity_id, to_document_id)
            REFERENCES documents (entity_id, id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE TRIGGER documents_no_delete BEFORE DELETE ON documents
    BEGIN SELECT RAISE(ABORT, 'documents cannot be deleted'); END
    """,
    """
    CREATE TRIGGER documents_immutable BEFORE UPDATE ON documents
    WHEN NEW.id IS NOT OLD.id OR NEW.entity_id IS NOT OLD.entity_id
      OR NEW.sha256 IS NOT OLD.sha256 OR NEW.size_bytes IS NOT OLD.size_bytes
      OR NEW.detected_format IS NOT OLD.detected_format
      OR NEW.storage_path IS NOT OLD.storage_path OR NEW.source IS NOT OLD.source
      OR NEW.status IS NOT OLD.status OR NEW.imported_at IS NOT OLD.imported_at
      OR NEW.imported_by IS NOT OLD.imported_by OR NEW.display_name IS NOT OLD.display_name
    BEGIN SELECT RAISE(ABORT, 'document identity and original are immutable'); END
    """,
    """
    CREATE TRIGGER document_links_no_update BEFORE UPDATE ON document_links
    BEGIN SELECT RAISE(ABORT, 'document_links is append-only'); END
    """,
    """
    CREATE TRIGGER document_links_no_delete BEFORE DELETE ON document_links
    BEGIN SELECT RAISE(ABORT, 'document_links is append-only'); END
    """,
    # invoices.entity_id and invoices.document_id are already immutable
    # (invoices_immutable_owner), so checking on insert is sufficient.
    """
    CREATE TRIGGER invoices_reference_document BEFORE INSERT ON invoices
    WHEN NOT EXISTS (
        SELECT 1 FROM documents d
        WHERE d.id = NEW.document_id AND d.entity_id = NEW.entity_id
          AND d.status = 'stored')
    BEGIN SELECT RAISE(ABORT, 'invoice must reference a stored document of its entity'); END
    """,
    # --- audit_events: allow subject type 'document' (copy of 0001 DDL) ---
    f"""
    CREATE TABLE audit_events_0002 (
        sequence INTEGER NOT NULL CHECK (sequence >= 1),
        event_id CHAR(32) NOT NULL CHECK {_uuid("event_id")},
        occurred_at VARCHAR(27) NOT NULL CHECK {_utc("occurred_at")},
        actor VARCHAR(81) NOT NULL CHECK {_actor("actor")},
        event_type VARCHAR(32) NOT NULL CHECK (event_type GLOB '[a-z]*.[a-z]*'
            AND event_type NOT GLOB '*[^a-z._]*'),
        entity_id CHAR(32),
        subject_type VARCHAR(16) NOT NULL CHECK (subject_type IN
            ('database', 'entity', 'invoice', 'document')),
        subject_id VARCHAR(64) NOT NULL CHECK (length(subject_id) BETWEEN 1 AND 64),
        details_json TEXT NOT NULL CHECK (json_valid(details_json)
            AND json_type(details_json) = 'object' AND length(details_json) <= 4096),
        hash_version INTEGER NOT NULL CHECK (hash_version = 1),
        prev_hash VARCHAR(64) NOT NULL CHECK {_hex64("prev_hash")},
        event_hash VARCHAR(64) NOT NULL CHECK {_hex64("event_hash")},
        CONSTRAINT pk_audit_events PRIMARY KEY (sequence),
        CONSTRAINT uq_audit_events_event_id UNIQUE (event_id),
        CONSTRAINT uq_audit_events_prev_hash UNIQUE (prev_hash),
        CONSTRAINT uq_audit_events_event_hash UNIQUE (event_hash),
        CONSTRAINT fk_audit_events_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT
    )
    """,
    "INSERT INTO audit_events_0002 SELECT * FROM audit_events ORDER BY sequence",
    "DROP TABLE audit_events",
    "ALTER TABLE audit_events_0002 RENAME TO audit_events",
    """
    CREATE TRIGGER audit_events_no_update BEFORE UPDATE ON audit_events
    BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END
    """,
    """
    CREATE TRIGGER audit_events_no_delete BEFORE DELETE ON audit_events
    BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END
    """,
    """
    CREATE TRIGGER audit_events_extend_chain BEFORE INSERT ON audit_events
    WHEN NEW.sequence != COALESCE((SELECT MAX(sequence) FROM audit_events), 0) + 1
      OR NEW.prev_hash != COALESCE(
        (SELECT event_hash FROM audit_events ORDER BY sequence DESC LIMIT 1),
        '0000000000000000000000000000000000000000000000000000000000000000')
    BEGIN SELECT RAISE(ABORT, 'audit events must extend the end of the chain'); END
    """,
]


def upgrade() -> None:
    connection = op.get_bind()
    # Existing invoices would have no document to reference. Refuse instead of
    # inventing documents; the migration rolls back and the original is kept.
    if connection.exec_driver_sql("SELECT COUNT(*) FROM invoices").scalar():
        msg = "existing invoices have no documents; migration 0002 refused"
        raise RuntimeError(msg)
    before = connection.exec_driver_sql(
        "SELECT COUNT(*), COALESCE(MAX(event_hash), '') FROM audit_events"
    ).one()
    for statement in _STATEMENTS:
        op.execute(statement)
    after = connection.exec_driver_sql(
        "SELECT COUNT(*), COALESCE(MAX(event_hash), '') FROM audit_events"
    ).one()
    if tuple(after) != tuple(before):
        msg = "audit events changed while rebuilding the table"
        raise RuntimeError(msg)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
