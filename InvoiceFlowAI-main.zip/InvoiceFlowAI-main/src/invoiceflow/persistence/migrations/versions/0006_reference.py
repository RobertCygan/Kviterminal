"""Phase 08b: reference data snapshots and supplier standard posting.

Revision ID: 0006_reference
Revises: 0005_validation
Create Date: 2026-10-24

* ``reference_imports``: one row per successful import of a chart of
  accounts, VAT codes or dimensions. The latest import of each kind is the
  current one; earlier imports are kept unchanged.
* ``chart_of_accounts``, ``vat_codes`` and ``dimension_values``: the rows of
  one import, only for an import of the matching kind.
* ``supplier_defaults``: standard posting per supplier, versioned; the
  highest version applies.

Every table is append-only. Rates are exact decimal text, dates ISO text.
The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0006_reference"
down_revision = "0005_validation"
branch_labels = None
depends_on = None

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)
_DATE = f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}"


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


def _actor(column: str) -> str:
    return (
        f"(length({column}) BETWEEN 1 AND 81 AND {column} NOT GLOB '*[^A-Za-z0-9._/-]*'"
        f" AND {column} GLOB '[a-z]*')"
    )


def _code(column: str, *, nullable: bool = False) -> str:
    check = f"(length({column}) BETWEEN 1 AND 20 AND {column} NOT GLOB '*[^0-9A-Za-z._-]*')"
    return f"({column} IS NULL OR {check})" if nullable else check


def _name(column: str) -> str:
    return (
        f"(length({column}) BETWEEN 1 AND 300"
        f" AND substr({column}, 1, 1) NOT IN ('=', '+', '-', '@'))"
    )


def _append_only(table: str) -> list[str]:
    return [
        f"""
        CREATE TRIGGER {table}_no_update BEFORE UPDATE ON {table}
        BEGIN SELECT RAISE(ABORT, '{table} is append-only'); END
        """,
        f"""
        CREATE TRIGGER {table}_no_delete BEFORE DELETE ON {table}
        BEGIN SELECT RAISE(ABORT, '{table} is append-only'); END
        """,
    ]


_STATEMENTS = [
    f"""
    CREATE TABLE reference_imports (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        kind VARCHAR(16) NOT NULL CHECK (kind IN ('chart', 'vat_codes', 'dimensions')),
        sha256 VARCHAR(64) NOT NULL CHECK {_hex64("sha256")},
        row_count INTEGER NOT NULL CHECK (row_count BETWEEN 1 AND 20000),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        created_by VARCHAR(81) NOT NULL CHECK {_actor("created_by")},
        CONSTRAINT pk_reference_imports PRIMARY KEY (id),
        CONSTRAINT uq_reference_imports_entity_id UNIQUE (entity_id, id),
        CONSTRAINT fk_reference_imports_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT
    )
    """,
    "CREATE INDEX ix_reference_imports_kind ON reference_imports (entity_id, kind, created_at)",
    *_append_only("reference_imports"),
    f"""
    CREATE TABLE chart_of_accounts (
        entity_id CHAR(32) NOT NULL,
        import_id CHAR(32) NOT NULL,
        account VARCHAR(20) NOT NULL CHECK {_code("account")},
        name VARCHAR(300) NOT NULL CHECK {_name("name")},
        default_vat_code VARCHAR(20) CHECK {_code("default_vat_code", nullable=True)},
        is_active BOOLEAN NOT NULL CHECK (is_active IN (0, 1)),
        CONSTRAINT pk_chart_of_accounts PRIMARY KEY (import_id, account),
        CONSTRAINT fk_chart_of_accounts_import FOREIGN KEY (entity_id, import_id)
            REFERENCES reference_imports (entity_id, id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE TRIGGER chart_of_accounts_import_kind BEFORE INSERT ON chart_of_accounts
    WHEN NOT EXISTS (SELECT 1 FROM reference_imports r
        WHERE r.id = NEW.import_id AND r.entity_id = NEW.entity_id AND r.kind = 'chart')
    BEGIN SELECT RAISE(ABORT, 'rows must belong to an import of kind chart'); END
    """,
    *_append_only("chart_of_accounts"),
    f"""
    CREATE TABLE vat_codes (
        entity_id CHAR(32) NOT NULL,
        import_id CHAR(32) NOT NULL,
        code VARCHAR(20) NOT NULL CHECK {_code("code")},
        valid_from DATE NOT NULL CHECK (valid_from GLOB '{_DATE}'),
        valid_to DATE CHECK (valid_to IS NULL OR (valid_to GLOB '{_DATE}'
            AND valid_to >= valid_from)),
        rate VARCHAR(40) NOT NULL CHECK (typeof(rate) = 'text' AND length(rate) BETWEEN 1 AND 6
            AND rate NOT GLOB '*[^0-9.]*' AND rate NOT GLOB '*.*.*'
            AND CAST(rate AS REAL) BETWEEN 0 AND 100),
        direction VARCHAR(8) NOT NULL CHECK (direction IN ('input', 'output')),
        saft_code VARCHAR(20) CHECK {_code("saft_code", nullable=True)},
        name VARCHAR(300) CHECK (name IS NULL OR {_name("name")}),
        CONSTRAINT pk_vat_codes PRIMARY KEY (import_id, code, valid_from),
        CONSTRAINT fk_vat_codes_import FOREIGN KEY (entity_id, import_id)
            REFERENCES reference_imports (entity_id, id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE TRIGGER vat_codes_import_kind BEFORE INSERT ON vat_codes
    WHEN NOT EXISTS (SELECT 1 FROM reference_imports r
        WHERE r.id = NEW.import_id AND r.entity_id = NEW.entity_id AND r.kind = 'vat_codes')
    BEGIN SELECT RAISE(ABORT, 'rows must belong to an import of kind vat_codes'); END
    """,
    *_append_only("vat_codes"),
    f"""
    CREATE TABLE dimension_values (
        entity_id CHAR(32) NOT NULL,
        import_id CHAR(32) NOT NULL,
        dimension VARCHAR(16) NOT NULL CHECK (dimension IN
            ('cost_center', 'department', 'project')),
        code VARCHAR(20) NOT NULL CHECK {_code("code")},
        name VARCHAR(300) NOT NULL CHECK {_name("name")},
        is_active BOOLEAN NOT NULL CHECK (is_active IN (0, 1)),
        CONSTRAINT pk_dimension_values PRIMARY KEY (import_id, dimension, code),
        CONSTRAINT fk_dimension_values_import FOREIGN KEY (entity_id, import_id)
            REFERENCES reference_imports (entity_id, id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE TRIGGER dimension_values_import_kind BEFORE INSERT ON dimension_values
    WHEN NOT EXISTS (SELECT 1 FROM reference_imports r
        WHERE r.id = NEW.import_id AND r.entity_id = NEW.entity_id AND r.kind = 'dimensions')
    BEGIN SELECT RAISE(ABORT, 'rows must belong to an import of kind dimensions'); END
    """,
    *_append_only("dimension_values"),
    f"""
    CREATE TABLE supplier_defaults (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        supplier_id CHAR(32) NOT NULL,
        version INTEGER NOT NULL CHECK (version >= 1),
        account VARCHAR(20) CHECK {_code("account", nullable=True)},
        vat_code VARCHAR(20) CHECK {_code("vat_code", nullable=True)},
        cost_center VARCHAR(20) CHECK {_code("cost_center", nullable=True)},
        department VARCHAR(20) CHECK {_code("department", nullable=True)},
        project VARCHAR(20) CHECK {_code("project", nullable=True)},
        set_at VARCHAR(27) NOT NULL CHECK {_utc("set_at")},
        set_by VARCHAR(81) NOT NULL CHECK {_actor("set_by")},
        CONSTRAINT pk_supplier_defaults PRIMARY KEY (id),
        CONSTRAINT uq_supplier_defaults_version UNIQUE (supplier_id, version),
        CONSTRAINT fk_supplier_defaults_supplier FOREIGN KEY (entity_id, supplier_id)
            REFERENCES suppliers (entity_id, id) ON DELETE RESTRICT
    )
    """,
    *_append_only("supplier_defaults"),
]


def upgrade() -> None:
    for statement in _STATEMENTS:
        op.execute(statement)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
