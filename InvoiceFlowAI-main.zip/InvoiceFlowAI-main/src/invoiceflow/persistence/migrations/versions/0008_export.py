"""Phase 10: export batches, export items and column mappings.

Revision ID: 0008_export
Revises: 0007_review
Create Date: 2026-10-24

* ``export_mappings``: append-only, versioned column choice of one entity.
* ``export_batches``: one file per batch (``created`` -> ``written`` or
  ``failed``), with the columns it used and the audit chain head (anchor).
* ``export_items``: one invoice in one batch, bound to its approval, revision
  and content hash. A partial unique index allows at most one active
  (``pending`` or ``exported``) item per invoice and target.
* Triggers on ``invoices`` and ``approvals``: an invoice is ``exported`` only
  with an exported item of its current content; while an item is pending, and
  after export, its content, status and approval decisions cannot change.

The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0008_export"
down_revision = "0007_review"
branch_labels = None
depends_on = None

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


def _actor(column: str) -> str:
    return (
        f"(length({column}) BETWEEN 1 AND 81 AND {column} NOT GLOB '*[^A-Za-z0-9._/-]*'"
        f" AND {column} GLOB '[a-z]*')"
    )


_STATEMENTS = [
    f"""
    CREATE TABLE export_mappings (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        version INTEGER NOT NULL CHECK (version >= 1),
        columns_json TEXT NOT NULL CHECK (json_valid(columns_json)
            AND json_type(columns_json) = 'array' AND length(columns_json) <= 8192),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        created_by VARCHAR(81) NOT NULL CHECK {_actor("created_by")},
        CONSTRAINT pk_export_mappings PRIMARY KEY (id),
        CONSTRAINT uq_export_mappings_version UNIQUE (entity_id, version),
        CONSTRAINT fk_export_mappings_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE TRIGGER export_mappings_next_version BEFORE INSERT ON export_mappings
    WHEN NEW.version != COALESCE(
        (SELECT MAX(version) FROM export_mappings WHERE entity_id = NEW.entity_id), 0) + 1
    BEGIN SELECT RAISE(ABORT, 'mapping versions must be consecutive'); END
    """,
    """
    CREATE TRIGGER export_mappings_no_update BEFORE UPDATE ON export_mappings
    BEGIN SELECT RAISE(ABORT, 'export_mappings is append-only'); END
    """,
    """
    CREATE TRIGGER export_mappings_no_delete BEFORE DELETE ON export_mappings
    BEGIN SELECT RAISE(ABORT, 'export_mappings is append-only'); END
    """,
    f"""
    CREATE TABLE export_batches (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        sequence INTEGER NOT NULL CHECK (sequence >= 1),
        target VARCHAR(8) NOT NULL CHECK (target IN ('excel', 'csv')),
        mapping_version INTEGER NOT NULL CHECK (mapping_version >= 0),
        columns_json TEXT NOT NULL CHECK (json_valid(columns_json)
            AND json_type(columns_json) = 'array' AND length(columns_json) <= 8192),
        status VARCHAR(8) NOT NULL CHECK (status IN ('created', 'written', 'failed')),
        file_name VARCHAR(64) NOT NULL CHECK (length(file_name) BETWEEN 20 AND 64
            AND file_name GLOB 'fakturaeksport-*' AND file_name NOT GLOB '*[^a-z0-9.-]*'),
        file_sha256 VARCHAR(64) CHECK (file_sha256 IS NULL OR {_hex64("file_sha256")}),
        item_count INTEGER NOT NULL CHECK (item_count >= 1),
        is_reexport INTEGER NOT NULL CHECK (is_reexport IN (0, 1)),
        reexport_reason VARCHAR(500),
        audit_anchor VARCHAR(64) NOT NULL CHECK {_hex64("audit_anchor")},
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        created_by VARCHAR(81) NOT NULL CHECK {_actor("created_by")},
        completed_at VARCHAR(27) CHECK (completed_at IS NULL OR {_utc("completed_at")}),
        CONSTRAINT pk_export_batches PRIMARY KEY (id),
        CONSTRAINT uq_export_batches_entity_id UNIQUE (entity_id, id),
        CONSTRAINT uq_export_batches_sequence UNIQUE (entity_id, sequence),
        CONSTRAINT uq_export_batches_file_name UNIQUE (entity_id, file_name),
        CONSTRAINT ck_export_batches_reason CHECK (
            (is_reexport = 0 AND reexport_reason IS NULL)
            OR (is_reexport = 1 AND length(reexport_reason) BETWEEN 10 AND 500)),
        CONSTRAINT ck_export_batches_written CHECK (
            (status = 'created' AND file_sha256 IS NULL AND completed_at IS NULL)
            OR (status = 'written' AND file_sha256 IS NOT NULL AND completed_at IS NOT NULL)
            OR (status = 'failed' AND file_sha256 IS NULL AND completed_at IS NOT NULL)),
        CONSTRAINT fk_export_batches_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE TRIGGER export_batches_next_in_sequence BEFORE INSERT ON export_batches
    WHEN NEW.sequence != COALESCE(
        (SELECT MAX(sequence) FROM export_batches WHERE entity_id = NEW.entity_id), 0) + 1
    BEGIN SELECT RAISE(ABORT, 'export batches must be consecutive'); END
    """,
    """
    CREATE TRIGGER export_batches_start_created BEFORE INSERT ON export_batches
    WHEN NEW.status != 'created'
    BEGIN SELECT RAISE(ABORT, 'an export batch starts as created'); END
    """,
    """
    CREATE TRIGGER export_batches_finish_once BEFORE UPDATE ON export_batches
    WHEN OLD.status != 'created' OR NEW.status = 'created'
      OR NEW.id IS NOT OLD.id OR NEW.entity_id IS NOT OLD.entity_id
      OR NEW.sequence IS NOT OLD.sequence OR NEW.target IS NOT OLD.target
      OR NEW.mapping_version IS NOT OLD.mapping_version
      OR NEW.columns_json IS NOT OLD.columns_json OR NEW.file_name IS NOT OLD.file_name
      OR NEW.item_count IS NOT OLD.item_count OR NEW.is_reexport IS NOT OLD.is_reexport
      OR NEW.reexport_reason IS NOT OLD.reexport_reason
      OR NEW.audit_anchor IS NOT OLD.audit_anchor OR NEW.created_at IS NOT OLD.created_at
      OR NEW.created_by IS NOT OLD.created_by
    BEGIN SELECT RAISE(ABORT, 'an export batch is finished exactly once'); END
    """,
    """
    CREATE TRIGGER export_batches_written_items BEFORE UPDATE OF status ON export_batches
    WHEN NEW.status = 'written' AND EXISTS (
        SELECT 1 FROM export_items i WHERE i.batch_id = NEW.id AND i.status = 'pending')
    BEGIN SELECT RAISE(ABORT, 'a written batch has no pending items'); END
    """,
    """
    CREATE TRIGGER export_batches_no_delete BEFORE DELETE ON export_batches
    BEGIN SELECT RAISE(ABORT, 'export_batches cannot be deleted'); END
    """,
    f"""
    CREATE TABLE export_items (
        id INTEGER NOT NULL,
        entity_id CHAR(32) NOT NULL,
        batch_id CHAR(32) NOT NULL,
        invoice_id CHAR(32) NOT NULL,
        approval_id CHAR(32) NOT NULL,
        revision INTEGER NOT NULL CHECK (revision >= 1),
        content_sha256 VARCHAR(64) NOT NULL CHECK {_hex64("content_sha256")},
        target VARCHAR(8) NOT NULL CHECK (target IN ('excel', 'csv')),
        status VARCHAR(10) NOT NULL CHECK (status IN
            ('pending', 'exported', 'failed', 'superseded')),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        updated_at VARCHAR(27) NOT NULL CHECK {_utc("updated_at")},
        CONSTRAINT pk_export_items PRIMARY KEY (id),
        CONSTRAINT uq_export_items_batch_invoice UNIQUE (batch_id, invoice_id),
        CONSTRAINT fk_export_items_batch FOREIGN KEY (entity_id, batch_id)
            REFERENCES export_batches (entity_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_export_items_invoice FOREIGN KEY (entity_id, invoice_id)
            REFERENCES invoices (entity_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_export_items_approval FOREIGN KEY (approval_id)
            REFERENCES approvals (id) ON DELETE RESTRICT,
        CONSTRAINT fk_export_items_revision FOREIGN KEY (invoice_id, revision)
            REFERENCES invoice_revisions (invoice_id, revision) ON DELETE RESTRICT
    )
    """,
    # The database itself prevents a second active export of the same invoice.
    """
    CREATE UNIQUE INDEX uq_export_items_active ON export_items (entity_id, invoice_id, target)
    WHERE status IN ('pending', 'exported')
    """,
    "CREATE INDEX ix_export_items_invoice ON export_items (invoice_id, id)",
    """
    CREATE TRIGGER export_items_start_pending BEFORE INSERT ON export_items
    WHEN NEW.status != 'pending' OR NOT EXISTS (
        SELECT 1 FROM export_batches b
        WHERE b.id = NEW.batch_id AND b.entity_id = NEW.entity_id
          AND b.status = 'created' AND b.target = NEW.target)
    BEGIN SELECT RAISE(ABORT, 'an export item starts pending in an open batch'); END
    """,
    """
    CREATE TRIGGER export_items_approved_content BEFORE INSERT ON export_items
    WHEN NOT EXISTS (
        SELECT 1 FROM invoices i
        JOIN approvals a ON a.invoice_id = i.id AND a.entity_id = i.entity_id
        JOIN export_batches b ON b.id = NEW.batch_id
        WHERE i.id = NEW.invoice_id AND i.entity_id = NEW.entity_id
          AND i.current_revision = NEW.revision AND i.content_sha256 = NEW.content_sha256
          AND a.id = NEW.approval_id AND a.decision = 'approved'
          AND a.revision = NEW.revision AND a.content_sha256 = NEW.content_sha256
          AND a.sequence = (SELECT MAX(c.sequence) FROM approvals c
                            WHERE c.invoice_id = NEW.invoice_id)
          AND ((i.workflow_status = 'approved' AND b.is_reexport = 0)
               OR (i.workflow_status = 'exported' AND b.is_reexport = 1)))
    BEGIN SELECT RAISE(ABORT, 'only the approved current content can be exported'); END
    """,
    """
    CREATE TRIGGER export_items_status_flow BEFORE UPDATE ON export_items
    WHEN NOT ((OLD.status = 'pending' AND NEW.status IN ('exported', 'failed'))
              OR (OLD.status IN ('exported', 'failed') AND NEW.status = 'superseded'))
      OR NEW.id IS NOT OLD.id OR NEW.entity_id IS NOT OLD.entity_id
      OR NEW.batch_id IS NOT OLD.batch_id OR NEW.invoice_id IS NOT OLD.invoice_id
      OR NEW.approval_id IS NOT OLD.approval_id OR NEW.revision IS NOT OLD.revision
      OR NEW.content_sha256 IS NOT OLD.content_sha256 OR NEW.target IS NOT OLD.target
      OR NEW.created_at IS NOT OLD.created_at
    BEGIN SELECT RAISE(ABORT, 'invalid export item change'); END
    """,
    """
    CREATE TRIGGER export_items_no_delete BEFORE DELETE ON export_items
    BEGIN SELECT RAISE(ABORT, 'export_items cannot be deleted'); END
    """,
    """
    CREATE TRIGGER invoices_exported_needs_export BEFORE UPDATE OF workflow_status ON invoices
    WHEN NEW.workflow_status = 'exported' AND NOT EXISTS (
        SELECT 1 FROM export_items e
        WHERE e.invoice_id = NEW.id AND e.entity_id = NEW.entity_id
          AND e.status = 'exported' AND e.revision = NEW.current_revision
          AND e.content_sha256 = NEW.content_sha256)
    BEGIN SELECT RAISE(ABORT, 'exported requires an export of the current content'); END
    """,
    """
    CREATE TRIGGER invoices_exported_frozen BEFORE UPDATE ON invoices
    WHEN OLD.workflow_status = 'exported'
      AND (NEW.workflow_status IS NOT OLD.workflow_status
           OR NEW.content_sha256 IS NOT OLD.content_sha256
           OR NEW.current_revision IS NOT OLD.current_revision)
    BEGIN SELECT RAISE(ABORT, 'an exported invoice cannot change'); END
    """,
    """
    CREATE TRIGGER invoices_pending_export_frozen BEFORE UPDATE ON invoices
    WHEN (NEW.content_sha256 IS NOT OLD.content_sha256
          OR NEW.current_revision IS NOT OLD.current_revision
          OR NEW.workflow_status NOT IN (OLD.workflow_status, 'exported'))
      AND EXISTS (SELECT 1 FROM export_items e
                  WHERE e.invoice_id = OLD.id AND e.status = 'pending')
    BEGIN SELECT RAISE(ABORT, 'an invoice being exported cannot change'); END
    """,
    """
    CREATE TRIGGER approvals_closed_by_export BEFORE INSERT ON approvals
    WHEN EXISTS (SELECT 1 FROM invoices i
                 WHERE i.id = NEW.invoice_id AND i.workflow_status = 'exported')
      OR EXISTS (SELECT 1 FROM export_items e
                 WHERE e.invoice_id = NEW.invoice_id AND e.status = 'pending')
    BEGIN SELECT RAISE(ABORT, 'an exported invoice takes no new decisions'); END
    """,
]


def upgrade() -> None:
    for statement in _STATEMENTS:
        op.execute(statement)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
