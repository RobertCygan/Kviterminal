"""Phase 08a: supplier register, payment account status and validation runs.

Revision ID: 0005_validation
Revises: 0004_ehf
Create Date: 2026-10-24

* ``suppliers``: one row per supplier and accounting entity, identified by the
  organisation number or, for foreign suppliers, the VAT identifier. Rows are
  immutable.
* ``supplier_bank_accounts``: payment accounts seen on invoices. The account
  and its supplier never change; only the status moves away from
  ``unverified`` (to ``verified`` or ``blocked``), and only with a time and a
  user. Rows cannot be deleted.
* ``validation_runs`` and ``validation_results``: one append-only run per
  validation of an invoice revision, numbered per invoice, with its findings.
* ``audit_events`` is rebuilt (a child table, safe with foreign keys on) to
  allow the subject type ``supplier``. Every row and hash is copied unchanged.

The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0005_validation"
down_revision = "0004_ehf"
branch_labels = None
depends_on = None

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


def _actor(column: str) -> str:
    return (
        f"(length({column}) BETWEEN 1 AND 81 AND {column} NOT GLOB '*[^A-Za-z0-9._/-]*'"
        f" AND {column} GLOB '[a-z]*')"
    )


def _append_only(table: str) -> list[str]:
    return [
        f"""
        CREATE TRIGGER {table}_no_update BEFORE UPDATE ON {table}
        BEGIN SELECT RAISE(ABORT, '{table} is append-only'); END
        """,
        f"""
        CREATE TRIGGER {table}_no_delete BEFORE DELETE ON {table}
        BEGIN SELECT RAISE(ABORT, '{table} is append-only'); END
        """,
    ]


_SUPPLIERS = [
    f"""
    CREATE TABLE suppliers (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        name VARCHAR(300) NOT NULL CHECK (length(name) BETWEEN 1 AND 300),
        org_number VARCHAR(9) CHECK (org_number IS NULL
            OR (length(org_number) = 9 AND org_number NOT GLOB '*[^0-9]*')),
        foreign_vat_id VARCHAR(20) CHECK (foreign_vat_id IS NULL
            OR (length(foreign_vat_id) BETWEEN 4 AND 20
                AND foreign_vat_id NOT GLOB '*[^A-Z0-9]*')),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        created_by VARCHAR(81) NOT NULL CHECK {_actor("created_by")},
        CONSTRAINT pk_suppliers PRIMARY KEY (id),
        CONSTRAINT uq_suppliers_entity_id UNIQUE (entity_id, id),
        CONSTRAINT ck_suppliers_identified CHECK (
            org_number IS NOT NULL OR foreign_vat_id IS NOT NULL),
        CONSTRAINT fk_suppliers_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE UNIQUE INDEX uq_suppliers_entity_org ON suppliers (entity_id, org_number)
    WHERE org_number IS NOT NULL
    """,
    """
    CREATE UNIQUE INDEX uq_suppliers_entity_vat ON suppliers (entity_id, foreign_vat_id)
    WHERE foreign_vat_id IS NOT NULL
    """,
    *_append_only("suppliers"),
]

_ACCOUNTS = [
    f"""
    CREATE TABLE supplier_bank_accounts (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        supplier_id CHAR(32) NOT NULL,
        account_kind VARCHAR(8) NOT NULL CHECK (account_kind IN ('bban', 'iban')),
        account VARCHAR(34) NOT NULL CHECK (
            (account_kind = 'bban' AND length(account) = 11 AND account NOT GLOB '*[^0-9]*')
            OR (account_kind = 'iban' AND length(account) BETWEEN 15 AND 34
                AND account NOT GLOB '*[^A-Z0-9]*')),
        status VARCHAR(16) NOT NULL CHECK (status IN ('unverified', 'verified', 'blocked')),
        first_seen_invoice_id CHAR(32),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        status_changed_at VARCHAR(27) CHECK (status_changed_at IS NULL
            OR {_utc("status_changed_at")}),
        status_changed_by VARCHAR(81) CHECK (status_changed_by IS NULL
            OR {_actor("status_changed_by")}),
        CONSTRAINT pk_supplier_bank_accounts PRIMARY KEY (id),
        CONSTRAINT uq_supplier_bank_accounts_entity_id UNIQUE (entity_id, id),
        CONSTRAINT uq_supplier_bank_accounts_account UNIQUE (supplier_id, account),
        CONSTRAINT ck_supplier_bank_accounts_change CHECK (
            (status = 'unverified' AND status_changed_at IS NULL AND status_changed_by IS NULL)
            OR (status <> 'unverified' AND status_changed_at IS NOT NULL
                AND status_changed_by IS NOT NULL)),
        CONSTRAINT fk_supplier_bank_accounts_supplier FOREIGN KEY (entity_id, supplier_id)
            REFERENCES suppliers (entity_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_supplier_bank_accounts_invoice FOREIGN KEY (entity_id, first_seen_invoice_id)
            REFERENCES invoices (entity_id, id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE TRIGGER supplier_bank_accounts_new_unverified BEFORE INSERT ON supplier_bank_accounts
    WHEN NEW.status <> 'unverified'
    BEGIN SELECT RAISE(ABORT, 'a new payment account is unverified'); END
    """,
    """
    CREATE TRIGGER supplier_bank_accounts_status_only BEFORE UPDATE ON supplier_bank_accounts
    WHEN NEW.id IS NOT OLD.id OR NEW.entity_id IS NOT OLD.entity_id
      OR NEW.supplier_id IS NOT OLD.supplier_id OR NEW.account_kind IS NOT OLD.account_kind
      OR NEW.account IS NOT OLD.account
      OR NEW.first_seen_invoice_id IS NOT OLD.first_seen_invoice_id
      OR NEW.created_at IS NOT OLD.created_at
      OR NEW.status = OLD.status OR NEW.status = 'unverified'
    BEGIN SELECT RAISE(ABORT, 'only the status of a payment account can change'); END
    """,
    """
    CREATE TRIGGER supplier_bank_accounts_no_delete BEFORE DELETE ON supplier_bank_accounts
    BEGIN SELECT RAISE(ABORT, 'supplier_bank_accounts cannot be deleted'); END
    """,
]

_RUNS = [
    f"""
    CREATE TABLE validation_runs (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        invoice_id CHAR(32) NOT NULL,
        revision INTEGER NOT NULL CHECK (revision >= 1),
        run_number INTEGER NOT NULL CHECK (run_number >= 1),
        ruleset_version VARCHAR(8) NOT NULL CHECK (ruleset_version GLOB '[0-9]*.[0-9]*'
            AND ruleset_version NOT GLOB '*[^0-9.]*'),
        settings_sha256 VARCHAR(64) NOT NULL CHECK {_hex64("settings_sha256")},
        error_count INTEGER NOT NULL CHECK (error_count BETWEEN 0 AND 200),
        warning_count INTEGER NOT NULL CHECK (warning_count BETWEEN 0 AND 200),
        info_count INTEGER NOT NULL CHECK (info_count BETWEEN 0 AND 200),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        created_by VARCHAR(81) NOT NULL CHECK {_actor("created_by")},
        CONSTRAINT pk_validation_runs PRIMARY KEY (id),
        CONSTRAINT uq_validation_runs_entity_id UNIQUE (entity_id, id),
        CONSTRAINT uq_validation_runs_number UNIQUE (invoice_id, run_number),
        CONSTRAINT fk_validation_runs_invoice FOREIGN KEY (entity_id, invoice_id)
            REFERENCES invoices (entity_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_validation_runs_revision FOREIGN KEY (invoice_id, revision)
            REFERENCES invoice_revisions (invoice_id, revision) ON DELETE RESTRICT
    )
    """,
    *_append_only("validation_runs"),
    """
    CREATE TABLE validation_results (
        entity_id CHAR(32) NOT NULL,
        run_id CHAR(32) NOT NULL,
        position INTEGER NOT NULL CHECK (position BETWEEN 1 AND 200),
        rule_id VARCHAR(16) NOT NULL CHECK (rule_id GLOB '[A-Z]*-[0-9][0-9][0-9]'
            AND rule_id NOT GLOB '*[^A-Z0-9-]*'),
        rule_version INTEGER NOT NULL CHECK (rule_version BETWEEN 1 AND 1000),
        severity VARCHAR(8) NOT NULL CHECK (severity IN ('info', 'warning', 'error')),
        field_path VARCHAR(128) CHECK (field_path IS NULL
            OR (length(field_path) BETWEEN 1 AND 128
                AND field_path NOT GLOB '*[^a-z0-9_.]*')),
        message_key VARCHAR(80) NOT NULL CHECK (message_key GLOB 'validation.*'
            AND message_key NOT GLOB '*[^a-z0-9_.]*'),
        params_json TEXT NOT NULL CHECK (json_valid(params_json)
            AND json_type(params_json) = 'object' AND length(params_json) <= 1024),
        CONSTRAINT pk_validation_results PRIMARY KEY (run_id, position),
        CONSTRAINT fk_validation_results_run FOREIGN KEY (entity_id, run_id)
            REFERENCES validation_runs (entity_id, id) ON DELETE RESTRICT
    )
    """,
    *_append_only("validation_results"),
]

_AUDIT = [
    f"""
    CREATE TABLE audit_events_0005 (
        sequence INTEGER NOT NULL CHECK (sequence >= 1),
        event_id CHAR(32) NOT NULL CHECK {_uuid("event_id")},
        occurred_at VARCHAR(27) NOT NULL CHECK {_utc("occurred_at")},
        actor VARCHAR(81) NOT NULL CHECK {_actor("actor")},
        event_type VARCHAR(32) NOT NULL CHECK (event_type GLOB '[a-z]*.[a-z]*'
            AND event_type NOT GLOB '*[^a-z._]*'),
        entity_id CHAR(32),
        subject_type VARCHAR(16) NOT NULL CHECK (subject_type IN
            ('database', 'entity', 'invoice', 'document', 'supplier')),
        subject_id VARCHAR(64) NOT NULL CHECK (length(subject_id) BETWEEN 1 AND 64),
        details_json TEXT NOT NULL CHECK (json_valid(details_json)
            AND json_type(details_json) = 'object' AND length(details_json) <= 4096),
        hash_version INTEGER NOT NULL CHECK (hash_version = 1),
        prev_hash VARCHAR(64) NOT NULL CHECK {_hex64("prev_hash")},
        event_hash VARCHAR(64) NOT NULL CHECK {_hex64("event_hash")},
        CONSTRAINT pk_audit_events PRIMARY KEY (sequence),
        CONSTRAINT uq_audit_events_event_id UNIQUE (event_id),
        CONSTRAINT uq_audit_events_prev_hash UNIQUE (prev_hash),
        CONSTRAINT uq_audit_events_event_hash UNIQUE (event_hash),
        CONSTRAINT fk_audit_events_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT
    )
    """,
    "INSERT INTO audit_events_0005 SELECT * FROM audit_events ORDER BY sequence",
    "DROP TABLE audit_events",
]

_AUDIT_TRIGGERS = [
    """
    CREATE TRIGGER audit_events_no_update BEFORE UPDATE ON audit_events
    BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END
    """,
    """
    CREATE TRIGGER audit_events_no_delete BEFORE DELETE ON audit_events
    BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END
    """,
    """
    CREATE TRIGGER audit_events_extend_chain BEFORE INSERT ON audit_events
    WHEN NEW.sequence != COALESCE((SELECT MAX(sequence) FROM audit_events), 0) + 1
      OR NEW.prev_hash != COALESCE(
        (SELECT event_hash FROM audit_events ORDER BY sequence DESC LIMIT 1),
        '0000000000000000000000000000000000000000000000000000000000000000')
    BEGIN SELECT RAISE(ABORT, 'audit events must extend the end of the chain'); END
    """,
]


def _audit_state(connection) -> tuple[int, str]:
    row = connection.exec_driver_sql(
        "SELECT COUNT(*), COALESCE(MAX(event_hash), '') FROM audit_events"
    ).one()
    return int(row[0]), str(row[1])


def upgrade() -> None:
    connection = op.get_bind()
    before = _audit_state(connection)
    for statement in (*_SUPPLIERS, *_ACCOUNTS, *_RUNS, *_AUDIT):
        op.execute(statement)
    op.execute("PRAGMA legacy_alter_table = ON")
    op.execute("ALTER TABLE audit_events_0005 RENAME TO audit_events")
    op.execute("PRAGMA legacy_alter_table = OFF")
    for statement in _AUDIT_TRIGGERS:
        op.execute(statement)
    if _audit_state(connection) != before:
        msg = "audit events changed while rebuilding the table"
        raise RuntimeError(msg)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
