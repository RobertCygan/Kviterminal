"""Phase 11a: how dark each analysed page is.

Revision ID: 0010_page_metrics
Revises: 0009_backup
Create Date: 2026-10-24

``document_pages`` gets the share of dark pixels (per mille) in the whole page
and in its central area, measured by the worker. Blank pages and separator
sheets of a scanned batch are recognised from them. Pages analysed before this
migration keep NULL; the page analysis engine version changed, so their
documents are analysed again on the next run.

The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0010_page_metrics"
down_revision = "0009_backup"
branch_labels = None
depends_on = None

_STATEMENTS = [
    """
    ALTER TABLE document_pages ADD COLUMN dark_permille INTEGER
        CHECK (dark_permille IS NULL OR dark_permille BETWEEN 0 AND 1000)
    """,
    """
    ALTER TABLE document_pages ADD COLUMN center_dark_permille INTEGER
        CHECK (center_dark_permille IS NULL OR center_dark_permille BETWEEN 0 AND 1000)
    """,
]


def upgrade() -> None:
    for statement in _STATEMENTS:
        op.execute(statement)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
