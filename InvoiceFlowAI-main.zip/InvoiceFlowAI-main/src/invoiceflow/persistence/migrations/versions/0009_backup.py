"""Phase 12: register of encrypted backups.

Revision ID: 0009_backup
Revises: 0008_export
Create Date: 2026-10-24

* ``backups``: one row per backup file this database made, with the file's
  SHA-256, size, file count and the audit anchor it contains. Rows are never
  deleted; deleting a backup file only records when and by whom, once.

Backups cover the whole data directory, so the table has no accounting entity.
The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0009_backup"
down_revision = "0008_export"
branch_labels = None
depends_on = None

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


def _actor(column: str) -> str:
    return (
        f"(length({column}) BETWEEN 1 AND 81 AND {column} NOT GLOB '*[^A-Za-z0-9._/-]*'"
        f" AND {column} GLOB '[a-z]*')"
    )


_STATEMENTS = [
    f"""
    CREATE TABLE backups (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        file_name VARCHAR(64) NOT NULL CHECK (file_name GLOB
            'invoiceflow-sikkerhetskopi-{_DIGIT * 8}-{_DIGIT * 6}.ifbak'),
        file_sha256 VARCHAR(64) NOT NULL CHECK {_hex64("file_sha256")},
        byte_count INTEGER NOT NULL CHECK (byte_count > 0),
        file_count INTEGER NOT NULL CHECK (file_count >= 1),
        schema_revision VARCHAR(32) NOT NULL CHECK (length(schema_revision) BETWEEN 1 AND 32
            AND schema_revision NOT GLOB '*[^a-z0-9_]*'),
        audit_sequence INTEGER NOT NULL CHECK (audit_sequence >= 1),
        audit_anchor VARCHAR(64) NOT NULL CHECK {_hex64("audit_anchor")},
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        created_by VARCHAR(81) NOT NULL CHECK {_actor("created_by")},
        deleted_at VARCHAR(27) CHECK (deleted_at IS NULL OR {_utc("deleted_at")}),
        deleted_by VARCHAR(81) CHECK (deleted_by IS NULL OR {_actor("deleted_by")}),
        CONSTRAINT pk_backups PRIMARY KEY (id),
        CONSTRAINT uq_backups_file_sha256 UNIQUE (file_sha256),
        CONSTRAINT ck_backups_deleted CHECK ((deleted_at IS NULL) = (deleted_by IS NULL))
    )
    """,
    """
    CREATE TRIGGER backups_delete_once BEFORE UPDATE ON backups
    WHEN OLD.deleted_at IS NOT NULL OR NEW.deleted_at IS NULL
      OR NEW.id IS NOT OLD.id OR NEW.file_name IS NOT OLD.file_name
      OR NEW.file_sha256 IS NOT OLD.file_sha256 OR NEW.byte_count IS NOT OLD.byte_count
      OR NEW.file_count IS NOT OLD.file_count OR NEW.schema_revision IS NOT OLD.schema_revision
      OR NEW.audit_sequence IS NOT OLD.audit_sequence OR NEW.audit_anchor IS NOT OLD.audit_anchor
      OR NEW.created_at IS NOT OLD.created_at OR NEW.created_by IS NOT OLD.created_by
    BEGIN SELECT RAISE(ABORT, 'a backup row only records its deletion, once'); END
    """,
    """
    CREATE TRIGGER backups_no_delete BEFORE DELETE ON backups
    BEGIN SELECT RAISE(ABORT, 'backups cannot be deleted'); END
    """,
]


def upgrade() -> None:
    for statement in _STATEMENTS:
        op.execute(statement)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
