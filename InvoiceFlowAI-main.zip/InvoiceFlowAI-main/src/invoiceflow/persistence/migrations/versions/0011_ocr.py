"""Phase 05: the OCR step and the recognised pages.

Revision ID: 0011_ocr
Revises: 0010_page_metrics
Create Date: 2026-10-24

* ``processing_jobs`` accepts the step ``ocr`` and the error code
  ``ocr_failed``; a successful OCR job has the number of recognised pages.
* ``ocr_pages`` holds one row per recognised page: counts and mean confidence
  in the database, the words with boxes in a derived file named by path and
  hash. Each row names the page analysis whose page image was read.

SQLite cannot change a CHECK constraint in place, so ``processing_jobs`` is
rebuilt with SQLite's twelve-step procedure (ADR-0032), as in migration 0004.

The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0011_ocr"
down_revision = "0010_page_metrics"
branch_labels = None
depends_on = None

# Read by the migrator: this migration rebuilds a parent table (ADR-0032).
FOREIGN_KEYS_OFF = True

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


_FINISHED = "'succeeded', 'failed', 'timed_out', 'cancelled'"
_ERROR_CODES = (
    "'encrypted', 'corrupt', 'no_pages', 'too_many_pages', 'page_too_large', 'too_much_text',"
    " 'output_too_large', 'unsupported_format', 'timed_out', 'memory_limit', 'worker_crashed',"
    " 'invalid_result', 'source_changed', 'source_missing', 'storage_failed', 'interrupted',"
    " 'cancelled', 'invalid_xml', 'unsupported_version', 'too_many_lines',"
    " 'too_many_attachments', 'attachment_too_large', 'ocr_failed'"
)

_JOBS = f"""
    CREATE TABLE processing_jobs_0011 (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        document_id CHAR(32) NOT NULL,
        step VARCHAR(32) NOT NULL CHECK (step IN ('page_analysis', 'ehf_extraction', 'ocr')),
        idempotency_key VARCHAR(64) NOT NULL CHECK {_hex64("idempotency_key")},
        attempt INTEGER NOT NULL CHECK (attempt BETWEEN 1 AND 1000),
        status VARCHAR(16) NOT NULL CHECK (status IN ('queued', 'running', {_FINISHED})),
        engine VARCHAR(16) NOT NULL CHECK (length(engine) BETWEEN 1 AND 16
            AND engine NOT GLOB '*[^a-z0-9]*'),
        engine_version VARCHAR(32) NOT NULL CHECK (length(engine_version) BETWEEN 1 AND 32
            AND engine_version NOT GLOB '*[^0-9A-Za-z.+-]*'),
        settings_hash VARCHAR(64) NOT NULL CHECK {_hex64("settings_hash")},
        queued_at VARCHAR(27) NOT NULL CHECK {_utc("queued_at")},
        started_at VARCHAR(27) CHECK (started_at IS NULL OR {_utc("started_at")}),
        finished_at VARCHAR(27) CHECK (finished_at IS NULL OR {_utc("finished_at")}),
        error_code VARCHAR(32) CHECK (error_code IS NULL OR error_code IN ({_ERROR_CODES})),
        page_count INTEGER CHECK (page_count IS NULL OR page_count BETWEEN 1 AND 1000),
        active_content BOOLEAN CHECK (active_content IS NULL OR active_content IN (0, 1)),
        CONSTRAINT pk_processing_jobs PRIMARY KEY (id),
        CONSTRAINT uq_processing_jobs_entity_id UNIQUE (entity_id, id),
        CONSTRAINT uq_processing_jobs_entity_document_id UNIQUE (entity_id, document_id, id),
        CONSTRAINT uq_processing_jobs_attempt UNIQUE (entity_id, idempotency_key, attempt),
        CONSTRAINT ck_processing_jobs_state CHECK (
            (status = 'queued' AND started_at IS NULL AND finished_at IS NULL
                AND error_code IS NULL AND page_count IS NULL AND active_content IS NULL)
            OR (status = 'running' AND started_at IS NOT NULL AND finished_at IS NULL
                AND error_code IS NULL AND page_count IS NULL AND active_content IS NULL)
            OR (status = 'succeeded' AND started_at IS NOT NULL AND finished_at IS NOT NULL
                AND error_code IS NULL AND active_content IS NOT NULL
                AND (page_count IS NOT NULL OR step = 'ehf_extraction'))
            OR (status IN ('failed', 'timed_out', 'cancelled') AND finished_at IS NOT NULL
                AND error_code IS NOT NULL AND page_count IS NULL)),
        CONSTRAINT fk_processing_jobs_document FOREIGN KEY (entity_id, document_id)
            REFERENCES documents (entity_id, id) ON DELETE RESTRICT
    )
"""

_JOB_TRIGGERS = [
    """
    CREATE UNIQUE INDEX uq_processing_jobs_succeeded ON processing_jobs
        (entity_id, idempotency_key) WHERE status = 'succeeded'
    """,
    """
    CREATE UNIQUE INDEX uq_processing_jobs_unfinished ON processing_jobs
        (entity_id, idempotency_key) WHERE status IN ('queued', 'running')
    """,
    "CREATE INDEX ix_processing_jobs_document ON processing_jobs (entity_id, document_id)",
    """
    CREATE TRIGGER processing_jobs_stored_document BEFORE INSERT ON processing_jobs
    WHEN NOT EXISTS (
        SELECT 1 FROM documents d
        WHERE d.id = NEW.document_id AND d.entity_id = NEW.entity_id AND d.status = 'stored')
    BEGIN SELECT RAISE(ABORT, 'only stored documents can be processed'); END
    """,
    """
    CREATE TRIGGER processing_jobs_no_delete BEFORE DELETE ON processing_jobs
    BEGIN SELECT RAISE(ABORT, 'processing_jobs cannot be deleted'); END
    """,
    f"""
    CREATE TRIGGER processing_jobs_transition BEFORE UPDATE ON processing_jobs
    WHEN NEW.id IS NOT OLD.id OR NEW.entity_id IS NOT OLD.entity_id
      OR NEW.document_id IS NOT OLD.document_id OR NEW.step IS NOT OLD.step
      OR NEW.idempotency_key IS NOT OLD.idempotency_key OR NEW.attempt IS NOT OLD.attempt
      OR NEW.engine IS NOT OLD.engine OR NEW.engine_version IS NOT OLD.engine_version
      OR NEW.settings_hash IS NOT OLD.settings_hash OR NEW.queued_at IS NOT OLD.queued_at
      OR OLD.status IN ({_FINISHED})
      OR (OLD.status = 'running' AND NEW.status NOT IN ({_FINISHED}))
      OR (OLD.status = 'running' AND NEW.started_at IS NOT OLD.started_at)
    BEGIN SELECT RAISE(ABORT, 'a job only moves forward and is final once finished'); END
    """,
]

_OCR_PAGES = [
    f"""
    CREATE TABLE ocr_pages (
        entity_id CHAR(32) NOT NULL,
        document_id CHAR(32) NOT NULL,
        job_id CHAR(32) NOT NULL,
        source_job_id CHAR(32) NOT NULL,
        page_number INTEGER NOT NULL CHECK (page_number BETWEEN 1 AND 1000),
        word_count INTEGER NOT NULL CHECK (word_count BETWEEN 0 AND 20000),
        line_count INTEGER NOT NULL CHECK (line_count BETWEEN 0 AND word_count),
        char_count INTEGER NOT NULL CHECK (char_count BETWEEN 0 AND 1000000),
        mean_confidence INTEGER NOT NULL CHECK (mean_confidence BETWEEN 0 AND 100),
        low_confidence_words INTEGER NOT NULL
            CHECK (low_confidence_words BETWEEN 0 AND word_count),
        storage_path VARCHAR(200) NOT NULL CHECK (length(storage_path) BETWEEN 1 AND 200
            AND storage_path GLOB '[0-9a-f]*/derived/*'
            AND storage_path NOT GLOB '*..*' AND storage_path NOT GLOB '*\\*'
            AND storage_path NOT GLOB '*//*'),
        sha256 VARCHAR(64) NOT NULL CHECK {_hex64("sha256")},
        size_bytes INTEGER NOT NULL CHECK (size_bytes >= 1),
        producer VARCHAR(48) NOT NULL CHECK (length(producer) BETWEEN 3 AND 48
            AND producer NOT GLOB '*[^0-9A-Za-z./+-]*' AND producer GLOB '[a-z]*/*'),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        CONSTRAINT pk_ocr_pages PRIMARY KEY (job_id, page_number),
        CONSTRAINT uq_ocr_pages_storage_path UNIQUE (storage_path),
        CONSTRAINT fk_ocr_pages_job FOREIGN KEY (entity_id, document_id, job_id)
            REFERENCES processing_jobs (entity_id, document_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_ocr_pages_source FOREIGN KEY (entity_id, source_job_id, page_number)
            REFERENCES document_pages (entity_id, job_id, page_number) ON DELETE RESTRICT
    )
    """,
    # Rows are added only by the transaction that finishes a running OCR job,
    # and only for a page image of the same document.
    """
    CREATE TRIGGER ocr_pages_running_job BEFORE INSERT ON ocr_pages
    WHEN NOT EXISTS (
        SELECT 1 FROM processing_jobs j
        WHERE j.id = NEW.job_id AND j.entity_id = NEW.entity_id AND j.status = 'running'
          AND j.step = 'ocr')
      OR NOT EXISTS (
        SELECT 1 FROM processing_jobs s
        WHERE s.id = NEW.source_job_id AND s.entity_id = NEW.entity_id
          AND s.document_id = NEW.document_id AND s.step = 'page_analysis'
          AND s.status = 'succeeded')
    BEGIN SELECT RAISE(ABORT, 'OCR pages belong to a running OCR job of the same document'); END
    """,
    """
    CREATE TRIGGER ocr_pages_no_update BEFORE UPDATE ON ocr_pages
    BEGIN SELECT RAISE(ABORT, 'ocr_pages is append-only'); END
    """,
    """
    CREATE TRIGGER ocr_pages_no_delete BEFORE DELETE ON ocr_pages
    BEGIN SELECT RAISE(ABORT, 'ocr_pages is append-only'); END
    """,
]


def _rename(statement: str) -> None:
    op.execute("PRAGMA legacy_alter_table = ON")
    op.execute(statement)
    op.execute("PRAGMA legacy_alter_table = OFF")


def upgrade() -> None:
    connection = op.get_bind()
    if connection.exec_driver_sql("PRAGMA foreign_keys").scalar() != 0:
        msg = "migration 0011 must run with foreign keys off (ADR-0032)"
        raise RuntimeError(msg)
    before = connection.exec_driver_sql("SELECT COUNT(*) FROM processing_jobs").scalar()

    op.execute(_JOBS)
    op.execute("INSERT INTO processing_jobs_0011 SELECT * FROM processing_jobs")
    op.execute("DROP TABLE processing_jobs")
    _rename("ALTER TABLE processing_jobs_0011 RENAME TO processing_jobs")
    for statement in _JOB_TRIGGERS:
        op.execute(statement)

    for statement in _OCR_PAGES:
        op.execute(statement)
    if connection.exec_driver_sql("SELECT COUNT(*) FROM processing_jobs").scalar() != before:
        msg = "rows changed while rebuilding"
        raise RuntimeError(msg)
    if connection.exec_driver_sql("PRAGMA foreign_key_check").fetchall():
        msg = "foreign key check failed after rebuilding"
        raise RuntimeError(msg)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
