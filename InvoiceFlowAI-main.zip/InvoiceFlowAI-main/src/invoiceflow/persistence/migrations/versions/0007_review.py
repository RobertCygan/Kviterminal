"""Phase 09: approvals bound to content, finding overrides and the approval gate.

Revision ID: 0007_review
Revises: 0006_reference
Create Date: 2026-10-24

* ``approvals``: append-only decisions (approved, rejected, revoked) on one
  revision and its content hash, with the validation run they relied on.
* ``finding_overrides``: append-only overrides of an error finding of one
  revision, with the person's reason. BANK-001 and DUP-001 cannot be overridden.
* Triggers on ``invoices``: the status ``approved`` requires a matching
  approval of the current revision and hash, and an approved invoice's content
  cannot change (a new revision must first leave the status ``approved``).

The DDL is written out literally: a migration is a frozen record.
"""

from alembic import op

revision = "0007_review"
down_revision = "0006_reference"
branch_labels = None
depends_on = None

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


def _actor(column: str) -> str:
    return (
        f"(length({column}) BETWEEN 1 AND 81 AND {column} NOT GLOB '*[^A-Za-z0-9._/-]*'"
        f" AND {column} GLOB '[a-z]*')"
    )


_STATEMENTS = [
    f"""
    CREATE TABLE approvals (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        invoice_id CHAR(32) NOT NULL,
        sequence INTEGER NOT NULL CHECK (sequence >= 1),
        revision INTEGER NOT NULL CHECK (revision >= 1),
        content_sha256 VARCHAR(64) NOT NULL CHECK {_hex64("content_sha256")},
        decision VARCHAR(8) NOT NULL CHECK (decision IN ('approved', 'rejected', 'revoked')),
        run_id CHAR(32),
        comment VARCHAR(500) CHECK (comment IS NULL OR length(comment) BETWEEN 1 AND 500),
        decided_at VARCHAR(27) NOT NULL CHECK {_utc("decided_at")},
        decided_by VARCHAR(81) NOT NULL CHECK {_actor("decided_by")},
        CONSTRAINT pk_approvals PRIMARY KEY (id),
        CONSTRAINT uq_approvals_sequence UNIQUE (invoice_id, sequence),
        CONSTRAINT ck_approvals_run CHECK (decision <> 'approved' OR run_id IS NOT NULL),
        CONSTRAINT fk_approvals_invoice FOREIGN KEY (entity_id, invoice_id)
            REFERENCES invoices (entity_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_approvals_revision FOREIGN KEY (invoice_id, revision)
            REFERENCES invoice_revisions (invoice_id, revision) ON DELETE RESTRICT,
        CONSTRAINT fk_approvals_run FOREIGN KEY (entity_id, run_id)
            REFERENCES validation_runs (entity_id, id) ON DELETE RESTRICT
    )
    """,
    """
    CREATE TRIGGER approvals_next_in_sequence BEFORE INSERT ON approvals
    WHEN NEW.sequence != COALESCE(
        (SELECT MAX(sequence) FROM approvals WHERE invoice_id = NEW.invoice_id), 0) + 1
    BEGIN SELECT RAISE(ABORT, 'approval decisions must be consecutive'); END
    """,
    """
    CREATE TRIGGER approvals_current_content BEFORE INSERT ON approvals
    WHEN NEW.decision = 'approved' AND NOT EXISTS (
        SELECT 1 FROM invoices i
        WHERE i.id = NEW.invoice_id AND i.entity_id = NEW.entity_id
          AND i.current_revision = NEW.revision AND i.content_sha256 = NEW.content_sha256)
    BEGIN SELECT RAISE(ABORT, 'an approval must name the current revision and content'); END
    """,
    """
    CREATE TRIGGER approvals_run_of_revision BEFORE INSERT ON approvals
    WHEN NEW.run_id IS NOT NULL AND NOT EXISTS (
        SELECT 1 FROM validation_runs v
        WHERE v.id = NEW.run_id AND v.invoice_id = NEW.invoice_id
          AND v.revision = NEW.revision)
    BEGIN SELECT RAISE(ABORT, 'the validation run must belong to the approved revision'); END
    """,
    """
    CREATE TRIGGER approvals_no_update BEFORE UPDATE ON approvals
    BEGIN SELECT RAISE(ABORT, 'approvals is append-only'); END
    """,
    """
    CREATE TRIGGER approvals_no_delete BEFORE DELETE ON approvals
    BEGIN SELECT RAISE(ABORT, 'approvals is append-only'); END
    """,
    f"""
    CREATE TABLE finding_overrides (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        invoice_id CHAR(32) NOT NULL,
        revision INTEGER NOT NULL CHECK (revision >= 1),
        rule_id VARCHAR(16) NOT NULL CHECK (rule_id GLOB '[A-Z]*-[0-9][0-9][0-9]'
            AND rule_id NOT GLOB '*[^A-Z0-9-]*' AND rule_id NOT IN ('BANK-001', 'DUP-001')),
        field_path VARCHAR(128) CHECK (field_path IS NULL
            OR (length(field_path) BETWEEN 1 AND 128
                AND field_path NOT GLOB '*[^a-z0-9_.]*')),
        message_key VARCHAR(80) NOT NULL CHECK (message_key GLOB 'validation.*'
            AND message_key NOT GLOB '*[^a-z0-9_.]*'),
        reason VARCHAR(500) NOT NULL CHECK (length(reason) BETWEEN 10 AND 500),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        created_by VARCHAR(81) NOT NULL CHECK {_actor("created_by")},
        CONSTRAINT pk_finding_overrides PRIMARY KEY (id),
        CONSTRAINT fk_finding_overrides_invoice FOREIGN KEY (entity_id, invoice_id)
            REFERENCES invoices (entity_id, id) ON DELETE RESTRICT,
        CONSTRAINT fk_finding_overrides_revision FOREIGN KEY (invoice_id, revision)
            REFERENCES invoice_revisions (invoice_id, revision) ON DELETE RESTRICT
    )
    """,
    "CREATE INDEX ix_finding_overrides_invoice ON finding_overrides (invoice_id, revision)",
    """
    CREATE TRIGGER finding_overrides_no_update BEFORE UPDATE ON finding_overrides
    BEGIN SELECT RAISE(ABORT, 'finding_overrides is append-only'); END
    """,
    """
    CREATE TRIGGER finding_overrides_no_delete BEFORE DELETE ON finding_overrides
    BEGIN SELECT RAISE(ABORT, 'finding_overrides is append-only'); END
    """,
    """
    CREATE TRIGGER invoices_approved_needs_approval BEFORE UPDATE OF workflow_status ON invoices
    WHEN NEW.workflow_status = 'approved' AND NOT EXISTS (
        SELECT 1 FROM approvals a
        WHERE a.invoice_id = NEW.id AND a.entity_id = NEW.entity_id
          AND a.decision = 'approved' AND a.revision = NEW.current_revision
          AND a.content_sha256 = NEW.content_sha256
          AND a.sequence = (SELECT MAX(b.sequence) FROM approvals b
                            WHERE b.invoice_id = NEW.id))
    BEGIN SELECT RAISE(ABORT, 'approved requires an approval of the current content'); END
    """,
    """
    CREATE TRIGGER invoices_approved_content_frozen BEFORE UPDATE ON invoices
    WHEN OLD.workflow_status = 'approved' AND NEW.workflow_status = 'approved'
      AND (NEW.content_sha256 IS NOT OLD.content_sha256
           OR NEW.current_revision IS NOT OLD.current_revision)
    BEGIN SELECT RAISE(ABORT, 'the content of an approved invoice cannot change'); END
    """,
]


def upgrade() -> None:
    for statement in _STATEMENTS:
        op.execute(statement)


def downgrade() -> None:
    raise NotImplementedError("Downgrade is not supported")
