"""Phase 02: accounting entities, invoice revisions and the audit chain.

Revision ID: 0001_initial
Revises:
Create Date: 2026-10-20

The DDL is written out literally: a migration is a frozen record of the schema
at one point in time and must not change when application code changes.
"""

from alembic import op

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

_DIGIT = "[0-9]"
_UTC = (
    f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}T{_DIGIT * 2}:{_DIGIT * 2}:{_DIGIT * 2}.{_DIGIT * 6}Z"
)
_DATE = f"{_DIGIT * 4}-{_DIGIT * 2}-{_DIGIT * 2}"
_ORG = _DIGIT * 9


def _uuid(column: str) -> str:
    return f"(length({column}) = 32 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _hex64(column: str) -> str:
    return f"(length({column}) = 64 AND {column} NOT GLOB '*[^0-9a-f]*')"


def _utc(column: str) -> str:
    return f"(length({column}) = 27 AND {column} GLOB '{_UTC}')"


def _decimal(column: str) -> str:
    return (
        f"({column} IS NULL OR (typeof({column}) = 'text' AND length({column}) BETWEEN 1 AND 40"
        f" AND {column} NOT GLOB '*[^0-9.-]*' AND {column} NOT GLOB '?*-*'"
        f" AND {column} NOT GLOB '*.*.*' AND {column} NOT GLOB '*.'"
        f" AND {column} NOT GLOB '.*' AND {column} NOT GLOB '-.*' AND {column} != '-'))"
    )


def _actor(column: str) -> str:
    return (
        f"(length({column}) BETWEEN 1 AND 81 AND {column} NOT GLOB '*[^A-Za-z0-9._/-]*'"
        f" AND {column} GLOB '[a-z]*')"
    )


_STATEMENTS = [
    f"""
    CREATE TABLE accounting_entities (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        name VARCHAR(300) NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 300),
        org_number VARCHAR(9) CHECK (org_number IS NULL OR org_number GLOB '{_ORG}'),
        default_currency VARCHAR(3) NOT NULL CHECK (default_currency GLOB '[A-Z][A-Z][A-Z]'),
        is_active BOOLEAN NOT NULL CHECK (is_active IN (0, 1)),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        updated_at VARCHAR(27) NOT NULL CHECK {_utc("updated_at")},
        CONSTRAINT pk_accounting_entities PRIMARY KEY (id)
    )
    """,
    """
    CREATE UNIQUE INDEX uq_accounting_entities_org_number
        ON accounting_entities (org_number) WHERE org_number IS NOT NULL
    """,
    f"""
    CREATE TABLE invoices (
        id CHAR(32) NOT NULL CHECK {_uuid("id")},
        entity_id CHAR(32) NOT NULL,
        document_id CHAR(32) NOT NULL CHECK {_uuid("document_id")},
        schema_version VARCHAR(8) NOT NULL CHECK (schema_version GLOB '[0-9]*.[0-9]*'),
        current_revision INTEGER NOT NULL CHECK (current_revision >= 1),
        content_sha256 VARCHAR(64) NOT NULL CHECK {_hex64("content_sha256")},
        workflow_status VARCHAR(16) NOT NULL CHECK (workflow_status IN
            ('draft', 'needs_review', 'approved', 'rejected', 'exported')),
        invoice_type VARCHAR(16) CHECK (invoice_type IS NULL OR invoice_type IN
            ('invoice', 'credit_note')),
        invoice_number VARCHAR(64),
        invoice_date DATE CHECK (invoice_date IS NULL OR invoice_date GLOB '{_DATE}'),
        due_date DATE CHECK (due_date IS NULL OR due_date GLOB '{_DATE}'),
        currency VARCHAR(3) CHECK (currency IS NULL OR currency GLOB '[A-Z][A-Z][A-Z]'),
        supplier_org_number VARCHAR(9) CHECK (supplier_org_number IS NULL
            OR supplier_org_number GLOB '{_ORG}'),
        net_amount VARCHAR(40) CHECK {_decimal("net_amount")},
        vat_amount VARCHAR(40) CHECK {_decimal("vat_amount")},
        rounding_amount VARCHAR(40) CHECK {_decimal("rounding_amount")},
        gross_amount VARCHAR(40) CHECK {_decimal("gross_amount")},
        row_version INTEGER NOT NULL CHECK (row_version >= 1),
        created_at VARCHAR(27) NOT NULL CHECK {_utc("created_at")},
        updated_at VARCHAR(27) NOT NULL CHECK {_utc("updated_at")},
        CONSTRAINT pk_invoices PRIMARY KEY (id),
        CONSTRAINT uq_invoices_entity_id UNIQUE (entity_id, id),
        CONSTRAINT fk_invoices_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT,
        CONSTRAINT fk_invoices_current_revision FOREIGN KEY (id, current_revision)
            REFERENCES invoice_revisions (invoice_id, revision)
            DEFERRABLE INITIALLY DEFERRED
    )
    """,
    "CREATE INDEX ix_invoices_entity_number ON invoices (entity_id, invoice_number)",
    "CREATE INDEX ix_invoices_entity_date ON invoices (entity_id, invoice_date)",
    f"""
    CREATE TABLE invoice_revisions (
        invoice_id CHAR(32) NOT NULL,
        revision INTEGER NOT NULL CHECK (revision >= 1),
        entity_id CHAR(32) NOT NULL,
        schema_version VARCHAR(8) NOT NULL CHECK (schema_version GLOB '[0-9]*.[0-9]*'),
        canonical_json TEXT NOT NULL CHECK (json_valid(canonical_json)
            AND json_type(canonical_json) = 'object'
            AND length(canonical_json) <= 10000000),
        content_sha256 VARCHAR(64) NOT NULL CHECK {_hex64("content_sha256")},
        change_kind VARCHAR(16) NOT NULL CHECK (change_kind IN ('created', 'revised')),
        recorded_at VARCHAR(27) NOT NULL CHECK {_utc("recorded_at")},
        recorded_by VARCHAR(81) NOT NULL CHECK {_actor("recorded_by")},
        CONSTRAINT pk_invoice_revisions PRIMARY KEY (invoice_id, revision),
        CONSTRAINT fk_invoice_revisions_invoice FOREIGN KEY (entity_id, invoice_id)
            REFERENCES invoices (entity_id, id) ON DELETE RESTRICT
            DEFERRABLE INITIALLY DEFERRED
    )
    """,
    f"""
    CREATE TABLE audit_events (
        sequence INTEGER NOT NULL CHECK (sequence >= 1),
        event_id CHAR(32) NOT NULL CHECK {_uuid("event_id")},
        occurred_at VARCHAR(27) NOT NULL CHECK {_utc("occurred_at")},
        actor VARCHAR(81) NOT NULL CHECK {_actor("actor")},
        event_type VARCHAR(32) NOT NULL CHECK (event_type GLOB '[a-z]*.[a-z]*'
            AND event_type NOT GLOB '*[^a-z._]*'),
        entity_id CHAR(32),
        subject_type VARCHAR(16) NOT NULL CHECK (subject_type IN
            ('database', 'entity', 'invoice')),
        subject_id VARCHAR(64) NOT NULL CHECK (length(subject_id) BETWEEN 1 AND 64),
        details_json TEXT NOT NULL CHECK (json_valid(details_json)
            AND json_type(details_json) = 'object' AND length(details_json) <= 4096),
        hash_version INTEGER NOT NULL CHECK (hash_version = 1),
        prev_hash VARCHAR(64) NOT NULL CHECK {_hex64("prev_hash")},
        event_hash VARCHAR(64) NOT NULL CHECK {_hex64("event_hash")},
        CONSTRAINT pk_audit_events PRIMARY KEY (sequence),
        CONSTRAINT uq_audit_events_event_id UNIQUE (event_id),
        CONSTRAINT uq_audit_events_prev_hash UNIQUE (prev_hash),
        CONSTRAINT uq_audit_events_event_hash UNIQUE (event_hash),
        CONSTRAINT fk_audit_events_entity FOREIGN KEY (entity_id)
            REFERENCES accounting_entities (id) ON DELETE RESTRICT
    )
    """,
    # Revisions and audit events are append-only, even for code that bypasses
    # the application layer.
    """
    CREATE TRIGGER invoice_revisions_no_update BEFORE UPDATE ON invoice_revisions
    BEGIN SELECT RAISE(ABORT, 'invoice_revisions is append-only'); END
    """,
    """
    CREATE TRIGGER invoice_revisions_no_delete BEFORE DELETE ON invoice_revisions
    BEGIN SELECT RAISE(ABORT, 'invoice_revisions is append-only'); END
    """,
    """
    CREATE TRIGGER invoice_revisions_consecutive BEFORE INSERT ON invoice_revisions
    WHEN NEW.revision != COALESCE(
        (SELECT MAX(revision) FROM invoice_revisions WHERE invoice_id = NEW.invoice_id), 0) + 1
    BEGIN SELECT RAISE(ABORT, 'invoice revisions must be consecutive'); END
    """,
    # The current-state row must always point at a stored revision with the
    # same owner and content hash.
    """
    CREATE TRIGGER invoices_match_revision_insert BEFORE INSERT ON invoices
    WHEN NOT EXISTS (
        SELECT 1 FROM invoice_revisions r
        WHERE r.invoice_id = NEW.id AND r.revision = NEW.current_revision
          AND r.entity_id = NEW.entity_id AND r.content_sha256 = NEW.content_sha256)
    BEGIN SELECT RAISE(ABORT, 'invoice must match a stored revision'); END
    """,
    """
    CREATE TRIGGER invoices_match_revision_update BEFORE UPDATE ON invoices
    WHEN NOT EXISTS (
        SELECT 1 FROM invoice_revisions r
        WHERE r.invoice_id = NEW.id AND r.revision = NEW.current_revision
          AND r.entity_id = NEW.entity_id AND r.content_sha256 = NEW.content_sha256)
    BEGIN SELECT RAISE(ABORT, 'invoice must match a stored revision'); END
    """,
    """
    CREATE TRIGGER invoices_immutable_owner BEFORE UPDATE OF id, entity_id, document_id
    ON invoices
    WHEN NEW.id IS NOT OLD.id OR NEW.entity_id IS NOT OLD.entity_id
      OR NEW.document_id IS NOT OLD.document_id
    BEGIN SELECT RAISE(ABORT, 'invoice ownership is immutable'); END
    """,
    """
    CREATE TRIGGER invoices_no_delete BEFORE DELETE ON invoices
    BEGIN SELECT RAISE(ABORT, 'invoices cannot be deleted'); END
    """,
    """
    CREATE TRIGGER accounting_entities_immutable_id BEFORE UPDATE OF id ON accounting_entities
    WHEN NEW.id IS NOT OLD.id
    BEGIN SELECT RAISE(ABORT, 'entity id is immutable'); END
    """,
    """
    CREATE TRIGGER audit_events_no_update BEFORE UPDATE ON audit_events
    BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END
    """,
    """
    CREATE TRIGGER audit_events_no_delete BEFORE DELETE ON audit_events
    BEGIN SELECT RAISE(ABORT, 'audit_events is append-only'); END
    """,
    # One linear chain: each new event must extend the current end exactly.
    # Genesis: the first event links to 64 zeros.
    """
    CREATE TRIGGER audit_events_extend_chain BEFORE INSERT ON audit_events
    WHEN NEW.sequence != COALESCE((SELECT MAX(sequence) FROM audit_events), 0) + 1
      OR NEW.prev_hash != COALESCE(
        (SELECT event_hash FROM audit_events ORDER BY sequence DESC LIMIT 1),
        '0000000000000000000000000000000000000000000000000000000000000000')
    BEGIN SELECT RAISE(ABORT, 'audit events must extend the end of the chain'); END
    """,
]


def upgrade() -> None:
    for statement in _STATEMENTS:
        op.execute(statement)


def downgrade() -> None:
    # InvoiceFlow never downgrades automatically; restore the pre-migration copy instead.
    raise NotImplementedError("Downgrade is not supported")
