"""Alembic environment for InvoiceFlow AI.

Migrations run only through ``invoiceflow.persistence.migrator``, which passes
an open connection inside an explicit ``BEGIN IMMEDIATE`` transaction. All DDL
therefore commits or rolls back as one unit; nothing here opens its own
connection, reads alembic.ini or configures logging.
"""

from alembic import context

connection = context.config.attributes.get("connection")
if connection is None:
    msg = "Run InvoiceFlow migrations through invoiceflow.persistence.migrator"
    raise RuntimeError(msg)

context.configure(connection=connection, target_metadata=None, transactional_ddl=True)
with context.begin_transaction():
    context.run_migrations()
