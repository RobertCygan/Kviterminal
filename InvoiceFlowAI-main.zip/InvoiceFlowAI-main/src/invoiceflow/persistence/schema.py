"""SQLAlchemy Core table definitions for the database schema (Phases 02-04, 08-12 and 15).

The authoritative DDL (including CHECK constraints and triggers) lives in the
Alembic migrations. These definitions describe the same columns for queries;
``tests/integration/persistence/test_migrations.py`` fails if they drift apart.
"""

from sqlalchemy import (
    Boolean,
    Column,
    Date,
    ForeignKeyConstraint,
    Index,
    Integer,
    MetaData,
    PrimaryKeyConstraint,
    String,
    Table,
    Text,
    UniqueConstraint,
    Uuid,
)

from invoiceflow.persistence.types import DecimalText, UtcDateTime

metadata = MetaData()


def _uuid() -> Uuid:
    # Stored as 32 lowercase hex characters; no native UUID type in SQLite.
    return Uuid(native_uuid=False)


accounting_entities = Table(
    "accounting_entities",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("name", String(300), nullable=False),
    Column("org_number", String(9), nullable=True),
    Column("default_currency", String(3), nullable=False),
    Column("is_active", Boolean(create_constraint=False), nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("updated_at", UtcDateTime(), nullable=False),
)
Index(
    "uq_accounting_entities_org_number",
    accounting_entities.c.org_number,
    unique=True,
    sqlite_where=accounting_entities.c.org_number.isnot(None),
)

invoices = Table(
    "invoices",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("document_id", _uuid(), nullable=False),
    Column("schema_version", String(8), nullable=False),
    Column("current_revision", Integer, nullable=False),
    Column("content_sha256", String(64), nullable=False),
    Column("workflow_status", String(16), nullable=False),
    Column("invoice_type", String(16), nullable=True),
    Column("invoice_number", String(64), nullable=True),
    Column("invoice_date", Date, nullable=True),
    Column("due_date", Date, nullable=True),
    Column("currency", String(3), nullable=True),
    Column("supplier_org_number", String(9), nullable=True),
    Column("net_amount", DecimalText(2), nullable=True),
    Column("vat_amount", DecimalText(2), nullable=True),
    Column("rounding_amount", DecimalText(2), nullable=True),
    Column("gross_amount", DecimalText(2), nullable=True),
    Column("row_version", Integer, nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("updated_at", UtcDateTime(), nullable=False),
    UniqueConstraint("entity_id", "id", name="uq_invoices_entity_id"),
    ForeignKeyConstraint(
        ["entity_id"],
        ["accounting_entities.id"],
        name="fk_invoices_entity",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["id", "current_revision"],
        ["invoice_revisions.invoice_id", "invoice_revisions.revision"],
        name="fk_invoices_current_revision",
        # Breaks the invoices <-> invoice_revisions cycle for table sorting;
        # the real DDL is in the migration, never emitted from this metadata.
        use_alter=True,
        deferrable=True,
        initially="DEFERRED",
    ),
)
Index("ix_invoices_entity_number", invoices.c.entity_id, invoices.c.invoice_number)
Index("ix_invoices_entity_date", invoices.c.entity_id, invoices.c.invoice_date)

invoice_revisions = Table(
    "invoice_revisions",
    metadata,
    Column("invoice_id", _uuid(), nullable=False),
    Column("revision", Integer, nullable=False),
    Column("entity_id", _uuid(), nullable=False),
    Column("schema_version", String(8), nullable=False),
    Column("canonical_json", Text, nullable=False),
    Column("content_sha256", String(64), nullable=False),
    Column("change_kind", String(16), nullable=False),
    Column("recorded_at", UtcDateTime(), nullable=False),
    Column("recorded_by", String(81), nullable=False),
    PrimaryKeyConstraint("invoice_id", "revision", name="pk_invoice_revisions"),
    ForeignKeyConstraint(
        ["entity_id", "invoice_id"],
        ["invoices.entity_id", "invoices.id"],
        name="fk_invoice_revisions_invoice",
        ondelete="RESTRICT",
        deferrable=True,
        initially="DEFERRED",
    ),
)

audit_events = Table(
    "audit_events",
    metadata,
    Column("sequence", Integer, primary_key=True, autoincrement=False),
    Column("event_id", _uuid(), nullable=False, unique=True),
    Column("occurred_at", UtcDateTime(), nullable=False),
    Column("actor", String(81), nullable=False),
    Column("event_type", String(32), nullable=False),
    Column("entity_id", _uuid(), nullable=True),
    Column("subject_type", String(16), nullable=False),
    Column("subject_id", String(64), nullable=False),
    Column("details_json", Text, nullable=False),
    Column("hash_version", Integer, nullable=False),
    Column("prev_hash", String(64), nullable=False, unique=True),
    Column("event_hash", String(64), nullable=False, unique=True),
    ForeignKeyConstraint(
        ["entity_id"],
        ["accounting_entities.id"],
        name="fk_audit_events_entity",
        ondelete="RESTRICT",
    ),
)

documents = Table(
    "documents",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("document_type", String(32), nullable=False),
    Column("sha256", String(64), nullable=False),
    Column("size_bytes", Integer, nullable=False),
    Column("detected_format", String(8), nullable=True),
    Column("display_name", String(255), nullable=False),
    Column("storage_path", String(200), nullable=False),
    Column("source", String(16), nullable=False),
    Column("status", String(16), nullable=False),
    Column("imported_at", UtcDateTime(), nullable=False),
    Column("imported_by", String(81), nullable=False),
    Column("integrity_checked_at", UtcDateTime(), nullable=True),
    Column("integrity_status", String(16), nullable=True),
    UniqueConstraint("entity_id", "id", name="uq_documents_entity_id"),
    UniqueConstraint("entity_id", "sha256", name="uq_documents_entity_sha256"),
    UniqueConstraint("storage_path", name="uq_documents_storage_path"),
    ForeignKeyConstraint(
        ["entity_id"],
        ["accounting_entities.id"],
        name="fk_documents_entity",
        ondelete="RESTRICT",
    ),
)
Index("ix_documents_entity_imported", documents.c.entity_id, documents.c.imported_at)

document_links = Table(
    "document_links",
    metadata,
    Column("entity_id", _uuid(), nullable=False),
    Column("from_document_id", _uuid(), nullable=False),
    Column("to_document_id", _uuid(), nullable=False),
    Column("link_type", String(16), nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("created_by", String(81), nullable=False),
    PrimaryKeyConstraint(
        "entity_id", "from_document_id", "to_document_id", "link_type", name="pk_document_links"
    ),
    ForeignKeyConstraint(
        ["entity_id", "from_document_id"],
        ["documents.entity_id", "documents.id"],
        name="fk_document_links_from",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["entity_id", "to_document_id"],
        ["documents.entity_id", "documents.id"],
        name="fk_document_links_to",
        ondelete="RESTRICT",
    ),
)

processing_jobs = Table(
    "processing_jobs",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("document_id", _uuid(), nullable=False),
    Column("step", String(32), nullable=False),
    Column("idempotency_key", String(64), nullable=False),
    Column("attempt", Integer, nullable=False),
    Column("status", String(16), nullable=False),
    Column("engine", String(16), nullable=False),
    Column("engine_version", String(32), nullable=False),
    Column("settings_hash", String(64), nullable=False),
    Column("queued_at", UtcDateTime(), nullable=False),
    Column("started_at", UtcDateTime(), nullable=True),
    Column("finished_at", UtcDateTime(), nullable=True),
    Column("error_code", String(32), nullable=True),
    Column("page_count", Integer, nullable=True),
    Column("active_content", Boolean(create_constraint=False), nullable=True),
    UniqueConstraint("entity_id", "id", name="uq_processing_jobs_entity_id"),
    UniqueConstraint(
        "entity_id", "document_id", "id", name="uq_processing_jobs_entity_document_id"
    ),
    UniqueConstraint("entity_id", "idempotency_key", "attempt", name="uq_processing_jobs_attempt"),
    ForeignKeyConstraint(
        ["entity_id", "document_id"],
        ["documents.entity_id", "documents.id"],
        name="fk_processing_jobs_document",
        ondelete="RESTRICT",
    ),
)
Index(
    "uq_processing_jobs_succeeded",
    processing_jobs.c.entity_id,
    processing_jobs.c.idempotency_key,
    unique=True,
    sqlite_where=processing_jobs.c.status == "succeeded",
)
Index(
    "uq_processing_jobs_unfinished",
    processing_jobs.c.entity_id,
    processing_jobs.c.idempotency_key,
    unique=True,
    sqlite_where=processing_jobs.c.status.in_(["queued", "running"]),
)
Index("ix_processing_jobs_document", processing_jobs.c.entity_id, processing_jobs.c.document_id)

document_pages = Table(
    "document_pages",
    metadata,
    Column("entity_id", _uuid(), nullable=False),
    Column("document_id", _uuid(), nullable=False),
    Column("job_id", _uuid(), nullable=False),
    Column("page_number", Integer, nullable=False),
    Column("width_px", Integer, nullable=False),
    Column("height_px", Integer, nullable=False),
    Column("rotation_degrees", Integer, nullable=False),
    Column("has_text_layer", Boolean(create_constraint=False), nullable=False),
    Column("text_layer_chars", Integer, nullable=False),
    Column("dark_permille", Integer, nullable=True),
    Column("center_dark_permille", Integer, nullable=True),
    PrimaryKeyConstraint("job_id", "page_number", name="pk_document_pages"),
    UniqueConstraint(
        "entity_id", "job_id", "page_number", name="uq_document_pages_entity_job_page"
    ),
    ForeignKeyConstraint(
        ["entity_id", "document_id", "job_id"],
        ["processing_jobs.entity_id", "processing_jobs.document_id", "processing_jobs.id"],
        name="fk_document_pages_job",
        ondelete="RESTRICT",
    ),
)

derived_files = Table(
    "derived_files",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("document_id", _uuid(), nullable=False),
    Column("job_id", _uuid(), nullable=False),
    Column("page_number", Integer, nullable=False),
    Column("kind", String(16), nullable=False),
    Column("storage_path", String(200), nullable=False),
    Column("sha256", String(64), nullable=False),
    Column("size_bytes", Integer, nullable=False),
    Column("producer", String(48), nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    UniqueConstraint("storage_path", name="uq_derived_files_storage_path"),
    UniqueConstraint("job_id", "page_number", "kind", name="uq_derived_files_job_page_kind"),
    ForeignKeyConstraint(
        ["entity_id", "document_id", "job_id"],
        ["processing_jobs.entity_id", "processing_jobs.document_id", "processing_jobs.id"],
        name="fk_derived_files_job",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["entity_id", "job_id", "page_number"],
        [
            "document_pages.entity_id",
            "document_pages.job_id",
            "document_pages.page_number",
        ],
        name="fk_derived_files_page",
        ondelete="RESTRICT",
    ),
)

# Phase 05: one row per page recognised by OCR; the words are in a derived file.
ocr_pages = Table(
    "ocr_pages",
    metadata,
    Column("entity_id", _uuid(), nullable=False),
    Column("document_id", _uuid(), nullable=False),
    Column("job_id", _uuid(), nullable=False),
    Column("source_job_id", _uuid(), nullable=False),
    Column("page_number", Integer, nullable=False),
    Column("word_count", Integer, nullable=False),
    Column("line_count", Integer, nullable=False),
    Column("char_count", Integer, nullable=False),
    Column("mean_confidence", Integer, nullable=False),
    Column("low_confidence_words", Integer, nullable=False),
    Column("storage_path", String(200), nullable=False),
    Column("sha256", String(64), nullable=False),
    Column("size_bytes", Integer, nullable=False),
    Column("producer", String(48), nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    PrimaryKeyConstraint("job_id", "page_number", name="pk_ocr_pages"),
    UniqueConstraint("storage_path", name="uq_ocr_pages_storage_path"),
    ForeignKeyConstraint(
        ["entity_id", "document_id", "job_id"],
        ["processing_jobs.entity_id", "processing_jobs.document_id", "processing_jobs.id"],
        name="fk_ocr_pages_job",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["entity_id", "source_job_id", "page_number"],
        [
            "document_pages.entity_id",
            "document_pages.job_id",
            "document_pages.page_number",
        ],
        name="fk_ocr_pages_source",
        ondelete="RESTRICT",
    ),
)

invoice_findings = Table(
    "invoice_findings",
    metadata,
    Column("entity_id", _uuid(), nullable=False),
    Column("invoice_id", _uuid(), nullable=False),
    Column("revision", Integer, nullable=False),
    Column("code", String(32), nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    PrimaryKeyConstraint("invoice_id", "revision", "code", name="pk_invoice_findings"),
    ForeignKeyConstraint(
        ["entity_id", "invoice_id"],
        ["invoices.entity_id", "invoices.id"],
        name="fk_invoice_findings_invoice",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["invoice_id", "revision"],
        ["invoice_revisions.invoice_id", "invoice_revisions.revision"],
        name="fk_invoice_findings_revision",
        ondelete="RESTRICT",
    ),
)

suppliers = Table(
    "suppliers",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("name", String(300), nullable=False),
    Column("org_number", String(9), nullable=True),
    Column("foreign_vat_id", String(20), nullable=True),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("created_by", String(81), nullable=False),
    UniqueConstraint("entity_id", "id", name="uq_suppliers_entity_id"),
    ForeignKeyConstraint(
        ["entity_id"],
        ["accounting_entities.id"],
        name="fk_suppliers_entity",
        ondelete="RESTRICT",
    ),
)
Index(
    "uq_suppliers_entity_org",
    suppliers.c.entity_id,
    suppliers.c.org_number,
    unique=True,
    sqlite_where=suppliers.c.org_number.isnot(None),
)
Index(
    "uq_suppliers_entity_vat",
    suppliers.c.entity_id,
    suppliers.c.foreign_vat_id,
    unique=True,
    sqlite_where=suppliers.c.foreign_vat_id.isnot(None),
)

supplier_bank_accounts = Table(
    "supplier_bank_accounts",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("supplier_id", _uuid(), nullable=False),
    Column("account_kind", String(8), nullable=False),
    Column("account", String(34), nullable=False),
    Column("status", String(16), nullable=False),
    Column("first_seen_invoice_id", _uuid(), nullable=True),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("status_changed_at", UtcDateTime(), nullable=True),
    Column("status_changed_by", String(81), nullable=True),
    UniqueConstraint("entity_id", "id", name="uq_supplier_bank_accounts_entity_id"),
    UniqueConstraint("supplier_id", "account", name="uq_supplier_bank_accounts_account"),
    ForeignKeyConstraint(
        ["entity_id", "supplier_id"],
        ["suppliers.entity_id", "suppliers.id"],
        name="fk_supplier_bank_accounts_supplier",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["entity_id", "first_seen_invoice_id"],
        ["invoices.entity_id", "invoices.id"],
        name="fk_supplier_bank_accounts_invoice",
        ondelete="RESTRICT",
    ),
)

validation_runs = Table(
    "validation_runs",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("invoice_id", _uuid(), nullable=False),
    Column("revision", Integer, nullable=False),
    Column("run_number", Integer, nullable=False),
    Column("ruleset_version", String(8), nullable=False),
    Column("settings_sha256", String(64), nullable=False),
    Column("error_count", Integer, nullable=False),
    Column("warning_count", Integer, nullable=False),
    Column("info_count", Integer, nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("created_by", String(81), nullable=False),
    UniqueConstraint("entity_id", "id", name="uq_validation_runs_entity_id"),
    UniqueConstraint("invoice_id", "run_number", name="uq_validation_runs_number"),
    ForeignKeyConstraint(
        ["entity_id", "invoice_id"],
        ["invoices.entity_id", "invoices.id"],
        name="fk_validation_runs_invoice",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["invoice_id", "revision"],
        ["invoice_revisions.invoice_id", "invoice_revisions.revision"],
        name="fk_validation_runs_revision",
        ondelete="RESTRICT",
    ),
)

validation_results = Table(
    "validation_results",
    metadata,
    Column("entity_id", _uuid(), nullable=False),
    Column("run_id", _uuid(), nullable=False),
    Column("position", Integer, nullable=False),
    Column("rule_id", String(16), nullable=False),
    Column("rule_version", Integer, nullable=False),
    Column("severity", String(8), nullable=False),
    Column("field_path", String(128), nullable=True),
    Column("message_key", String(80), nullable=False),
    Column("params_json", Text, nullable=False),
    PrimaryKeyConstraint("run_id", "position", name="pk_validation_results"),
    ForeignKeyConstraint(
        ["entity_id", "run_id"],
        ["validation_runs.entity_id", "validation_runs.id"],
        name="fk_validation_results_run",
        ondelete="RESTRICT",
    ),
)

reference_imports = Table(
    "reference_imports",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("kind", String(16), nullable=False),
    Column("sha256", String(64), nullable=False),
    Column("row_count", Integer, nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("created_by", String(81), nullable=False),
    UniqueConstraint("entity_id", "id", name="uq_reference_imports_entity_id"),
    ForeignKeyConstraint(
        ["entity_id"],
        ["accounting_entities.id"],
        name="fk_reference_imports_entity",
        ondelete="RESTRICT",
    ),
)
Index(
    "ix_reference_imports_kind",
    reference_imports.c.entity_id,
    reference_imports.c.kind,
    reference_imports.c.created_at,
)


def _import_fk(table: str) -> ForeignKeyConstraint:
    return ForeignKeyConstraint(
        ["entity_id", "import_id"],
        ["reference_imports.entity_id", "reference_imports.id"],
        name=f"fk_{table}_import",
        ondelete="RESTRICT",
    )


chart_of_accounts = Table(
    "chart_of_accounts",
    metadata,
    Column("entity_id", _uuid(), nullable=False),
    Column("import_id", _uuid(), nullable=False),
    Column("account", String(20), nullable=False),
    Column("name", String(300), nullable=False),
    Column("default_vat_code", String(20), nullable=True),
    Column("is_active", Boolean(create_constraint=False), nullable=False),
    PrimaryKeyConstraint("import_id", "account", name="pk_chart_of_accounts"),
    _import_fk("chart_of_accounts"),
)

vat_codes = Table(
    "vat_codes",
    metadata,
    Column("entity_id", _uuid(), nullable=False),
    Column("import_id", _uuid(), nullable=False),
    Column("code", String(20), nullable=False),
    Column("valid_from", Date, nullable=False),
    Column("valid_to", Date, nullable=True),
    Column("rate", DecimalText(0), nullable=False),
    Column("direction", String(8), nullable=False),
    Column("saft_code", String(20), nullable=True),
    Column("name", String(300), nullable=True),
    PrimaryKeyConstraint("import_id", "code", "valid_from", name="pk_vat_codes"),
    _import_fk("vat_codes"),
)

dimension_values = Table(
    "dimension_values",
    metadata,
    Column("entity_id", _uuid(), nullable=False),
    Column("import_id", _uuid(), nullable=False),
    Column("dimension", String(16), nullable=False),
    Column("code", String(20), nullable=False),
    Column("name", String(300), nullable=False),
    Column("is_active", Boolean(create_constraint=False), nullable=False),
    PrimaryKeyConstraint("import_id", "dimension", "code", name="pk_dimension_values"),
    _import_fk("dimension_values"),
)

supplier_defaults = Table(
    "supplier_defaults",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("supplier_id", _uuid(), nullable=False),
    Column("version", Integer, nullable=False),
    Column("account", String(20), nullable=True),
    Column("vat_code", String(20), nullable=True),
    Column("cost_center", String(20), nullable=True),
    Column("department", String(20), nullable=True),
    Column("project", String(20), nullable=True),
    Column("set_at", UtcDateTime(), nullable=False),
    Column("set_by", String(81), nullable=False),
    UniqueConstraint("supplier_id", "version", name="uq_supplier_defaults_version"),
    ForeignKeyConstraint(
        ["entity_id", "supplier_id"],
        ["suppliers.entity_id", "suppliers.id"],
        name="fk_supplier_defaults_supplier",
        ondelete="RESTRICT",
    ),
)

approvals = Table(
    "approvals",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("invoice_id", _uuid(), nullable=False),
    Column("sequence", Integer, nullable=False),
    Column("revision", Integer, nullable=False),
    Column("content_sha256", String(64), nullable=False),
    Column("decision", String(8), nullable=False),
    Column("run_id", _uuid(), nullable=True),
    Column("comment", String(500), nullable=True),
    Column("decided_at", UtcDateTime(), nullable=False),
    Column("decided_by", String(81), nullable=False),
    UniqueConstraint("invoice_id", "sequence", name="uq_approvals_sequence"),
    ForeignKeyConstraint(
        ["entity_id", "invoice_id"],
        ["invoices.entity_id", "invoices.id"],
        name="fk_approvals_invoice",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["invoice_id", "revision"],
        ["invoice_revisions.invoice_id", "invoice_revisions.revision"],
        name="fk_approvals_revision",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["entity_id", "run_id"],
        ["validation_runs.entity_id", "validation_runs.id"],
        name="fk_approvals_run",
        ondelete="RESTRICT",
    ),
)

finding_overrides = Table(
    "finding_overrides",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("invoice_id", _uuid(), nullable=False),
    Column("revision", Integer, nullable=False),
    Column("rule_id", String(16), nullable=False),
    Column("field_path", String(128), nullable=True),
    Column("message_key", String(80), nullable=False),
    Column("reason", String(500), nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("created_by", String(81), nullable=False),
    ForeignKeyConstraint(
        ["entity_id", "invoice_id"],
        ["invoices.entity_id", "invoices.id"],
        name="fk_finding_overrides_invoice",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["invoice_id", "revision"],
        ["invoice_revisions.invoice_id", "invoice_revisions.revision"],
        name="fk_finding_overrides_revision",
        ondelete="RESTRICT",
    ),
)
Index("ix_finding_overrides_invoice", finding_overrides.c.invoice_id, finding_overrides.c.revision)

export_mappings = Table(
    "export_mappings",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("version", Integer, nullable=False),
    Column("columns_json", Text, nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("created_by", String(81), nullable=False),
    UniqueConstraint("entity_id", "version", name="uq_export_mappings_version"),
    ForeignKeyConstraint(
        ["entity_id"],
        ["accounting_entities.id"],
        name="fk_export_mappings_entity",
        ondelete="RESTRICT",
    ),
)

export_batches = Table(
    "export_batches",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("sequence", Integer, nullable=False),
    Column("target", String(8), nullable=False),
    Column("mapping_version", Integer, nullable=False),
    Column("columns_json", Text, nullable=False),
    Column("status", String(8), nullable=False),
    Column("file_name", String(64), nullable=False),
    Column("file_sha256", String(64), nullable=True),
    Column("item_count", Integer, nullable=False),
    Column("is_reexport", Integer, nullable=False),
    Column("reexport_reason", String(500), nullable=True),
    Column("audit_anchor", String(64), nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("created_by", String(81), nullable=False),
    Column("completed_at", UtcDateTime(), nullable=True),
    UniqueConstraint("entity_id", "id", name="uq_export_batches_entity_id"),
    UniqueConstraint("entity_id", "sequence", name="uq_export_batches_sequence"),
    UniqueConstraint("entity_id", "file_name", name="uq_export_batches_file_name"),
    ForeignKeyConstraint(
        ["entity_id"],
        ["accounting_entities.id"],
        name="fk_export_batches_entity",
        ondelete="RESTRICT",
    ),
)

export_items = Table(
    "export_items",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("entity_id", _uuid(), nullable=False),
    Column("batch_id", _uuid(), nullable=False),
    Column("invoice_id", _uuid(), nullable=False),
    Column("approval_id", _uuid(), nullable=False),
    Column("revision", Integer, nullable=False),
    Column("content_sha256", String(64), nullable=False),
    Column("target", String(8), nullable=False),
    Column("status", String(10), nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("updated_at", UtcDateTime(), nullable=False),
    UniqueConstraint("batch_id", "invoice_id", name="uq_export_items_batch_invoice"),
    ForeignKeyConstraint(
        ["entity_id", "batch_id"],
        ["export_batches.entity_id", "export_batches.id"],
        name="fk_export_items_batch",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["entity_id", "invoice_id"],
        ["invoices.entity_id", "invoices.id"],
        name="fk_export_items_invoice",
        ondelete="RESTRICT",
    ),
    ForeignKeyConstraint(
        ["approval_id"], ["approvals.id"], name="fk_export_items_approval", ondelete="RESTRICT"
    ),
    ForeignKeyConstraint(
        ["invoice_id", "revision"],
        ["invoice_revisions.invoice_id", "invoice_revisions.revision"],
        name="fk_export_items_revision",
        ondelete="RESTRICT",
    ),
)
Index(
    "uq_export_items_active",
    export_items.c.entity_id,
    export_items.c.invoice_id,
    export_items.c.target,
    unique=True,
    sqlite_where=export_items.c.status.in_(["pending", "exported"]),
)
Index("ix_export_items_invoice", export_items.c.invoice_id, export_items.c.id)

backups = Table(
    "backups",
    metadata,
    Column("id", _uuid(), primary_key=True),
    Column("file_name", String(64), nullable=False),
    Column("file_sha256", String(64), nullable=False),
    Column("byte_count", Integer, nullable=False),
    Column("file_count", Integer, nullable=False),
    Column("schema_revision", String(32), nullable=False),
    Column("audit_sequence", Integer, nullable=False),
    Column("audit_anchor", String(64), nullable=False),
    Column("created_at", UtcDateTime(), nullable=False),
    Column("created_by", String(81), nullable=False),
    Column("deleted_at", UtcDateTime(), nullable=True),
    Column("deleted_by", String(81), nullable=True),
    UniqueConstraint("file_sha256", name="uq_backups_file_sha256"),
)
