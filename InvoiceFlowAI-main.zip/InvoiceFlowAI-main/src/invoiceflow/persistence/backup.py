"""Consistent database copies for backups and checks of restored ones (Phase 12).

The copy uses SQLite's online backup API from a read-only connection, so the
live database is never copied as a file and never changed. A restored copy is
checked like a database at startup (integrity, known schema, settings, the
whole audit chain) and reports every file it refers to.
"""

import sqlite3
from pathlib import Path

from invoiceflow.application.backup.model import BackupError, DatabaseCopy, SnapshotInfo
from invoiceflow.application.errors import DatabaseError
from invoiceflow.persistence.migrator import (
    inspect_database,
    known_revisions,
    verify_database,
)


def _read_only(path: Path) -> sqlite3.Connection:
    return sqlite3.connect(f"{path.as_uri()}?mode=ro", uri=True)


def _info(connection: sqlite3.Connection) -> SnapshotInfo:
    (revision,) = connection.execute("SELECT version_num FROM alembic_version").fetchone()
    row = connection.execute(
        "SELECT sequence, event_hash FROM audit_events ORDER BY sequence DESC LIMIT 1"
    ).fetchone()
    if row is None:
        raise BackupError("database")
    return SnapshotInfo(revision, row[0], row[1])


def _contents(connection: sqlite3.Connection) -> DatabaseCopy:
    referenced = {
        f"documents/{storage_path}": sha256
        for storage_path, sha256 in connection.execute("SELECT storage_path, sha256 FROM documents")
    }
    return DatabaseCopy(_info(connection), referenced)


class SqliteSnapshotter:
    """Implements :class:`invoiceflow.application.ports.DatabaseSnapshotter`."""

    def __init__(self, database_path: Path) -> None:
        self._path = database_path

    def snapshot(self, target: Path) -> DatabaseCopy:
        """A self-contained, checked copy of the live database at ``target``."""
        try:
            source = _read_only(self._path)
            try:
                copy = sqlite3.connect(target)
                try:
                    source.backup(copy)
                    # One file without -wal/-shm, like the migration safety copy.
                    if copy.execute("PRAGMA journal_mode=DELETE").fetchone() != ("delete",):
                        raise BackupError("database")
                    if copy.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
                        raise BackupError("database")
                    return _contents(copy)
                finally:
                    copy.close()
            finally:
                source.close()
        except sqlite3.Error as exc:
            raise BackupError("database") from exc

    def inspect(self, path: Path) -> DatabaseCopy:
        """Check a restored database and list the files it refers to."""
        try:
            _, revisions = known_revisions()
            if inspect_database(path, revisions) is None:
                raise BackupError("database")
            verify_database(path)
        except DatabaseError as exc:
            raise BackupError("chain" if exc.code == "AUDIT_CHAIN_INVALID" else "database") from exc
        try:
            connection = _read_only(path)
            try:
                return _contents(connection)
            finally:
                connection.close()
        except sqlite3.Error as exc:
            raise BackupError("database") from exc
