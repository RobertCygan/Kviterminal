"""SQLite engine with fixed connection settings (docs/DATA_MODEL.md §3.7).

Persistent vs. per-connection settings
--------------------------------------
* ``journal_mode=WAL`` is stored in the database file once set; it is
  re-asserted and verified on every connection.
* ``foreign_keys``, ``synchronous``, ``trusted_schema``, ``secure_delete`` and
  ``busy_timeout`` apply only to the connection that sets them, so they are
  set on every new connection, before any transaction starts.

Transactions
------------
The driver's implicit transaction handling is disabled and every transaction
starts with ``BEGIN IMMEDIATE``: the write lock is taken at the start, so two
writers can never read the same chain end and both extend it.
"""

from pathlib import Path
from typing import Any

from sqlalchemy import Connection, Engine, create_engine, event
from sqlalchemy.engine import URL

BUSY_TIMEOUT_MS = 5000

CONNECTION_PRAGMAS = (
    "PRAGMA foreign_keys = ON",
    "PRAGMA synchronous = FULL",
    "PRAGMA trusted_schema = OFF",
    "PRAGMA secure_delete = ON",
    f"PRAGMA busy_timeout = {BUSY_TIMEOUT_MS}",
)

EXPECTED_SETTINGS = {
    "foreign_keys": 1,
    "journal_mode": "wal",
    "synchronous": 2,  # FULL
    "trusted_schema": 0,
    "secure_delete": 1,
    "busy_timeout": BUSY_TIMEOUT_MS,
}


class SettingsError(RuntimeError):
    """A connection does not have the required SQLite settings."""


def _configure_connection(dbapi_connection: Any, _record: object) -> None:
    # Autocommit at driver level: transactions are started explicitly below.
    dbapi_connection.isolation_level = None
    cursor = dbapi_connection.cursor()
    try:
        for pragma in CONNECTION_PRAGMAS:
            cursor.execute(pragma)
        mode = cursor.execute("PRAGMA journal_mode = WAL").fetchone()[0]
        if str(mode).lower() != "wal":
            msg = "WAL journal mode could not be enabled"
            raise SettingsError(msg)
    finally:
        cursor.close()


def _begin_immediate(connection: Connection) -> None:
    connection.exec_driver_sql("BEGIN IMMEDIATE")


def create_sqlite_engine(path: Path) -> Engine:
    """Engine for one database file; dispose it to release every file handle."""
    engine = create_engine(URL.create("sqlite+pysqlite", database=str(path)))
    event.listen(engine, "connect", _configure_connection)
    event.listen(engine, "begin", _begin_immediate)
    return engine


def read_settings(connection: Connection) -> dict[str, object]:
    """Current values of the required settings on this connection."""
    values: dict[str, object] = {}
    for name in EXPECTED_SETTINGS:
        value = connection.exec_driver_sql(f"PRAGMA {name}").scalar()
        values[name] = str(value).lower() if name == "journal_mode" else value
    return values


def verify_settings(connection: Connection) -> None:
    actual = read_settings(connection)
    if actual != EXPECTED_SETTINGS:
        msg = "SQLite connection settings differ from the required values"
        raise SettingsError(msg)
