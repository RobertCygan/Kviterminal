"""Safe database initialisation and migration (docs/PHASE_02_REPORT.md §4).

Rules
-----
* An existing database is first inspected **read-only**: integrity check,
  recognised InvoiceFlow schema, known revision. Nothing is written if any
  check fails.
* A database newer than this program, a foreign SQLite file, or a corrupt file
  is refused. There is no automatic downgrade, replacement or repair.
* Before migrating an existing database, a consistent copy is made with
  SQLite's online backup API and verified.
* All migration DDL and the matching audit event run in one ``BEGIN IMMEDIATE``
  transaction. A failure rolls back the whole migration and keeps both the
  original database and the safety copy.
* A migration that rebuilds a parent table declares ``FOREIGN_KEYS_OFF = True``
  (ADR-0032). Foreign keys are then switched off for that connection before the
  transaction starts, and ``PRAGMA foreign_key_check`` must find nothing before
  it commits. Every later connection has foreign keys on again.
"""

import datetime as dt
import os
import sqlite3
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from alembic import command
from alembic.config import Config
from alembic.script import ScriptDirectory
from sqlalchemy import Connection

from invoiceflow.application.audit import AuditDraft, AuditEventType, ChainVerification
from invoiceflow.application.errors import DatabaseError
from invoiceflow.persistence.database import Database
from invoiceflow.persistence.engine import (
    EXPECTED_SETTINGS,
    SettingsError,
    create_sqlite_engine,
    read_settings,
    verify_settings,
)
from invoiceflow.persistence.repositories import SqlAuditLog

MIGRATIONS_DIR = Path(__file__).resolve().parent / "migrations"
DATABASE_FILENAME = "invoiceflow.sqlite3"
SYSTEM_ACTOR = "system"


@dataclass(frozen=True, slots=True)
class InitializationResult:
    revision: str
    created: bool
    migrated_from: str | None
    backup_path: Path | None
    audit: ChainVerification


def _alembic_config(script_location: Path) -> Config:
    config = Config()
    config.set_main_option("script_location", str(script_location))
    return config


def known_revisions(script_location: Path = MIGRATIONS_DIR) -> tuple[str, list[str]]:
    script = ScriptDirectory.from_config(_alembic_config(script_location))
    heads = script.get_heads()
    if len(heads) != 1:
        msg = "migrations must have exactly one head"
        raise RuntimeError(msg)
    return heads[0], [revision.revision for revision in script.walk_revisions()]


def needs_foreign_keys_off(current: str | None, script_location: Path = MIGRATIONS_DIR) -> bool:
    """True if a pending migration rebuilds a parent table (ADR-0032)."""
    script = ScriptDirectory.from_config(_alembic_config(script_location))
    pending = script.iterate_revisions("heads", current or "base")
    return any(getattr(revision.module, "FOREIGN_KEYS_OFF", False) for revision in pending)


def _read_only(path: Path) -> sqlite3.Connection:
    return sqlite3.connect(f"{path.as_uri()}?mode=ro", uri=True)


def inspect_database(path: Path, revisions: list[str]) -> str | None:
    """Return the stored revision, or ``None`` for an empty database.

    Raises ``DatabaseError`` for corrupt, foreign or newer databases. Opens the
    file read-only, so an unrecognised file is never modified.
    """
    try:
        connection = _read_only(path)
    except sqlite3.Error as exc:
        raise DatabaseError("DATABASE_UNAVAILABLE") from exc
    try:
        try:
            check = connection.execute("PRAGMA quick_check").fetchall()
        except sqlite3.DatabaseError as exc:
            # "file is not a database" and similar: not an InvoiceFlow database.
            raise DatabaseError("DATABASE_UNRECOGNIZED") from exc
        if check != [("ok",)]:
            raise DatabaseError("DATABASE_INTEGRITY_FAILED")
        tables = {
            row[0]
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"
            )
        }
        if not tables:
            return None
        if "alembic_version" not in tables:
            raise DatabaseError("DATABASE_UNRECOGNIZED")
        rows = connection.execute("SELECT version_num FROM alembic_version").fetchall()
        if len(rows) != 1:
            raise DatabaseError("DATABASE_UNRECOGNIZED")
        revision = rows[0][0]
        if revision not in revisions:
            raise DatabaseError("DATABASE_NEWER_SCHEMA")
        required = {"accounting_entities", "invoices", "invoice_revisions", "audit_events"}
        if not required.issubset(tables):
            raise DatabaseError("DATABASE_UNRECOGNIZED")
        return revision
    except sqlite3.Error as exc:
        raise DatabaseError("DATABASE_UNAVAILABLE") from exc
    finally:
        connection.close()


def create_safety_copy(source: Path, backup_dir: Path, revision: str, now: dt.datetime) -> Path:
    """Consistent, verified copy of ``source`` made with the SQLite backup API.

    The copy is written under a temporary name and only renamed into place once
    its integrity and revision are verified. It is not encrypted: it has the
    same confidentiality as the database itself (see docs/SECURITY.md §12).
    """
    stamp = now.astimezone(dt.UTC).strftime("%Y%m%dT%H%M%S%fZ")
    target = backup_dir / f"invoiceflow-{revision}-{stamp}.sqlite3"
    temporary = backup_dir / f".{target.name}.partial"
    try:
        backup_dir.mkdir(parents=True, exist_ok=True)
        if target.exists() or temporary.exists():
            raise DatabaseError("DATABASE_BACKUP_FAILED")
        source_connection = _read_only(source)
        try:
            target_connection = sqlite3.connect(temporary)
            try:
                source_connection.backup(target_connection)
                # The copy inherits WAL mode from the source; switch it back so
                # the copy is one self-contained file without -wal/-shm files.
                mode = target_connection.execute("PRAGMA journal_mode=DELETE").fetchone()
            finally:
                target_connection.close()
            if mode != ("delete",):
                raise DatabaseError("DATABASE_BACKUP_FAILED")
        finally:
            source_connection.close()
        check = _read_only(temporary)
        try:
            ok = check.execute("PRAGMA integrity_check").fetchall() == [("ok",)]
            stored = check.execute("SELECT version_num FROM alembic_version").fetchall()
        finally:
            check.close()
        if not ok or stored != [(revision,)]:
            raise DatabaseError("DATABASE_BACKUP_FAILED")
        os.replace(temporary, target)
        return target
    except DatabaseError:
        _remove_partial(temporary)
        raise
    except (OSError, sqlite3.Error) as exc:
        _remove_partial(temporary)
        raise DatabaseError("DATABASE_BACKUP_FAILED") from exc


def _remove_partial(temporary: Path) -> None:
    for suffix in ("", "-journal", "-wal", "-shm"):
        temporary.with_name(temporary.name + suffix).unlink(missing_ok=True)


def _upgrade(
    path: Path,
    script_location: Path,
    current: str | None,
    head: str,
    now: dt.datetime,
    backup_created: bool,
) -> None:
    engine = create_sqlite_engine(path)
    foreign_keys_off = needs_foreign_keys_off(current, script_location)
    try:
        with engine.connect() as connection:
            if foreign_keys_off:
                # Must happen outside a transaction; SQLite ignores it inside one.
                connection.connection.dbapi_connection.execute("PRAGMA foreign_keys = OFF")
            with connection.begin():
                _run_migrations(connection, script_location, current, head, now, backup_created)
                if foreign_keys_off:
                    if connection.exec_driver_sql("PRAGMA foreign_key_check").fetchall():
                        raise DatabaseError("DATABASE_INTEGRITY_FAILED")
                    expected = EXPECTED_SETTINGS | {"foreign_keys": 0}
                    if read_settings(connection) != expected:
                        msg = "SQLite connection settings differ from the required values"
                        raise SettingsError(msg)
                else:
                    verify_settings(connection)
                if not SqlAuditLog(connection).verify().valid:
                    raise DatabaseError("AUDIT_CHAIN_INVALID")
    finally:
        engine.dispose()


def _run_migrations(
    connection: Connection,
    script_location: Path,
    current: str | None,
    head: str,
    now: dt.datetime,
    backup_created: bool,
) -> None:
    config = _alembic_config(script_location)
    config.attributes["connection"] = connection
    command.upgrade(config, "head")
    if current is None:
        draft = AuditDraft(
            event_type=AuditEventType.DATABASE_CREATED,
            actor=SYSTEM_ACTOR,
            entity_id=None,
            subject_id=head,
            details={"schema_revision": head},
        )
    else:
        draft = AuditDraft(
            event_type=AuditEventType.DATABASE_MIGRATED,
            actor=SYSTEM_ACTOR,
            entity_id=None,
            subject_id=head,
            details={
                "from_revision": current,
                "to_revision": head,
                "backup_created": backup_created,
            },
        )
    # The caller verifies settings and the chain before the transaction
    # commits: a valid SQL migration may still damage existing events.
    SqlAuditLog(connection).append(draft, occurred_at=now)


def initialize_database(
    path: Path,
    backup_dir: Path,
    *,
    clock: Callable[[], dt.datetime] = lambda: dt.datetime.now(dt.UTC),
    script_location: Path = MIGRATIONS_DIR,
) -> InitializationResult:
    """Create or migrate the database at ``path`` and verify it before use."""
    if path.is_symlink() or path.parent.is_symlink():
        raise DatabaseError("DATABASE_UNAVAILABLE")
    try:
        head, revisions = known_revisions(script_location)
    except Exception as exc:
        raise DatabaseError("DATABASE_MIGRATION_FAILED") from exc
    current = inspect_database(path, revisions) if path.exists() else None
    backup_path = None
    migrated_from = None
    if current != head:
        now = clock()
        if current is not None:
            backup_path = create_safety_copy(path, backup_dir, current, now)
            migrated_from = current
        try:
            _upgrade(path, script_location, current, head, now, backup_path is not None)
        except Exception as exc:
            raise DatabaseError("DATABASE_MIGRATION_FAILED") from exc
    return InitializationResult(
        revision=head,
        created=current is None,
        migrated_from=migrated_from,
        backup_path=backup_path,
        audit=verify_database(path),
    )


def verify_database(path: Path) -> ChainVerification:
    """Check connection settings and the complete audit chain."""
    database = Database(path)
    try:
        with database.engine.connect() as connection, connection.begin():
            try:
                verify_settings(connection)
            except SettingsError as exc:
                raise DatabaseError("DATABASE_UNAVAILABLE") from exc
            result = SqlAuditLog(connection).verify()
    except DatabaseError:
        raise
    except Exception as exc:
        raise DatabaseError("DATABASE_UNAVAILABLE") from exc
    finally:
        database.close()
    if not result.valid:
        raise DatabaseError("AUDIT_CHAIN_INVALID")
    return result
