"""SQLite persistence adapters (SQLAlchemy 2.0 Core and Alembic)."""
