"""SQLite adapters for the application persistence ports.

All statements run on the caller's connection inside the unit of work's
transaction; repositories never commit.
"""

import datetime as dt
import json
from collections.abc import Callable, Iterator, Sequence
from types import MappingProxyType
from typing import Any
from uuid import UUID, uuid4

from pydantic import ValidationError
from sqlalchemy import Connection, RowMapping, and_, func, insert, select, update
from sqlalchemy.exc import IntegrityError as SqlIntegrityError

from invoiceflow.application.audit import (
    GENESIS_HASH,
    AuditDraft,
    AuditRecord,
    ChainVerification,
    chain,
    verify_chain,
)
from invoiceflow.application.backup.model import BackupRecord
from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentRecord,
    DocumentStatus,
    DocumentType,
    ImportSource,
    IntegrityStatus,
)
from invoiceflow.application.errors import (
    ConflictError,
    DataIntegrityError,
    InvoiceFlowError,
    NotFoundError,
)
from invoiceflow.application.export.model import (
    BatchStatus,
    ExportBatchRecord,
    ExportItemRecord,
    ExportMapping,
    ExportTarget,
    ItemStatus,
    columns_json,
    parse_columns,
)
from invoiceflow.application.ports import (
    BankAccounts,
    Batches,
    Decisions,
    DocumentLinks,
    EntityRecord,
    InvoiceRecord,
    Items,
    Overrides,
    ReferenceEntries,
    Suppliers,
)
from invoiceflow.application.processing_model import (
    FINISHED,
    DerivedFileRecord,
    DerivedKind,
    JobRecord,
    JobStatus,
    OcrPageRecord,
    PageRecord,
    ProcessingErrorCode,
    ProcessingStep,
)
from invoiceflow.application.reference.model import (
    AccountEntry,
    Dimension,
    DimensionEntry,
    ImportRecord,
    ReferenceData,
    ReferenceKind,
    SupplierDefaults,
    VatCodeEntry,
    VatDirection,
)
from invoiceflow.application.review.model import ApprovalRecord, Decision, OverrideRecord
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.validation.model import (
    AccountKind,
    AccountStatus,
    BankAccountRecord,
    InvoiceHeader,
    RuleId,
    Severity,
    SupplierRecord,
    ValidationFinding,
    ValidationRun,
    ValidationSummary,
)
from invoiceflow.domain.canonical import canonical_json_bytes, invoice_canonical_json, sha256_hex
from invoiceflow.domain.invoice import CanonicalInvoice, InvoiceType
from invoiceflow.persistence.schema import (
    accounting_entities,
    approvals,
    audit_events,
    backups,
    chart_of_accounts,
    derived_files,
    dimension_values,
    document_links,
    document_pages,
    documents,
    export_batches,
    export_items,
    export_mappings,
    finding_overrides,
    invoice_findings,
    invoice_revisions,
    invoices,
    ocr_pages,
    processing_jobs,
    reference_imports,
    supplier_bank_accounts,
    supplier_defaults,
    suppliers,
    validation_results,
    validation_runs,
    vat_codes,
)

INITIAL_WORKFLOW_STATUS = "draft"


class SqlEntityRepository:
    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def add(
        self,
        *,
        entity_id: UUID,
        name: str,
        org_number: str | None,
        default_currency: str,
        created_at: dt.datetime,
    ) -> EntityRecord:
        try:
            self._connection.execute(
                insert(accounting_entities).values(
                    id=entity_id,
                    name=name,
                    org_number=org_number,
                    default_currency=default_currency,
                    is_active=True,
                    created_at=created_at,
                    updated_at=created_at,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return EntityRecord(entity_id, name, org_number, default_currency, created_at)

    def get(self, entity_id: UUID) -> EntityRecord:
        row = (
            self._connection.execute(
                select(accounting_entities).where(accounting_entities.c.id == entity_id)
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise NotFoundError()
        return self._record(row)

    def list(self) -> list[EntityRecord]:
        rows = self._connection.execute(
            select(accounting_entities).order_by(
                accounting_entities.c.created_at, accounting_entities.c.id
            )
        ).mappings()
        return [self._record(row) for row in rows]

    @staticmethod
    def _record(row: RowMapping) -> EntityRecord:
        return EntityRecord(
            row["id"], row["name"], row["org_number"], row["default_currency"], row["created_at"]
        )


def _value(field: Any) -> Any:
    return None if field is None else field.value


def project(invoice: CanonicalInvoice) -> dict[str, object]:
    """Header columns derived from the canonical invoice, for queries only.

    The revision snapshot is the source of truth; these columns are rewritten
    from it in the same transaction and never edited on their own.
    """
    invoice_type = _value(invoice.invoice_type)
    return {
        "document_id": invoice.document_id,
        "schema_version": invoice.schema_version,
        "invoice_type": None if invoice_type is None else str(invoice_type),
        "invoice_number": _value(invoice.invoice_number),
        "invoice_date": _value(invoice.invoice_date),
        "due_date": _value(invoice.due_date),
        "currency": _value(invoice.currency),
        "supplier_org_number": _value(invoice.supplier.org_number),
        "net_amount": _value(invoice.totals.net_amount),
        "vat_amount": _value(invoice.totals.vat_amount),
        "rounding_amount": _value(invoice.totals.rounding_amount),
        "gross_amount": _value(invoice.totals.gross_amount),
    }


class SqlInvoiceRepository:
    """Entity-scoped access to invoices and their immutable revisions."""

    def __init__(self, connection: Connection, scope: EntityScope) -> None:
        if not isinstance(scope, EntityScope):
            msg = "an EntityScope is required"
            raise TypeError(msg)
        self._connection = connection
        self._entity_id = scope.entity_id

    def add(
        self, *, invoice_id: UUID, invoice: CanonicalInvoice, recorded_at: dt.datetime, actor: str
    ) -> InvoiceRecord:
        canonical = invoice_canonical_json(invoice)
        digest = sha256_hex(canonical)
        try:
            self._insert_revision(
                invoice_id, 1, invoice, canonical, digest, "created", recorded_at, actor
            )
            self._connection.execute(
                insert(invoices).values(
                    id=invoice_id,
                    entity_id=self._entity_id,
                    current_revision=1,
                    content_sha256=digest,
                    workflow_status=INITIAL_WORKFLOW_STATUS,
                    row_version=1,
                    created_at=recorded_at,
                    updated_at=recorded_at,
                    **project(invoice),
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return InvoiceRecord(
            invoice_id, self._entity_id, 1, digest, INITIAL_WORKFLOW_STATUS, invoice
        )

    def replace(
        self,
        *,
        invoice_id: UUID,
        invoice: CanonicalInvoice,
        expected_revision: int,
        recorded_at: dt.datetime,
        actor: str,
    ) -> InvoiceRecord:
        current = self._current_row(invoice_id)
        if current["current_revision"] != expected_revision:
            raise ConflictError()
        if invoice.document_id != current["document_id"]:
            # A revision describes the same document; moving it is not a revision.
            raise InvoiceFlowError("INVALID_INPUT", "error.invalid_input")
        canonical = invoice_canonical_json(invoice)
        digest = sha256_hex(canonical)
        if digest == current["content_sha256"]:
            return self.get(invoice_id)
        revision = expected_revision + 1
        try:
            self._insert_revision(
                invoice_id, revision, invoice, canonical, digest, "revised", recorded_at, actor
            )
            result = self._connection.execute(
                update(invoices)
                .where(
                    and_(
                        invoices.c.id == invoice_id,
                        invoices.c.entity_id == self._entity_id,
                        invoices.c.current_revision == expected_revision,
                        invoices.c.row_version == current["row_version"],
                    )
                )
                .values(
                    current_revision=revision,
                    content_sha256=digest,
                    row_version=current["row_version"] + 1,
                    updated_at=recorded_at,
                    # New content is a draft again; an approval never carries over.
                    workflow_status=INITIAL_WORKFLOW_STATUS,
                    **project(invoice),
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        if result.rowcount != 1:
            raise ConflictError()
        return InvoiceRecord(
            invoice_id, self._entity_id, revision, digest, INITIAL_WORKFLOW_STATUS, invoice
        )

    def get(self, invoice_id: UUID) -> InvoiceRecord:
        current = self._current_row(invoice_id)
        return self.get_revision(invoice_id, current["current_revision"], current)

    def get_revision(
        self, invoice_id: UUID, revision: int, current: RowMapping | None = None
    ) -> InvoiceRecord:
        if current is None:
            current = self._current_row(invoice_id)
        row = (
            self._connection.execute(
                select(invoice_revisions).where(
                    and_(
                        invoice_revisions.c.invoice_id == invoice_id,
                        invoice_revisions.c.revision == revision,
                        invoice_revisions.c.entity_id == self._entity_id,
                    )
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise NotFoundError()
        canonical = row["canonical_json"].encode("utf-8")
        if sha256_hex(canonical) != row["content_sha256"]:
            raise DataIntegrityError()
        try:
            invoice = CanonicalInvoice.model_validate_json(canonical)
        except ValidationError as exc:
            raise DataIntegrityError() from exc
        if invoice_canonical_json(invoice) != canonical:
            raise DataIntegrityError()
        if row["schema_version"] != invoice.schema_version:
            raise DataIntegrityError()
        if invoice.document_id != current["document_id"]:
            raise DataIntegrityError()
        if revision == current["current_revision"]:
            if current["content_sha256"] != row["content_sha256"]:
                raise DataIntegrityError()
            if any(current[key] != value for key, value in project(invoice).items()):
                raise DataIntegrityError()
        return InvoiceRecord(
            invoice_id,
            self._entity_id,
            revision,
            row["content_sha256"],
            current["workflow_status"],
            invoice,
        )

    def list_ids(self) -> list[UUID]:
        return list(
            self._connection.execute(
                select(invoices.c.id)
                .where(invoices.c.entity_id == self._entity_id)
                .order_by(invoices.c.created_at, invoices.c.id)
            ).scalars()
        )

    def ids_for_document(self, document_id: UUID) -> list[UUID]:
        return list(
            self._connection.execute(
                select(invoices.c.id)
                .where(
                    and_(
                        invoices.c.entity_id == self._entity_id,
                        invoices.c.document_id == document_id,
                    )
                )
                .order_by(invoices.c.created_at, invoices.c.id)
            ).scalars()
        )

    def ids_by_supplier_and_number(self, supplier_org_number: str, number: str) -> list[UUID]:
        """Invoices of this entity with the same supplier and invoice number."""
        return list(
            self._connection.execute(
                select(invoices.c.id).where(
                    and_(
                        invoices.c.entity_id == self._entity_id,
                        invoices.c.supplier_org_number == supplier_org_number,
                        invoices.c.invoice_number == number,
                    )
                )
            ).scalars()
        )

    def add_findings(
        self, invoice_id: UUID, revision: int, codes: Sequence[str], created_at: dt.datetime
    ) -> None:
        if not codes:
            return
        self._current_row(invoice_id)  # NotFoundError for a missing or foreign invoice
        try:
            self._connection.execute(
                insert(invoice_findings),
                [
                    {
                        "entity_id": self._entity_id,
                        "invoice_id": invoice_id,
                        "revision": revision,
                        "code": str(code),
                        "created_at": created_at,
                    }
                    for code in codes
                ],
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc

    def findings(self, invoice_id: UUID) -> list[tuple[int, str]]:
        rows = self._connection.execute(
            select(invoice_findings.c.revision, invoice_findings.c.code)
            .where(
                and_(
                    invoice_findings.c.invoice_id == invoice_id,
                    invoice_findings.c.entity_id == self._entity_id,
                )
            )
            .order_by(invoice_findings.c.revision, invoice_findings.c.code)
        )
        return [(row[0], row[1]) for row in rows]

    def set_status(self, invoice_id: UUID, status: str, *, expected_revision: int) -> None:
        """Change the workflow status of the current revision (compare-and-set)."""
        current = self._current_row(invoice_id)
        try:
            result = self._connection.execute(
                update(invoices)
                .where(
                    and_(
                        invoices.c.id == invoice_id,
                        invoices.c.entity_id == self._entity_id,
                        invoices.c.current_revision == expected_revision,
                        invoices.c.row_version == current["row_version"],
                    )
                )
                .values(workflow_status=status, row_version=current["row_version"] + 1)
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        if result.rowcount != 1:
            raise ConflictError()

    def headers(self) -> list[InvoiceHeader]:
        """Current header projection of every invoice of the entity (duplicate checks)."""
        rows = self._connection.execute(
            select(
                invoices.c.id,
                invoices.c.invoice_type,
                invoices.c.invoice_number,
                invoices.c.supplier_org_number,
                invoices.c.gross_amount,
                invoices.c.invoice_date,
            )
            .where(invoices.c.entity_id == self._entity_id)
            .order_by(invoices.c.created_at, invoices.c.id)
        ).mappings()
        return [
            InvoiceHeader(
                invoice_id=row["id"],
                invoice_type=None
                if row["invoice_type"] is None
                else InvoiceType(row["invoice_type"]),
                invoice_number=row["invoice_number"],
                supplier_org_number=row["supplier_org_number"],
                gross_amount=row["gross_amount"],
                invoice_date=row["invoice_date"],
            )
            for row in rows
        ]

    def _current_row(self, invoice_id: UUID) -> RowMapping:
        # Filtering by entity makes another entity's invoice indistinguishable
        # from a missing one.
        row = (
            self._connection.execute(
                select(invoices).where(
                    and_(invoices.c.id == invoice_id, invoices.c.entity_id == self._entity_id)
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise NotFoundError()
        return row

    def _insert_revision(
        self,
        invoice_id: UUID,
        revision: int,
        invoice: CanonicalInvoice,
        canonical: bytes,
        digest: str,
        change_kind: str,
        recorded_at: dt.datetime,
        actor: str,
    ) -> None:
        self._connection.execute(
            insert(invoice_revisions).values(
                invoice_id=invoice_id,
                revision=revision,
                entity_id=self._entity_id,
                schema_version=invoice.schema_version,
                canonical_json=canonical.decode("utf-8"),
                content_sha256=digest,
                change_kind=change_kind,
                recorded_at=recorded_at,
                recorded_by=actor,
            )
        )


def _document(row: RowMapping) -> DocumentRecord:
    integrity = row["integrity_status"]
    detected = row["detected_format"]
    return DocumentRecord(
        document_id=row["id"],
        entity_id=row["entity_id"],
        document_type=DocumentType(row["document_type"]),
        sha256=row["sha256"],
        size_bytes=row["size_bytes"],
        detected_format=None if detected is None else DocumentFormat(detected),
        display_name=row["display_name"],
        storage_path=row["storage_path"],
        source=ImportSource(row["source"]),
        status=DocumentStatus(row["status"]),
        imported_at=row["imported_at"],
        imported_by=row["imported_by"],
        integrity_status=None if integrity is None else IntegrityStatus(integrity),
        integrity_checked_at=row["integrity_checked_at"],
    )


class SqlDocumentRepository:
    """Entity-scoped document metadata; files live in the DocumentStore."""

    def __init__(self, connection: Connection, scope: EntityScope) -> None:
        if not isinstance(scope, EntityScope):
            msg = "an EntityScope is required"
            raise TypeError(msg)
        self._connection = connection
        self._entity_id = scope.entity_id

    def add(self, record: DocumentRecord) -> DocumentRecord:
        if record.entity_id != self._entity_id:
            raise NotFoundError()
        try:
            self._connection.execute(
                insert(documents).values(
                    id=record.document_id,
                    entity_id=self._entity_id,
                    document_type=str(record.document_type),
                    sha256=record.sha256,
                    size_bytes=record.size_bytes,
                    detected_format=None
                    if record.detected_format is None
                    else str(record.detected_format),
                    display_name=record.display_name,
                    storage_path=record.storage_path,
                    source=str(record.source),
                    status=str(record.status),
                    imported_at=record.imported_at,
                    imported_by=record.imported_by,
                    integrity_checked_at=record.integrity_checked_at,
                    integrity_status=None
                    if record.integrity_status is None
                    else str(record.integrity_status),
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return record

    def get(self, document_id: UUID) -> DocumentRecord:
        row = (
            self._connection.execute(
                select(documents).where(
                    and_(documents.c.id == document_id, documents.c.entity_id == self._entity_id)
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise NotFoundError()
        return _document(row)

    def find_by_sha256(self, sha256: str) -> DocumentRecord | None:
        row = (
            self._connection.execute(
                select(documents).where(
                    and_(documents.c.sha256 == sha256, documents.c.entity_id == self._entity_id)
                )
            )
            .mappings()
            .one_or_none()
        )
        return None if row is None else _document(row)

    def list(self) -> list[DocumentRecord]:
        rows = self._connection.execute(
            select(documents)
            .where(documents.c.entity_id == self._entity_id)
            .order_by(documents.c.imported_at.desc(), documents.c.id)
        ).mappings()
        return [_document(row) for row in rows]

    def set_type(
        self, document_id: UUID, document_type: DocumentType, *, expected: DocumentType
    ) -> DocumentRecord:
        result = self._connection.execute(
            update(documents)
            .where(
                and_(
                    documents.c.id == document_id,
                    documents.c.entity_id == self._entity_id,
                    documents.c.document_type == str(expected),
                )
            )
            .values(document_type=str(DocumentType(document_type)))
        )
        if result.rowcount != 1:
            self.get(document_id)  # NotFoundError for a missing or foreign document
            raise ConflictError()
        return self.get(document_id)

    def set_integrity(
        self, document_id: UUID, status: IntegrityStatus, *, checked_at: dt.datetime
    ) -> None:
        result = self._connection.execute(
            update(documents)
            .where(and_(documents.c.id == document_id, documents.c.entity_id == self._entity_id))
            .values(integrity_status=str(IntegrityStatus(status)), integrity_checked_at=checked_at)
        )
        if result.rowcount != 1:
            raise NotFoundError()

    def add_link(
        self,
        from_document_id: UUID,
        to_document_id: UUID,
        link_type: str,
        *,
        created_at: dt.datetime,
        actor: str,
    ) -> bool:
        """Link two documents of this entity; False if the link already exists."""
        self.get(from_document_id)
        self.get(to_document_id)
        key = (from_document_id, to_document_id, link_type)
        if key in {(link[0], link[1], link[2]) for link in self.links(from_document_id)}:
            return False
        try:
            self._connection.execute(
                insert(document_links).values(
                    entity_id=self._entity_id,
                    from_document_id=from_document_id,
                    to_document_id=to_document_id,
                    link_type=link_type,
                    created_at=created_at,
                    created_by=actor,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return True

    def links(self, document_id: UUID) -> DocumentLinks:
        """Links from ``document_id`` as (from, to, type), oldest first."""
        rows = self._connection.execute(
            select(
                document_links.c.from_document_id,
                document_links.c.to_document_id,
                document_links.c.link_type,
            )
            .where(
                and_(
                    document_links.c.entity_id == self._entity_id,
                    document_links.c.from_document_id == document_id,
                )
            )
            .order_by(document_links.c.created_at, document_links.c.to_document_id)
        )
        return [(row[0], row[1], row[2]) for row in rows]


def _job(row: RowMapping) -> JobRecord:
    error = row["error_code"]
    return JobRecord(
        job_id=row["id"],
        entity_id=row["entity_id"],
        document_id=row["document_id"],
        step=ProcessingStep(row["step"]),
        idempotency_key=row["idempotency_key"],
        attempt=row["attempt"],
        status=JobStatus(row["status"]),
        engine=row["engine"],
        engine_version=row["engine_version"],
        settings_hash=row["settings_hash"],
        queued_at=row["queued_at"],
        started_at=row["started_at"],
        finished_at=row["finished_at"],
        error_code=None if error is None else ProcessingErrorCode(error),
        page_count=row["page_count"],
        active_content=row["active_content"],
    )


class SqlProcessingRepository:
    """Entity-scoped processing jobs with their pages and derived files.

    Another entity's job reads as missing, exactly like a document.
    """

    def __init__(self, connection: Connection, scope: EntityScope) -> None:
        if not isinstance(scope, EntityScope):
            msg = "an EntityScope is required"
            raise TypeError(msg)
        self._connection = connection
        self._entity_id = scope.entity_id

    def add_job(self, job: JobRecord) -> JobRecord:
        if job.entity_id != self._entity_id:
            raise NotFoundError()
        try:
            self._connection.execute(
                insert(processing_jobs).values(
                    id=job.job_id,
                    entity_id=self._entity_id,
                    document_id=job.document_id,
                    step=str(job.step),
                    idempotency_key=job.idempotency_key,
                    attempt=job.attempt,
                    status=str(job.status),
                    engine=job.engine,
                    engine_version=job.engine_version,
                    settings_hash=job.settings_hash,
                    queued_at=job.queued_at,
                    started_at=job.started_at,
                    finished_at=job.finished_at,
                    error_code=None if job.error_code is None else str(job.error_code),
                    page_count=job.page_count,
                    active_content=job.active_content,
                )
            )
        except SqlIntegrityError as exc:
            # A second unfinished or successful job for the same key, or a
            # document that is quarantined or belongs to another entity.
            raise ConflictError() from exc
        return job

    def get_job(self, job_id: UUID) -> JobRecord:
        row = (
            self._connection.execute(
                select(processing_jobs).where(
                    and_(
                        processing_jobs.c.id == job_id,
                        processing_jobs.c.entity_id == self._entity_id,
                    )
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise NotFoundError()
        return _job(row)

    def _find(self, idempotency_key: str, statuses: Sequence[JobStatus]) -> JobRecord | None:
        row = (
            self._connection.execute(
                select(processing_jobs)
                .where(
                    and_(
                        processing_jobs.c.entity_id == self._entity_id,
                        processing_jobs.c.idempotency_key == idempotency_key,
                        processing_jobs.c.status.in_([str(status) for status in statuses]),
                    )
                )
                .order_by(processing_jobs.c.attempt.desc())
                .limit(1)
            )
            .mappings()
            .one_or_none()
        )
        return None if row is None else _job(row)

    def find_succeeded(self, idempotency_key: str) -> JobRecord | None:
        return self._find(idempotency_key, [JobStatus.SUCCEEDED])

    def find_unfinished(self, idempotency_key: str) -> JobRecord | None:
        return self._find(idempotency_key, [JobStatus.QUEUED, JobStatus.RUNNING])

    def next_attempt(self, idempotency_key: str) -> int:
        current = self._connection.execute(
            select(func.max(processing_jobs.c.attempt)).where(
                and_(
                    processing_jobs.c.entity_id == self._entity_id,
                    processing_jobs.c.idempotency_key == idempotency_key,
                )
            )
        ).scalar_one()
        return 1 if current is None else current + 1

    def latest_jobs(self, *, ocr: bool = False) -> dict[UUID, JobRecord]:
        """The most recent analysis job of every document (for display).

        With ``ocr`` the most recent OCR job instead (Phase 05); OCR is a
        second step and never hides the analysis of a document.
        """
        step_is_ocr = processing_jobs.c.step == str(ProcessingStep.OCR)
        rows = self._connection.execute(
            select(processing_jobs)
            .where(
                and_(
                    processing_jobs.c.entity_id == self._entity_id,
                    step_is_ocr if ocr else ~step_is_ocr,
                )
            )
            .order_by(processing_jobs.c.queued_at, processing_jobs.c.attempt, processing_jobs.c.id)
        ).mappings()
        latest: dict[UUID, JobRecord] = {}
        for row in rows:
            latest[row["document_id"]] = _job(row)
        return latest

    def unfinished_jobs(self) -> list[JobRecord]:
        rows = self._connection.execute(
            select(processing_jobs)
            .where(
                and_(
                    processing_jobs.c.entity_id == self._entity_id,
                    processing_jobs.c.status.in_([str(JobStatus.QUEUED), str(JobStatus.RUNNING)]),
                )
            )
            .order_by(processing_jobs.c.queued_at, processing_jobs.c.id)
        ).mappings()
        return [_job(row) for row in rows]

    def succeeded_job_ids(self) -> frozenset[UUID]:
        return frozenset(
            self._connection.execute(
                select(processing_jobs.c.id).where(
                    and_(
                        processing_jobs.c.entity_id == self._entity_id,
                        processing_jobs.c.status == str(JobStatus.SUCCEEDED),
                    )
                )
            ).scalars()
        )

    def finish_job(
        self,
        job_id: UUID,
        *,
        status: JobStatus,
        finished_at: dt.datetime,
        error_code: ProcessingErrorCode | None = None,
        page_count: int | None = None,
        active_content: bool | None = None,
    ) -> JobRecord:
        status = JobStatus(status)
        if status not in FINISHED:
            msg = "a job can only be finished with a final status"
            raise ValueError(msg)
        try:
            result = self._connection.execute(
                update(processing_jobs)
                .where(
                    and_(
                        processing_jobs.c.id == job_id,
                        processing_jobs.c.entity_id == self._entity_id,
                        processing_jobs.c.status.in_(
                            [str(JobStatus.QUEUED), str(JobStatus.RUNNING)]
                        ),
                    )
                )
                .values(
                    status=str(status),
                    finished_at=finished_at,
                    error_code=None if error_code is None else str(error_code),
                    page_count=page_count,
                    active_content=active_content,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        if result.rowcount != 1:
            self.get_job(job_id)  # NotFoundError for a missing or foreign job
            raise ConflictError()
        return self.get_job(job_id)

    def add_pages(self, pages: Sequence[PageRecord]) -> None:
        if not pages:
            return
        # Metrics exist since migration 0010; rows without them leave the columns out.
        metrics = any(page.dark_permille is not None for page in pages)
        try:
            self._connection.execute(
                insert(document_pages),
                [
                    {
                        "entity_id": self._entity_id,
                        "document_id": page.document_id,
                        "job_id": page.job_id,
                        "page_number": page.page_number,
                        "width_px": page.width_px,
                        "height_px": page.height_px,
                        "rotation_degrees": page.rotation_degrees,
                        "has_text_layer": page.has_text_layer,
                        "text_layer_chars": page.text_layer_chars,
                    }
                    | (
                        {
                            "dark_permille": page.dark_permille,
                            "center_dark_permille": page.center_dark_permille,
                        }
                        if metrics
                        else {}
                    )
                    for page in pages
                ],
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc

    def add_derived_files(self, files: Sequence[DerivedFileRecord]) -> None:
        if not files:
            return
        try:
            self._connection.execute(
                insert(derived_files),
                [
                    {
                        "id": record.file_id,
                        "entity_id": self._entity_id,
                        "document_id": record.document_id,
                        "job_id": record.job_id,
                        "page_number": record.page_number,
                        "kind": str(record.kind),
                        "storage_path": record.storage_path,
                        "sha256": record.sha256,
                        "size_bytes": record.size_bytes,
                        "producer": record.producer,
                        "created_at": record.created_at,
                    }
                    for record in files
                ],
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc

    def pages(self, job_id: UUID) -> list[PageRecord]:
        rows = self._connection.execute(
            select(document_pages)
            .where(
                and_(
                    document_pages.c.job_id == job_id,
                    document_pages.c.entity_id == self._entity_id,
                )
            )
            .order_by(document_pages.c.page_number)
        ).mappings()
        return [
            PageRecord(
                job_id=row["job_id"],
                document_id=row["document_id"],
                page_number=row["page_number"],
                width_px=row["width_px"],
                height_px=row["height_px"],
                rotation_degrees=row["rotation_degrees"],
                text_layer_chars=row["text_layer_chars"],
                dark_permille=row["dark_permille"],
                center_dark_permille=row["center_dark_permille"],
            )
            for row in rows
        ]

    def add_ocr_pages(self, pages: Sequence[OcrPageRecord]) -> None:
        if not pages:
            return
        try:
            self._connection.execute(
                insert(ocr_pages),
                [
                    {
                        "entity_id": self._entity_id,
                        "document_id": page.document_id,
                        "job_id": page.job_id,
                        "source_job_id": page.source_job_id,
                        "page_number": page.page_number,
                        "word_count": page.word_count,
                        "line_count": page.line_count,
                        "char_count": page.char_count,
                        "mean_confidence": page.mean_confidence,
                        "low_confidence_words": page.low_confidence_words,
                        "storage_path": page.storage_path,
                        "sha256": page.sha256,
                        "size_bytes": page.size_bytes,
                        "producer": page.producer,
                        "created_at": page.created_at,
                    }
                    for page in pages
                ],
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc

    def ocr_pages(self, job_id: UUID) -> list[OcrPageRecord]:
        rows = self._connection.execute(
            select(ocr_pages)
            .where(and_(ocr_pages.c.job_id == job_id, ocr_pages.c.entity_id == self._entity_id))
            .order_by(ocr_pages.c.page_number)
        ).mappings()
        return [
            OcrPageRecord(
                job_id=row["job_id"],
                document_id=row["document_id"],
                source_job_id=row["source_job_id"],
                page_number=row["page_number"],
                word_count=row["word_count"],
                line_count=row["line_count"],
                char_count=row["char_count"],
                mean_confidence=row["mean_confidence"],
                low_confidence_words=row["low_confidence_words"],
                storage_path=row["storage_path"],
                sha256=row["sha256"],
                size_bytes=row["size_bytes"],
                producer=row["producer"],
                created_at=row["created_at"],
            )
            for row in rows
        ]

    def derived_files(self, job_id: UUID) -> list[DerivedFileRecord]:
        rows = self._connection.execute(
            select(derived_files)
            .where(
                and_(
                    derived_files.c.job_id == job_id,
                    derived_files.c.entity_id == self._entity_id,
                )
            )
            .order_by(derived_files.c.page_number, derived_files.c.kind)
        ).mappings()
        return [
            DerivedFileRecord(
                file_id=row["id"],
                job_id=row["job_id"],
                document_id=row["document_id"],
                page_number=row["page_number"],
                kind=DerivedKind(row["kind"]),
                storage_path=row["storage_path"],
                sha256=row["sha256"],
                size_bytes=row["size_bytes"],
                producer=row["producer"],
                created_at=row["created_at"],
            )
            for row in rows
        ]


def _supplier(row: RowMapping) -> SupplierRecord:
    return SupplierRecord(
        supplier_id=row["id"],
        entity_id=row["entity_id"],
        name=row["name"],
        org_number=row["org_number"],
        foreign_vat_id=row["foreign_vat_id"],
        created_at=row["created_at"],
    )


def _account(row: RowMapping) -> BankAccountRecord:
    return BankAccountRecord(
        account_id=row["id"],
        supplier_id=row["supplier_id"],
        kind=AccountKind(row["account_kind"]),
        account=row["account"],
        status=AccountStatus(row["status"]),
        first_seen_invoice_id=row["first_seen_invoice_id"],
        created_at=row["created_at"],
        status_changed_at=row["status_changed_at"],
        status_changed_by=row["status_changed_by"],
    )


class SqlSupplierRepository:
    """Entity-scoped supplier register; another entity's rows read as missing."""

    def __init__(self, connection: Connection, scope: EntityScope) -> None:
        if not isinstance(scope, EntityScope):
            msg = "an EntityScope is required"
            raise TypeError(msg)
        self._connection = connection
        self._entity_id = scope.entity_id

    def find(self, *, org_number: str | None, foreign_vat_id: str | None) -> SupplierRecord | None:
        """The supplier with this organisation number, else this foreign VAT id."""
        for column, value in (
            (suppliers.c.org_number, org_number),
            (suppliers.c.foreign_vat_id, foreign_vat_id),
        ):
            if value is None:
                continue
            row = (
                self._connection.execute(
                    select(suppliers).where(
                        and_(suppliers.c.entity_id == self._entity_id, column == value)
                    )
                )
                .mappings()
                .one_or_none()
            )
            if row is not None:
                return _supplier(row)
        return None

    def get(self, supplier_id: UUID) -> SupplierRecord:
        row = (
            self._connection.execute(
                select(suppliers).where(
                    and_(suppliers.c.id == supplier_id, suppliers.c.entity_id == self._entity_id)
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise NotFoundError()
        return _supplier(row)

    def add(
        self,
        *,
        supplier_id: UUID,
        name: str,
        org_number: str | None,
        foreign_vat_id: str | None,
        created_at: dt.datetime,
        actor: str,
    ) -> SupplierRecord:
        try:
            self._connection.execute(
                insert(suppliers).values(
                    id=supplier_id,
                    entity_id=self._entity_id,
                    name=name,
                    org_number=org_number,
                    foreign_vat_id=foreign_vat_id,
                    created_at=created_at,
                    created_by=actor,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return self.get(supplier_id)

    def list(self) -> Suppliers:
        rows = self._connection.execute(
            select(suppliers)
            .where(suppliers.c.entity_id == self._entity_id)
            .order_by(suppliers.c.name, suppliers.c.id)
        ).mappings()
        return [_supplier(row) for row in rows]

    def accounts(self, supplier_id: UUID) -> BankAccounts:
        rows = self._connection.execute(
            select(supplier_bank_accounts)
            .where(
                and_(
                    supplier_bank_accounts.c.entity_id == self._entity_id,
                    supplier_bank_accounts.c.supplier_id == supplier_id,
                )
            )
            .order_by(supplier_bank_accounts.c.created_at, supplier_bank_accounts.c.account)
        ).mappings()
        return [_account(row) for row in rows]

    def get_account(self, account_id: UUID) -> BankAccountRecord:
        row = (
            self._connection.execute(
                select(supplier_bank_accounts).where(
                    and_(
                        supplier_bank_accounts.c.id == account_id,
                        supplier_bank_accounts.c.entity_id == self._entity_id,
                    )
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise NotFoundError()
        return _account(row)

    def add_account(
        self,
        *,
        account_id: UUID,
        supplier_id: UUID,
        kind: AccountKind,
        account: str,
        first_seen_invoice_id: UUID | None,
        created_at: dt.datetime,
    ) -> BankAccountRecord:
        self.get(supplier_id)
        try:
            self._connection.execute(
                insert(supplier_bank_accounts).values(
                    id=account_id,
                    entity_id=self._entity_id,
                    supplier_id=supplier_id,
                    account_kind=str(AccountKind(kind)),
                    account=account,
                    status=str(AccountStatus.UNVERIFIED),
                    first_seen_invoice_id=first_seen_invoice_id,
                    created_at=created_at,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return self.get_account(account_id)

    def set_account_status(
        self,
        account_id: UUID,
        status: AccountStatus,
        *,
        expected: AccountStatus,
        changed_at: dt.datetime,
        actor: str,
    ) -> BankAccountRecord:
        """Compare-and-set: the status changes only from ``expected``."""
        try:
            result = self._connection.execute(
                update(supplier_bank_accounts)
                .where(
                    and_(
                        supplier_bank_accounts.c.id == account_id,
                        supplier_bank_accounts.c.entity_id == self._entity_id,
                        supplier_bank_accounts.c.status == str(expected),
                    )
                )
                .values(
                    status=str(AccountStatus(status)),
                    status_changed_at=changed_at,
                    status_changed_by=actor,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        if result.rowcount != 1:
            self.get_account(account_id)  # NotFoundError for a missing or foreign account
            raise ConflictError()
        return self.get_account(account_id)


def _finding(row: RowMapping) -> ValidationFinding:
    try:
        return ValidationFinding(
            rule_id=RuleId(row["rule_id"]),
            rule_version=row["rule_version"],
            severity=Severity(row["severity"]),
            field_path=row["field_path"],
            message_key=row["message_key"],
            params=json.loads(row["params_json"]),
        )
    except (ValueError, ValidationError) as exc:
        raise DataIntegrityError() from exc


class SqlValidationRepository:
    """Append-only validation runs and findings of one entity."""

    def __init__(self, connection: Connection, scope: EntityScope) -> None:
        if not isinstance(scope, EntityScope):
            msg = "an EntityScope is required"
            raise TypeError(msg)
        self._connection = connection
        self._entity_id = scope.entity_id

    def next_run_number(self, invoice_id: UUID) -> int:
        current = self._connection.execute(
            select(func.max(validation_runs.c.run_number)).where(
                validation_runs.c.invoice_id == invoice_id
            )
        ).scalar_one()
        return 1 if current is None else current + 1

    def add_run(self, run: ValidationRun) -> ValidationRun:
        try:
            self._connection.execute(
                insert(validation_runs).values(
                    id=run.run_id,
                    entity_id=self._entity_id,
                    invoice_id=run.invoice_id,
                    revision=run.revision,
                    run_number=run.run_number,
                    ruleset_version=run.ruleset_version,
                    settings_sha256=run.settings_sha256,
                    error_count=run.summary.errors,
                    warning_count=run.summary.warnings,
                    info_count=run.summary.infos,
                    created_at=run.created_at,
                    created_by=run.created_by,
                )
            )
            if run.findings:
                self._connection.execute(
                    insert(validation_results),
                    [
                        {
                            "entity_id": self._entity_id,
                            "run_id": run.run_id,
                            "position": position,
                            "rule_id": str(finding.rule_id),
                            "rule_version": finding.rule_version,
                            "severity": str(finding.severity),
                            "field_path": finding.field_path,
                            "message_key": finding.message_key,
                            "params_json": canonical_json_bytes(dict(finding.params)).decode(
                                "utf-8"
                            ),
                        }
                        for position, finding in enumerate(run.findings, start=1)
                    ],
                )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return run

    def _run(self, row: RowMapping) -> ValidationRun:
        findings = self._connection.execute(
            select(validation_results)
            .where(
                and_(
                    validation_results.c.run_id == row["id"],
                    validation_results.c.entity_id == self._entity_id,
                )
            )
            .order_by(validation_results.c.position)
        ).mappings()
        summary = ValidationSummary(row["error_count"], row["warning_count"], row["info_count"])
        loaded = tuple(_finding(finding) for finding in findings)
        if ValidationSummary.of(loaded) != summary:
            raise DataIntegrityError()
        return ValidationRun(
            run_id=row["id"],
            invoice_id=row["invoice_id"],
            revision=row["revision"],
            run_number=row["run_number"],
            ruleset_version=row["ruleset_version"],
            settings_sha256=row["settings_sha256"],
            summary=summary,
            created_at=row["created_at"],
            created_by=row["created_by"],
            findings=loaded,
        )

    def latest(self, invoice_id: UUID) -> ValidationRun | None:
        row = (
            self._connection.execute(
                select(validation_runs)
                .where(
                    and_(
                        validation_runs.c.invoice_id == invoice_id,
                        validation_runs.c.entity_id == self._entity_id,
                    )
                )
                .order_by(validation_runs.c.run_number.desc())
                .limit(1)
            )
            .mappings()
            .one_or_none()
        )
        return None if row is None else self._run(row)

    def latest_runs(self) -> dict[UUID, ValidationRun]:
        """Latest run of every validated invoice of the entity, without findings."""
        newest = (
            select(
                validation_runs.c.invoice_id,
                func.max(validation_runs.c.run_number).label("run_number"),
            )
            .where(validation_runs.c.entity_id == self._entity_id)
            .group_by(validation_runs.c.invoice_id)
            .subquery()
        )
        rows = self._connection.execute(
            select(validation_runs).join(
                newest,
                and_(
                    validation_runs.c.invoice_id == newest.c.invoice_id,
                    validation_runs.c.run_number == newest.c.run_number,
                ),
            )
        ).mappings()
        return {
            row["invoice_id"]: ValidationRun(
                run_id=row["id"],
                invoice_id=row["invoice_id"],
                revision=row["revision"],
                run_number=row["run_number"],
                ruleset_version=row["ruleset_version"],
                settings_sha256=row["settings_sha256"],
                summary=ValidationSummary(
                    row["error_count"], row["warning_count"], row["info_count"]
                ),
                created_at=row["created_at"],
                created_by=row["created_by"],
            )
            for row in rows
        }


def _import(row: RowMapping) -> ImportRecord:
    return ImportRecord(
        import_id=row["id"],
        kind=ReferenceKind(row["kind"]),
        sha256=row["sha256"],
        row_count=row["row_count"],
        created_at=row["created_at"],
        created_by=row["created_by"],
    )


class SqlReferenceRepository:
    """Append-only reference data snapshots of one entity; the latest of each kind applies."""

    def __init__(self, connection: Connection, scope: EntityScope) -> None:
        if not isinstance(scope, EntityScope):
            msg = "an EntityScope is required"
            raise TypeError(msg)
        self._connection = connection
        self._entity_id = scope.entity_id

    def add_import(self, record: ImportRecord, entries: ReferenceEntries) -> ImportRecord:
        base = {"entity_id": self._entity_id, "import_id": record.import_id}
        if record.kind is ReferenceKind.CHART:
            table, rows = (
                chart_of_accounts,
                [
                    base
                    | {
                        "account": entry.account,
                        "name": entry.name,
                        "default_vat_code": entry.default_vat_code,
                        "is_active": entry.is_active,
                    }
                    for entry in entries
                    if isinstance(entry, AccountEntry)
                ],
            )
        elif record.kind is ReferenceKind.VAT_CODES:
            table, rows = (
                vat_codes,
                [
                    base
                    | {
                        "code": entry.code,
                        "valid_from": entry.valid_from,
                        "valid_to": entry.valid_to,
                        "rate": entry.rate,
                        "direction": str(entry.direction),
                        "saft_code": entry.saft_code,
                        "name": entry.name,
                    }
                    for entry in entries
                    if isinstance(entry, VatCodeEntry)
                ],
            )
        else:
            table, rows = (
                dimension_values,
                [
                    base
                    | {
                        "dimension": str(entry.dimension),
                        "code": entry.code,
                        "name": entry.name,
                        "is_active": entry.is_active,
                    }
                    for entry in entries
                    if isinstance(entry, DimensionEntry)
                ],
            )
        if len(rows) != len(entries) or len(rows) != record.row_count:
            raise ConflictError()
        try:
            self._connection.execute(
                insert(reference_imports).values(
                    id=record.import_id,
                    entity_id=self._entity_id,
                    kind=str(record.kind),
                    sha256=record.sha256,
                    row_count=record.row_count,
                    created_at=record.created_at,
                    created_by=record.created_by,
                )
            )
            self._connection.execute(insert(table), rows)
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return record

    def latest_imports(self) -> dict[ReferenceKind, ImportRecord]:
        rows = self._connection.execute(
            select(reference_imports)
            .where(reference_imports.c.entity_id == self._entity_id)
            .order_by(reference_imports.c.created_at, reference_imports.c.id)
        ).mappings()
        latest: dict[ReferenceKind, ImportRecord] = {}
        for row in rows:
            record = _import(row)
            latest[record.kind] = record  # ordered by time: the last one wins
        return latest

    def _rows(self, table: Any, import_id: UUID) -> list[RowMapping]:
        return list(
            self._connection.execute(
                select(table).where(
                    and_(table.c.entity_id == self._entity_id, table.c.import_id == import_id)
                )
            ).mappings()
        )

    def current(self) -> ReferenceData:
        latest = self.latest_imports()
        accounts = codes = dimensions = None
        if ReferenceKind.CHART in latest:
            accounts = MappingProxyType(
                {
                    row["account"]: AccountEntry(
                        row["account"], row["name"], row["default_vat_code"], bool(row["is_active"])
                    )
                    for row in self._rows(chart_of_accounts, latest[ReferenceKind.CHART].import_id)
                }
            )
        if ReferenceKind.VAT_CODES in latest:
            codes = tuple(
                VatCodeEntry(
                    code=row["code"],
                    rate=row["rate"],
                    direction=VatDirection(row["direction"]),
                    valid_from=row["valid_from"],
                    valid_to=row["valid_to"],
                    saft_code=row["saft_code"],
                    name=row["name"],
                )
                for row in sorted(
                    self._rows(vat_codes, latest[ReferenceKind.VAT_CODES].import_id),
                    key=lambda row: (row["code"], row["valid_from"]),
                )
            )
        if ReferenceKind.DIMENSIONS in latest:
            values = self._rows(dimension_values, latest[ReferenceKind.DIMENSIONS].import_id)
            dimensions = MappingProxyType(
                {
                    (Dimension(row["dimension"]), row["code"]): DimensionEntry(
                        Dimension(row["dimension"]),
                        row["code"],
                        row["name"],
                        bool(row["is_active"]),
                    )
                    for row in values
                }
            )
        return ReferenceData(accounts=accounts, vat_codes=codes, dimensions=dimensions)

    def defaults(self, supplier_id: UUID) -> SupplierDefaults | None:
        row = (
            self._connection.execute(
                select(supplier_defaults)
                .where(
                    and_(
                        supplier_defaults.c.entity_id == self._entity_id,
                        supplier_defaults.c.supplier_id == supplier_id,
                    )
                )
                .order_by(supplier_defaults.c.version.desc())
                .limit(1)
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            return None
        dimensions = {
            dimension: row[dimension.value]
            for dimension in Dimension
            if row[dimension.value] is not None
        }
        return SupplierDefaults(
            supplier_id=supplier_id,
            account=row["account"],
            vat_code=row["vat_code"],
            dimensions=MappingProxyType(dimensions),
            set_at=row["set_at"],
            set_by=row["set_by"],
        )

    def add_defaults(self, entry_id: UUID, defaults: SupplierDefaults) -> SupplierDefaults:
        version = self._connection.execute(
            select(func.max(supplier_defaults.c.version)).where(
                supplier_defaults.c.supplier_id == defaults.supplier_id
            )
        ).scalar_one()
        try:
            self._connection.execute(
                insert(supplier_defaults).values(
                    id=entry_id,
                    entity_id=self._entity_id,
                    supplier_id=defaults.supplier_id,
                    version=1 if version is None else version + 1,
                    account=defaults.account,
                    vat_code=defaults.vat_code,
                    cost_center=defaults.dimensions.get(Dimension.COST_CENTER),
                    department=defaults.dimensions.get(Dimension.DEPARTMENT),
                    project=defaults.dimensions.get(Dimension.PROJECT),
                    set_at=defaults.set_at,
                    set_by=defaults.set_by,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        stored = self.defaults(defaults.supplier_id)
        if stored is None:  # pragma: no cover - the insert above succeeded
            raise NotFoundError()
        return stored


class SqlReviewRepository:
    """Append-only approval decisions and finding overrides of one entity."""

    def __init__(self, connection: Connection, scope: EntityScope) -> None:
        if not isinstance(scope, EntityScope):
            msg = "an EntityScope is required"
            raise TypeError(msg)
        self._connection = connection
        self._entity_id = scope.entity_id

    def next_sequence(self, invoice_id: UUID) -> int:
        current = self._connection.execute(
            select(func.max(approvals.c.sequence)).where(approvals.c.invoice_id == invoice_id)
        ).scalar_one()
        return 1 if current is None else current + 1

    def add_decision(self, record: ApprovalRecord) -> ApprovalRecord:
        try:
            self._connection.execute(
                insert(approvals).values(
                    id=record.approval_id,
                    entity_id=self._entity_id,
                    invoice_id=record.invoice_id,
                    sequence=record.sequence,
                    revision=record.revision,
                    content_sha256=record.content_sha256,
                    decision=str(record.decision),
                    run_id=record.run_id,
                    comment=record.comment,
                    decided_at=record.decided_at,
                    decided_by=record.decided_by,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return record

    def decisions(self, invoice_id: UUID) -> Decisions:
        rows = self._connection.execute(
            select(approvals)
            .where(
                and_(approvals.c.invoice_id == invoice_id, approvals.c.entity_id == self._entity_id)
            )
            .order_by(approvals.c.sequence)
        ).mappings()
        return [
            ApprovalRecord(
                approval_id=row["id"],
                invoice_id=row["invoice_id"],
                sequence=row["sequence"],
                revision=row["revision"],
                content_sha256=row["content_sha256"],
                decision=Decision(row["decision"]),
                run_id=row["run_id"],
                comment=row["comment"],
                decided_at=row["decided_at"],
                decided_by=row["decided_by"],
            )
            for row in rows
        ]

    def add_override(self, record: OverrideRecord) -> OverrideRecord:
        try:
            self._connection.execute(
                insert(finding_overrides).values(
                    id=record.override_id,
                    entity_id=self._entity_id,
                    invoice_id=record.invoice_id,
                    revision=record.revision,
                    rule_id=str(record.rule_id),
                    field_path=record.field_path,
                    message_key=record.message_key,
                    reason=record.reason,
                    created_at=record.created_at,
                    created_by=record.created_by,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return record

    def overrides(self, invoice_id: UUID, revision: int) -> Overrides:
        rows = self._connection.execute(
            select(finding_overrides)
            .where(
                and_(
                    finding_overrides.c.invoice_id == invoice_id,
                    finding_overrides.c.entity_id == self._entity_id,
                    finding_overrides.c.revision == revision,
                )
            )
            .order_by(finding_overrides.c.created_at, finding_overrides.c.id)
        ).mappings()
        return [
            OverrideRecord(
                override_id=row["id"],
                invoice_id=row["invoice_id"],
                revision=row["revision"],
                rule_id=RuleId(row["rule_id"]),
                field_path=row["field_path"],
                message_key=row["message_key"],
                reason=row["reason"],
                created_at=row["created_at"],
                created_by=row["created_by"],
            )
            for row in rows
        ]


def _batch(row: RowMapping) -> ExportBatchRecord:
    return ExportBatchRecord(
        batch_id=row["id"],
        sequence=row["sequence"],
        target=ExportTarget(row["target"]),
        mapping_version=row["mapping_version"],
        columns=parse_columns(row["columns_json"]),
        status=BatchStatus(row["status"]),
        file_name=row["file_name"],
        file_sha256=row["file_sha256"],
        item_count=row["item_count"],
        is_reexport=bool(row["is_reexport"]),
        reexport_reason=row["reexport_reason"],
        audit_anchor=row["audit_anchor"],
        created_at=row["created_at"],
        created_by=row["created_by"],
        completed_at=row["completed_at"],
    )


def _item(row: RowMapping) -> ExportItemRecord:
    return ExportItemRecord(
        batch_id=row["batch_id"],
        invoice_id=row["invoice_id"],
        approval_id=row["approval_id"],
        revision=row["revision"],
        content_sha256=row["content_sha256"],
        target=ExportTarget(row["target"]),
        status=ItemStatus(row["status"]),
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        item_id=row["id"],
    )


class SqlExportRepository:
    """Export mappings, batches and items of one entity (Phase 10)."""

    def __init__(self, connection: Connection, scope: EntityScope) -> None:
        if not isinstance(scope, EntityScope):
            msg = "an EntityScope is required"
            raise TypeError(msg)
        self._connection = connection
        self._entity_id = scope.entity_id

    def mapping(self) -> ExportMapping | None:
        row = (
            self._connection.execute(
                select(export_mappings)
                .where(export_mappings.c.entity_id == self._entity_id)
                .order_by(export_mappings.c.version.desc())
                .limit(1)
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            return None
        return ExportMapping(row["version"], parse_columns(row["columns_json"]), row["created_at"])

    def add_mapping(self, mapping_id: UUID, mapping: ExportMapping, actor: str) -> ExportMapping:
        try:
            self._connection.execute(
                insert(export_mappings).values(
                    id=mapping_id,
                    entity_id=self._entity_id,
                    version=mapping.version,
                    columns_json=columns_json(mapping.columns),
                    created_at=mapping.created_at,
                    created_by=actor,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return mapping

    def next_sequence(self) -> int:
        current = self._connection.execute(
            select(func.max(export_batches.c.sequence)).where(
                export_batches.c.entity_id == self._entity_id
            )
        ).scalar_one()
        return 1 if current is None else current + 1

    def add_batch(self, batch: ExportBatchRecord, items: Sequence[ExportItemRecord]) -> None:
        try:
            self._connection.execute(
                insert(export_batches).values(
                    id=batch.batch_id,
                    entity_id=self._entity_id,
                    sequence=batch.sequence,
                    target=str(batch.target),
                    mapping_version=batch.mapping_version,
                    columns_json=columns_json(batch.columns),
                    status=str(batch.status),
                    file_name=batch.file_name,
                    file_sha256=batch.file_sha256,
                    item_count=batch.item_count,
                    is_reexport=int(batch.is_reexport),
                    reexport_reason=batch.reexport_reason,
                    audit_anchor=batch.audit_anchor,
                    created_at=batch.created_at,
                    created_by=batch.created_by,
                    completed_at=batch.completed_at,
                )
            )
            self._connection.execute(
                insert(export_items),
                [
                    {
                        "entity_id": self._entity_id,
                        "batch_id": item.batch_id,
                        "invoice_id": item.invoice_id,
                        "approval_id": item.approval_id,
                        "revision": item.revision,
                        "content_sha256": item.content_sha256,
                        "target": str(item.target),
                        "status": str(item.status),
                        "created_at": item.created_at,
                        "updated_at": item.updated_at,
                    }
                    for item in items
                ],
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc

    def get_batch(self, batch_id: UUID) -> ExportBatchRecord:
        row = (
            self._connection.execute(
                select(export_batches).where(
                    and_(
                        export_batches.c.id == batch_id,
                        export_batches.c.entity_id == self._entity_id,
                    )
                )
            )
            .mappings()
            .one_or_none()
        )
        if row is None:
            raise NotFoundError()
        return _batch(row)

    def batches(self) -> Batches:
        rows = self._connection.execute(
            select(export_batches)
            .where(export_batches.c.entity_id == self._entity_id)
            .order_by(export_batches.c.sequence.desc())
        ).mappings()
        return [_batch(row) for row in rows]

    def open_batches(self) -> Batches:
        rows = self._connection.execute(
            select(export_batches)
            .where(
                and_(
                    export_batches.c.entity_id == self._entity_id,
                    export_batches.c.status == str(BatchStatus.CREATED),
                )
            )
            .order_by(export_batches.c.sequence)
        ).mappings()
        return [_batch(row) for row in rows]

    def items(self, batch_id: UUID) -> Items:
        rows = self._connection.execute(
            select(export_items)
            .where(
                and_(
                    export_items.c.batch_id == batch_id,
                    export_items.c.entity_id == self._entity_id,
                )
            )
            .order_by(export_items.c.id)
        ).mappings()
        return [_item(row) for row in rows]

    def latest_items(self) -> dict[UUID, ExportItemRecord]:
        """The most recent export item of every invoice of the entity."""
        latest = (
            select(func.max(export_items.c.id))
            .where(export_items.c.entity_id == self._entity_id)
            .group_by(export_items.c.invoice_id)
        )
        rows = self._connection.execute(
            select(export_items).where(export_items.c.id.in_(latest))
        ).mappings()
        return {row["invoice_id"]: _item(row) for row in rows}

    def finish(
        self,
        batch_id: UUID,
        status: BatchStatus,
        item_status: ItemStatus,
        *,
        file_sha256: str | None,
        completed_at: dt.datetime,
    ) -> ExportBatchRecord:
        """Close an open batch and its pending items (compare-and-set on ``created``)."""
        try:
            self._connection.execute(
                update(export_items)
                .where(
                    and_(
                        export_items.c.batch_id == batch_id,
                        export_items.c.entity_id == self._entity_id,
                        export_items.c.status == str(ItemStatus.PENDING),
                    )
                )
                .values(status=str(item_status), updated_at=completed_at)
            )
            result = self._connection.execute(
                update(export_batches)
                .where(
                    and_(
                        export_batches.c.id == batch_id,
                        export_batches.c.entity_id == self._entity_id,
                        export_batches.c.status == str(BatchStatus.CREATED),
                    )
                )
                .values(status=str(status), file_sha256=file_sha256, completed_at=completed_at)
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        if result.rowcount != 1:
            raise ConflictError()
        return self.get_batch(batch_id)

    def supersede(self, item_id: int, *, updated_at: dt.datetime) -> None:
        try:
            result = self._connection.execute(
                update(export_items)
                .where(
                    and_(
                        export_items.c.id == item_id,
                        export_items.c.entity_id == self._entity_id,
                    )
                )
                .values(status=str(ItemStatus.SUPERSEDED), updated_at=updated_at)
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        if result.rowcount != 1:
            raise ConflictError()


def _backup(row: RowMapping) -> BackupRecord:
    return BackupRecord(
        backup_id=row["id"],
        file_name=row["file_name"],
        file_sha256=row["file_sha256"],
        byte_count=row["byte_count"],
        file_count=row["file_count"],
        schema_revision=row["schema_revision"],
        audit_sequence=row["audit_sequence"],
        audit_anchor=row["audit_anchor"],
        created_at=row["created_at"],
        created_by=row["created_by"],
        deleted_at=row["deleted_at"],
        deleted_by=row["deleted_by"],
    )


class SqlBackupRepository:
    """Register of backup files (Phase 12); global like the audit chain."""

    def __init__(self, connection: Connection) -> None:
        self._connection = connection

    def add(self, record: BackupRecord) -> BackupRecord:
        try:
            self._connection.execute(
                insert(backups).values(
                    id=record.backup_id,
                    file_name=record.file_name,
                    file_sha256=record.file_sha256,
                    byte_count=record.byte_count,
                    file_count=record.file_count,
                    schema_revision=record.schema_revision,
                    audit_sequence=record.audit_sequence,
                    audit_anchor=record.audit_anchor,
                    created_at=record.created_at,
                    created_by=record.created_by,
                )
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        return record

    def list(self) -> list[BackupRecord]:
        rows = self._connection.execute(
            select(backups).order_by(backups.c.created_at.desc(), backups.c.id)
        ).mappings()
        return [_backup(row) for row in rows]

    def find(self, file_sha256: str) -> BackupRecord | None:
        row = (
            self._connection.execute(select(backups).where(backups.c.file_sha256 == file_sha256))
            .mappings()
            .one_or_none()
        )
        return None if row is None else _backup(row)

    def mark_deleted(self, backup_id: UUID, *, deleted_at: dt.datetime, actor: str) -> None:
        try:
            result = self._connection.execute(
                update(backups)
                .where(and_(backups.c.id == backup_id, backups.c.deleted_at.is_(None)))
                .values(deleted_at=deleted_at, deleted_by=actor)
            )
        except SqlIntegrityError as exc:
            raise ConflictError() from exc
        if result.rowcount != 1:
            raise ConflictError()


class SqlAuditLog:
    """Append-only, globally ordered audit chain."""

    def __init__(self, connection: Connection, *, new_id: Callable[[], UUID] = uuid4) -> None:
        self._connection = connection
        self._new_id = new_id

    def append(self, draft: AuditDraft, *, occurred_at: dt.datetime) -> AuditRecord:
        if not isinstance(draft, AuditDraft):
            msg = "audit events must be AuditDraft instances"
            raise TypeError(msg)
        # The transaction holds the write lock (BEGIN IMMEDIATE), so the end of
        # the chain cannot move between this read and the insert below.
        last = self._connection.execute(
            select(audit_events.c.sequence, audit_events.c.event_hash)
            .order_by(audit_events.c.sequence.desc())
            .limit(1)
        ).one_or_none()
        sequence, prev_hash = (1, GENESIS_HASH) if last is None else (last[0] + 1, last[1])
        record = chain(
            draft,
            sequence=sequence,
            prev_hash=prev_hash,
            event_id=self._new_id(),
            occurred_at=occurred_at,
        )
        self._connection.execute(
            insert(audit_events).values(
                sequence=record.sequence,
                event_id=record.event_id,
                occurred_at=record.occurred_at,
                actor=record.actor,
                event_type=record.event_type,
                entity_id=record.entity_id,
                subject_type=record.subject_type,
                subject_id=record.subject_id,
                details_json=canonical_json_bytes(dict(record.details)).decode("utf-8"),
                hash_version=record.hash_version,
                prev_hash=record.prev_hash,
                event_hash=record.event_hash,
            )
        )
        return record

    def head(self) -> str:
        """Hash of the last event: the anchor written into backups and exports."""
        last = self._connection.execute(
            select(audit_events.c.event_hash).order_by(audit_events.c.sequence.desc()).limit(1)
        ).scalar_one_or_none()
        return GENESIS_HASH if last is None else last

    def records(self) -> Iterator[AuditRecord]:
        rows = self._connection.execute(select(audit_events).order_by(audit_events.c.sequence))
        for row in rows.mappings():
            yield AuditRecord(
                sequence=row["sequence"],
                event_id=row["event_id"],
                occurred_at=row["occurred_at"],
                actor=row["actor"],
                event_type=row["event_type"],
                entity_id=row["entity_id"],
                subject_type=row["subject_type"],
                subject_id=row["subject_id"],
                details=json.loads(row["details_json"]),
                prev_hash=row["prev_hash"],
                event_hash=row["event_hash"],
                hash_version=row["hash_version"],
            )

    def verify(self) -> ChainVerification:
        try:
            return verify_chain(self.records())
        except (ValueError, TypeError):
            # Unparseable stored values (e.g. a malformed timestamp) are tampering.
            return ChainVerification(False, 0, None, "unreadable")
