"""Database handle and unit of work for the application composition root."""

from pathlib import Path
from types import TracebackType

from sqlalchemy import Connection, Engine, RootTransaction

from invoiceflow.application.scope import EntityScope
from invoiceflow.persistence.engine import create_sqlite_engine, read_settings
from invoiceflow.persistence.repositories import (
    SqlAuditLog,
    SqlBackupRepository,
    SqlDocumentRepository,
    SqlEntityRepository,
    SqlExportRepository,
    SqlInvoiceRepository,
    SqlProcessingRepository,
    SqlReferenceRepository,
    SqlReviewRepository,
    SqlSupplierRepository,
    SqlValidationRepository,
)


class SqlUnitOfWork:
    """One ``BEGIN IMMEDIATE`` transaction; commit is explicit, rollback is the default.

    Leaving the ``with`` block without ``commit()`` - normally or through an
    exception - rolls back every change made through the repositories,
    including audit events. The connection is always returned and closed.
    """

    def __init__(self, engine: Engine) -> None:
        self._engine = engine
        self._connection: Connection | None = None
        self._transaction: RootTransaction | None = None

    def __enter__(self) -> "SqlUnitOfWork":
        if self._connection is not None:
            msg = "a unit of work can only be used once"
            raise RuntimeError(msg)
        self._connection = self._engine.connect()
        try:
            self._transaction = self._connection.begin()
        except BaseException:
            self._connection.close()
            raise
        self.entities = SqlEntityRepository(self._connection)
        self.audit = SqlAuditLog(self._connection)
        self.backups = SqlBackupRepository(self._connection)
        return self

    def invoices(self, scope: EntityScope) -> SqlInvoiceRepository:
        return SqlInvoiceRepository(self._active_connection(), scope)

    def documents(self, scope: EntityScope) -> SqlDocumentRepository:
        return SqlDocumentRepository(self._active_connection(), scope)

    def processing(self, scope: EntityScope) -> SqlProcessingRepository:
        return SqlProcessingRepository(self._active_connection(), scope)

    def suppliers(self, scope: EntityScope) -> SqlSupplierRepository:
        return SqlSupplierRepository(self._active_connection(), scope)

    def validations(self, scope: EntityScope) -> SqlValidationRepository:
        return SqlValidationRepository(self._active_connection(), scope)

    def references(self, scope: EntityScope) -> SqlReferenceRepository:
        return SqlReferenceRepository(self._active_connection(), scope)

    def reviews(self, scope: EntityScope) -> SqlReviewRepository:
        return SqlReviewRepository(self._active_connection(), scope)

    def exports(self, scope: EntityScope) -> SqlExportRepository:
        return SqlExportRepository(self._active_connection(), scope)

    def commit(self) -> None:
        if self._transaction is None or not self._transaction.is_active:
            msg = "no active transaction to commit"
            raise RuntimeError(msg)
        self._transaction.commit()

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        try:
            if self._transaction is not None and self._transaction.is_active:
                self._transaction.rollback()
        finally:
            if self._connection is not None:
                self._connection.close()
            self._transaction = None

    def _active_connection(self) -> Connection:
        if self._connection is None or self._transaction is None:
            msg = "unit of work is not active"
            raise RuntimeError(msg)
        if not self._transaction.is_active:
            msg = "unit of work is already committed"
            raise RuntimeError(msg)
        return self._connection


class Database:
    """Owns the engine for one database file."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.engine = create_sqlite_engine(path)

    def unit_of_work(self) -> SqlUnitOfWork:
        return SqlUnitOfWork(self.engine)

    def settings(self) -> dict[str, object]:
        with self.engine.connect() as connection, connection.begin():
            return read_settings(connection)

    def close(self) -> None:
        """Release all pooled connections so the files can be moved or deleted."""
        self.engine.dispose()
