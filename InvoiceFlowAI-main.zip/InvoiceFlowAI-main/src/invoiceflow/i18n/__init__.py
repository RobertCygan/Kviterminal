"""Strict translation lookup with named parameters."""

from invoiceflow.i18n.catalog_nb_no import CATALOG


def t(key: str, **params: object) -> str:
    """Fail on missing translations or missing formatting arguments."""
    return CATALOG[key].format(**params)
