"""Exact Norwegian number and date formatting without Qt or floats."""

from datetime import date, datetime
from decimal import ROUND_HALF_UP, Decimal, localcontext


def _decimal(value: Decimal | int) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (Decimal, int)):
        raise TypeError("Expected Decimal or int")
    result = Decimal(value)
    if not result.is_finite():
        raise ValueError("Expected a finite number")
    if abs(result.adjusted()) > 1000:
        raise ValueError("Number exceeds display limit")
    return result


def format_amount(value: Decimal | int) -> str:
    """Round half up and use a nonbreaking space as thousands separator."""
    number = _decimal(value)
    with localcontext() as context:
        context.prec = max(28, len(number.as_tuple().digits) + abs(number.adjusted()) + 4)
        rounded = number.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return format(rounded, ",.2f").replace(",", "\u00a0").replace(".", ",")


def format_percent(value: Decimal | int) -> str:
    """Format an exact percentage without losing fractional digits."""
    text = format(_decimal(value), "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text.replace(".", ",") + "\u00a0%"


def format_date(value: date) -> str:
    """Accept a calendar date only, avoiding accidental timezone conversion."""
    if not isinstance(value, date) or isinstance(value, datetime):
        raise TypeError("Expected date")
    return f"{value.day:02d}.{value.month:02d}.{value.year:04d}"
