"""Page analysis vocabulary, limits and the worker result contracts (Phase 04).

An isolated worker process (ADR-0010) parses one untrusted original and reports
what it found as JSON. The main process accepts that report only after it has
been validated against the models in this module, so a compromised or
confused worker cannot smuggle fields, paths or inconsistent counts into the
database. Nothing here performs I/O.
"""

import datetime as dt
import re
from dataclasses import dataclass
from enum import StrEnum
from typing import Annotated, Literal, Self
from uuid import UUID

from pydantic import Field, StringConstraints, model_validator

from invoiceflow.domain.base import ContractModel
from invoiceflow.domain.canonical import canonical_json_bytes, sha256_hex

RESULT_VERSION = 1
# Page analysis also measures how dark each page is (Phase 11a). The suffix is
# part of the engine version, so documents analysed before it are analysed again.
PAGE_METRICS_VERSION = "side1"
MAX_PERMILLE = 1000
# Absolute ceilings; the configurable limits below must stay inside them.
MAX_PAGES_CEILING = 1000
MAX_PIXELS_CEILING = 200_000_000
MAX_DIMENSION_PX = 100_000
MAX_CHARS_CEILING = 1_000_000
MIN_DPI = 72
MAX_DPI = 600  # docs/SECURITY.md §8.1


class ProcessingStep(StrEnum):
    """Page count, text layer with positions and page images in one worker run."""

    PAGE_ANALYSIS = "page_analysis"
    EHF_EXTRACTION = "ehf_extraction"  # Phase 15: EHF XML to the canonical invoice
    OCR = "ocr"  # Phase 05: text of the page images without a text layer


class JobStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    TIMED_OUT = "timed_out"
    CANCELLED = "cancelled"


FINISHED = frozenset(
    {JobStatus.SUCCEEDED, JobStatus.FAILED, JobStatus.TIMED_OUT, JobStatus.CANCELLED}
)


class ProcessingErrorCode(StrEnum):
    """Stable reasons; never free text from the document or a library message."""

    ENCRYPTED = "encrypted"
    CORRUPT = "corrupt"
    NO_PAGES = "no_pages"
    TOO_MANY_PAGES = "too_many_pages"
    PAGE_TOO_LARGE = "page_too_large"
    TOO_MUCH_TEXT = "too_much_text"
    OUTPUT_TOO_LARGE = "output_too_large"
    UNSUPPORTED_FORMAT = "unsupported_format"
    TIMED_OUT = "timed_out"
    MEMORY_LIMIT = "memory_limit"
    WORKER_CRASHED = "worker_crashed"
    INVALID_RESULT = "invalid_result"
    SOURCE_CHANGED = "source_changed"
    SOURCE_MISSING = "source_missing"
    STORAGE_FAILED = "storage_failed"
    INTERRUPTED = "interrupted"
    CANCELLED = "cancelled"
    INVALID_XML = "invalid_xml"
    UNSUPPORTED_VERSION = "unsupported_version"
    TOO_MANY_LINES = "too_many_lines"
    TOO_MANY_ATTACHMENTS = "too_many_attachments"
    ATTACHMENT_TOO_LARGE = "attachment_too_large"
    OCR_FAILED = "ocr_failed"


class DerivedKind(StrEnum):
    PAGE_RENDER = "page_render"
    TEXT_LAYER = "text_layer"


@dataclass(frozen=True, slots=True)
class ProcessingLimits:
    """Defaults from docs/SECURITY.md §8.1; tests scale the time and memory down."""

    max_pages: int = 100
    max_pixels: int = 100_000_000
    dpi: int = 300
    timeout_seconds: float = 120.0
    memory_bytes: int = 2 * 1024 * 1024 * 1024
    max_chars_per_page: int = 200_000
    max_output_bytes: int = 1024 * 1024 * 1024

    def __post_init__(self) -> None:
        checks = (
            1 <= self.max_pages <= MAX_PAGES_CEILING,
            1 <= self.max_pixels <= MAX_PIXELS_CEILING,
            MIN_DPI <= self.dpi <= MAX_DPI,
            0 < self.timeout_seconds <= 3600,
            64 * 1024 * 1024 <= self.memory_bytes <= 16 * 1024 * 1024 * 1024,
            0 <= self.max_chars_per_page <= MAX_CHARS_CEILING,
            1 <= self.max_output_bytes <= 16 * 1024 * 1024 * 1024,
        )
        if not all(checks):
            msg = "processing limits outside the allowed range"
            raise ValueError(msg)

    def settings_hash(self) -> str:
        """Hash of every setting that changes the output (not time or memory)."""
        return sha256_hex(
            canonical_json_bytes(
                {
                    "result_version": RESULT_VERSION,
                    "dpi": self.dpi,
                    "max_pages": self.max_pages,
                    "max_pixels": self.max_pixels,
                    "max_chars_per_page": self.max_chars_per_page,
                    "render_format": "png",
                }
            )
        )


def render_name(page_number: int) -> str:
    return f"page-{page_number:04d}.png"


def text_name(page_number: int) -> str:
    return f"text-{page_number:04d}.json"


_Hex64 = Annotated[str, StringConstraints(pattern=r"^[0-9a-f]{64}$")]
_Engine = Annotated[str, StringConstraints(pattern=r"^[a-z0-9]{1,16}$")]
_Version = Annotated[str, StringConstraints(pattern=r"^[0-9A-Za-z.+-]{1,32}$")]
_PageNumber = Annotated[int, Field(strict=True, ge=1, le=MAX_PAGES_CEILING)]
_Pixels = Annotated[int, Field(strict=True, ge=1, le=MAX_DIMENSION_PX)]
_Unit = Annotated[float, Field(strict=True, ge=0.0, le=1.0, allow_inf_nan=False)]
_Permille = Annotated[int, Field(strict=True, ge=0, le=MAX_PERMILLE)]


class PageResult(ContractModel):
    """One page as reported by the worker; files are named, never pathed."""

    page_number: _PageNumber
    width_px: _Pixels
    height_px: _Pixels
    rotation_degrees: Literal[0, 90, 180, 270]
    text_chars: Annotated[int, Field(strict=True, ge=0, le=MAX_CHARS_CEILING)]
    render_file: str
    text_file: str | None
    # Share of dark pixels in the whole page and in its central area (Phase 11a).
    dark_permille: _Permille
    center_dark_permille: _Permille

    @model_validator(mode="after")
    def _names_follow_page_number(self) -> Self:
        if self.render_file != render_name(self.page_number):
            raise ValueError("unexpected render file name")
        expected_text = text_name(self.page_number) if self.text_chars else None
        if self.text_file != expected_text:
            raise ValueError("unexpected text file name")
        return self


class WorkerResult(ContractModel):
    """The complete report of one worker run, validated before use."""

    result_version: Literal[1]
    status: Literal["ok", "error"]
    error_code: ProcessingErrorCode | None = None
    engine: _Engine
    engine_version: _Version
    sha256: _Hex64
    page_count: Annotated[int, Field(strict=True, ge=0, le=MAX_PAGES_CEILING)] = 0
    active_content: Annotated[bool, Field(strict=True)] = False
    pages: tuple[PageResult, ...] = ()

    @model_validator(mode="after")
    def _consistent(self) -> Self:
        if self.status == "error":
            if self.error_code is None or self.pages:
                raise ValueError("an error result has a code and no pages")
            return self
        if self.error_code is not None or self.page_count < 1:
            raise ValueError("a successful result has pages and no error code")
        numbers = [page.page_number for page in self.pages]
        if numbers != list(range(1, self.page_count + 1)):
            raise ValueError("pages must be numbered 1..page_count")
        return self


class TextLayer(ContractModel):
    """Text of one page with one box per character, normalised to 0-1.

    Boxes are ``(x0, y0, x1, y1)`` in the coordinate system of the rendered
    page image (origin top left), so later phases can relate characters to
    pixels without knowing the PDF page geometry.
    """

    result_version: Literal[1]
    page_number: _PageNumber
    text: Annotated[str, StringConstraints(max_length=MAX_CHARS_CEILING)]
    boxes: tuple[tuple[_Unit, _Unit, _Unit, _Unit], ...]

    @model_validator(mode="after")
    def _one_box_per_character(self) -> Self:
        if len(self.boxes) != len(self.text):
            raise ValueError("one box per character is required")
        for x0, y0, x1, y1 in self.boxes:
            if x0 > x1 or y0 > y1:
                raise ValueError("box corners are out of order")
        return self


def idempotency_key(
    document_id: UUID, step: ProcessingStep, engine: str, engine_version: str, settings_hash: str
) -> str:
    """Same document, step, engine version and settings means the same output."""
    return sha256_hex(
        canonical_json_bytes(
            {
                "document_id": str(document_id),
                "step": str(step),
                "engine": engine,
                "engine_version": engine_version,
                "settings_hash": settings_hash,
            }
        )
    )


@dataclass(frozen=True, slots=True)
class JobRecord:
    job_id: UUID
    entity_id: UUID
    document_id: UUID
    step: ProcessingStep
    idempotency_key: str
    attempt: int
    status: JobStatus
    engine: str
    engine_version: str
    settings_hash: str
    queued_at: dt.datetime
    started_at: dt.datetime | None = None
    finished_at: dt.datetime | None = None
    error_code: ProcessingErrorCode | None = None
    page_count: int | None = None
    active_content: bool | None = None

    @property
    def producer(self) -> str:
        return f"{self.engine}/{self.engine_version}"


@dataclass(frozen=True, slots=True)
class PageRecord:
    job_id: UUID
    document_id: UUID
    page_number: int
    width_px: int
    height_px: int
    rotation_degrees: int
    text_layer_chars: int
    # None for pages analysed before Phase 11a.
    dark_permille: int | None = None
    center_dark_permille: int | None = None

    @property
    def has_text_layer(self) -> bool:
        return self.text_layer_chars > 0


@dataclass(frozen=True, slots=True)
class DerivedFileRecord:
    file_id: UUID
    job_id: UUID
    document_id: UUID
    page_number: int
    kind: DerivedKind
    storage_path: str
    sha256: str
    size_bytes: int
    producer: str
    created_at: dt.datetime


@dataclass(frozen=True, slots=True)
class ProcessingRecovery:
    """What startup reconciliation found; derived files are moved, never deleted."""

    interrupted: int = 0
    work_removed: int = 0
    derived_moved: int = 0
    failed: int = 0


# -- Phase 15: EHF ----------------------------------------------------------------

EHF_PARSER_VERSION = "1.0"
MAX_EHF_ATTACHMENTS = 20
MAX_ATTACHMENT_BYTES = 50 * 1024 * 1024


class InvoiceFindingCode(StrEnum):
    """Deviations recorded when an invoice revision is registered (flags, not errors)."""

    LINE_SUM_MISMATCH = "line_sum_mismatch"
    NET_MISMATCH = "net_mismatch"
    VAT_MISMATCH = "vat_mismatch"
    GROSS_MISMATCH = "gross_mismatch"
    PAYABLE_MISMATCH = "payable_mismatch"
    CURRENCY_MISMATCH = "currency_mismatch"
    NEGATIVE_TOTAL = "negative_total"
    WRONG_RECIPIENT = "wrong_recipient"
    MISSING_RECIPIENT = "missing_recipient"
    POSSIBLE_DUPLICATE = "possible_duplicate"
    UNREADABLE_VALUE = "unreadable_value"
    MISSING_REQUIRED = "missing_required"
    EXTERNAL_ATTACHMENT = "external_attachment"
    ATTACHMENT_REFUSED = "attachment_refused"


def attachment_name(index: int) -> str:
    return f"attachment-{index:02d}.bin"


_Amount = Annotated[str, StringConstraints(pattern=r"^[+-]?[0-9]{1,15}(\.[0-9]{1,6})?$")]


class EhfMonetary(ContractModel):
    """Amounts as written in the file, for the arithmetic checks in the main process."""

    line_sum: _Amount | None = None  # sum of the line amounts, computed by the worker
    line_extension: _Amount | None = None
    allowance_total: _Amount | None = None
    charge_total: _Amount | None = None
    tax_exclusive: _Amount | None = None
    tax_amount: _Amount | None = None
    tax_subtotal_sum: _Amount | None = None
    tax_inclusive: _Amount | None = None
    prepaid: _Amount | None = None
    rounding: _Amount | None = None
    payable: _Amount | None = None
    currencies: tuple[Annotated[str, StringConstraints(pattern=r"^[A-Z]{3}$")], ...] = Field(
        default=(), max_length=10
    )


class EhfAttachment(ContractModel):
    file: str
    filename: Annotated[str, StringConstraints(min_length=1, max_length=255)] | None = None
    mime_code: Annotated[str, StringConstraints(min_length=1, max_length=100)] | None = None
    size_bytes: Annotated[int, Field(strict=True, ge=1, le=MAX_ATTACHMENT_BYTES)]


class EhfReport(ContractModel):
    """The worker's report for one EHF file. ``invoice`` is validated separately."""

    result_version: Literal[1]
    status: Literal["ok", "error"]
    error_code: ProcessingErrorCode | None = None
    engine: _Engine
    engine_version: _Version
    sha256: _Hex64
    invoice: dict[str, object] | None = None
    monetary: EhfMonetary | None = None
    attachments: tuple[EhfAttachment, ...] = Field(default=(), max_length=MAX_EHF_ATTACHMENTS)
    unreadable_values: Annotated[int, Field(strict=True, ge=0)] = 0
    external_attachments: Annotated[int, Field(strict=True, ge=0)] = 0

    @model_validator(mode="after")
    def _consistent(self) -> Self:
        if self.status == "error":
            if self.error_code is None or self.invoice is not None or self.attachments:
                raise ValueError("an error report has a code and nothing else")
            return self
        if self.error_code is not None or self.invoice is None or self.monetary is None:
            raise ValueError("a successful report has an invoice and amounts")
        names = [attachment.file for attachment in self.attachments]
        if names != [attachment_name(index) for index in range(1, len(names) + 1)]:
            raise ValueError("attachments must be numbered 01..n")
        return self


# -- Phase 05: OCR -----------------------------------------------------------------

OCR_ENGINE = "tesseract"
# Version of our OCR output format and settings; part of the engine version.
OCR_FORMAT_VERSION = "ocr1"
MAX_OCR_WORDS = 20_000
MAX_WORD_CHARS = 100
MAX_CONFIDENCE = 100

_Language = Annotated[str, StringConstraints(pattern=r"^[a-z]{3}(\+[a-z]{3}){0,2}$")]
_Count = Annotated[int, Field(strict=True, ge=0, le=MAX_OCR_WORDS)]
_Confidence = Annotated[int, Field(strict=True, ge=0, le=MAX_CONFIDENCE)]


def ocr_name(page_number: int) -> str:
    return f"ocr-{page_number:04d}.json"


def ocr_input_name(page_number: int) -> str:
    return f"input-{page_number:04d}.png"


@dataclass(frozen=True, slots=True)
class OcrSettings:
    """Everything besides the engine that changes the recognised text."""

    language: str = "nor"
    page_segmentation: int = 3  # Tesseract: fully automatic layout, no OSD
    low_confidence: int = 60  # words below this are counted as uncertain

    def __post_init__(self) -> None:
        checks = (
            re.fullmatch(r"[a-z]{3}(\+[a-z]{3}){0,2}", self.language) is not None,
            self.page_segmentation in (1, 3, 4, 6, 11, 12),
            0 < self.low_confidence <= MAX_CONFIDENCE,
        )
        if not all(checks):
            msg = "OCR settings outside the allowed range"
            raise ValueError(msg)

    def settings_hash(self, limits: ProcessingLimits) -> str:
        return sha256_hex(
            canonical_json_bytes(
                {
                    "result_version": RESULT_VERSION,
                    "format": OCR_FORMAT_VERSION,
                    "language": self.language,
                    "page_segmentation": self.page_segmentation,
                    "low_confidence": self.low_confidence,
                    "page_analysis": limits.settings_hash(),
                }
            )
        )


class OcrWord(ContractModel):
    """One recognised word; the box is normalised to the page image (origin top left)."""

    text: Annotated[str, StringConstraints(min_length=1, max_length=MAX_WORD_CHARS)]
    box: tuple[_Unit, _Unit, _Unit, _Unit]
    confidence: _Confidence
    line: _Count  # index of the line on the page, in reading order

    @model_validator(mode="after")
    def _ordered_box(self) -> Self:
        x0, y0, x1, y1 = self.box
        if x0 > x1 or y0 > y1:
            raise ValueError("box corners are out of order")
        return self


class OcrLayer(ContractModel):
    """The words of one page in reading order, grouped into numbered lines."""

    result_version: Literal[1]
    page_number: _PageNumber
    language: _Language
    words: tuple[OcrWord, ...] = Field(default=(), max_length=MAX_OCR_WORDS)

    @model_validator(mode="after")
    def _lines_in_order(self) -> Self:
        previous = 0
        for index, word in enumerate(self.words):
            if (index == 0 and word.line != 0) or word.line not in (previous, previous + 1):
                raise ValueError("lines must be numbered 0..n in order")
            previous = word.line
        return self

    @property
    def line_count(self) -> int:
        return self.words[-1].line + 1 if self.words else 0

    def text(self) -> str:
        """Words joined by spaces, lines by line breaks."""
        lines: list[list[str]] = [[] for _ in range(self.line_count)]
        for word in self.words:
            lines[word.line].append(word.text)
        return "\n".join(" ".join(line) for line in lines)

    def mean_confidence(self) -> int:
        if not self.words:
            return 0
        return round(sum(word.confidence for word in self.words) / len(self.words))


class OcrPageResult(ContractModel):
    page_number: _PageNumber
    file: str
    word_count: _Count
    line_count: _Count
    char_count: Annotated[int, Field(strict=True, ge=0, le=MAX_CHARS_CEILING)]
    mean_confidence: _Confidence
    low_confidence_words: _Count

    @model_validator(mode="after")
    def _consistent(self) -> Self:
        if self.file != ocr_name(self.page_number):
            raise ValueError("unexpected OCR file name")
        if self.line_count > self.word_count or self.low_confidence_words > self.word_count:
            raise ValueError("inconsistent word counts")
        return self


class OcrReport(ContractModel):
    """The worker's report for the OCR of one document's page images."""

    result_version: Literal[1]
    status: Literal["ok", "error"]
    error_code: ProcessingErrorCode | None = None
    engine: _Engine
    engine_version: _Version
    sha256: _Hex64
    pages: tuple[OcrPageResult, ...] = Field(default=(), max_length=MAX_PAGES_CEILING)

    @model_validator(mode="after")
    def _consistent(self) -> Self:
        if self.status == "error":
            if self.error_code is None or self.pages:
                raise ValueError("an error report has a code and no pages")
            return self
        if self.error_code is not None or not self.pages:
            raise ValueError("a successful report has pages and no error code")
        numbers = [page.page_number for page in self.pages]
        if numbers != sorted(set(numbers)):
            raise ValueError("pages must be in increasing order")
        return self


class TextSource(StrEnum):
    TEXT_LAYER = "text_layer"  # written into the PDF
    OCR = "ocr"  # recognised from the page image (Phase 05)
    NONE = "none"  # blank, a separator sheet, or not recognised


@dataclass(frozen=True, slots=True)
class PageText:
    """The text of one page for display; ``text`` is ``None`` if its file is unreadable."""

    page_number: int
    source: TextSource
    text: str | None
    mean_confidence: int | None = None


@dataclass(frozen=True, slots=True)
class OcrPageRecord:
    """One recognised page: counts in the database, the words in a derived file."""

    job_id: UUID
    document_id: UUID
    source_job_id: UUID  # the page analysis whose page image was read
    page_number: int
    word_count: int
    line_count: int
    char_count: int
    mean_confidence: int
    low_confidence_words: int
    storage_path: str
    sha256: str
    size_bytes: int
    producer: str
    created_at: dt.datetime
