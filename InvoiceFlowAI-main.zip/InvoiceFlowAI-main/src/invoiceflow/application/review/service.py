"""Review, correction and approval of invoices (Phase 09, ADR-0035).

Every decision is bound to one revision and its content hash. Approval
validates the current revision again in the same transaction, so it can never
rely on stale findings. Findings BANK-001 and DUP-001 cannot be overridden.
"""

import datetime as dt
import unicodedata
from collections.abc import Callable
from dataclasses import dataclass
from uuid import UUID, uuid4

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.errors import ConflictError, InvoiceFlowError
from invoiceflow.application.ports import (
    DerivedStore,
    InvoiceRecord,
    UnitOfWork,
    UnitOfWorkFactory,
)
from invoiceflow.application.processing_model import DerivedKind, JobStatus, ProcessingStep
from invoiceflow.application.review.editing import apply_edit
from invoiceflow.application.review.model import (
    MAX_REASON,
    MIN_REASON,
    NON_OVERRIDABLE,
    ApprovalRecord,
    Decision,
    OverrideRecord,
    WorkflowStatus,
)
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import revise_in, utc_now
from invoiceflow.application.validation.model import (
    Severity,
    ValidationFinding,
    ValidationRun,
)
from invoiceflow.application.validation.service import USER_ACTOR, ValidationService

MAX_PREVIEW_BYTES = 64 * 1024 * 1024


class ReviewError(InvoiceFlowError):
    """A review action was refused; ``reason`` is a stable code."""

    def __init__(self, reason: str, **params: object) -> None:
        super().__init__("REVIEW_REFUSED", f"review.error.{reason}", **params)
        self.reason = reason


def _open_for_review(record: InvoiceRecord, expected_revision: int) -> None:
    """The page's revision is current, and the invoice is not exported (Phase 10)."""
    if record.revision != expected_revision:
        raise ConflictError()
    if record.workflow_status == WorkflowStatus.EXPORTED:
        raise ReviewError("exported")


def _finding_key(finding: ValidationFinding) -> tuple[str, str | None, str]:
    return (finding.rule_id.value, finding.field_path, finding.message_key)


def _user_text(text: str | None, minimum: int, maximum: int, reason: str) -> str | None:
    """A person's own text: trimmed, within limits, without control characters."""
    if text is None or not text.strip():
        if minimum:
            raise ReviewError(reason)
        return None
    value = text.strip()
    if not minimum <= len(value) <= maximum:
        raise ReviewError(reason)
    allowed = {"\n", "\t"}
    if any(c not in allowed and unicodedata.category(c) in ("Cc", "Cf") for c in value):
        raise ReviewError(reason)
    return value


@dataclass(frozen=True, slots=True)
class ReviewView:
    """Everything the review page shows for one invoice."""

    record: InvoiceRecord
    run: ValidationRun | None
    overridden: frozenset[tuple[str, str | None, str]]
    decisions: tuple[ApprovalRecord, ...]
    revisions: tuple[InvoiceRecord, ...]

    def is_overridden(self, finding: ValidationFinding) -> bool:
        return _finding_key(finding) in self.overridden


def open_errors(
    run: ValidationRun, overridden: frozenset[tuple[str, str | None, str]]
) -> list[ValidationFinding]:
    """Error findings that still block approval."""
    return [
        finding
        for finding in run.findings
        if finding.severity is Severity.ERROR
        and (finding.rule_id in NON_OVERRIDABLE or _finding_key(finding) not in overridden)
    ]


class ReviewService:
    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        validation: ValidationService,
        *,
        derived: DerivedStore | None = None,
        clock: Callable[[], dt.datetime] = utc_now,
        new_id: Callable[[], UUID] = uuid4,
    ) -> None:
        self._uow_factory = uow_factory
        self._validation = validation
        self._derived = derived
        self._clock = clock
        self._new_id = new_id

    # --- reading -----------------------------------------------------------------------

    def view(self, scope: EntityScope, invoice_id: UUID) -> ReviewView:
        with self._uow_factory() as uow:
            invoices = uow.invoices(scope)
            record = invoices.get(invoice_id)
            run = uow.validations(scope).latest(invoice_id)
            if run is not None and run.revision != record.revision:
                run = None
            reviews = uow.reviews(scope)
            overridden = frozenset(o.key() for o in reviews.overrides(invoice_id, record.revision))
            revisions = tuple(
                invoices.get_revision(invoice_id, number)
                for number in range(1, record.revision + 1)
            )
            return ReviewView(
                record, run, overridden, tuple(reviews.decisions(invoice_id)), revisions
            )

    def preview(self, scope: EntityScope, invoice_id: UUID) -> bytes | None:
        """PNG of the first page of the invoice's PDF view, if one was analysed (F04).

        The invoice's own document comes first, then its attachments. The file
        is returned only if its hash still matches the database.
        """
        if self._derived is None:
            return None
        with self._uow_factory() as uow:
            document_id = uow.invoices(scope).get(invoice_id).invoice.document_id
            links = uow.documents(scope).links(document_id)
            candidates = [document_id, *(to for _, to, kind in links if kind == "attachment")]
            processing = uow.processing(scope)
            jobs = processing.latest_jobs()
            for candidate in candidates:
                job = jobs.get(candidate)
                if job is None or job.status is not JobStatus.SUCCEEDED:
                    continue
                if job.step is not ProcessingStep.PAGE_ANALYSIS:
                    continue
                for derived in processing.derived_files(job.job_id):
                    if derived.page_number == 1 and derived.kind is DerivedKind.PAGE_RENDER:
                        data = self._derived.read_published(
                            derived.storage_path, derived.sha256, MAX_PREVIEW_BYTES
                        )
                        if data is not None:
                            return data
        return None

    # --- correcting --------------------------------------------------------------------

    def edit(
        self,
        scope: EntityScope,
        invoice_id: UUID,
        path: str,
        text: str,
        *,
        expected_revision: int,
        actor: str = USER_ACTOR,
    ) -> InvoiceRecord:
        """Set one field by hand: a new revision, then a new validation run."""
        now = self._clock()
        with self._uow_factory() as uow:
            record = uow.invoices(scope).get(invoice_id)
            _open_for_review(record, expected_revision)
            changed = apply_edit(record.invoice, path, text, now)
            revised = revise_in(
                uow,
                scope,
                invoice_id,
                changed,
                expected_revision=expected_revision,
                actor=actor,
                now=now,
            )
            if revised.revision != record.revision:
                self._validation.validate_in(uow, scope, invoice_id, actor=actor)
            uow.commit()
        return revised

    def override(
        self,
        scope: EntityScope,
        invoice_id: UUID,
        finding: ValidationFinding,
        reason: str,
        *,
        expected_revision: int,
        actor: str = USER_ACTOR,
    ) -> OverrideRecord:
        """Accept one error finding of the current revision with a reason."""
        if finding.rule_id in NON_OVERRIDABLE:
            raise ReviewError("not_overridable", rule=finding.rule_id.value)
        text = _user_text(reason, MIN_REASON, MAX_REASON, "reason")
        now = self._clock()
        with self._uow_factory() as uow:
            record = uow.invoices(scope).get(invoice_id)
            _open_for_review(record, expected_revision)
            run = uow.validations(scope).latest(invoice_id)
            current = [] if run is None or run.revision != record.revision else run.findings
            if _finding_key(finding) not in {_finding_key(f) for f in current}:
                raise ReviewError("unknown_finding")
            stored = uow.reviews(scope).add_override(
                OverrideRecord(
                    override_id=self._new_id(),
                    invoice_id=invoice_id,
                    revision=record.revision,
                    rule_id=finding.rule_id,
                    field_path=finding.field_path,
                    message_key=finding.message_key,
                    reason=text or "",
                    created_at=now,
                    created_by=actor,
                )
            )
            self._audit(
                uow,
                scope,
                invoice_id,
                actor,
                now,
                AuditEventType.FINDING_OVERRIDDEN,
                {"revision": record.revision, "rule_id": finding.rule_id.value},
            )
            uow.commit()
        return stored

    # --- deciding ----------------------------------------------------------------------

    def approve(
        self,
        scope: EntityScope,
        invoice_id: UUID,
        *,
        expected_revision: int,
        comment: str | None = None,
        actor: str = USER_ACTOR,
    ) -> ApprovalRecord:
        """Approve exactly the current content after a fresh validation run."""
        note = _user_text(comment, 0, MAX_REASON, "comment")
        now = self._clock()
        with self._uow_factory() as uow:
            record = uow.invoices(scope).get(invoice_id)
            _open_for_review(record, expected_revision)
            if record.workflow_status == WorkflowStatus.APPROVED:
                raise ReviewError("already_approved")
            run = self._validation.validate_in(uow, scope, invoice_id, actor=actor)
            reviews = uow.reviews(scope)
            overrides = reviews.overrides(invoice_id, record.revision)
            blocking = open_errors(run, frozenset(o.key() for o in overrides))
            for finding in blocking:
                if finding.rule_id in NON_OVERRIDABLE:
                    raise ReviewError("blocked", rule=finding.rule_id.value)
            if blocking:
                raise ReviewError("open_errors", count=len(blocking))
            used = {_finding_key(f) for f in run.findings} & {o.key() for o in overrides}
            decision = self._decide(uow, record, Decision.APPROVED, run.run_id, note, actor, now)
            uow.invoices(scope).set_status(
                invoice_id, WorkflowStatus.APPROVED, expected_revision=record.revision
            )
            self._audit(
                uow,
                scope,
                invoice_id,
                actor,
                now,
                AuditEventType.INVOICE_APPROVED,
                {
                    "approval_id": str(decision.approval_id),
                    "revision": record.revision,
                    "content_sha256": record.content_sha256,
                    "run_id": str(run.run_id),
                    "override_count": len(used),
                },
            )
            uow.commit()
        return decision

    def reject(
        self,
        scope: EntityScope,
        invoice_id: UUID,
        *,
        expected_revision: int,
        comment: str,
        actor: str = USER_ACTOR,
    ) -> ApprovalRecord:
        """Reject the current content; a comment with the reason is required."""
        note = _user_text(comment, 1, MAX_REASON, "comment")
        return self._close(
            scope,
            invoice_id,
            expected_revision,
            Decision.REJECTED,
            WorkflowStatus.REJECTED,
            AuditEventType.INVOICE_REJECTED,
            note,
            actor,
        )

    def revoke(
        self,
        scope: EntityScope,
        invoice_id: UUID,
        *,
        expected_revision: int,
        actor: str = USER_ACTOR,
    ) -> ApprovalRecord:
        """Withdraw an approval; the invoice is a draft again."""
        return self._close(
            scope,
            invoice_id,
            expected_revision,
            Decision.REVOKED,
            WorkflowStatus.DRAFT,
            AuditEventType.INVOICE_APPROVAL_REVOKED,
            None,
            actor,
            require=WorkflowStatus.APPROVED,
        )

    def _close(
        self,
        scope: EntityScope,
        invoice_id: UUID,
        expected_revision: int,
        decision: Decision,
        status: WorkflowStatus,
        event: AuditEventType,
        note: str | None,
        actor: str,
        *,
        require: WorkflowStatus | None = None,
    ) -> ApprovalRecord:
        now = self._clock()
        with self._uow_factory() as uow:
            record = uow.invoices(scope).get(invoice_id)
            _open_for_review(record, expected_revision)
            if require is not None and record.workflow_status != require:
                raise ReviewError("not_approved")
            stored = self._decide(uow, record, decision, None, note, actor, now)
            uow.invoices(scope).set_status(invoice_id, status, expected_revision=record.revision)
            self._audit(
                uow,
                scope,
                invoice_id,
                actor,
                now,
                event,
                {
                    "approval_id": str(stored.approval_id),
                    "revision": record.revision,
                    "content_sha256": record.content_sha256,
                },
            )
            uow.commit()
        return stored

    def _decide(
        self,
        uow: UnitOfWork,
        record: InvoiceRecord,
        decision: Decision,
        run_id: UUID | None,
        note: str | None,
        actor: str,
        now: dt.datetime,
    ) -> ApprovalRecord:
        reviews = uow.reviews(_scope_of(record))
        return reviews.add_decision(
            ApprovalRecord(
                approval_id=self._new_id(),
                invoice_id=record.invoice_id,
                sequence=reviews.next_sequence(record.invoice_id),
                revision=record.revision,
                content_sha256=record.content_sha256,
                decision=decision,
                run_id=run_id,
                comment=note,
                decided_at=now,
                decided_by=actor,
            )
        )

    @staticmethod
    def _audit(
        uow: UnitOfWork,
        scope: EntityScope,
        invoice_id: UUID,
        actor: str,
        now: dt.datetime,
        event: AuditEventType,
        details: dict[str, object],
    ) -> None:
        uow.audit.append(
            AuditDraft(
                event_type=event,
                actor=actor,
                entity_id=scope.entity_id,
                subject_id=str(invoice_id),
                details=details,
            ),
            occurred_at=now,
        )


def _scope_of(record: InvoiceRecord) -> EntityScope:
    return EntityScope(record.entity_id)
