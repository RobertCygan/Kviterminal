"""Manual correction of invoice fields (Phase 09). Pure, no I/O.

A person types Norwegian text; it is read strictly (never guessed) into the
canonical type of the field. The new value gets the provenance ``manual``
with the producer ``bruker/lokal`` and the time, and keeps the evidence of
the value it replaces, so the source can still be shown next to it.
"""

import datetime as dt
import re
import unicodedata
from collections.abc import Callable, Mapping
from decimal import Decimal, InvalidOperation
from typing import Any

from pydantic import ValidationError

from invoiceflow.application.errors import InvoiceFlowError
from invoiceflow.domain.invoice import CanonicalInvoice

MANUAL_PRODUCER = "bruker/lokal"

_NORWEGIAN_DATE = re.compile(r"([0-9]{1,2})\.([0-9]{1,2})\.([0-9]{4})")
_ISO_DATE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
_MONEY = re.compile(r"-?[0-9]+(\.[0-9]{1,2})?")
_SPACES = str.maketrans("", "", " \N{NO-BREAK SPACE}\N{NARROW NO-BREAK SPACE}")


class EditError(InvoiceFlowError):
    """The typed text is not a valid value for the field; nothing was changed."""

    def __init__(self, reason: str) -> None:
        super().__init__("INVALID_INPUT", f"review.error.{reason}")
        self.reason = reason


def _clean(text: str) -> str:
    value = text.strip()
    if not value:
        raise EditError("empty")
    if any(unicodedata.category(char) in ("Cc", "Cf") for char in value):
        raise EditError("control_character")
    return value


def parse_text(text: str) -> str:
    return _clean(text)


def parse_money(text: str) -> str:
    value = _clean(text).translate(_SPACES)
    if "," in value and "." in value:
        raise EditError("amount")
    value = value.replace(",", ".")
    if not _MONEY.fullmatch(value):
        raise EditError("amount")
    try:
        Decimal(value)
    except InvalidOperation:  # pragma: no cover - the pattern admits only numbers
        raise EditError("amount") from None
    return value


def parse_date(text: str) -> str:
    value = _clean(text)
    try:
        if _ISO_DATE.fullmatch(value):
            return dt.date.fromisoformat(value).isoformat()
        match = _NORWEGIAN_DATE.fullmatch(value)
        if match:
            day, month, year = (int(part) for part in match.groups())
            return dt.date(year, month, day).isoformat()
    except ValueError:
        pass
    raise EditError("date")


def parse_digits(text: str) -> str:
    """Account numbers, KID and organisation numbers: spaces and dots are ignored."""
    value = _clean(text).translate(_SPACES).replace(".", "")
    if not value.replace("-", "").isascii() or not value.replace("-", "").isdigit():
        raise EditError("digits")
    return value


def parse_upper(text: str) -> str:
    """Currency codes and IBAN: spaces are ignored, letters made upper case."""
    value = _clean(text).translate(_SPACES).upper()
    if not value.isascii() or not value.isalnum():
        raise EditError("code")
    return value


def parse_code(text: str) -> str:
    return _clean(text)


Parser = Callable[[str], str]

# Field paths a person may correct; "N" stands for an accounting line number.
EDITABLE: Mapping[str, Parser] = {
    "invoice_number": parse_text,
    "invoice_date": parse_date,
    "due_date": parse_date,
    "currency": parse_upper,
    "buyer_reference": parse_text,
    "referenced_invoice_number": parse_text,
    "supplier.name": parse_text,
    "supplier.org_number": parse_digits,
    "payment.kid": parse_digits,
    "payment.bank_account": parse_digits,
    "payment.iban": parse_upper,
    "totals.net_amount": parse_money,
    "totals.vat_amount": parse_money,
    "totals.rounding_amount": parse_money,
    "totals.gross_amount": parse_money,
    "accounting_lines.N.account": parse_code,
    "accounting_lines.N.vat_code": parse_code,
    "accounting_lines.N.net_amount": parse_money,
    "accounting_lines.N.cost_center": parse_code,
    "accounting_lines.N.department": parse_code,
    "accounting_lines.N.project": parse_code,
}


def _pattern(path: str) -> tuple[str, int | None]:
    parts = path.split(".")
    if len(parts) == 3 and parts[0] == "accounting_lines" and parts[1].isdigit():
        return f"accounting_lines.N.{parts[2]}", int(parts[1])
    return path, None


def is_editable(path: str) -> bool:
    return _pattern(path)[0] in EDITABLE


def _container(data: dict[str, Any], path: str, line_number: int | None) -> tuple[dict, str]:
    parts = path.split(".")
    if line_number is not None:
        lines = data.get("accounting_lines") or []
        for line in lines:
            if line.get("line_number") == line_number:
                return line, parts[2]
        raise EditError("unknown_field")
    node = data
    for part in parts[:-1]:
        child = node.get(part)
        if child is None:
            child = {}
            node[part] = child
        node = child
    return node, parts[-1]


def apply_edit(
    invoice: CanonicalInvoice, path: str, text: str, recorded_at: dt.datetime
) -> CanonicalInvoice:
    """A copy of the invoice with one field set by a person; validated as a whole."""
    pattern, line_number = _pattern(path)
    parser = EDITABLE.get(pattern)
    if parser is None:
        raise EditError("unknown_field")
    value = parser(text)
    data = invoice.model_dump(mode="json")
    container, name = _container(data, path, line_number)
    previous = container.get(name)
    provenance: dict[str, Any] = {
        "source": "manual",
        "producer": MANUAL_PRODUCER,
        "recorded_at": recorded_at.isoformat(),
    }
    if isinstance(previous, dict) and previous.get("provenance", {}).get("evidence"):
        provenance["evidence"] = previous["provenance"]["evidence"]
    container[name] = {"value": value, "provenance": provenance}
    try:
        return CanonicalInvoice.model_validate(data)
    except ValidationError:
        raise EditError("invalid_value") from None
