"""Approval decisions and finding overrides (Phase 09, ADR-0035). No I/O."""

import datetime as dt
from dataclasses import dataclass
from enum import StrEnum
from uuid import UUID

from invoiceflow.application.validation.model import RuleId

# These findings can never be overridden: they block approval until resolved.
NON_OVERRIDABLE = frozenset({RuleId.BANK_001, RuleId.DUP_001})
MIN_REASON = 10
MAX_REASON = 500


class Decision(StrEnum):
    APPROVED = "approved"
    REJECTED = "rejected"
    REVOKED = "revoked"


class WorkflowStatus(StrEnum):
    DRAFT = "draft"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPORTED = "exported"  # Phase 10: final; the content can no longer change


@dataclass(frozen=True, slots=True)
class ApprovalRecord:
    approval_id: UUID
    invoice_id: UUID
    sequence: int
    revision: int
    content_sha256: str
    decision: Decision
    run_id: UUID | None
    comment: str | None
    decided_at: dt.datetime
    decided_by: str


@dataclass(frozen=True, slots=True)
class OverrideRecord:
    override_id: UUID
    invoice_id: UUID
    revision: int
    rule_id: RuleId
    field_path: str | None
    message_key: str
    reason: str
    created_at: dt.datetime
    created_by: str

    def key(self) -> tuple[str, str | None, str]:
        return (self.rule_id.value, self.field_path, self.message_key)
