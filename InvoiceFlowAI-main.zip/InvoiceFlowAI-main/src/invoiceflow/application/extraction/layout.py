"""Words and lines of a page, from its text layer or its OCR (Phase 06). No I/O.

Both sources become the same layout: words with a box normalised to the page
image (origin top left) and, for OCR, a confidence. Lines are rebuilt from the
geometry rather than taken from the source, so a label and its value on the
same row end up on one line even when the PDF or Tesseract put them in
different blocks. Every word keeps its character offset in the line text, so
a match in the text can be traced back to its boxes.

Document text is data: nothing here interprets it beyond splitting it up.
"""

from collections.abc import Sequence
from dataclasses import dataclass
from enum import StrEnum

from invoiceflow.application.processing_model import OcrLayer, TextLayer

Box = tuple[float, float, float, float]
_SPACES = frozenset(" \t\r\n\N{NO-BREAK SPACE}\N{THIN SPACE}\N{NARROW NO-BREAK SPACE}")
# A gap wider than this many character heights splits a word or a line cell.
_WORD_GAP = 0.8


class TextOrigin(StrEnum):
    TEXT_LAYER = "tekstlag"
    OCR = "ocr"


@dataclass(frozen=True, slots=True)
class Word:
    text: str
    box: Box
    confidence: int | None = None  # 0-100 for OCR, None for a text layer


@dataclass(frozen=True, slots=True)
class Line:
    page_number: int
    index: int  # 0-based, top to bottom
    words: tuple[Word, ...]

    @property
    def text(self) -> str:
        return " ".join(word.text for word in self.words)

    def starts(self) -> list[int]:
        """Character offset of each word in :attr:`text`."""
        offsets, position = [], 0
        for word in self.words:
            offsets.append(position)
            position += len(word.text) + 1
        return offsets

    def words_in(self, start: int, end: int) -> tuple[Word, ...]:
        """The words a character span ``[start, end)`` of :attr:`text` touches."""
        return tuple(
            word
            for word, offset in zip(self.words, self.starts(), strict=True)
            if offset < end and offset + len(word.text) > start
        )


@dataclass(frozen=True, slots=True)
class PageLayout:
    page_number: int
    origin: TextOrigin
    lines: tuple[Line, ...]


def union(boxes: Sequence[Box]) -> Box:
    return (
        min(box[0] for box in boxes),
        min(box[1] for box in boxes),
        max(box[2] for box in boxes),
        max(box[3] for box in boxes),
    )


def _height(box: Box) -> float:
    return box[3] - box[1]


def words_from_text_layer(layer: TextLayer) -> list[Word]:
    """Split on whitespace and on wide horizontal gaps between characters."""
    words: list[Word] = []
    current: list[tuple[str, Box]] = []

    def flush() -> None:
        if current:
            text = "".join(char for char, _ in current)
            words.append(Word(text, union([box for _, box in current])))
            current.clear()

    for char, box in zip(layer.text, layer.boxes, strict=True):
        if char in _SPACES:
            flush()
            continue
        if current:
            previous = current[-1][1]
            size = max(_height(previous), _height(box), 1e-6)
            if box[0] - previous[2] > _WORD_GAP * size or abs(box[1] - previous[1]) > size:
                flush()
        current.append((char, box))
    flush()
    return words


def words_from_ocr(layer: OcrLayer) -> list[Word]:
    return [Word(word.text, word.box, word.confidence) for word in layer.words]


def lines_from_words(page_number: int, words: Sequence[Word]) -> tuple[Line, ...]:
    """Group words whose vertical centres lie within half a word height, left to right."""
    rows: list[list[Word]] = []
    for word in sorted(words, key=lambda w: ((w.box[1] + w.box[3]) / 2, w.box[0])):
        centre = (word.box[1] + word.box[3]) / 2
        if rows:
            row = rows[-1]
            row_centre = sum((w.box[1] + w.box[3]) / 2 for w in row) / len(row)
            height = max(max(_height(w.box) for w in row), _height(word.box))
            if abs(centre - row_centre) <= height / 2:
                row.append(word)
                continue
        rows.append([word])
    return tuple(
        Line(page_number, index, tuple(sorted(row, key=lambda w: w.box[0])))
        for index, row in enumerate(rows)
    )


def page_layout(page_number: int, layer: TextLayer | OcrLayer) -> PageLayout:
    if isinstance(layer, OcrLayer):
        return PageLayout(
            page_number, TextOrigin.OCR, lines_from_words(page_number, words_from_ocr(layer))
        )
    words = words_from_text_layer(layer)
    return PageLayout(page_number, TextOrigin.TEXT_LAYER, lines_from_words(page_number, words))
