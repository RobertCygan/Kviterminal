"""Rule-based extraction of Norwegian invoice fields (Phase 06, ADR-0041)."""
