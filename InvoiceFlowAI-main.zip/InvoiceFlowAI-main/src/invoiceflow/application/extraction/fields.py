"""Norwegian invoice fields from the words of a document part (Phase 06, ADR-0041). No I/O.

Rules, not guesses:

* A value is taken only next to its label (``Fakturanr``, ``Forfallsdato``,
  ``Å betale`` …), on the same line or right below the label, or in a form
  that is unmistakable on its own (``1234.56.78903``, ``NO 999 999 999 MVA``).
* Every value carries provenance: page, box, the raw text and, for OCR, the
  lowest word confidence. A value that is found but cannot be read
  (``31.02.2026``) is kept as ``value=None`` with its raw text and counted.
* Nothing is calculated or filled in. Totals that do not add up are left as
  read and flagged when the invoice is registered.

The supplier is told from the customer by the entity's own organisation
number: an organisation number equal to it belongs to the customer.
"""

import functools
import re
from collections.abc import Callable, Iterator, Sequence
from dataclasses import dataclass
from decimal import Decimal
from typing import Any
from uuid import UUID

from pydantic import TypeAdapter, ValidationError

from invoiceflow.application.extraction import parse
from invoiceflow.application.extraction.layout import Line, PageLayout, TextOrigin, Word, union
from invoiceflow.application.extraction.parse import Match
from invoiceflow.domain.invoice import CanonicalInvoice, InvoiceType
from invoiceflow.domain.types import (
    BankAccount,
    Bic,
    CurrencyCode,
    Iban,
    Identifier,
    IsoDate,
    Kid,
    LongText,
    Money,
    OrgNumber,
    Quantity,
    ShortText,
    UnitPrice,
    VatRate,
)

EXTRACTION_VERSION = "1"
PRODUCER = f"regel/fakturafelt/{EXTRACTION_VERSION}"
MAX_LINES = 200  # invoice lines read from one part
_BELOW = 3  # lines below a label searched for its value


def _label(pattern: str) -> re.Pattern[str]:
    return re.compile(rf"(?<![\wæøå])(?:{pattern})(?![\wæøå])\s*[:.]?", re.IGNORECASE)


INVOICE_NUMBER = _label(
    r"faktura\s?(?:nr|nummer|no)\.?|fakt\.?\s?nr\.?|fakturanr\.?|invoice\s(?:no|number)\.?"
    r"|kreditnota\s?(?:nr|nummer)\.?|kreditnotanr\.?"
)
INVOICE_DATE = _label(r"fakturadato|faktura\s?dato|invoice\s?date|utstedt")
GENERIC_DATE = _label(r"dato|date")
DUE_DATE = _label(r"forfallsdato|forfall|betalingsfrist|due\s?date|betales\s(?:innen|senest)")
KID_LABEL = _label(r"kid(?:-?(?:nr|nummer))?\.?")
ACCOUNT_LABEL = _label(
    r"kontonummer|kontonr\.?|bankkonto(?:nr)?|konto\s?nr\.?|konto|betal\s?til\s?konto"
    r"|account\s?(?:no|number)?"
)
IBAN_LABEL = _label(r"iban")
BIC_LABEL = _label(r"bic|swift(?:-?kode)?")
ORG_LABEL = _label(
    r"org\.?\s?nr\.?|org\.?\s?no\.?|organisasjonsnummer|organisasjonsnr\.?|foretaksregisteret"
)
CUSTOMER_LABEL = _label(r"kunde|deres\s?org|kjøper|faktureres\s?til|bill\s?to")
GROSS_PAYABLE = _label(
    r"å\s?betale|sum\s?å\s?betale|beløp\s?å\s?betale|totalt\s?å\s?betale|til\s?betaling"
    r"|amount\s?due|total\s?due"
)
GROSS_TOTAL = _label(
    r"sum\s?inkl\.?\s?mva|total\s?inkl\.?\s?mva|totalt\s?inkl\.?\s?mva|totalbeløp|total"
)
NET_TOTAL = _label(
    r"sum\s?eks(?:kl)?\.?\s?mva|totalt?\s?eks(?:kl)?\.?\s?mva|beløp\s?eks(?:kl)?\.?\s?mva"
    r"|netto(?:beløp)?|subtotal"
)
VAT_TOTAL = _label(r"sum\s?mva|mva-?beløp|total\s?mva|totalt\s?mva|merverdiavgift\s?totalt")
VAT_WORD = _label(r"mva|merverdiavgift|vat")
ROUNDING = _label(r"øre(?:s)?avrunding|avrunding|rounding")
REFERENCED = _label(
    r"gjelder\s?faktura(?:\s?(?:nr|nummer))?\.?|kreditert\s?faktura|ref\.?\s?faktura"
    r"|original\s?faktura"
)
BUYER_REFERENCE = _label(r"deres\s?ref(?:eranse)?\.?|your\s?ref(?:erence)?\.?")
OUR_REFERENCE = _label(r"vår\s?ref(?:eranse)?\.?|our\s?ref")
CREDIT_TITLE = re.compile(r"(?<![\wæøå])(kreditnota|credit\s?note)(?![\wæøå])", re.IGNORECASE)
INVOICE_TITLE = re.compile(r"(?<![\wæøå])(faktura|invoice)(?![\wæøå])", re.IGNORECASE)
COMPANY = re.compile(r"(?<![\wæøå])(AS|ASA|ANS|DA|SA|BA|NUF|KS|ENK)\.?$")
TABLE_HEADER = (
    re.compile(r"beskrivelse|varetekst|produkt|description|tjeneste|vare(?:nr)?", re.IGNORECASE),
    re.compile(r"antall|ant\.|qty|mengde", re.IGNORECASE),
    re.compile(r"pris|price", re.IGNORECASE),
    re.compile(r"beløp|amount|sum|total", re.IGNORECASE),
)
QUANTITY = re.compile(r"\d{1,9}(?:[,.]\d{1,6})?")


@functools.cache
def _adapter(kind: Any) -> TypeAdapter[Any]:
    return TypeAdapter(kind)


def _valid(kind: Any, value: object) -> bool:
    try:
        _adapter(kind).validate_python(value)
    except ValidationError:
        return False
    return True


@dataclass
class _State:
    """How many values were found but could not be read."""

    unreadable: int = 0


@dataclass(frozen=True, slots=True)
class Context:
    document_id: UUID
    first_page: int
    last_page: int
    entity_org_number: str | None = None
    entity_name: str | None = None


@dataclass(frozen=True, slots=True)
class Extraction:
    invoice: CanonicalInvoice
    unreadable: int  # values found but not readable
    titled: bool  # the part calls itself an invoice or a credit note


@dataclass(frozen=True, slots=True)
class _Hit:
    page: PageLayout
    line: Line
    match: Match

    @property
    def words(self) -> tuple[Word, ...]:
        return self.line.words_in(self.match.start, self.match.end)


def _field(
    hit: _Hit, value: object, kind: Any, state: _State, *, raw: str | None = None
) -> dict[str, object]:
    """A ``FieldValue`` as data; an invalid value is kept as ``None`` with its raw text."""
    if value is not None and not _valid(kind, value):
        value = None
    if value is None:
        state.unreadable += 1
    words = hit.words or hit.line.words
    confidences = [word.confidence for word in words if word.confidence is not None]
    x0, y0, x1, y1 = union([word.box for word in words])
    provenance: dict[str, object] = {
        "source": "extracted",
        "producer": PRODUCER,
        "evidence": {
            "page_number": hit.page.page_number,
            "bbox": {"x0": x0, "y0": y0, "x1": x1, "y1": y1},
            "source_ref": f"{hit.page.origin}/s{hit.page.page_number}/l{hit.line.index + 1}",
            "raw_text": (raw if raw is not None else hit.match.raw)[:2000],
        },
    }
    if confidences and hit.page.origin is TextOrigin.OCR:
        provenance["confidence"] = min(confidences) / 100
    plain = str(value) if isinstance(value, Decimal) else value
    if hasattr(value, "isoformat"):
        plain = value.isoformat()  # type: ignore[union-attr]
    return {"value": plain, "provenance": provenance}


def _lines(pages: Sequence[PageLayout]) -> Iterator[tuple[PageLayout, Line]]:
    for page in pages:
        for line in page.lines:
            yield page, line


def _overlaps(words: Sequence[Word], line: Line, match: Match) -> bool:
    """Does the match lie below the label words (horizontal overlap)?"""
    left, _, right, _ = union([word.box for word in words])
    found = line.words_in(match.start, match.end)
    if not found:
        return False
    x0, _, x1, _ = union([word.box for word in found])
    return x0 <= right + 0.01 and x1 >= left - 0.01


def _matches(line: Line, finder: Callable[[str], list[Match]]) -> list[Match]:
    """Matches inside one table cell each, with offsets in the line text.

    A value never runs across a column gap: ``17.10.26`` and ``0888120004`` in
    neighbouring columns are not one KID.
    """
    found = []
    starts = dict(zip(line.words, line.starts(), strict=True))
    for text, words in _cells(line):
        offset = starts[words[0]]
        found += [Match(m.start + offset, m.end + offset, m.raw) for m in finder(text)]
    return found


def _labelled(
    pages: Sequence[PageLayout],
    label: re.Pattern[str],
    finder: Callable[[str], list[Match]],
    *,
    last: bool = False,
) -> _Hit | None:
    """The value right after a label on its line, else right below the label."""
    hits: list[_Hit] = []
    page_lines = {page.page_number: page.lines for page in pages}
    for page, line in _lines(pages):
        for found in label.finditer(line.text):
            after = [m for m in _matches(line, finder) if m.start >= found.end()]
            if after:
                hits.append(_Hit(page, line, after[0]))
                break
            label_words = line.words_in(found.start(), found.end())
            below = page_lines[page.page_number][line.index + 1 : line.index + 1 + _BELOW]
            for other in below:
                candidates = [
                    m for m in _matches(other, finder) if _overlaps(label_words, other, m)
                ]
                if candidates:
                    hits.append(_Hit(page, other, candidates[0]))
                    break
            if hits and not last:
                return hits[0]
    if not hits:
        return None
    return hits[-1] if last else hits[0]


def _amount_field(hit: _Hit | None, state: _State, *, credit: bool) -> dict[str, object] | None:
    if hit is None:
        return None
    value = parse.parse_amount(hit.match.raw)
    if value is not None and credit:
        value = abs(value)  # D-16: credit notes carry positive amounts
    return _field(hit, value, Money, state)


def _last_amount(text: str) -> list[Match]:
    amounts = parse.find(parse.AMOUNT, text)
    return amounts[-1:]


def _identifier(text: str) -> list[Match]:
    return [
        Match(m.start(), m.end(), m.group(0))
        for m in re.finditer(r"[A-Za-z0-9][A-Za-z0-9/._-]{0,62}", text)
        if any(char.isdigit() for char in m.group(0))
    ]


def _org_numbers(pages: Sequence[PageLayout]) -> list[_Hit]:
    """Organisation numbers next to a label, or in the ``NO … MVA`` form."""
    hits = []
    for page, line in _lines(pages):
        labelled = ORG_LABEL.search(line.text)
        for match in parse.find(parse.ORG_NUMBER, line.text):
            explicit = match.raw.upper().startswith("NO") or parse.is_vat_registered(match.raw)
            if (labelled and match.start >= labelled.start()) or explicit:
                hits.append(_Hit(page, line, match))
    return hits


def _party_name(
    pages: Sequence[PageLayout], org_hit: _Hit | None, entity: str | None
) -> _Hit | None:
    """A company name (ending in AS, ASA …) in one cell: by the organisation number, else on top."""
    candidates: list[tuple[PageLayout, Line]] = []
    if org_hit is not None:
        candidates.append((org_hit.page, org_hit.line))
    if pages:
        candidates += [(pages[0], line) for line in pages[0].lines[:12]]
    for page, line in candidates:
        starts = dict(zip(line.words, line.starts(), strict=True))
        for text, words in _cells(line):
            label = ORG_LABEL.search(text)
            name = text[: label.start()].strip(" ,:-") if label else text.strip()
            if not name or ":" in name or not COMPANY.search(name):
                continue
            if entity is not None and name.casefold() == entity.casefold():
                continue
            start = starts[words[0]] + text.find(name)
            return _Hit(page, line, Match(start, start + len(name), name))
    return None


def _invoice_type(
    pages: Sequence[PageLayout], state: _State
) -> tuple[dict[str, object] | None, bool]:
    first_title: _Hit | None = None
    for page, line in _lines(pages):
        credit = CREDIT_TITLE.search(line.text)
        if credit:
            hit = _Hit(page, line, Match(credit.start(), credit.end(), credit.group(0)))
            return _field(hit, InvoiceType.CREDIT_NOTE.value, InvoiceType, state), True
        title = INVOICE_TITLE.search(line.text)
        if title and first_title is None:
            first_title = _Hit(page, line, Match(title.start(), title.end(), title.group(0)))
    if first_title is None:
        return None, False
    return _field(first_title, InvoiceType.INVOICE.value, InvoiceType, state), True


def _cells(line: Line) -> list[tuple[str, tuple[Word, ...]]]:
    """Runs of words separated by gaps wider than a character height (table columns)."""
    cells: list[list[Word]] = []
    for word in line.words:
        if cells:
            previous = cells[-1][-1]
            height = max(previous.box[3] - previous.box[1], word.box[3] - word.box[1], 1e-6)
            if word.box[0] - previous.box[2] <= 1.2 * height:
                cells[-1].append(word)
                continue
        cells.append([word])
    return [(" ".join(word.text for word in cell), tuple(cell)) for cell in cells]


def _cell_hit(page: PageLayout, line: Line, words: tuple[Word, ...]) -> _Hit:
    start = line.starts()[line.words.index(words[0])]
    text = " ".join(word.text for word in words)
    return _Hit(page, line, Match(start, start + len(text), text))


def _quantity(text: str) -> Decimal | None:
    if not QUANTITY.fullmatch(text):
        return None
    return Decimal(text.replace(",", "."))


def _invoice_lines(
    pages: Sequence[PageLayout], state: _State, *, credit: bool
) -> list[dict[str, object]]:
    """Rows of the line table: description, then quantity, unit price and amount columns."""
    rows: list[dict[str, object]] = []
    in_table = False
    stop = (NET_TOTAL, GROSS_PAYABLE, GROSS_TOTAL, VAT_TOTAL)
    for page, line in _lines(pages):
        text = line.text
        if sum(bool(p.search(text)) for p in TABLE_HEADER) >= 3:
            in_table = True
            continue
        if not in_table:
            continue
        if any(label.search(text) for label in stop):
            break
        cells = _cells(line)
        amounts = [(c, w) for c, w in cells if parse.AMOUNT.fullmatch(c)]
        if not amounts or len(rows) == MAX_LINES:
            continue
        description = [(c, w) for c, w in cells if not any(ch.isdigit() for ch in c)]
        if not description:
            continue
        net_text, net_words = amounts[-1]
        row: dict[str, object] = {"line_number": len(rows) + 1}
        description_words = tuple(word for _, words in description for word in words)
        row["description"] = _field(
            _cell_hit(page, line, description_words),
            " ".join(c for c, _ in description),
            LongText,
            state,
        )
        net = parse.parse_amount(net_text)
        row["net_amount"] = _field(
            _cell_hit(page, line, net_words),
            None if net is None else abs(net) if credit else net,
            Money,
            state,
        )
        numbers = [(c, w) for c, w in cells[:-1] if (c, w) not in description]
        numbers = [(c, w) for c, w in numbers if w is not net_words]
        if len(numbers) >= 2 and net is not None:
            quantity_text, quantity_words = numbers[-2]
            price_text, price_words = numbers[-1]
            quantity, price = _quantity(quantity_text), parse.parse_amount(price_text)
            # Only a consistent row is split into quantity and price.
            if (
                quantity is not None
                and price is not None
                and abs(quantity * price - net) < Decimal("0.01")
            ):
                row["quantity"] = _field(
                    _cell_hit(page, line, quantity_words), quantity, Quantity, state
                )
                row["unit_price"] = _field(
                    _cell_hit(page, line, price_words),
                    abs(price) if credit else price,
                    UnitPrice,
                    state,
                )
        rows.append(row)
    return rows


def _vat_breakdown(
    pages: Sequence[PageLayout], state: _State, *, credit: bool
) -> list[dict[str, object]]:
    """``MVA 25 % av 12 634,50 3 158,63``: rate, then base and VAT (or VAT only)."""
    entries = []
    for page, line in _lines(pages):
        text = line.text
        if not VAT_WORD.search(text) or VAT_TOTAL.search(text):
            continue
        rates = parse.find(parse.VAT_RATE, text)
        if not rates:
            continue
        amounts = [m for m in parse.find(parse.AMOUNT, text) if m.start > rates[0].end]
        if not amounts:
            continue
        entry: dict[str, object] = {
            "vat_rate": _field(
                _Hit(page, line, rates[0]), parse.parse_vat_rate(rates[0].raw), VatRate, state
            )
        }
        entry["vat_amount"] = _amount_field(_Hit(page, line, amounts[-1]), state, credit=credit)
        if len(amounts) >= 2:
            entry["taxable_amount"] = _amount_field(
                _Hit(page, line, amounts[0]), state, credit=credit
            )
        entries.append(entry)
    return entries[:20]


def _currency(
    pages: Sequence[PageLayout], gross: _Hit | None, state: _State
) -> dict[str, object] | None:
    lines = [(gross.page, gross.line)] if gross is not None else []
    lines += list(_lines(pages))
    for page, line in lines:
        found = parse.find(parse.CURRENCY, line.text)
        if found:
            return _field(
                _Hit(page, line, found[0]), parse.parse_currency(found[0].raw), CurrencyCode, state
            )
    return None


def _rest_of_line(pages: Sequence[PageLayout], label: re.Pattern[str]) -> _Hit | None:
    for page, line in _lines(pages):
        found = label.search(line.text)
        if not found:
            continue
        rest = line.text[found.end() :]
        other = OUR_REFERENCE.search(rest)
        value = (rest[: other.start()] if other else rest).strip(" :,-")
        if value:
            start = line.text.index(value, found.end())
            return _Hit(page, line, Match(start, start + len(value), value))
    return None


def _simple(
    hit: _Hit | None, parser: Callable[[str], object], kind: Any, state: _State
) -> dict[str, object] | None:
    return None if hit is None else _field(hit, parser(hit.match.raw), kind, state)


def extract(pages: Sequence[PageLayout], context: Context) -> Extraction:
    """One invoice from the pages of one part of a document."""
    state = _State()
    invoice_type, titled = _invoice_type(pages, state)
    credit = invoice_type is not None and invoice_type["value"] == InvoiceType.CREDIT_NOTE.value

    number = _labelled(pages, INVOICE_NUMBER, _identifier)
    invoice_date = _labelled(pages, INVOICE_DATE, parse.find_dates) or _labelled(
        pages, GENERIC_DATE, parse.find_dates
    )
    due_date = _labelled(pages, DUE_DATE, parse.find_dates)
    kid = _labelled(pages, KID_LABEL, lambda text: parse.find(parse.KID, text))
    account = _labelled(pages, ACCOUNT_LABEL, lambda text: parse.find(parse.BANK_ACCOUNT, text))
    iban = _labelled(pages, IBAN_LABEL, lambda text: parse.find(parse.IBAN, text))
    bic = _labelled(pages, BIC_LABEL, lambda text: parse.find(parse.BIC, text))
    referenced = _labelled(pages, REFERENCED, _identifier) if credit else None
    gross = _labelled(pages, GROSS_PAYABLE, _last_amount, last=True) or _labelled(
        pages, GROSS_TOTAL, _last_amount, last=True
    )
    net = _labelled(pages, NET_TOTAL, _last_amount, last=True)
    vat = _labelled(pages, VAT_TOTAL, _last_amount, last=True)
    rounding = _labelled(pages, ROUNDING, _last_amount, last=True)

    supplier_org, customer_org = None, None
    for hit in _org_numbers(pages):
        value = parse.parse_org_number(hit.match.raw)
        is_customer = (value is not None and value == context.entity_org_number) or bool(
            CUSTOMER_LABEL.search(hit.line.text[: hit.match.start])
        )
        if is_customer and customer_org is None:
            customer_org = hit
        elif not is_customer and supplier_org is None:
            supplier_org = hit
    supplier_name = _party_name(pages, supplier_org, context.entity_name)

    supplier: dict[str, object] = {}
    if supplier_name is not None:
        supplier["name"] = _field(supplier_name, supplier_name.match.raw, ShortText, state)
    if supplier_org is not None:
        supplier["org_number"] = _simple(supplier_org, parse.parse_org_number, OrgNumber, state)
        if parse.is_vat_registered(supplier_org.match.raw):
            supplier["vat_registered"] = _field(supplier_org, True, bool, state)
    customer: dict[str, object] | None = None
    if customer_org is not None:
        customer = {"org_number": _simple(customer_org, parse.parse_org_number, OrgNumber, state)}
    if context.entity_name:
        for page, line in _lines(pages):
            position = line.text.casefold().find(context.entity_name.casefold())
            if position >= 0:
                end = position + len(context.entity_name)
                hit = _Hit(page, line, Match(position, end, line.text[position:end]))
                customer = (customer or {}) | {"name": _field(hit, hit.match.raw, ShortText, state)}
                break

    payment = {
        key: value
        for key, value in (
            ("kid", _simple(kid, parse.parse_kid, Kid, state)),
            ("bank_account", _simple(account, parse.parse_bank_account, BankAccount, state)),
            ("iban", _simple(iban, parse.parse_iban, Iban, state)),
            ("bic", _simple(bic, parse.parse_bic, Bic, state)),
        )
        if value is not None
    }
    breakdown = _vat_breakdown(pages, state, credit=credit)
    vat_field = _amount_field(vat, state, credit=credit)
    if vat_field is None and len(breakdown) == 1:
        vat_field = breakdown[0]["vat_amount"]  # type: ignore[assignment]  # the single VAT line
    totals = {
        key: value
        for key, value in (
            ("net_amount", _amount_field(net, state, credit=credit)),
            ("vat_amount", vat_field),
            ("rounding_amount", _amount_field(rounding, state, credit=False)),
            ("gross_amount", _amount_field(gross, state, credit=credit)),
        )
        if value is not None
    }
    data: dict[str, object] = {
        "document_id": str(context.document_id),
        "first_page": context.first_page,
        "last_page": context.last_page,
        "supplier": supplier,
        "totals": totals,
        "lines": _invoice_lines(pages, state, credit=credit),
        "vat_breakdown": breakdown,
    }
    optional = {
        "invoice_type": invoice_type,
        "invoice_number": _simple(number, parse.parse_identifier, Identifier, state),
        "invoice_date": _simple(invoice_date, parse.parse_date, IsoDate, state),
        "due_date": _simple(due_date, parse.parse_date, IsoDate, state),
        "currency": _currency(pages, gross, state),
        "referenced_invoice_number": _simple(referenced, parse.parse_identifier, Identifier, state),
        "buyer_reference": _simple(_rest_of_line(pages, BUYER_REFERENCE), str, ShortText, state),
        "customer": customer,
        "payment": payment or None,
    }
    data |= {key: value for key, value in optional.items() if value is not None}
    return Extraction(CanonicalInvoice.model_validate(data), state.unreadable, titled)
