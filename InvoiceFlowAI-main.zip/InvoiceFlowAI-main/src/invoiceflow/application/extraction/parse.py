"""Finding and normalising Norwegian invoice values in a line of text (Phase 06). No I/O.

Each ``find_*`` function returns matches with their character span, so the
caller can point at the words a value came from. Each ``parse_*`` function
turns the raw text of one match into the canonical form, or ``None`` when the
text looks like a value but is not a valid one (31.02.2026): the raw text is
then kept as evidence and the field is flagged, never guessed.

The patterns are linear (no nested repetition) and work on one line at a
time, whose length the page limits already bound.
"""

import datetime as dt
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

_MINUS = "-\N{MINUS SIGN}\N{EN DASH}"
_GROUP = " .\N{NO-BREAK SPACE}\N{NARROW NO-BREAK SPACE}\N{THIN SPACE}"
# 1 234,50 · 1.234,50 · 1234,50 · 1 234,- · 1,234.50 · 1234.50
AMOUNT = re.compile(
    rf"(?<![\d,.])([{_MINUS}]\s?)?"
    rf"(\d{{1,3}}(?:[{_GROUP}]\d{{3}})+|\d{{1,3}}(?:,\d{{3}})+(?=\.\d\d)|\d+)"
    r"(,\d\d|,-|\.\d\d)"
    r"(?![\d.,])(?!\s?%)"
)
DATE_NUMERIC = re.compile(
    r"(?<![\d.])(\d{1,2})[./-](\d{1,2})[./-](\d{4}|\d{2})(?![\d])|(?<![\d])(\d{4})-(\d{2})-(\d{2})(?![\d])"
)
_MONTHS = {
    "jan": 1,
    "feb": 2,
    "mar": 3,
    "apr": 4,
    "mai": 5,
    "may": 5,
    "jun": 6,
    "jul": 7,
    "aug": 8,
    "sep": 9,
    "okt": 10,
    "oct": 10,
    "nov": 11,
    "des": 12,
    "dec": 12,
}
DATE_WORDS = re.compile(
    r"(?<![\d])(\d{1,2})\.?\s(jan|feb|mar|apr|mai|may|jun|jul|aug|sep|okt|oct|nov|des|dec)"
    r"[a-zæøå]*\.?\s(\d{4})(?![\d])",
    re.IGNORECASE,
)
ORG_NUMBER = re.compile(
    r"(?<![\d])(?:NO\s?)?(\d{3}[ .]?\d{3}[ .]?\d{3})(?![\d])(\s?MVA)?", re.IGNORECASE
)
BANK_ACCOUNT = re.compile(r"(?<![\d.])(\d{4}[ .]?\d{2}[ .]?\d{5})(?![\d])")
KID = re.compile(r"(?<![\d])(\d[\d ]{0,30}[\d-])(?![\d])")
IBAN = re.compile(r"\b([A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){2,7}(?: ?[A-Z0-9]{1,4})?)\b")
BIC = re.compile(r"\b([A-Z]{6}[A-Z0-9]{2}(?:[A-Z0-9]{3})?)\b")
VAT_RATE = re.compile(r"(?<![\d,.])(\d{1,2}(?:[,.]\d{1,2})?)\s?%")
CURRENCY = re.compile(r"\b(NOK|EUR|SEK|DKK|USD|GBP)\b|\bkr\b\.?", re.IGNORECASE)
IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9/._-]{0,62}")


@dataclass(frozen=True, slots=True)
class Match:
    start: int
    end: int
    raw: str


def find(pattern: re.Pattern[str], text: str) -> list[Match]:
    return [Match(m.start(), m.end(), m.group(0)) for m in pattern.finditer(text)]


def parse_amount(raw: str) -> Decimal | None:
    """Two decimals, Norwegian or English grouping, optional leading minus."""
    match = AMOUNT.fullmatch(raw.strip())
    if match is None:
        return None
    sign, whole, fraction = match.groups()
    digits = re.sub(r"\D", "", whole)
    cents = "00" if fraction == ",-" else fraction[1:]
    try:
        value = Decimal(f"{digits}.{cents}")
    except InvalidOperation:
        return None
    if len(digits) > 13:  # Money allows 15 digits in all
        return None
    return -value if sign else value


def _date(year: int, month: int, day: int) -> dt.date | None:
    if year < 100:
        year += 2000
    try:
        value = dt.date(year, month, day)
    except ValueError:
        return None
    return value if 1990 <= value.year <= 2100 else None


def find_dates(text: str) -> list[Match]:
    matches = find(DATE_NUMERIC, text) + find(DATE_WORDS, text)
    return sorted(matches, key=lambda match: match.start)


def parse_date(raw: str) -> dt.date | None:
    """``24.10.2026``, ``24.10.26``, ``2026-10-24``, ``24. oktober 2026``; else ``None``."""
    text = raw.strip()
    numeric = DATE_NUMERIC.fullmatch(text)
    if numeric is not None:
        day, month, year, iso_year, iso_month, iso_day = numeric.groups()
        if iso_year is not None:
            return _date(int(iso_year), int(iso_month), int(iso_day))
        return _date(int(year), int(month), int(day))
    words = DATE_WORDS.fullmatch(text)
    if words is not None:
        day, month, year = words.groups()
        return _date(int(year), _MONTHS[month.lower()[:3]], int(day))
    return None


def digits(raw: str) -> str:
    return re.sub(r"\D", "", raw)


def parse_org_number(raw: str) -> str | None:
    value = digits(raw)
    return value if len(value) == 9 else None


def is_vat_registered(raw: str) -> bool:
    return raw.upper().rstrip().endswith("MVA")


def parse_bank_account(raw: str) -> str | None:
    value = digits(raw)
    return value if len(value) == 11 else None


def parse_kid(raw: str) -> str | None:
    """2-25 characters: digits, the last may be ``-`` (MOD11 remainder 10)."""
    value = re.sub(r"\s", "", raw)
    return value if re.fullmatch(r"\d{1,24}[0-9-]", value) and len(value) >= 2 else None


def parse_iban(raw: str) -> str | None:
    value = raw.replace(" ", "").upper()
    return value if re.fullmatch(r"[A-Z]{2}\d{2}[A-Z0-9]{11,30}", value) else None


def parse_bic(raw: str) -> str | None:
    value = raw.strip().upper()
    return value if re.fullmatch(r"[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?", value) else None


def parse_vat_rate(raw: str) -> Decimal | None:
    match = VAT_RATE.fullmatch(raw.strip())
    if match is None:
        return None
    value = Decimal(match.group(1).replace(",", "."))
    return value if Decimal(0) <= value <= Decimal(100) else None


def parse_currency(raw: str) -> str | None:
    text = raw.strip().rstrip(".").upper()
    return "NOK" if text == "KR" else text if re.fullmatch(r"[A-Z]{3}", text) else None


def parse_identifier(raw: str) -> str | None:
    """An invoice number: one token with at least one digit, at most 64 characters."""
    value = raw.strip().strip(".:,;")
    if not IDENTIFIER.fullmatch(value) or not any(char.isdigit() for char in value):
        return None
    return value
