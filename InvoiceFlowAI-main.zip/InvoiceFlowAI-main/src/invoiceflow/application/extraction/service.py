"""Draft invoices from the text of analysed documents (Phase 06, ADR-0041).

For every part of a document (a scanned batch is split at separator sheets,
F11a) the field rules read one invoice from the words of its pages: the text
layer, else the OCR words. The invoice is registered as a draft, like an EHF
invoice: findings, posting suggestion and validation in one transaction, and
a human reviews and approves it (F09).

A part is registered once. A document the user has typed as something other
than an invoice or credit note is never read; an unclassified one only when it
calls itself an invoice or credit note (D-24: the document type is not
changed). Pages without any text yet (OCR not installed) are left for later.
"""

import datetime as dt
from collections.abc import Callable, Mapping, Sequence
from decimal import Decimal
from uuid import UUID, uuid4

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentRecord,
    DocumentType,
    ImportSource,
)
from invoiceflow.application.ehf import duplicate_key, ordered, recipient_findings
from invoiceflow.application.extraction.fields import Context, Extraction, extract
from invoiceflow.application.extraction.layout import page_layout
from invoiceflow.application.ports import UnitOfWorkFactory
from invoiceflow.application.processing import InvoicePoster, InvoiceValidator
from invoiceflow.application.processing_model import (
    InvoiceFindingCode,
    OcrLayer,
    PageRecord,
    TextLayer,
)
from invoiceflow.application.scan.model import split_batch
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import SYSTEM_ACTOR, utc_now

READABLE_TYPES = frozenset(
    {DocumentType.UNCLASSIFIED, DocumentType.INVOICE, DocumentType.CREDIT_NOTE}
)
_TYPED = frozenset({DocumentType.INVOICE, DocumentType.CREDIT_NOTE})


def _amount(field: object) -> Decimal | None:
    value = getattr(field, "value", None)
    return value if isinstance(value, Decimal) else None


def _sum_differs(parts: Sequence[Decimal | None], total: Decimal | None) -> bool:
    """Only complete sums are compared: a missing part or total is not a finding."""
    if total is None or not parts or any(part is None for part in parts):
        return False
    return sum(part for part in parts if part is not None) != total


def extraction_findings(extraction: Extraction) -> list[InvoiceFindingCode]:
    """What the extracted invoice itself shows; nothing is corrected."""
    invoice = extraction.invoice
    totals = invoice.totals
    net, vat, gross = (
        _amount(totals.net_amount),
        _amount(totals.vat_amount),
        _amount(totals.gross_amount),
    )
    rounding = _amount(totals.rounding_amount) or Decimal(0)
    findings = []
    if _sum_differs([_amount(line.net_amount) for line in invoice.lines], net):
        findings.append(InvoiceFindingCode.LINE_SUM_MISMATCH)
    if _sum_differs([_amount(entry.vat_amount) for entry in invoice.vat_breakdown], vat):
        findings.append(InvoiceFindingCode.VAT_MISMATCH)
    if net is not None and vat is not None and gross is not None and net + vat + rounding != gross:
        findings.append(InvoiceFindingCode.GROSS_MISMATCH)
    if gross is not None and gross < 0:
        findings.append(InvoiceFindingCode.NEGATIVE_TOTAL)
    if extraction.unreadable:
        findings.append(InvoiceFindingCode.UNREADABLE_VALUE)
    required = (
        invoice.invoice_number,
        invoice.invoice_date,
        invoice.currency,
        invoice.supplier.name,
        totals.gross_amount,
    )
    if any(field is None for field in required):
        findings.append(InvoiceFindingCode.MISSING_REQUIRED)
    return findings


def readable(document: DocumentRecord) -> bool:
    """PDFs and images that may be invoices; EHF and its attachments have their own path."""
    return (
        document.detected_format not in (None, DocumentFormat.XML)
        and document.source is not ImportSource.EHF_ATTACHMENT
        and document.document_type in READABLE_TYPES
    )


class ExtractionService:
    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        *,
        validator: InvoiceValidator | None = None,
        poster: InvoicePoster | None = None,
        clock: Callable[[], dt.datetime] = utc_now,
        new_id: Callable[[], UUID] = uuid4,
    ) -> None:
        self._uow_factory = uow_factory
        self._validator = validator
        self._poster = poster
        self._clock = clock
        self._new_id = new_id

    @staticmethod
    def readable(document: DocumentRecord) -> bool:
        return readable(document)

    def register(
        self,
        scope: EntityScope,
        document: DocumentRecord,
        pages: Sequence[PageRecord],
        layers: Mapping[int, TextLayer | OcrLayer],
        *,
        actor: str = SYSTEM_ACTOR,
    ) -> list[UUID]:
        """Register a draft invoice for every part not registered yet; returns the new ids."""
        if not readable(document) or not pages:
            return []
        with self._uow_factory() as uow:
            entity = uow.entities.get(scope.entity_id)
            invoices = uow.invoices(scope)
            registered = {
                invoices.get(invoice_id).invoice.first_page
                for invoice_id in invoices.ids_for_document(document.document_id)
            }
        created = []
        for first, last in split_batch(pages).parts:
            if first in registered:
                continue
            layouts = [page_layout(n, layers[n]) for n in range(first, last + 1) if n in layers]
            if not layouts:
                continue  # no text yet: OCR missing or not run
            context = Context(document.document_id, first, last, entity.org_number, entity.name)
            extraction = extract(layouts, context)
            if not extraction.titled and document.document_type not in _TYPED:
                continue  # an unclassified document that does not call itself an invoice
            created.append(self._register(scope, entity.org_number, extraction, actor))
        return created

    def _register(
        self, scope: EntityScope, entity_org: str | None, extraction: Extraction, actor: str
    ) -> UUID:
        now = self._clock()
        invoice = extraction.invoice
        with self._uow_factory() as uow:
            invoices = uow.invoices(scope)
            codes = extraction_findings(extraction) + recipient_findings(invoice, entity_org)
            key = duplicate_key(invoice)
            if key is not None and invoices.ids_by_supplier_and_number(*key):
                codes.append(InvoiceFindingCode.POSSIBLE_DUPLICATE)
            codes = ordered(codes)
            invoice_id = self._new_id()
            if self._poster is not None:
                invoice = self._poster.prepare(uow, scope, invoice)
            record = invoices.add(
                invoice_id=invoice_id, invoice=invoice, recorded_at=now, actor=actor
            )
            uow.audit.append(
                AuditDraft(
                    event_type=AuditEventType.INVOICE_CREATED,
                    actor=actor,
                    entity_id=scope.entity_id,
                    subject_id=str(invoice_id),
                    details={
                        "revision": record.revision,
                        "content_sha256": record.content_sha256,
                        "schema_version": invoice.schema_version,
                    },
                ),
                occurred_at=now,
            )
            invoices.add_findings(invoice_id, record.revision, codes, now)
            if self._validator is not None:
                self._validator.validate_in(uow, scope, invoice_id, actor=actor)
            uow.commit()
        return invoice_id
