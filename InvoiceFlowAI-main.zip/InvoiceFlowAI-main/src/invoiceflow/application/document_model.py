"""Generic document vocabulary and pure checks (docs/DOCUMENT_ARCHIVE_SCOPE.md).

A document is any accounting-related original file. An invoice is one kind of
document; other kinds are never forced into ``CanonicalInvoice``. Nothing in
this module performs I/O, so the rules can be tested and reused everywhere.
"""

import datetime as dt
import unicodedata
from dataclasses import dataclass
from enum import StrEnum
from uuid import UUID

MAX_DOCUMENT_BYTES = 50 * 1024 * 1024  # docs/SECURITY.md: maximum file size
HEADER_BYTES = 16
MAX_DISPLAY_NAME = 255
FALLBACK_DISPLAY_NAME = "dokument"


class DocumentType(StrEnum):
    UNCLASSIFIED = "unclassified"
    INVOICE = "invoice"
    CREDIT_NOTE = "credit_note"
    RECEIPT = "receipt"
    CONTRACT = "contract"
    PAYMENT_CONFIRMATION = "payment_confirmation"
    CORRESPONDENCE = "correspondence"
    OTHER = "other"


class DocumentFormat(StrEnum):
    PDF = "pdf"
    PNG = "png"
    JPEG = "jpeg"
    TIFF = "tiff"
    XML = "xml"  # EHF/PEPPOL BIS Billing 3.0 (Phase 15)


class DocumentStatus(StrEnum):
    STORED = "stored"
    QUARANTINED = "quarantined"


class IntegrityStatus(StrEnum):
    OK = "ok"
    MISMATCH = "mismatch"
    MISSING = "missing"


class ImportSource(StrEnum):
    FILE_IMPORT = "file_import"
    INBOX = "inbox"
    EHF_ATTACHMENT = "ehf_attachment"  # embedded in an EHF invoice (Phase 15)


class ImportOutcome(StrEnum):
    IMPORTED = "imported"
    DUPLICATE = "duplicate"
    QUARANTINED = "quarantined"
    REJECTED = "rejected"
    # Technical failure (e.g. the archive folder was locked); nothing was stored
    # and the source is unchanged, so the file can simply be imported again.
    FAILED = "failed"


class RejectReason(StrEnum):
    """The file was not copied into the archive at all."""

    EMPTY = "empty"
    TOO_LARGE = "too_large"
    UNREADABLE = "unreadable"
    CHANGED = "changed_during_read"
    NOT_A_FILE = "not_a_regular_file"


class QuarantineReason(StrEnum):
    """The file was copied, but only into quarantine; it is never opened again."""

    UNKNOWN_FORMAT = "unknown_format"
    EXTENSION_MISMATCH = "extension_mismatch"


class SizeClass(StrEnum):
    """Coarse size for audit details; exact sizes stay in the documents table."""

    UNDER_100KB = "under_100kb"
    UNDER_1MB = "under_1mb"
    UNDER_10MB = "under_10mb"
    UP_TO_50MB = "up_to_50mb"


_SIGNATURES: tuple[tuple[bytes, DocumentFormat], ...] = (
    (b"%PDF-", DocumentFormat.PDF),
    (b"\x89PNG\r\n\x1a\n", DocumentFormat.PNG),
    (b"\xff\xd8\xff", DocumentFormat.JPEG),
    (b"II*\x00", DocumentFormat.TIFF),
    (b"MM\x00*", DocumentFormat.TIFF),
)
_UTF8_BOM = b"\xef\xbb\xbf"
# XML is recognised only by an XML declaration or an EHF root element; any other
# file that merely starts with "<" stays unknown (quarantine).
_XML_STARTS = (b"<?xml", b"<Invoice", b"<CreditNote")

EXTENSIONS: dict[DocumentFormat, frozenset[str]] = {
    DocumentFormat.PDF: frozenset({".pdf"}),
    DocumentFormat.PNG: frozenset({".png"}),
    DocumentFormat.JPEG: frozenset({".jpg", ".jpeg", ".jpe"}),
    DocumentFormat.TIFF: frozenset({".tif", ".tiff"}),
    DocumentFormat.XML: frozenset({".xml"}),
}

STORED_EXTENSION: dict[DocumentFormat, str] = {
    DocumentFormat.PDF: "pdf",
    DocumentFormat.PNG: "png",
    DocumentFormat.JPEG: "jpg",
    DocumentFormat.TIFF: "tif",
    DocumentFormat.XML: "xml",
}


def detect_format(header: bytes) -> DocumentFormat | None:
    """Format from the file signature. A signature is not full validation (F04)."""
    for signature, document_format in _SIGNATURES:
        if header.startswith(signature):
            return document_format
    text = header.removeprefix(_UTF8_BOM)
    if text.startswith(_XML_STARTS):
        return DocumentFormat.XML
    return None


def extension_matches(filename: str, document_format: DocumentFormat) -> bool:
    """True only for a known extension of the detected format (case-insensitive)."""
    name = filename.replace("\\", "/").rsplit("/", 1)[-1]
    if "." not in name:
        return False
    extension = "." + name.rsplit(".", 1)[1].lower()
    return extension in EXTENSIONS[document_format]


def sanitize_display_name(filename: str) -> str:
    """A safe label for display only; it is never used to build a path."""
    name = filename.replace("\\", "/").rsplit("/", 1)[-1]
    name = unicodedata.normalize("NFC", name)
    name = "".join(ch for ch in name if unicodedata.category(ch) not in {"Cc", "Cf", "Zl", "Zp"})
    name = " ".join(name.split()).strip(" .")
    return name[:MAX_DISPLAY_NAME] or FALLBACK_DISPLAY_NAME


def size_class(size_bytes: int) -> SizeClass:
    if size_bytes < 100 * 1024:
        return SizeClass.UNDER_100KB
    if size_bytes < 1024 * 1024:
        return SizeClass.UNDER_1MB
    if size_bytes < 10 * 1024 * 1024:
        return SizeClass.UNDER_10MB
    return SizeClass.UP_TO_50MB


@dataclass(frozen=True, slots=True)
class DocumentRecord:
    """Ownership, integrity and archive metadata of one original file."""

    document_id: UUID
    entity_id: UUID
    document_type: DocumentType
    sha256: str
    size_bytes: int
    detected_format: DocumentFormat | None
    display_name: str
    storage_path: str
    source: ImportSource
    status: DocumentStatus
    imported_at: dt.datetime
    imported_by: str
    integrity_status: IntegrityStatus | None = None
    integrity_checked_at: dt.datetime | None = None


@dataclass(frozen=True, slots=True)
class ImportResult:
    outcome: ImportOutcome
    document_id: UUID | None = None
    reason: RejectReason | QuarantineReason | None = None


@dataclass(frozen=True, slots=True)
class RecoveryReport:
    """What startup reconciliation found for one entity; nothing is ever deleted."""

    staging_removed: int = 0
    orphans_moved: int = 0
    missing: tuple[UUID, ...] = ()
    failed: int = 0  # files that could not be cleaned up or moved; left in place
