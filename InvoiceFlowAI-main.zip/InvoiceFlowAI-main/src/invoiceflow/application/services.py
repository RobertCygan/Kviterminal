"""Application services for Phase 02: entities and invoice revisions.

Each operation writes its business change and its audit event in one unit of
work, so a failure stores neither.
"""

import datetime as dt
from collections.abc import Callable
from dataclasses import dataclass
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

from pydantic import ValidationError

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.document_model import DocumentStatus
from invoiceflow.application.errors import ConflictError, InvoiceFlowError, NotFoundError
from invoiceflow.application.ports import (
    EntityRecord,
    InvoiceRecord,
    UnitOfWork,
    UnitOfWorkFactory,
)
from invoiceflow.application.review.model import ApprovalRecord, Decision, WorkflowStatus
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.validation.model import ValidationSummary
from invoiceflow.domain.base import ContractModel
from invoiceflow.domain.invoice import CanonicalInvoice
from invoiceflow.domain.provenance import FieldValue
from invoiceflow.domain.types import CurrencyCode, OrgNumber, ShortText

SYSTEM_ACTOR = "system"


def utc_now() -> dt.datetime:
    return dt.datetime.now(dt.UTC)


class NewEntity(ContractModel):
    """Validated input for creating an accounting entity (regnskapsenhet)."""

    name: ShortText
    org_number: OrgNumber | None = None
    default_currency: CurrencyCode = "NOK"


class EntityService:
    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        *,
        clock: Callable[[], dt.datetime] = utc_now,
        new_id: Callable[[], UUID] = uuid4,
    ) -> None:
        self._uow_factory = uow_factory
        self._clock = clock
        self._new_id = new_id

    def create(
        self,
        *,
        name: str,
        org_number: str | None = None,
        default_currency: str = "NOK",
        actor: str = SYSTEM_ACTOR,
    ) -> EntityRecord:
        try:
            data = NewEntity(name=name, org_number=org_number, default_currency=default_currency)
        except ValidationError as exc:
            raise InvoiceFlowError("INVALID_INPUT", "error.invalid_input") from exc
        entity_id = self._new_id()
        now = self._clock()
        draft = AuditDraft(
            event_type=AuditEventType.ENTITY_CREATED,
            actor=actor,
            entity_id=entity_id,
            subject_id=str(entity_id),
        )
        with self._uow_factory() as uow:
            record = uow.entities.add(
                entity_id=entity_id,
                name=data.name,
                org_number=data.org_number,
                default_currency=data.default_currency,
                created_at=now,
            )
            uow.audit.append(draft, occurred_at=now)
            uow.commit()
        return record

    def get(self, entity_id: UUID) -> EntityRecord:
        with self._uow_factory() as uow:
            return uow.entities.get(entity_id)

    def list(self) -> list[EntityRecord]:
        with self._uow_factory() as uow:
            return uow.entities.list()


class InvoiceService:
    """Store canonical invoices as immutable, entity-scoped revisions."""

    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        *,
        clock: Callable[[], dt.datetime] = utc_now,
        new_id: Callable[[], UUID] = uuid4,
    ) -> None:
        self._uow_factory = uow_factory
        self._clock = clock
        self._new_id = new_id

    def register(
        self, scope: EntityScope, invoice: CanonicalInvoice, *, actor: str = SYSTEM_ACTOR
    ) -> InvoiceRecord:
        """Store a new invoice as revision 1."""
        invoice_id = self._new_id()
        now = self._clock()
        with self._uow_factory() as uow:
            uow.entities.get(scope.entity_id)
            # The invoice must describe a stored document of the same entity
            # (also enforced by the database trigger invoices_reference_document).
            document = uow.documents(scope).get(invoice.document_id)
            if document.status != DocumentStatus.STORED:
                raise NotFoundError()
            record = uow.invoices(scope).add(
                invoice_id=invoice_id, invoice=invoice, recorded_at=now, actor=actor
            )
            uow.audit.append(
                AuditDraft(
                    event_type=AuditEventType.INVOICE_CREATED,
                    actor=actor,
                    entity_id=scope.entity_id,
                    subject_id=str(invoice_id),
                    details={
                        "revision": record.revision,
                        "content_sha256": record.content_sha256,
                        "schema_version": invoice.schema_version,
                    },
                ),
                occurred_at=now,
            )
            uow.commit()
        return record

    def summaries(self, scope: EntityScope) -> dict[UUID, "InvoiceSummary"]:
        """Latest revision of every invoice, keyed by its document (for the inbox)."""
        return summarize_invoices(self._uow_factory, scope)

    def revise(
        self,
        scope: EntityScope,
        invoice_id: UUID,
        invoice: CanonicalInvoice,
        *,
        expected_revision: int,
        actor: str = SYSTEM_ACTOR,
    ) -> InvoiceRecord:
        """Append a new revision; identical content is idempotent (no new revision)."""
        with self._uow_factory() as uow:
            record = revise_in(
                uow,
                scope,
                invoice_id,
                invoice,
                expected_revision=expected_revision,
                actor=actor,
                now=self._clock(),
            )
            uow.commit()
        return record

    def get(self, scope: EntityScope, invoice_id: UUID) -> InvoiceRecord:
        with self._uow_factory() as uow:
            return uow.invoices(scope).get(invoice_id)

    def get_revision(self, scope: EntityScope, invoice_id: UUID, revision: int) -> InvoiceRecord:
        with self._uow_factory() as uow:
            return uow.invoices(scope).get_revision(invoice_id, revision)


def revise_in(
    uow: UnitOfWork,
    scope: EntityScope,
    invoice_id: UUID,
    invoice: CanonicalInvoice,
    *,
    expected_revision: int,
    actor: str,
    now: dt.datetime,
) -> InvoiceRecord:
    """A new revision and its audit event in the caller's unit of work."""
    repository = uow.invoices(scope)
    current = repository.get(invoice_id)
    if current.revision != expected_revision:
        raise ConflictError()
    record = repository.replace(
        invoice_id=invoice_id,
        invoice=invoice,
        expected_revision=expected_revision,
        recorded_at=now,
        actor=actor,
    )
    if record.revision == current.revision:
        return record
    if current.workflow_status == WorkflowStatus.APPROVED:
        _revoke(uow, scope, current, actor=actor, now=now)
    uow.audit.append(
        AuditDraft(
            event_type=AuditEventType.INVOICE_REVISED,
            actor=actor,
            entity_id=scope.entity_id,
            subject_id=str(invoice_id),
            details={
                "revision": record.revision,
                "previous_revision": current.revision,
                "content_sha256": record.content_sha256,
                "previous_content_sha256": current.content_sha256,
                "schema_version": invoice.schema_version,
            },
        ),
        occurred_at=now,
    )
    return record


def _revoke(
    uow: UnitOfWork, scope: EntityScope, current: InvoiceRecord, *, actor: str, now: dt.datetime
) -> None:
    """New content ends the approval of the old content (ADR-0035)."""
    reviews = uow.reviews(scope)
    decision = reviews.add_decision(
        ApprovalRecord(
            approval_id=uuid4(),
            invoice_id=current.invoice_id,
            sequence=reviews.next_sequence(current.invoice_id),
            revision=current.revision,
            content_sha256=current.content_sha256,
            decision=Decision.REVOKED,
            run_id=None,
            comment=None,
            decided_at=now,
            decided_by=actor,
        )
    )
    uow.audit.append(
        AuditDraft(
            event_type=AuditEventType.INVOICE_APPROVAL_REVOKED,
            actor=actor,
            entity_id=scope.entity_id,
            subject_id=str(current.invoice_id),
            details={
                "approval_id": str(decision.approval_id),
                "revision": current.revision,
                "content_sha256": current.content_sha256,
            },
        ),
        occurred_at=now,
    )


@dataclass(frozen=True, slots=True)
class InvoiceSummary:
    """What the inbox shows about the invoice registered for a document."""

    invoice_id: UUID
    supplier_name: str | None
    invoice_number: str | None
    gross_amount: Decimal | None
    currency: str | None
    findings: tuple[str, ...]
    # Latest validation of the current revision; None if it was not validated.
    validation: ValidationSummary | None = None
    workflow_status: str = "draft"


def _value(field: FieldValue[Any] | None) -> Any:
    return None if field is None else field.value


def summarize_invoices(
    uow_factory: UnitOfWorkFactory, scope: EntityScope
) -> dict[UUID, InvoiceSummary]:
    """Latest revision of every invoice of the entity, keyed by its document."""
    summaries: dict[UUID, InvoiceSummary] = {}
    with uow_factory() as uow:
        repository = uow.invoices(scope)
        runs = uow.validations(scope).latest_runs()
        for invoice_id in repository.list_ids():
            record = repository.get(invoice_id)
            invoice = record.invoice
            # Import findings describe the source document; they were recorded
            # with the first revision and stay relevant after later revisions.
            findings = tuple(dict.fromkeys(code for _, code in repository.findings(invoice_id)))
            summaries[invoice.document_id] = InvoiceSummary(
                invoice_id=invoice_id,
                supplier_name=_value(invoice.supplier.name),
                invoice_number=_value(invoice.invoice_number),
                gross_amount=_value(invoice.totals.gross_amount),
                currency=_value(invoice.currency),
                findings=findings,
                validation=run.summary
                if (run := runs.get(invoice_id)) is not None and run.revision == record.revision
                else None,
                workflow_status=record.workflow_status,
            )
    return summaries
