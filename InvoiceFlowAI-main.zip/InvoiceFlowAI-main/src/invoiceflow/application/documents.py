"""Secure document import into the entity-scoped original archive (Phase 03).

Crash model
-----------
File storage and the database cannot share one transaction. The order is:

1. ``stage``: copy the source into a private staging file, hash, fsync.
2. ``publish``: re-verify and atomically rename into the content-addressed
   original path (idempotent: an identical existing file is reused).
3. One unit of work: document row and audit event, then commit.

A crash after 1 leaves a staging file; after 2 an original without a row.
Startup reconciliation (:meth:`DocumentService.reconcile`) removes staging
leftovers and moves unreferenced originals to ``orphans`` - it never deletes
an original. Importing the same file again after a crash is safe.
"""

import datetime as dt
from collections.abc import Callable, Sequence
from pathlib import Path
from uuid import UUID, uuid4

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.document_model import (
    MAX_DOCUMENT_BYTES,
    STORED_EXTENSION,
    DocumentRecord,
    DocumentStatus,
    DocumentType,
    ImportOutcome,
    ImportResult,
    ImportSource,
    IntegrityStatus,
    QuarantineReason,
    RecoveryReport,
    detect_format,
    extension_matches,
    sanitize_display_name,
    size_class,
)
from invoiceflow.application.errors import ConflictError, StorageError
from invoiceflow.application.ports import (
    DocumentStore,
    StagedFile,
    StagingError,
    UnitOfWorkFactory,
)
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import SYSTEM_ACTOR, utc_now


class DocumentService:
    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        store: DocumentStore,
        *,
        clock: Callable[[], dt.datetime] = utc_now,
        new_id: Callable[[], UUID] = uuid4,
        max_bytes: int = MAX_DOCUMENT_BYTES,
    ) -> None:
        self._uow_factory = uow_factory
        self._store = store
        self._clock = clock
        self._new_id = new_id
        self._max_bytes = max_bytes

    def import_file(
        self,
        scope: EntityScope,
        source: Path,
        *,
        origin: ImportSource = ImportSource.FILE_IMPORT,
        actor: str = SYSTEM_ACTOR,
        name: str | None = None,
    ) -> ImportResult:
        """Import one file. The source file is never modified or removed.

        ``name`` replaces the source's own name for the extension check and the
        display name (an EHF attachment is stored by the worker under a fixed
        name, but declares its own file name).
        """
        with self._uow_factory() as uow:
            uow.entities.get(scope.entity_id)  # NotFoundError for an unknown entity
        try:
            staged = self._store.stage(source, scope.entity_id, self._max_bytes)
        except StagingError as exc:
            attempt = self._new_id()
            self._record(
                scope,
                AuditEventType.DOCUMENT_REJECTED,
                attempt,
                {"reject_reason": str(exc.reason), "source": str(origin)},
                actor,
            )
            return ImportResult(ImportOutcome.REJECTED, None, exc.reason)
        try:
            return self._import_staged(scope, name or source.name, staged, origin, actor)
        finally:
            self._store.discard(staged)

    def import_files(
        self,
        scope: EntityScope,
        sources: Sequence[Path],
        *,
        origin: ImportSource = ImportSource.FILE_IMPORT,
        actor: str = SYSTEM_ACTOR,
        should_stop: Callable[[], bool] = lambda: False,
    ) -> list[ImportResult]:
        """Import several files; a storage failure for one does not stop the rest.

        ``should_stop`` is asked between files (never in the middle of one), so
        the application can shut down without cutting an import in half.
        """
        results = []
        for source in sources:
            if should_stop():
                break
            try:
                results.append(self.import_file(scope, source, origin=origin, actor=actor))
            except StorageError:
                # Nothing was stored and the source is untouched: report and go on.
                results.append(ImportResult(ImportOutcome.FAILED))
        return results

    def import_inbox(
        self,
        scope: EntityScope,
        inbox: Path,
        *,
        actor: str = SYSTEM_ACTOR,
        should_stop: Callable[[], bool] = lambda: False,
    ) -> list[ImportResult]:
        """Import every regular file directly in ``inbox`` (not recursive)."""
        return self.import_files(
            scope,
            self._store.list_candidates(inbox),
            origin=ImportSource.INBOX,
            actor=actor,
            should_stop=should_stop,
        )

    def list_documents(self, scope: EntityScope) -> list[DocumentRecord]:
        with self._uow_factory() as uow:
            return uow.documents(scope).list()

    def get(self, scope: EntityScope, document_id: UUID) -> DocumentRecord:
        with self._uow_factory() as uow:
            return uow.documents(scope).get(document_id)

    def set_type(
        self,
        scope: EntityScope,
        document_id: UUID,
        document_type: DocumentType,
        *,
        actor: str = SYSTEM_ACTOR,
    ) -> DocumentRecord:
        """Classify a document manually; the change is audited (D-24)."""
        document_type = DocumentType(document_type)
        with self._uow_factory() as uow:
            repository = uow.documents(scope)
            current = repository.get(document_id)
            if current.document_type == document_type:
                return current
            updated = repository.set_type(
                document_id, document_type, expected=current.document_type
            )
            uow.audit.append(
                AuditDraft(
                    event_type=AuditEventType.DOCUMENT_TYPE_CHANGED,
                    actor=actor,
                    entity_id=scope.entity_id,
                    subject_id=str(document_id),
                    details={
                        "document_type": str(document_type),
                        "previous_document_type": str(current.document_type),
                    },
                ),
                occurred_at=self._clock(),
            )
            uow.commit()
        return updated

    def reconcile(self, scope: EntityScope) -> RecoveryReport:
        """Repair the state after a crash without deleting any original."""
        with self._uow_factory() as uow:
            documents = uow.documents(scope).list()
        report = self._store.recover(
            scope.entity_id, frozenset(record.storage_path for record in documents)
        )
        missing = tuple(
            record.document_id
            for record in documents
            if record.storage_path in report.missing_paths
        )
        if missing:
            now = self._clock()
            with self._uow_factory() as uow:
                repository = uow.documents(scope)
                for document_id in missing:
                    repository.set_integrity(document_id, IntegrityStatus.MISSING, checked_at=now)
                uow.commit()
        return RecoveryReport(report.staging_removed, report.orphans_moved, missing, report.failed)

    def verify_integrity(self, scope: EntityScope) -> dict[UUID, IntegrityStatus]:
        """Re-hash every original of the entity and record the result."""
        results = {
            record.document_id: self._store.verify(record.storage_path, record.sha256)
            for record in self.list_documents(scope)
        }
        now = self._clock()
        with self._uow_factory() as uow:
            repository = uow.documents(scope)
            for document_id, status in results.items():
                repository.set_integrity(document_id, status, checked_at=now)
            uow.commit()
        return results

    def _import_staged(
        self,
        scope: EntityScope,
        filename: str,
        staged: StagedFile,
        origin: ImportSource,
        actor: str,
    ) -> ImportResult:
        with self._uow_factory() as uow:
            existing = uow.documents(scope).find_by_sha256(staged.sha256)
        if existing is not None:
            return self._duplicate(scope, existing.document_id, staged, origin, actor)
        document_format = detect_format(staged.header)
        reason = None
        if document_format is None:
            reason = QuarantineReason.UNKNOWN_FORMAT
        elif not extension_matches(filename, document_format):
            reason = QuarantineReason.EXTENSION_MISMATCH
        document_id = self._new_id()
        if reason is None and document_format is not None:
            storage_path = self._store.publish(
                staged, scope.entity_id, staged.sha256, STORED_EXTENSION[document_format]
            )
            status = DocumentStatus.STORED
        else:
            storage_path = self._store.quarantine(staged, scope.entity_id, document_id)
            status = DocumentStatus.QUARANTINED
            document_format = None
        record = DocumentRecord(
            document_id=document_id,
            entity_id=scope.entity_id,
            document_type=DocumentType.UNCLASSIFIED,
            sha256=staged.sha256,
            size_bytes=staged.size_bytes,
            detected_format=document_format,
            display_name=sanitize_display_name(filename),
            storage_path=storage_path,
            source=origin,
            status=status,
            imported_at=self._clock(),
            imported_by=actor,
        )
        if reason is None:
            event = AuditEventType.DOCUMENT_IMPORTED
            details: dict[str, object] = {
                "sha256": staged.sha256,
                "size_class": str(size_class(staged.size_bytes)),
                "format": str(document_format),
                "document_type": str(DocumentType.UNCLASSIFIED),
                "source": str(origin),
            }
        else:
            event = AuditEventType.DOCUMENT_QUARANTINED
            details = {
                "sha256": staged.sha256,
                "size_class": str(size_class(staged.size_bytes)),
                "quarantine_reason": str(reason),
                "source": str(origin),
            }
        try:
            with self._uow_factory() as uow:
                uow.documents(scope).add(record)
                uow.audit.append(
                    AuditDraft(
                        event_type=event,
                        actor=actor,
                        entity_id=scope.entity_id,
                        subject_id=str(document_id),
                        details=details,
                    ),
                    occurred_at=record.imported_at,
                )
                uow.commit()
        except ConflictError:
            # A concurrent import of the same file won the race; the published
            # original is the same content-addressed file and stays in use.
            with self._uow_factory() as uow:
                winner = uow.documents(scope).find_by_sha256(staged.sha256)
            if winner is None:
                raise
            return self._duplicate(scope, winner.document_id, staged, origin, actor)
        if reason is None:
            return ImportResult(ImportOutcome.IMPORTED, document_id)
        return ImportResult(ImportOutcome.QUARANTINED, document_id, reason)

    def _duplicate(
        self,
        scope: EntityScope,
        existing_id: UUID,
        staged: StagedFile,
        origin: ImportSource,
        actor: str,
    ) -> ImportResult:
        self._record(
            scope,
            AuditEventType.DOCUMENT_DUPLICATE_REJECTED,
            existing_id,
            {"sha256": staged.sha256, "source": str(origin)},
            actor,
        )
        return ImportResult(ImportOutcome.DUPLICATE, existing_id)

    def _record(
        self,
        scope: EntityScope,
        event: AuditEventType,
        subject: UUID,
        details: dict[str, object],
        actor: str,
    ) -> None:
        with self._uow_factory() as uow:
            uow.entities.get(scope.entity_id)
            uow.audit.append(
                AuditDraft(
                    event_type=event,
                    actor=actor,
                    entity_id=scope.entity_id,
                    subject_id=str(subject),
                    details=details,
                ),
                occurred_at=self._clock(),
            )
            uow.commit()
