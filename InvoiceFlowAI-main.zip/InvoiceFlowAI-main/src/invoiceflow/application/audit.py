"""Audit events: privacy-safe payloads and a verifiable hash chain (ADR-0016, ADR-0027).

The rules here are pure Python so that they can be tested without a database
and reused by any persistence adapter.

Chain design
------------
* One global chain ordered by ``sequence`` (1, 2, 3, ...). Global events such
  as database migrations have no accounting entity, and a single chain gives
  one unambiguous order across entities.
* Genesis: the first event has ``prev_hash`` = 64 zeros.
* ``event_hash`` = SHA-256 of the canonical JSON of :func:`hash_payload`,
  which covers every stored column (including ``sequence`` and ``prev_hash``).

Privacy
-------
Details are validated against a per-event allowlist of keys and value
patterns (identifiers, revision numbers, hashes, codes). Free text, amounts,
names and exception messages cannot be stored, because no allowed pattern
accepts them. Callers cannot opt out.
"""

import datetime as dt
import re
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from types import MappingProxyType
from uuid import UUID

from invoiceflow.application.backup.model import MAX_MEMBERS
from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentType,
    ImportSource,
    QuarantineReason,
    RejectReason,
    SizeClass,
)
from invoiceflow.application.export.model import ExportErrorCode, ExportField, ExportTarget
from invoiceflow.application.processing_model import (
    MAX_PAGES_CEILING,
    JobStatus,
    ProcessingErrorCode,
    ProcessingStep,
)
from invoiceflow.application.reference.model import MAX_REFERENCE_ROWS, ReferenceKind
from invoiceflow.application.validation.model import AccountKind, AccountStatus, RuleId
from invoiceflow.domain.canonical import canonical_json_bytes, format_utc, sha256_hex

HASH_VERSION = 1
GENESIS_HASH = "0" * 64
MAX_REVISION = 1_000_000_000
MAX_EXPORT_ITEMS = 1_000_000

_HEX64 = re.compile(r"[0-9a-f]{64}")
_CODE = re.compile(r"[a-z0-9_]{1,32}")
_SCHEMA_VERSION = re.compile(r"[0-9]{1,3}\.[0-9]{1,3}")
_ACTOR = re.compile(r"[a-z]{1,16}(/[A-Za-z0-9._-]{1,64})?")
_UUID_TEXT = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")


class AuditEventType(StrEnum):
    DATABASE_CREATED = "database.created"
    DATABASE_MIGRATED = "database.migrated"
    ENTITY_CREATED = "entity.created"
    INVOICE_CREATED = "invoice.created"
    INVOICE_REVISED = "invoice.revised"
    DOCUMENT_IMPORTED = "document.imported"
    DOCUMENT_DUPLICATE_REJECTED = "document.duplicate_rejected"
    DOCUMENT_QUARANTINED = "document.quarantined"
    DOCUMENT_REJECTED = "document.rejected"
    DOCUMENT_TYPE_CHANGED = "document.type_changed"
    PROCESSING_STARTED = "document.processing_started"
    PROCESSING_FINISHED = "document.processing_finished"
    INVOICE_VALIDATED = "invoice.validated"
    SUPPLIER_CREATED = "supplier.created"
    SUPPLIER_ACCOUNT_ADDED = "supplier.account_added"
    SUPPLIER_ACCOUNT_STATUS_CHANGED = "supplier.account_status_changed"
    REFERENCE_IMPORTED = "reference.imported"
    SUPPLIER_DEFAULTS_SET = "supplier.defaults_set"
    INVOICE_APPROVED = "invoice.approved"
    INVOICE_REJECTED = "invoice.rejected"
    INVOICE_APPROVAL_REVOKED = "invoice.approval_revoked"
    FINDING_OVERRIDDEN = "finding.overridden"
    INVOICE_EXPORTED = "invoice.exported"
    EXPORT_COMPLETED = "export.completed"
    EXPORT_FAILED = "export.failed"
    EXPORT_MAPPING_SET = "export.mapping_set"
    BACKUP_CREATED = "backup.created"
    BACKUP_VERIFIED = "backup.verified"
    BACKUP_RESTORED = "backup.restored"
    BACKUP_DELETED = "backup.deleted"


class SubjectType(StrEnum):
    DATABASE = "database"
    ENTITY = "entity"
    INVOICE = "invoice"
    DOCUMENT = "document"
    SUPPLIER = "supplier"


def _revision(value: object) -> bool:
    return type(value) is int and 1 <= value <= MAX_REVISION


def _hex64(value: object) -> bool:
    return isinstance(value, str) and bool(_HEX64.fullmatch(value))


def _code(value: object) -> bool:
    return isinstance(value, str) and bool(_CODE.fullmatch(value))


def _schema_version(value: object) -> bool:
    return isinstance(value, str) and bool(_SCHEMA_VERSION.fullmatch(value))


def _uuid_text(value: object) -> bool:
    return isinstance(value, str) and bool(_UUID_TEXT.fullmatch(value))


def _attempt(value: object) -> bool:
    return type(value) is int and 1 <= value <= 1000


def _page_count(value: object) -> bool:
    return type(value) is int and 1 <= value <= MAX_PAGES_CEILING


def _count(limit: int) -> Callable[[object], bool]:
    return lambda value: type(value) is int and 0 <= value <= limit


def _boolean(value: object) -> bool:
    return type(value) is bool


def _member(enum: type[StrEnum]) -> Callable[[object], bool]:
    # Exact enumeration values only: a free-form code could still carry a name.
    values = frozenset(item.value for item in enum)
    return lambda value: type(value) is str and value in values


_VALIDATORS: dict[str, Callable[[object], bool]] = {
    "revision": _revision,
    "previous_revision": _revision,
    "content_sha256": _hex64,
    "previous_content_sha256": _hex64,
    "schema_version": _schema_version,
    "schema_revision": _code,
    "from_revision": _code,
    "to_revision": _code,
    "backup_created": _boolean,
    "sha256": _hex64,
    "size_class": _member(SizeClass),
    "format": _member(DocumentFormat),
    "document_type": _member(DocumentType),
    "previous_document_type": _member(DocumentType),
    "source": _member(ImportSource),
    "quarantine_reason": _member(QuarantineReason),
    "reject_reason": _member(RejectReason),
    "job_id": _uuid_text,
    "attempt": _attempt,
    "step": _member(ProcessingStep),
    "job_status": _member(JobStatus),
    "error_code": _member(ProcessingErrorCode),
    "page_count": _page_count,
    "active_content": _boolean,
    "line_count": _count(5000),
    "attachment_count": _count(20),
    "finding_count": _count(50),
    "word_count": _count(20_000_000),  # Phase 05: all OCR words of a document
    "mean_confidence": _count(100),
    "run_id": _uuid_text,
    "ruleset_version": _schema_version,
    "error_count": _count(200),
    "warning_count": _count(200),
    "info_count": _count(200),
    "account_id": _uuid_text,
    "account_kind": _member(AccountKind),
    "account_status": _member(AccountStatus),
    "previous_account_status": _member(AccountStatus),
    "reference_kind": _member(ReferenceKind),
    "row_count": _count(MAX_REFERENCE_ROWS),
    "approval_id": _uuid_text,
    "override_count": _count(200),
    "rule_id": _member(RuleId),
    "batch_id": _uuid_text,
    "target": _member(ExportTarget),
    "item_count": _count(MAX_EXPORT_ITEMS),
    "file_sha256": _hex64,
    "audit_anchor": _hex64,
    "mapping_version": _count(MAX_REVISION),
    "column_count": _count(len(ExportField)),
    "is_reexport": _boolean,
    "recovered": _boolean,
    "export_error": _member(ExportErrorCode),
    "backup_id": _uuid_text,
    "file_count": _count(MAX_MEMBERS),
    "audit_sequence": _count(2**62),
    "valid": _boolean,
}

ALLOWED_DETAILS: Mapping[AuditEventType, frozenset[str]] = MappingProxyType(
    {
        AuditEventType.DATABASE_CREATED: frozenset({"schema_revision"}),
        AuditEventType.DATABASE_MIGRATED: frozenset(
            {"from_revision", "to_revision", "backup_created"}
        ),
        AuditEventType.ENTITY_CREATED: frozenset(),
        AuditEventType.INVOICE_CREATED: frozenset({"revision", "content_sha256", "schema_version"}),
        AuditEventType.INVOICE_REVISED: frozenset(
            {
                "revision",
                "previous_revision",
                "content_sha256",
                "previous_content_sha256",
                "schema_version",
            }
        ),
        AuditEventType.DOCUMENT_IMPORTED: frozenset(
            {"sha256", "size_class", "format", "document_type", "source"}
        ),
        AuditEventType.DOCUMENT_DUPLICATE_REJECTED: frozenset({"sha256", "source"}),
        AuditEventType.DOCUMENT_QUARANTINED: frozenset(
            {"sha256", "size_class", "quarantine_reason", "source"}
        ),
        AuditEventType.DOCUMENT_REJECTED: frozenset({"reject_reason", "source"}),
        AuditEventType.DOCUMENT_TYPE_CHANGED: frozenset(
            {"document_type", "previous_document_type"}
        ),
        AuditEventType.PROCESSING_STARTED: frozenset({"job_id", "attempt", "step"}),
        AuditEventType.PROCESSING_FINISHED: frozenset(
            {
                "job_id",
                "step",
                "job_status",
                "error_code",
                "page_count",
                "active_content",
                "line_count",
                "attachment_count",
                "finding_count",
                "word_count",
                "mean_confidence",
            }
        ),
        AuditEventType.INVOICE_VALIDATED: frozenset(
            {
                "run_id",
                "revision",
                "ruleset_version",
                "error_count",
                "warning_count",
                "info_count",
            }
        ),
        AuditEventType.SUPPLIER_CREATED: frozenset(),
        AuditEventType.SUPPLIER_ACCOUNT_ADDED: frozenset({"account_id", "account_kind"}),
        AuditEventType.SUPPLIER_ACCOUNT_STATUS_CHANGED: frozenset(
            {"account_id", "account_status", "previous_account_status"}
        ),
        AuditEventType.REFERENCE_IMPORTED: frozenset({"reference_kind", "row_count", "sha256"}),
        AuditEventType.SUPPLIER_DEFAULTS_SET: frozenset(),
        AuditEventType.INVOICE_APPROVED: frozenset(
            {"approval_id", "revision", "content_sha256", "run_id", "override_count"}
        ),
        AuditEventType.INVOICE_REJECTED: frozenset({"approval_id", "revision", "content_sha256"}),
        AuditEventType.INVOICE_APPROVAL_REVOKED: frozenset(
            {"approval_id", "revision", "content_sha256"}
        ),
        AuditEventType.FINDING_OVERRIDDEN: frozenset({"revision", "rule_id"}),
        AuditEventType.INVOICE_EXPORTED: frozenset(
            {"batch_id", "approval_id", "revision", "content_sha256", "target", "is_reexport"}
        ),
        AuditEventType.EXPORT_COMPLETED: frozenset(
            {
                "batch_id",
                "target",
                "item_count",
                "file_sha256",
                "audit_anchor",
                "mapping_version",
                "is_reexport",
                "recovered",
            }
        ),
        AuditEventType.EXPORT_FAILED: frozenset(
            {"batch_id", "target", "item_count", "export_error"}
        ),
        AuditEventType.EXPORT_MAPPING_SET: frozenset({"mapping_version", "column_count"}),
        AuditEventType.BACKUP_CREATED: frozenset(
            {
                "backup_id",
                "file_sha256",
                "file_count",
                "schema_revision",
                "audit_sequence",
                "audit_anchor",
            }
        ),
        AuditEventType.BACKUP_VERIFIED: frozenset({"backup_id", "valid"}),
        AuditEventType.BACKUP_RESTORED: frozenset({"backup_id", "valid"}),
        AuditEventType.BACKUP_DELETED: frozenset({"backup_id", "file_sha256"}),
    }
)

SUBJECT_FOR: Mapping[AuditEventType, SubjectType] = MappingProxyType(
    {
        AuditEventType.DATABASE_CREATED: SubjectType.DATABASE,
        AuditEventType.DATABASE_MIGRATED: SubjectType.DATABASE,
        AuditEventType.ENTITY_CREATED: SubjectType.ENTITY,
        AuditEventType.INVOICE_CREATED: SubjectType.INVOICE,
        AuditEventType.INVOICE_REVISED: SubjectType.INVOICE,
        AuditEventType.DOCUMENT_IMPORTED: SubjectType.DOCUMENT,
        AuditEventType.DOCUMENT_DUPLICATE_REJECTED: SubjectType.DOCUMENT,
        AuditEventType.DOCUMENT_QUARANTINED: SubjectType.DOCUMENT,
        # The subject of a rejection is the import attempt: no document exists.
        AuditEventType.DOCUMENT_REJECTED: SubjectType.DOCUMENT,
        AuditEventType.DOCUMENT_TYPE_CHANGED: SubjectType.DOCUMENT,
        AuditEventType.PROCESSING_STARTED: SubjectType.DOCUMENT,
        AuditEventType.PROCESSING_FINISHED: SubjectType.DOCUMENT,
        AuditEventType.INVOICE_VALIDATED: SubjectType.INVOICE,
        AuditEventType.SUPPLIER_CREATED: SubjectType.SUPPLIER,
        AuditEventType.SUPPLIER_ACCOUNT_ADDED: SubjectType.SUPPLIER,
        AuditEventType.SUPPLIER_ACCOUNT_STATUS_CHANGED: SubjectType.SUPPLIER,
        # The subject of a reference import is the entity whose data it replaces.
        AuditEventType.REFERENCE_IMPORTED: SubjectType.ENTITY,
        AuditEventType.SUPPLIER_DEFAULTS_SET: SubjectType.SUPPLIER,
        AuditEventType.INVOICE_APPROVED: SubjectType.INVOICE,
        AuditEventType.INVOICE_REJECTED: SubjectType.INVOICE,
        AuditEventType.INVOICE_APPROVAL_REVOKED: SubjectType.INVOICE,
        AuditEventType.FINDING_OVERRIDDEN: SubjectType.INVOICE,
        AuditEventType.INVOICE_EXPORTED: SubjectType.INVOICE,
        # The subject of a batch event is the entity whose invoices it exports.
        AuditEventType.EXPORT_COMPLETED: SubjectType.ENTITY,
        AuditEventType.EXPORT_FAILED: SubjectType.ENTITY,
        AuditEventType.EXPORT_MAPPING_SET: SubjectType.ENTITY,
        # Backups cover the whole data directory: global events like migrations.
        AuditEventType.BACKUP_CREATED: SubjectType.DATABASE,
        AuditEventType.BACKUP_VERIFIED: SubjectType.DATABASE,
        AuditEventType.BACKUP_RESTORED: SubjectType.DATABASE,
        AuditEventType.BACKUP_DELETED: SubjectType.DATABASE,
    }
)

# Events that concern one accounting entity must name it; global events must not.
ENTITY_REQUIRED = frozenset(
    {
        AuditEventType.ENTITY_CREATED,
        AuditEventType.INVOICE_CREATED,
        AuditEventType.INVOICE_REVISED,
        AuditEventType.DOCUMENT_IMPORTED,
        AuditEventType.DOCUMENT_DUPLICATE_REJECTED,
        AuditEventType.DOCUMENT_QUARANTINED,
        AuditEventType.DOCUMENT_REJECTED,
        AuditEventType.DOCUMENT_TYPE_CHANGED,
        AuditEventType.PROCESSING_STARTED,
        AuditEventType.PROCESSING_FINISHED,
        AuditEventType.INVOICE_VALIDATED,
        AuditEventType.SUPPLIER_CREATED,
        AuditEventType.SUPPLIER_ACCOUNT_ADDED,
        AuditEventType.SUPPLIER_ACCOUNT_STATUS_CHANGED,
        AuditEventType.REFERENCE_IMPORTED,
        AuditEventType.SUPPLIER_DEFAULTS_SET,
        AuditEventType.INVOICE_APPROVED,
        AuditEventType.INVOICE_REJECTED,
        AuditEventType.INVOICE_APPROVAL_REVOKED,
        AuditEventType.FINDING_OVERRIDDEN,
        AuditEventType.INVOICE_EXPORTED,
        AuditEventType.EXPORT_COMPLETED,
        AuditEventType.EXPORT_FAILED,
        AuditEventType.EXPORT_MAPPING_SET,
    }
)


class AuditPayloadError(ValueError):
    """An audit event violates the privacy or structure policy."""


@dataclass(frozen=True, slots=True)
class AuditDraft:
    """An event before it receives its place in the chain.

    Validation runs on construction, so an invalid payload never reaches a
    repository, whichever caller creates it.
    """

    event_type: AuditEventType
    actor: str
    entity_id: UUID | None
    subject_id: str
    details: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        validate_draft(self)
        object.__setattr__(self, "details", MappingProxyType(dict(self.details)))

    @property
    def subject_type(self) -> SubjectType:
        return SUBJECT_FOR[self.event_type]


@dataclass(frozen=True, slots=True)
class AuditRecord:
    """A stored event, as read back for verification."""

    sequence: int
    event_id: UUID
    occurred_at: dt.datetime
    actor: str
    event_type: str
    entity_id: UUID | None
    subject_type: str
    subject_id: str
    details: Mapping[str, object]
    prev_hash: str
    event_hash: str
    hash_version: int = HASH_VERSION


def validate_draft(draft: AuditDraft) -> None:
    """Reject anything outside the allowlist; never trust the caller's discipline."""
    try:
        event_type = AuditEventType(draft.event_type)
    except ValueError as exc:
        raise AuditPayloadError("unknown event type") from exc
    if not isinstance(draft.actor, str) or not _ACTOR.fullmatch(draft.actor):
        raise AuditPayloadError("invalid actor")
    if event_type in ENTITY_REQUIRED:
        if not isinstance(draft.entity_id, UUID):
            raise AuditPayloadError("entity_id required")
    elif draft.entity_id is not None:
        raise AuditPayloadError("global event must not name an entity")
    subject_type = SUBJECT_FOR[event_type]
    if subject_type is SubjectType.DATABASE:
        if not _code(draft.subject_id):
            raise AuditPayloadError("invalid subject_id")
    elif not isinstance(draft.subject_id, str) or not _UUID_TEXT.fullmatch(draft.subject_id):
        raise AuditPayloadError("invalid subject_id")
    if not isinstance(draft.details, Mapping):
        raise AuditPayloadError("details must be a mapping")
    allowed = ALLOWED_DETAILS[event_type]
    for key, value in draft.details.items():
        if key not in allowed:
            raise AuditPayloadError(f"detail key not allowed: {key!r}"[:80])
        if not _VALIDATORS[key](value):
            raise AuditPayloadError(f"invalid value for detail {key!r}")


def hash_payload(
    *,
    sequence: int,
    event_id: UUID,
    occurred_at: dt.datetime,
    actor: str,
    event_type: str,
    entity_id: UUID | None,
    subject_type: str,
    subject_id: str,
    details: Mapping[str, object],
    prev_hash: str,
    hash_version: int = HASH_VERSION,
) -> dict[str, object]:
    """The exact structure that is hashed. Changing it requires a new hash_version."""
    return {
        "hash_version": hash_version,
        "sequence": sequence,
        "event_id": str(event_id),
        "occurred_at": format_utc(occurred_at),
        "actor": actor,
        "event_type": str(event_type),
        "entity_id": None if entity_id is None else str(entity_id),
        "subject_type": str(subject_type),
        "subject_id": subject_id,
        "details": dict(details),
        "prev_hash": prev_hash,
    }


def compute_event_hash(**fields: object) -> str:
    return sha256_hex(canonical_json_bytes(hash_payload(**fields)))


def chain(
    draft: AuditDraft,
    *,
    sequence: int,
    prev_hash: str,
    event_id: UUID,
    occurred_at: dt.datetime,
) -> AuditRecord:
    """Place a validated draft after ``prev_hash`` at position ``sequence``."""
    fields: dict[str, object] = {
        "sequence": sequence,
        "event_id": event_id,
        "occurred_at": occurred_at,
        "actor": draft.actor,
        "event_type": str(draft.event_type),
        "entity_id": draft.entity_id,
        "subject_type": str(draft.subject_type),
        "subject_id": draft.subject_id,
        "details": dict(draft.details),
        "prev_hash": prev_hash,
    }
    return AuditRecord(event_hash=compute_event_hash(**fields), **fields)


@dataclass(frozen=True, slots=True)
class ChainVerification:
    """Result of verifying the chain from genesis to the last stored event."""

    valid: bool
    events_checked: int
    first_invalid_sequence: int | None = None
    reason: str | None = None


def verify_chain(records: Iterable[AuditRecord]) -> ChainVerification:
    """Check order, links, hashes and payload policy of every event.

    Detects: altered fields, removed or inserted events in the middle,
    reordering and broken genesis. It cannot detect removal of events at the
    *end* of the chain, or a complete rewrite by someone able to recompute all
    hashes (see docs/THREAT_MODEL.md, T11).
    """
    expected_prev = GENESIS_HASH
    count = 0
    for expected_sequence, record in enumerate(records, start=1):
        count = expected_sequence
        if record.sequence != expected_sequence:
            return ChainVerification(False, count - 1, record.sequence, "sequence")
        if record.hash_version != HASH_VERSION:
            return ChainVerification(False, count - 1, record.sequence, "hash_version")
        if record.prev_hash != expected_prev:
            return ChainVerification(False, count - 1, record.sequence, "link")
        try:
            _draft_of(record)
        except (AuditPayloadError, ValueError):
            return ChainVerification(False, count - 1, record.sequence, "payload")
        recomputed = compute_event_hash(
            sequence=record.sequence,
            event_id=record.event_id,
            occurred_at=record.occurred_at,
            actor=record.actor,
            event_type=record.event_type,
            entity_id=record.entity_id,
            subject_type=record.subject_type,
            subject_id=record.subject_id,
            details=record.details,
            prev_hash=record.prev_hash,
        )
        if recomputed != record.event_hash:
            return ChainVerification(False, count - 1, record.sequence, "hash")
        expected_prev = record.event_hash
    return ChainVerification(True, count)


def _draft_of(record: AuditRecord) -> AuditDraft:
    """Re-validate a stored event against the same policy used when writing."""
    draft = AuditDraft(
        event_type=AuditEventType(record.event_type),
        actor=record.actor,
        entity_id=record.entity_id,
        subject_id=record.subject_id,
        details=record.details,
    )
    if str(draft.subject_type) != record.subject_type:
        raise AuditPayloadError("subject type mismatch")
    return draft
