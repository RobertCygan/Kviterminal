"""The watched scan folder and the parts of scanned batches (Phase 11a).

A poll imports every file the scanner has finished writing, moves it out of
the folder and analyses the new documents. Imports go through the ordinary
import (signature, size and duplicate checks, quarantine); the folder adds no
trust. Parts are computed from the page analysis and never stored: they are
shown to the person and become the page ranges of invoices in later phases.
"""

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentRecord,
    ImportOutcome,
    ImportSource,
)
from invoiceflow.application.documents import DocumentService
from invoiceflow.application.ports import ScanFolder, StorageError
from invoiceflow.application.processing import ProcessingService
from invoiceflow.application.processing_model import JobStatus, PageRecord, ProcessingStep
from invoiceflow.application.scan.model import BatchSplit, split_batch
from invoiceflow.application.scan.separator import separator_sheet
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import SYSTEM_ACTOR

MAX_BATCHES = 100
_PAGED = frozenset({DocumentFormat.PDF, DocumentFormat.TIFF})


@dataclass(frozen=True, slots=True)
class ScanPoll:
    imported: int = 0
    duplicates: int = 0
    refused: int = 0
    failed: int = 0
    processed: int = 0


@dataclass(frozen=True, slots=True)
class BatchView:
    """A multi-page document and how it divides (newest first on the page)."""

    document: DocumentRecord
    page_count: int
    split: BatchSplit
    pages: tuple[PageRecord, ...] = ()  # in page order, for checking the thresholds


class ScanService:
    def __init__(
        self,
        documents: DocumentService,
        processing: ProcessingService,
        folder: ScanFolder,
        inbox: Path,
    ) -> None:
        self._documents = documents
        self._processing = processing
        self._folder = folder
        self._inbox = inbox

    @property
    def inbox(self) -> Path:
        return self._inbox

    def poll(
        self,
        scope: EntityScope,
        *,
        actor: str = SYSTEM_ACTOR,
        should_stop: Callable[[], bool] = lambda: False,
    ) -> ScanPoll:
        """Import finished files from the scan folder, set them aside, analyse them."""
        counts = dict.fromkeys(("imported", "duplicates", "refused", "failed"), 0)
        for source in self._folder.ready_files(self._inbox):
            if should_stop():
                break
            try:
                result = self._documents.import_file(
                    scope, source, origin=ImportSource.INBOX, actor=actor
                )
            except StorageError:
                result = None
            if result is None or result.outcome is ImportOutcome.FAILED:
                counts["failed"] += 1  # left in place: the next poll tries again
                continue
            try:
                self._folder.set_aside(self._inbox, source, result.outcome)
            except StorageError:
                counts["failed"] += 1
            key = {
                ImportOutcome.IMPORTED: "imported",
                ImportOutcome.DUPLICATE: "duplicates",
            }.get(result.outcome, "refused")
            counts[key] += 1
        processed = 0
        if counts["imported"] and not should_stop():
            jobs = self._processing.process_pending(scope, actor=actor, should_stop=should_stop)
            # Documents analysed; their OCR (Phase 05) is a second job of the same document.
            processed = sum(job.step is not ProcessingStep.OCR for job in jobs)
        return ScanPoll(processed=processed, **counts)

    def batches(self, scope: EntityScope) -> list[BatchView]:
        """Analysed PDF and TIFF documents with their parts, newest first."""
        jobs = self._processing.latest_jobs(scope)
        views = []
        for document in self._documents.list_documents(scope):
            job = jobs.get(document.document_id)
            if (
                document.detected_format not in _PAGED
                or job is None
                or job.step is not ProcessingStep.PAGE_ANALYSIS
                or job.status is not JobStatus.SUCCEEDED
            ):
                continue
            pages = tuple(
                sorted(self._processing.pages(scope, job.job_id), key=lambda p: p.page_number)
            )
            views.append(BatchView(document, len(pages), split_batch(pages), pages))
            if len(views) == MAX_BATCHES:
                break
        return views

    def save_separator_sheet(self, destination: Path, copies: int = 1) -> None:
        self._folder.write_file(destination, separator_sheet(copies))
