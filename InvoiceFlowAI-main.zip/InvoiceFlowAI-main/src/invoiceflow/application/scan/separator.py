"""A printable separator sheet and the minimal PDF writer behind it (Phase 11a). No I/O.

The sheet has a large black box over the central area, which page analysis
recognises (:func:`invoiceflow.application.scan.model.classify`), and a short
instruction in Norwegian above it. It is written by hand, so the bytes are
known exactly and no PDF library is needed outside the worker.
"""

from collections.abc import Sequence

A4 = (595, 842)
# The box reaches 5 % beyond the measured central area (20-80 % wide, 30-70 %
# high) on every side, so a slightly skewed scan still covers it.
BOX = (0.15, 0.25, 0.85, 0.75)
TITLE = "SKILLEARK \N{EN DASH} InvoiceFlow AI"
INSTRUCTION = "Legg et slikt ark foran hver faktura i bunken. Arket blir ikke en del av fakturaen."


def build_pdf(objects: Sequence[bytes], *, trailer_extra: bytes = b"") -> bytes:
    """A PDF whose objects are numbered from 1; object 1 is the catalog."""
    out = bytearray(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n")
    offsets = []
    for number, body in enumerate(objects, start=1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % number + body + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objects) + 1)
    for offset in offsets:
        out += b"%010d 00000 n \n" % offset
    out += b"trailer\n<< /Size %d /Root 1 0 R %s>>\nstartxref\n%d\n%%%%EOF\n" % (
        len(objects) + 1,
        trailer_extra,
        xref,
    )
    return bytes(out)


def stream(content: bytes, dictionary: bytes = b"") -> bytes:
    return b"<< %s/Length %d >>\nstream\n" % (dictionary, len(content)) + content + b"\nendstream"


def pdf_text(text: str) -> bytes:
    """A literal string for a standard font with WinAnsiEncoding."""
    escaped = text.encode("cp1252").replace(b"\\", b"\\\\").replace(b"(", b"\\(")
    return b"(" + escaped.replace(b")", b"\\)") + b")"


def separator_content() -> bytes:
    """Drawing operators of one separator page (A4, font /F1)."""
    width, height = A4
    left, top, right, bottom = BOX
    x0, x1 = round(left * width), round(right * width)
    y0, y1 = round((1 - bottom) * height), round((1 - top) * height)
    return (
        b"0 g %d %d %d %d re f " % (x0, y0, x1 - x0, y1 - y0)
        + b"BT /F1 20 Tf 72 760 Td "
        + pdf_text(TITLE)
        + b" Tj ET BT /F1 10 Tf 72 730 Td "
        + pdf_text(INSTRUCTION)
        + b" Tj ET"
    )


def separator_sheet(copies: int = 1) -> bytes:
    """A PDF with ``copies`` identical separator pages, ready to print."""
    if not 1 <= copies <= 100:
        msg = "between 1 and 100 copies"
        raise ValueError(msg)
    kids = b" ".join(b"%d 0 R" % (4 + 2 * index) for index in range(copies))
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [" + kids + b"] /Count %d >>" % copies,
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
    ]
    content = stream(separator_content())
    for index in range(copies):
        objects.append(
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            b"/Resources << /Font << /F1 3 0 R >> >> /Contents %d 0 R >>" % (5 + 2 * index)
        )
        objects.append(content)
    return build_pdf(objects)
