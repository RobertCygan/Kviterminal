"""Scanned batches: blank pages, separator sheets and parts (Phase 11a)."""
