"""Blank pages, separator sheets and parts of a scanned batch (Phase 11a). No I/O.

A scanner feeds a stack of invoices as one file. The worker measures how dark
each page is (in per mille, on a small greyscale copy). Here a page is:

* a **separator sheet** when its central area is almost black and the page as
  a whole is not: the sheet from :mod:`invoiceflow.application.scan.separator`;
* **blank** when it has almost no ink and no text layer (the back of a
  one-sided page scanned in duplex);
* otherwise **content**.

Separator sheets end a part; blank pages are left out of it. Nothing is
deleted: the original stays complete, and a part is a page range in it, as
``CanonicalInvoice.first_page``/``last_page`` describe.

Pages close to a threshold are flagged (Phase 11b): another scanner, a
different resolution or a worn separator sheet could put them on the other
side, so they are what to look at when the thresholds are checked against real
scans.
"""

from collections.abc import Sequence
from dataclasses import dataclass
from enum import StrEnum

from invoiceflow.application.processing_model import PageRecord

BLANK_MAX_DARK = 3  # at most 0.3 % dark pixels
SEPARATOR_MIN_CENTER = 850  # the central area is at least 85 % dark
SEPARATOR_DARK = (150, 650)  # the black box covers about a third of the sheet
# Margins for pages "near a threshold" (Phase 11b).
BLANK_NEAR_DARK = 10  # content without a text layer and at most 1 % dark
SEPARATOR_NEAR_CENTER = 700  # content whose central area is mostly dark
SEPARATOR_SURE_CENTER = 900  # a separator sheet below this is a weak one
SEPARATOR_SURE_DARK = (200, 600)  # likewise outside this range


class PageKind(StrEnum):
    CONTENT = "content"
    BLANK = "blank"
    SEPARATOR = "separator"
    UNKNOWN = "unknown"  # analysed before Phase 11a: no measurement


def classify(page: PageRecord) -> PageKind:
    dark, center = page.dark_permille, page.center_dark_permille
    if dark is None or center is None:
        return PageKind.UNKNOWN
    if center >= SEPARATOR_MIN_CENTER and SEPARATOR_DARK[0] <= dark <= SEPARATOR_DARK[1]:
        return PageKind.SEPARATOR
    if dark <= BLANK_MAX_DARK and page.text_layer_chars == 0:
        return PageKind.BLANK
    return PageKind.CONTENT


def near_threshold(page: PageRecord) -> bool:
    """Whether a slightly different scan could classify this page otherwise."""
    kind = classify(page)
    dark, center = page.dark_permille, page.center_dark_permille
    if dark is None or center is None:
        return False
    if kind is PageKind.SEPARATOR:
        low, high = SEPARATOR_SURE_DARK
        return center < SEPARATOR_SURE_CENTER or not low <= dark <= high
    if kind is PageKind.CONTENT:
        nearly_blank = dark <= BLANK_NEAR_DARK and page.text_layer_chars == 0
        return nearly_blank or center >= SEPARATOR_NEAR_CENTER
    return False


@dataclass(frozen=True, slots=True)
class BatchSplit:
    """How one analysed document divides into parts (first and last page, inclusive)."""

    kinds: tuple[PageKind, ...]
    parts: tuple[tuple[int, int], ...]
    near: tuple[int, ...] = ()  # page numbers close to a threshold

    def pages_of(self, kind: PageKind) -> tuple[int, ...]:
        return tuple(number for number, found in enumerate(self.kinds, start=1) if found is kind)

    @property
    def measured(self) -> bool:
        return PageKind.UNKNOWN not in self.kinds

    @property
    def needs_split(self) -> bool:
        """More than one part, or pages that are not part of the invoice."""
        return len(self.parts) > 1 or any(kind is not PageKind.CONTENT for kind in self.kinds)


def split_batch(pages: Sequence[PageRecord]) -> BatchSplit:
    """Parts between separator sheets, without blank pages at their edges.

    A blank page inside a part (the empty back of page 1 of a two-page invoice)
    stays inside the range; it is listed so that later steps can skip it.
    Without measurements, the whole document is one part.
    """
    ordered = sorted(pages, key=lambda page: page.page_number)
    kinds = tuple(classify(page) for page in ordered)
    near = tuple(number for number, page in enumerate(ordered, start=1) if near_threshold(page))
    if PageKind.UNKNOWN in kinds:
        return BatchSplit(kinds, ((1, len(ordered)),) if ordered else (), near)
    parts: list[tuple[int, int]] = []
    first: int | None = None
    last = 0
    for number, kind in enumerate(kinds, start=1):
        if kind is PageKind.SEPARATOR:
            if first is not None:
                parts.append((first, last))
            first = None
        elif kind is PageKind.CONTENT:
            first = number if first is None else first
            last = number
    if first is not None:
        parts.append((first, last))
    return BatchSplit(kinds, tuple(parts), near)
