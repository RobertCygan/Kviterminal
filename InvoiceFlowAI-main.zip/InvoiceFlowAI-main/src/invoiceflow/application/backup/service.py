"""Create, check, restore and delete encrypted backups (Phase 12, ADR-0037).

* **Create:** the audit chain must be intact; a consistent database copy, the
  document archive, the export folder and the configuration are written into
  one encrypted file in a folder the person chooses. The passphrase is never
  stored; without it the backup cannot be read.
* **Check / restore:** everything is decrypted and authenticated, unpacked
  into a private work folder (check) or an empty folder the person chooses
  (restore), and verified: manifest hashes, database integrity and schema,
  the whole audit chain, the anchor in the manifest, and every file the
  database refers to. A restore that fails any check leaves the folder empty.
* **Delete:** only a file this database made (its hash is registered); the
  register keeps the row and records the deletion. Nothing is deleted
  automatically (retention, Å-07).
"""

import datetime as dt
import secrets
from collections.abc import Callable
from pathlib import Path
from uuid import UUID, uuid4

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.backup.model import (
    DATABASE_NAME,
    NONCE_PREFIX_BYTES,
    SALT_BYTES,
    SCRYPT_N,
    BackupCheck,
    BackupError,
    BackupHeader,
    BackupRecord,
    Manifest,
    backup_file_name,
    check_passphrase,
    missing_documents,
    missing_or_changed,
)
from invoiceflow.application.ports import (
    BackupArchive,
    DatabaseSnapshotter,
    UnitOfWork,
    UnitOfWorkFactory,
)
from invoiceflow.application.services import utc_now
from invoiceflow.application.validation.service import USER_ACTOR
from invoiceflow.domain.canonical import format_utc

SUBJECT = "backup"


class BackupService:
    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        snapshotter: DatabaseSnapshotter,
        archive: BackupArchive,
        *,
        clock: Callable[[], dt.datetime] = utc_now,
        new_id: Callable[[], UUID] = uuid4,
        random_bytes: Callable[[int], bytes] = secrets.token_bytes,
        scrypt_n: int = SCRYPT_N,
    ) -> None:
        self._uow_factory = uow_factory
        self._snapshotter = snapshotter
        self._archive = archive
        self._clock = clock
        self._new_id = new_id
        self._random = random_bytes
        self._scrypt_n = scrypt_n

    def backups(self) -> list[BackupRecord]:
        with self._uow_factory() as uow:
            return uow.backups.list()

    def recover(self) -> int:
        """Remove work folders a crash left behind (startup); they are unencrypted."""
        return self._archive.discard_workspaces()

    # --- create ------------------------------------------------------------------------

    def create(
        self,
        folder: Path,
        passphrase: str,
        confirmation: str,
        *,
        actor: str = USER_ACTOR,
    ) -> BackupRecord:
        secret = check_passphrase(passphrase, confirmation)
        with self._uow_factory() as uow:
            if not uow.audit.verify().valid:
                raise BackupError("chain")
        now = self._clock()
        header = BackupHeader(
            backup_id=self._new_id(),
            created_at=format_utc(now),
            salt=self._random(SALT_BYTES),
            nonce_prefix=self._random(NONCE_PREFIX_BYTES),
            scrypt_n=self._scrypt_n,
        )
        name = backup_file_name(now)
        with self._archive.workspace() as work:
            copy = work / "invoiceflow.sqlite3"
            contents = self._snapshotter.snapshot(copy)
            info = contents.info
            files = [(DATABASE_NAME, copy), *self._archive.data_files()]
            key = self._archive.derive_key(secret, header)
            digest, size, manifest = self._archive.write(
                folder / name,
                header,
                key,
                files,
                lambda entries: Manifest(
                    header.backup_id,
                    header.created_at,
                    info.schema_revision,
                    info.audit_sequence,
                    info.audit_anchor,
                    entries,
                ),
            )
            written = {e.path: (e.sha256, e.size) for e in manifest.entries}
            if missing_documents(contents, written):
                # A backup that could not be restored is worse than none: the
                # archive is damaged (see the integrity check in the inbox).
                self._archive.delete(folder / name)
                raise BackupError("source_incomplete")
        record = BackupRecord(
            backup_id=header.backup_id,
            file_name=name,
            file_sha256=digest,
            byte_count=size,
            file_count=len(manifest.entries),
            schema_revision=info.schema_revision,
            audit_sequence=info.audit_sequence,
            audit_anchor=info.audit_anchor,
            created_at=now,
            created_by=actor,
        )
        with self._uow_factory() as uow:
            uow.backups.add(record)
            self._audit(
                uow,
                actor,
                AuditEventType.BACKUP_CREATED,
                {
                    "backup_id": str(record.backup_id),
                    "file_sha256": digest,
                    "file_count": record.file_count,
                    "schema_revision": info.schema_revision,
                    "audit_sequence": info.audit_sequence,
                    "audit_anchor": info.audit_anchor,
                },
            )
            uow.commit()
        return record

    # --- check and restore --------------------------------------------------------------

    def verify(self, source: Path, passphrase: str, *, actor: str = USER_ACTOR) -> BackupCheck:
        """Decrypt into a private folder and run every restore check; nothing is kept."""
        secret = check_passphrase(passphrase)
        header = self._archive.read_header(source)
        try:
            with self._archive.workspace() as work:
                check = self._unpack(source, header, secret, work / "data")
        except BackupError:
            self._outcome(AuditEventType.BACKUP_VERIFIED, header.backup_id, False, actor)
            raise
        self._outcome(AuditEventType.BACKUP_VERIFIED, header.backup_id, True, actor)
        return check

    def restore(
        self, source: Path, passphrase: str, target: Path, *, actor: str = USER_ACTOR
    ) -> BackupCheck:
        """A complete data directory in an empty folder; never over the running one."""
        secret = check_passphrase(passphrase)
        header = self._archive.read_header(source)
        self._archive.prepare_target(target)
        try:
            check = self._unpack(source, header, secret, target)
        except BaseException:
            self._archive.clear(target)
            self._outcome(AuditEventType.BACKUP_RESTORED, header.backup_id, False, actor)
            raise
        self._outcome(AuditEventType.BACKUP_RESTORED, header.backup_id, True, actor)
        return check

    def _unpack(
        self, source: Path, header: BackupHeader, secret: bytes, target: Path
    ) -> BackupCheck:
        key = self._archive.derive_key(secret, header)
        manifest, written = self._archive.extract(source, header, key, target)
        if (manifest.backup_id, manifest.created_at) != (header.backup_id, header.created_at):
            raise BackupError("damaged")
        if missing_or_changed(manifest, written):
            raise BackupError("manifest")
        restored = self._snapshotter.inspect(target / DATABASE_NAME)
        if (
            restored.info.schema_revision,
            restored.info.audit_sequence,
            restored.info.audit_anchor,
        ) != (manifest.schema_revision, manifest.audit_sequence, manifest.audit_anchor):
            raise BackupError("anchor")
        if missing_documents(restored, written):
            raise BackupError("missing_file")
        digest = self._archive.file_sha256(source)
        with self._uow_factory() as uow:
            record = uow.backups.find(digest)
        return BackupCheck(
            backup_id=header.backup_id,
            created_at=header.created_at,
            file_count=len(manifest.entries),
            byte_count=sum(entry.size for entry in manifest.entries),
            audit_sequence=manifest.audit_sequence,
            known=record is not None and record.backup_id == header.backup_id,
        )

    # --- delete ------------------------------------------------------------------------

    def delete(self, source: Path, *, actor: str = USER_ACTOR) -> BackupRecord:
        """Delete a backup file this database made; the register records it."""
        digest = self._archive.file_sha256(source)
        with self._uow_factory() as uow:
            record = uow.backups.find(digest)
        if record is None or record.deleted_at is not None:
            raise BackupError("unknown_backup")
        self._archive.delete(source)
        now = self._clock()
        with self._uow_factory() as uow:
            uow.backups.mark_deleted(record.backup_id, deleted_at=now, actor=actor)
            self._audit(
                uow,
                actor,
                AuditEventType.BACKUP_DELETED,
                {"backup_id": str(record.backup_id), "file_sha256": digest},
            )
            uow.commit()
        return record

    # --- audit -------------------------------------------------------------------------

    def _outcome(self, event: AuditEventType, backup_id: UUID, valid: bool, actor: str) -> None:
        with self._uow_factory() as uow:
            self._audit(uow, actor, event, {"backup_id": str(backup_id), "valid": valid})
            uow.commit()

    def _audit(
        self, uow: UnitOfWork, actor: str, event: AuditEventType, details: dict[str, object]
    ) -> None:
        uow.audit.append(
            AuditDraft(
                event_type=event,
                actor=actor,
                entity_id=None,
                subject_id=SUBJECT,
                details=details,
            ),
            occurred_at=self._clock(),
        )
