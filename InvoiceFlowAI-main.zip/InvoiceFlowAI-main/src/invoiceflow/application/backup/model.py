"""Encrypted backups: format, manifest and rules (Phase 12, ADR-0037). No I/O.

A backup is one file: a plain header (format, key derivation parameters,
nonce prefix) followed by an AES-256-GCM stream of a tar archive. The archive
holds a consistent copy of the database, the document archive, the export
folder and the configuration, and ends with a manifest of every file's SHA-256
and the audit anchor. The header is authenticated with every chunk.
"""

import datetime as dt
import json
import re
import unicodedata
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from uuid import UUID

from invoiceflow.application.errors import InvoiceFlowError

FORMAT_VERSION = 1
MAGIC = b"IFBAK\x00\x01\n"
MAX_HEADER = 4096
SALT_BYTES = 16
NONCE_PREFIX_BYTES = 8
KEY_BYTES = 32
CHUNK_SIZE = 1024 * 1024
MIN_CHUNK = 64 * 1024
MAX_CHUNK = 8 * 1024 * 1024
# scrypt cost: 2**17 * 8 * 128 bytes = 128 MiB of memory, about half a second.
SCRYPT_N = 2**17
SCRYPT_R = 8
SCRYPT_P = 1
MIN_SCRYPT_N = 2**10  # Tests only; the service always writes SCRYPT_N.
MAX_SCRYPT_N = 2**20
MIN_PASSPHRASE = 12
MAX_PASSPHRASE = 1024
MAX_MEMBERS = 1_000_000
MAX_MEMBER_BYTES = 8 * 1024**3
MANIFEST_NAME = "manifest.json"
DATABASE_NAME = "database/invoiceflow.sqlite3"
FILE_SUFFIX = ".ifbak"

# Paths inside the archive mirror the data directory and nothing else.
_COMPONENT = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
_TOP_LEVEL = frozenset({"database", "documents", "exports", "config"})
_HEX = re.compile(r"[0-9a-f]+")
_FILE_NAME = re.compile(r"invoiceflow-sikkerhetskopi-[0-9]{8}-[0-9]{6}\.ifbak")


class BackupError(InvoiceFlowError):
    """A backup action was refused or failed; ``reason`` is a stable code."""

    def __init__(self, reason: str, **params: object) -> None:
        super().__init__("BACKUP_REFUSED", f"backup.error.{reason}", **params)
        self.reason = reason


def check_passphrase(text: str, confirmation: str | None = None) -> bytes:
    """The key material of a passphrase: NFC, 12-1024 characters, no control characters."""
    if confirmation is not None and text != confirmation:
        raise BackupError("mismatch")
    value = unicodedata.normalize("NFC", text)
    if not MIN_PASSPHRASE <= len(value) <= MAX_PASSPHRASE or not value.strip():
        raise BackupError("passphrase")
    if any(unicodedata.category(c) in ("Cc", "Cf") for c in value):
        raise BackupError("passphrase")
    return value.encode("utf-8")


def check_member(path: str) -> str:
    """A relative archive path below one of the known top-level folders."""
    parts = path.split("/")
    if (
        len(path) > 512
        or not 2 <= len(parts) <= 10
        or parts[0] not in _TOP_LEVEL
        or not all(_COMPONENT.fullmatch(part) and part not in (".", "..") for part in parts)
    ):
        raise BackupError("damaged")
    return path


def backup_file_name(created_at: dt.datetime) -> str:
    return f"invoiceflow-sikkerhetskopi-{created_at.astimezone(dt.UTC):%Y%m%d-%H%M%S}{FILE_SUFFIX}"


def is_backup_file_name(name: str) -> bool:
    return bool(_FILE_NAME.fullmatch(name))


@dataclass(frozen=True, slots=True)
class BackupHeader:
    """Unencrypted, authenticated description of how to decrypt the stream."""

    backup_id: UUID
    created_at: str
    salt: bytes
    nonce_prefix: bytes
    scrypt_n: int = SCRYPT_N
    scrypt_r: int = SCRYPT_R
    scrypt_p: int = SCRYPT_P
    chunk_size: int = CHUNK_SIZE

    def to_bytes(self) -> bytes:
        return json.dumps(
            {
                "format": FORMAT_VERSION,
                "backup_id": str(self.backup_id),
                "created_at": self.created_at,
                "kdf": "scrypt",
                "n": self.scrypt_n,
                "r": self.scrypt_r,
                "p": self.scrypt_p,
                "salt": self.salt.hex(),
                "cipher": "aes-256-gcm",
                "nonce_prefix": self.nonce_prefix.hex(),
                "chunk_size": self.chunk_size,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("ascii")

    @classmethod
    def from_bytes(cls, data: bytes) -> "BackupHeader":
        """Parse and bound every value; anything unexpected is a damaged file."""
        try:
            raw = json.loads(data.decode("ascii"))
            if (
                not isinstance(raw, dict)
                or raw.get("format") != FORMAT_VERSION
                or raw.get("kdf") != "scrypt"
                or raw.get("cipher") != "aes-256-gcm"
            ):
                raise ValueError
            n, r, p, chunk = raw["n"], raw["r"], raw["p"], raw["chunk_size"]
            numbers = (n, r, p, chunk)
            if any(type(value) is not int for value in numbers):
                raise ValueError
            if not (MIN_SCRYPT_N <= n <= MAX_SCRYPT_N and n & (n - 1) == 0):
                raise ValueError
            if r != SCRYPT_R or not 1 <= p <= 4 or not MIN_CHUNK <= chunk <= MAX_CHUNK:
                raise ValueError
            salt, prefix = raw["salt"], raw["nonce_prefix"]
            if not (
                isinstance(salt, str)
                and isinstance(prefix, str)
                and _HEX.fullmatch(salt)
                and _HEX.fullmatch(prefix)
                and len(salt) == 2 * SALT_BYTES
                and len(prefix) == 2 * NONCE_PREFIX_BYTES
            ):
                raise ValueError
            created = raw["created_at"]
            if not isinstance(created, str) or len(created) != 27:
                raise ValueError
            header = cls(
                UUID(raw["backup_id"]),
                created,
                bytes.fromhex(salt),
                bytes.fromhex(prefix),
                n,
                r,
                p,
                chunk,
            )
        except (ValueError, KeyError, TypeError, UnicodeDecodeError) as exc:
            raise BackupError("damaged") from exc
        if header.to_bytes() != data:
            raise BackupError("damaged")  # Only the canonical form is accepted.
        return header


@dataclass(frozen=True, slots=True)
class ManifestEntry:
    path: str
    sha256: str
    size: int


@dataclass(frozen=True, slots=True)
class Manifest:
    """The last archive member: what the backup must contain, and the audit anchor."""

    backup_id: UUID
    created_at: str
    schema_revision: str
    audit_sequence: int
    audit_anchor: str
    entries: tuple[ManifestEntry, ...]

    def to_bytes(self) -> bytes:
        return json.dumps(
            {
                "format": FORMAT_VERSION,
                "backup_id": str(self.backup_id),
                "created_at": self.created_at,
                "schema_revision": self.schema_revision,
                "audit_sequence": self.audit_sequence,
                "audit_anchor": self.audit_anchor,
                "files": [
                    {"path": e.path, "sha256": e.sha256, "size": e.size} for e in self.entries
                ],
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

    @classmethod
    def from_bytes(cls, data: bytes) -> "Manifest":
        try:
            raw = json.loads(data.decode("utf-8"))
            if raw["format"] != FORMAT_VERSION:
                raise ValueError
            entries = tuple(
                ManifestEntry(check_member(item["path"]), item["sha256"], item["size"])
                for item in raw["files"]
            )
            manifest = cls(
                UUID(raw["backup_id"]),
                raw["created_at"],
                raw["schema_revision"],
                raw["audit_sequence"],
                raw["audit_anchor"],
                entries,
            )
        except (ValueError, KeyError, TypeError, UnicodeDecodeError) as exc:
            raise BackupError("damaged") from exc
        if manifest.to_bytes() != data:
            raise BackupError("damaged")
        return manifest

    def files(self) -> Mapping[str, ManifestEntry]:
        return {entry.path: entry for entry in self.entries}


@dataclass(frozen=True, slots=True)
class SnapshotInfo:
    """A consistent database copy and the audit chain head it contains."""

    schema_revision: str
    audit_sequence: int
    audit_anchor: str


@dataclass(frozen=True, slots=True)
class DatabaseCopy:
    """A database copy, its audit head and the documents it refers to."""

    info: SnapshotInfo
    # Path below the data directory -> SHA-256 of every original and quarantined
    # file. Derived page images and export files are backed up and checked
    # against the manifest, but a missing one does not make a backup unusable.
    referenced: Mapping[str, str]


def missing_documents(copy: DatabaseCopy, written: Mapping[str, tuple[str, int]]) -> list[str]:
    """Documents the database refers to that are absent or different in the backup."""
    return sorted(
        path for path, sha256 in copy.referenced.items() if written.get(path, ("", 0))[0] != sha256
    )


@dataclass(frozen=True, slots=True)
class BackupRecord:
    backup_id: UUID
    file_name: str
    file_sha256: str
    byte_count: int
    file_count: int
    schema_revision: str
    audit_sequence: int
    audit_anchor: str
    created_at: dt.datetime
    created_by: str
    deleted_at: dt.datetime | None = None
    deleted_by: str | None = None


@dataclass(frozen=True, slots=True)
class BackupCheck:
    """Result of a verification or restore that passed every check."""

    backup_id: UUID
    created_at: str
    file_count: int
    byte_count: int
    audit_sequence: int
    known: bool  # A backup made by this database (record and file hash match)


def missing_or_changed(manifest: Manifest, written: Mapping[str, tuple[str, int]]) -> Sequence[str]:
    """Paths whose content differs from the manifest, in either direction."""
    expected = {e.path: (e.sha256, e.size) for e in manifest.entries}
    return sorted(
        path for path in expected.keys() | written.keys() if expected.get(path) != written.get(path)
    )
