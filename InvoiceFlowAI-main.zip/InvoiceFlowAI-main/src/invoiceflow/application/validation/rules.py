"""The rule catalogue of Phase 08a (docs/DATA_MODEL.md §7). Pure functions, no I/O.

Each rule reads a :class:`ValidationContext` and returns findings. A rule that
lacks the data it needs (no lines, no due date) reports nothing: missing
values are REQ-001's business, and no rule guesses. Amounts are compared as
``Decimal``; rounding is always explicit ``ROUND_HALF_UP``.
"""

import datetime as dt
from collections.abc import Callable, Iterator, Sequence
from decimal import ROUND_HALF_UP, Decimal
from typing import Any

from invoiceflow.application.reference.model import Dimension, VatDirection
from invoiceflow.application.validation.model import (
    MAX_FINDINGS,
    AccountStatus,
    InvoiceHeader,
    RuleId,
    Severity,
    ValidationContext,
    ValidationFinding,
)
from invoiceflow.domain.checksums import (
    valid_bank_account,
    valid_iban,
    valid_kid,
    valid_org_number,
)
from invoiceflow.domain.invoice import CanonicalInvoice, InvoiceType
from invoiceflow.domain.provenance import FieldValue

_CENT = Decimal("0.01")
_NUMBER_SEPARATORS = str.maketrans("", "", " -_./")

Rule = Callable[[ValidationContext], Iterator[ValidationFinding]]


def _value(field: FieldValue[Any] | None) -> Any:
    return None if field is None else field.value


def _text(value: Decimal | dt.date | int) -> str:
    if isinstance(value, Decimal):
        return format(value, "f")
    return str(value)


def _finding(
    rule_id: RuleId,
    severity: Severity,
    message: str,
    field_path: str | None = None,
    **params: Decimal | dt.date | int | str,
) -> ValidationFinding:
    return ValidationFinding(
        rule_id=rule_id,
        severity=severity,
        field_path=field_path,
        message_key=f"validation.{message}",
        params={
            name: value if isinstance(value, str) else _text(value)
            for name, value in params.items()
        },
    )


def normalized_invoice_number(number: str) -> str:
    """Upper case, without spaces and ``-_./``, without leading zeros (DUP-001)."""
    compact = number.upper().translate(_NUMBER_SEPARATORS)
    if not compact:
        return ""
    return compact.lstrip("0") or "0"


def _vat(amount: Decimal, rate: Decimal) -> Decimal:
    return (amount * rate / 100).quantize(_CENT, rounding=ROUND_HALF_UP)


# --- REQ: required fields -------------------------------------------------------------


def req_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    required = (
        ("supplier.name", invoice.supplier.name),
        ("invoice_number", invoice.invoice_number),
        ("invoice_date", invoice.invoice_date),
        ("currency", invoice.currency),
        ("totals.net_amount", invoice.totals.net_amount),
        ("totals.vat_amount", invoice.totals.vat_amount),
        ("totals.gross_amount", invoice.totals.gross_amount),
    )
    for path, field in required:
        if _value(field) is None:
            yield _finding(RuleId.REQ_001, Severity.ERROR, "req_001", path)


def _is_norwegian(invoice: CanonicalInvoice) -> bool:
    supplier = invoice.supplier
    country = _value(supplier.address.country_code) if supplier.address else None
    if country is not None:
        return country == "NO"
    return _value(supplier.foreign_vat_id) is None


def req_002(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    if _is_norwegian(invoice) and _value(invoice.supplier.org_number) is None:
        yield _finding(RuleId.REQ_002, Severity.ERROR, "req_002", "supplier.org_number")


# --- ENT: recipient -------------------------------------------------------------------


def ent_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    customer = context.invoice.customer
    org = _value(customer.org_number) if customer else None
    if context.entity_org_number is not None and org not in (None, context.entity_org_number):
        yield _finding(RuleId.ENT_001, Severity.WARNING, "ent_001", "customer.org_number")


# --- SUM: totals ----------------------------------------------------------------------


def sum_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    net = _value(invoice.totals.net_amount)
    amounts = [_value(line.net_amount) for line in invoice.lines]
    if net is None or not amounts or any(amount is None for amount in amounts):
        return
    line_sum = sum(amounts, Decimal("0.00"))
    if line_sum != net:
        yield _finding(
            RuleId.SUM_001,
            Severity.ERROR,
            "sum_001",
            "totals.net_amount",
            expected=line_sum,
            actual=net,
        )


def sum_002(context: ValidationContext) -> Iterator[ValidationFinding]:
    totals = context.invoice.totals
    net, vat, gross = (
        _value(totals.net_amount),
        _value(totals.vat_amount),
        _value(totals.gross_amount),
    )
    if net is None or vat is None or gross is None:
        return
    expected = net + vat + (_value(totals.rounding_amount) or Decimal("0.00"))
    if expected != gross:
        yield _finding(
            RuleId.SUM_002,
            Severity.ERROR,
            "sum_002",
            "totals.gross_amount",
            expected=expected,
            actual=gross,
        )


# --- MVA: VAT -------------------------------------------------------------------------


def mva_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    """VAT per rate = base * rate, ROUND_HALF_UP to øre, within the tolerance."""
    invoice = context.invoice
    tolerance = context.settings.vat_tolerance
    if invoice.vat_breakdown:
        for index, entry in enumerate(invoice.vat_breakdown, start=1):
            rate, base, vat = (
                _value(entry.vat_rate),
                _value(entry.taxable_amount),
                _value(entry.vat_amount),
            )
            if rate is None or base is None or vat is None:
                continue
            expected = _vat(base, rate)
            if abs(vat - expected) > tolerance:
                yield _finding(
                    RuleId.MVA_001,
                    Severity.ERROR,
                    "mva_001",
                    f"vat_breakdown.{index}.vat_amount",
                    rate=rate,
                    expected=expected,
                    actual=vat,
                )
        return
    # Without a VAT summary: group the lines by rate and compare with the total.
    total_vat = _value(invoice.totals.vat_amount)
    if total_vat is None or not invoice.lines:
        return
    bases: dict[Decimal, Decimal] = {}
    for line in invoice.lines:
        rate, amount = _value(line.vat_rate), _value(line.net_amount)
        if rate is None or amount is None:
            return
        bases[rate] = bases.get(rate, Decimal("0.00")) + amount
    expected = sum((_vat(base, rate) for rate, base in bases.items()), Decimal("0.00"))
    if abs(total_vat - expected) > tolerance * len(bases):
        yield _finding(
            RuleId.MVA_001,
            Severity.ERROR,
            "mva_001_total",
            "totals.vat_amount",
            expected=expected,
            actual=total_vat,
        )


def mva_003(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    vat = _value(invoice.totals.vat_amount)
    if vat is not None and vat > 0 and _value(invoice.supplier.vat_registered) is False:
        yield _finding(RuleId.MVA_003, Severity.ERROR, "mva_003", "totals.vat_amount")


# --- DAT: dates -----------------------------------------------------------------------


def dat_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    issued, due = _value(invoice.invoice_date), _value(invoice.due_date)
    if issued is not None and due is not None and due < issued:
        yield _finding(RuleId.DAT_001, Severity.ERROR, "dat_001", "due_date")


def dat_002(context: ValidationContext) -> Iterator[ValidationFinding]:
    issued = _value(context.invoice.invoice_date)
    if issued is None:
        return
    if issued > context.today:
        yield _finding(RuleId.DAT_002, Severity.WARNING, "dat_002_future", "invoice_date")
    oldest = context.today - dt.timedelta(days=context.settings.max_invoice_age_days)
    if issued < oldest:
        yield _finding(
            RuleId.DAT_002,
            Severity.WARNING,
            "dat_002_old",
            "invoice_date",
            days=context.settings.max_invoice_age_days,
        )


# --- ID: check digits -----------------------------------------------------------------


def id_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    parties = (("supplier", invoice.supplier), ("customer", invoice.customer))
    for name, party in parties:
        org = _value(party.org_number) if party else None
        if org is not None and not valid_org_number(org):
            yield _finding(RuleId.ID_001, Severity.ERROR, "id_001", f"{name}.org_number")


def id_002(context: ValidationContext) -> Iterator[ValidationFinding]:
    payment = context.invoice.payment
    account = _value(payment.bank_account) if payment else None
    if account is not None and not valid_bank_account(account):
        yield _finding(RuleId.ID_002, Severity.ERROR, "id_002", "payment.bank_account")


def id_003(context: ValidationContext) -> Iterator[ValidationFinding]:
    payment = context.invoice.payment
    kid = _value(payment.kid) if payment else None
    if kid is not None and not valid_kid(kid):
        yield _finding(RuleId.ID_003, Severity.WARNING, "id_003", "payment.kid")


def id_004(context: ValidationContext) -> Iterator[ValidationFinding]:
    payment = context.invoice.payment
    iban = _value(payment.iban) if payment else None
    if iban is not None and not valid_iban(iban):
        yield _finding(RuleId.ID_004, Severity.ERROR, "id_004", "payment.iban")


# --- DUP: duplicates within the entity ------------------------------------------------


def _same_supplier(context: ValidationContext) -> list[InvoiceHeader]:
    org = _value(context.invoice.supplier.org_number)
    if org is None:
        return []
    return [
        other
        for other in context.other_invoices
        if other.invoice_id != context.invoice_id and other.supplier_org_number == org
    ]


def dup_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    number = _value(invoice.invoice_number)
    if number is None:
        return
    key = normalized_invoice_number(number)
    invoice_type = _value(invoice.invoice_type) or InvoiceType.INVOICE
    for other in _same_supplier(context):
        if other.invoice_number is None:
            continue
        other_type = other.invoice_type or InvoiceType.INVOICE
        if other_type == invoice_type and normalized_invoice_number(other.invoice_number) == key:
            yield _finding(RuleId.DUP_001, Severity.ERROR, "dup_001", "invoice_number")
            return


def dup_002(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    gross, issued = _value(invoice.totals.gross_amount), _value(invoice.invoice_date)
    number = _value(invoice.invoice_number)
    if gross is None or issued is None or number is None:
        return
    key = normalized_invoice_number(number)
    for other in _same_supplier(context):
        if (
            other.gross_amount == gross
            and other.invoice_date == issued
            and other.invoice_number is not None
            and normalized_invoice_number(other.invoice_number) != key
        ):
            yield _finding(RuleId.DUP_002, Severity.WARNING, "dup_002", "totals.gross_amount")
            return


# --- BANK: payment account in the supplier register -----------------------------------

_BANK_MESSAGES = {
    None: "bank_001_unregistered",
    AccountStatus.UNVERIFIED: "bank_001_unverified",
    AccountStatus.BLOCKED: "bank_001_blocked",
}


def payment_accounts(invoice: CanonicalInvoice) -> list[tuple[str, str]]:
    """(field path, account) for each payment account stated on the invoice."""
    payment = invoice.payment
    if payment is None:
        return []
    accounts = [
        ("payment.bank_account", _value(payment.bank_account)),
        ("payment.iban", _value(payment.iban)),
    ]
    return [(path, account) for path, account in accounts if account is not None]


def bank_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    for path, account in payment_accounts(context.invoice):
        status = context.account_statuses.get(account)
        if status is not AccountStatus.VERIFIED:
            yield _finding(RuleId.BANK_001, Severity.ERROR, _BANK_MESSAGES[status], path)


# --- MVA-002 and ACC: reference data and posting (Phase 08b) ---------------------------


def _invoice_rates(invoice: CanonicalInvoice) -> set[Decimal]:
    rates = {_value(entry.vat_rate) for entry in invoice.vat_breakdown}
    rates |= {_value(line.vat_rate) for line in invoice.lines}
    return {rate for rate in rates if rate is not None}


def mva_002(context: ValidationContext) -> Iterator[ValidationFinding]:
    """Every VAT rate on the invoice is a valid input VAT code on the invoice date."""
    reference = context.reference
    if reference.vat_codes is None:
        yield _finding(RuleId.MVA_002, Severity.INFO, "mva_002_no_codes")
        return
    day = _value(context.invoice.invoice_date)
    if day is None:
        return
    valid = {entry.rate for entry in reference.input_codes_on(day)}
    for rate in sorted(_invoice_rates(context.invoice) - valid):
        yield _finding(RuleId.MVA_002, Severity.ERROR, "mva_002", "vat_breakdown", rate=rate)


def acc_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    if not invoice.accounting_lines:
        yield _finding(RuleId.ACC_001, Severity.ERROR, "acc_001_none", "accounting_lines")
        return
    amounts = [_value(line.net_amount) for line in invoice.accounting_lines]
    net = _value(invoice.totals.net_amount)
    if any(amount is None for amount in amounts):
        yield _finding(RuleId.ACC_001, Severity.ERROR, "acc_001_incomplete", "accounting_lines")
        return
    total = sum(amounts, Decimal("0.00"))
    if net is not None and total != net:
        yield _finding(
            RuleId.ACC_001,
            Severity.ERROR,
            "acc_001",
            "accounting_lines",
            expected=net,
            actual=total,
        )


_DIMENSION_FIELDS = (
    (Dimension.COST_CENTER, "cost_center"),
    (Dimension.DEPARTMENT, "department"),
    (Dimension.PROJECT, "project"),
)


def acc_002(context: ValidationContext) -> Iterator[ValidationFinding]:
    """Accounts and dimension values exist and are active in the entity's data."""
    reference = context.reference
    lines = context.invoice.accounting_lines
    if lines and reference.accounts is None:
        yield _finding(RuleId.ACC_002, Severity.INFO, "acc_002_no_chart")
    dimensions_reported = False
    for line in lines:
        path = f"accounting_lines.{line.line_number}"
        account = _value(line.account)
        if account is None:
            yield _finding(RuleId.ACC_002, Severity.ERROR, "acc_002_no_account", f"{path}.account")
        elif reference.accounts is not None:
            entry = reference.accounts.get(account)
            if entry is None:
                yield _finding(RuleId.ACC_002, Severity.ERROR, "acc_002_unknown", f"{path}.account")
            elif not entry.is_active:
                yield _finding(
                    RuleId.ACC_002, Severity.ERROR, "acc_002_inactive", f"{path}.account"
                )
        for dimension, name in _DIMENSION_FIELDS:
            code = _value(getattr(line, name))
            if code is None:
                continue
            if reference.dimensions is None:
                if not dimensions_reported:
                    dimensions_reported = True
                    yield _finding(RuleId.ACC_002, Severity.INFO, "acc_002_no_dimensions")
                continue
            value = reference.dimensions.get((dimension, code))
            if value is None or not value.is_active:
                yield _finding(
                    RuleId.ACC_002,
                    Severity.ERROR,
                    "acc_002_dimension",
                    f"{path}.{name}",
                    dimension=str(dimension),
                )


def acc_003(context: ValidationContext) -> Iterator[ValidationFinding]:
    """Each line has a VAT code that is valid on the date and matches a rate on the invoice."""
    reference = context.reference
    day = _value(context.invoice.invoice_date)
    rates = _invoice_rates(context.invoice)
    for line in context.invoice.accounting_lines:
        path = f"accounting_lines.{line.line_number}.vat_code"
        code = _value(line.vat_code)
        if code is None:
            yield _finding(RuleId.ACC_003, Severity.ERROR, "acc_003_none", path)
            continue
        if reference.vat_codes is None or day is None:
            continue
        entry = reference.vat_code(code, day)
        if entry is None:
            yield _finding(RuleId.ACC_003, Severity.ERROR, "acc_003_unknown", path)
        elif entry.direction is not VatDirection.INPUT:
            yield _finding(RuleId.ACC_003, Severity.ERROR, "acc_003_output", path)
        elif rates and entry.rate not in rates:
            yield _finding(RuleId.ACC_003, Severity.ERROR, "acc_003_rate", path, rate=entry.rate)


# --- CRN and CUR ----------------------------------------------------------------------


def crn_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    invoice = context.invoice
    if (
        _value(invoice.invoice_type) == InvoiceType.CREDIT_NOTE
        and _value(invoice.referenced_invoice_number) is None
    ):
        yield _finding(RuleId.CRN_001, Severity.WARNING, "crn_001", "referenced_invoice_number")


def cur_001(context: ValidationContext) -> Iterator[ValidationFinding]:
    currency = _value(context.invoice.currency)
    if currency is not None and currency != context.settings.base_currency:
        yield _finding(RuleId.CUR_001, Severity.WARNING, "cur_001", "currency", currency=currency)


RULES: Sequence[Rule] = (
    req_001,
    req_002,
    ent_001,
    sum_001,
    sum_002,
    mva_001,
    mva_002,
    mva_003,
    dat_001,
    dat_002,
    id_001,
    id_002,
    id_003,
    id_004,
    dup_001,
    dup_002,
    bank_001,
    crn_001,
    cur_001,
    acc_001,
    acc_002,
    acc_003,
)

_SEVERITY_ORDER = {Severity.ERROR: 0, Severity.WARNING: 1, Severity.INFO: 2}
_RULE_ORDER = {rule_id: index for index, rule_id in enumerate(RuleId)}


def validate(context: ValidationContext) -> list[ValidationFinding]:
    """Run every rule; findings are ordered by severity, rule and field."""
    findings = [finding for rule in RULES for finding in rule(context)]
    findings.sort(
        key=lambda finding: (
            _SEVERITY_ORDER[finding.severity],
            _RULE_ORDER[finding.rule_id],
            finding.field_path or "",
            finding.message_key,
        )
    )
    return findings[:MAX_FINDINGS]
