"""Validation runs and the supplier register (Phase 08a, ADR-0033).

A run reads the current revision of an invoice, the entity, the supplier
register and the other invoices of the entity, applies the rule catalogue and
stores the findings with an audit event, all in one unit of work. The engine
never changes an invoice, never confirms a payment account and never approves
anything.

Payment accounts seen on an invoice are registered as ``unverified``. Only a
deliberate user action (:meth:`ValidationService.set_account_status`) can mark
an account as verified or blocked.
"""

import datetime as dt
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any
from uuid import UUID, uuid4

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.errors import ConflictError, InvoiceFlowError
from invoiceflow.application.ports import UnitOfWork, UnitOfWorkFactory
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import SYSTEM_ACTOR, utc_now
from invoiceflow.application.validation.model import (
    RULESET_VERSION,
    AccountKind,
    AccountStatus,
    BankAccountRecord,
    SupplierRecord,
    ValidationContext,
    ValidationRun,
    ValidationSettings,
    ValidationSummary,
)
from invoiceflow.application.validation.rules import payment_accounts, validate
from invoiceflow.domain.checksums import valid_bank_account, valid_iban, valid_org_number
from invoiceflow.domain.invoice import CanonicalInvoice
from invoiceflow.domain.provenance import FieldValue

# The local user of the Windows session. Actor identifiers are technical and
# never a name (SECURITY.md §18); F09 decides whether more is needed (Å-10).
USER_ACTOR = "user/local"

_MANUAL_STATUSES = frozenset({AccountStatus.VERIFIED, AccountStatus.BLOCKED})


def _value(field: FieldValue[Any] | None) -> Any:
    return None if field is None else field.value


@dataclass(frozen=True, slots=True)
class SupplierView:
    """A supplier with its payment accounts, for the supplier page."""

    supplier: SupplierRecord
    accounts: tuple[BankAccountRecord, ...]


def supplier_identity(invoice: CanonicalInvoice) -> tuple[str | None, str | None] | None:
    """(organisation number, foreign VAT id) usable as a register key, or None.

    An organisation number with a wrong check digit is never registered: it
    may be a misreading, and the register must not fill up with them.
    """
    org = _value(invoice.supplier.org_number)
    if org is not None:
        return (org, None) if valid_org_number(org) else None
    vat_id = _value(invoice.supplier.foreign_vat_id)
    return None if vat_id is None else (None, vat_id)


def _account_kind(path: str, account: str) -> AccountKind | None:
    if path == "payment.bank_account":
        return AccountKind.BBAN if valid_bank_account(account) else None
    return AccountKind.IBAN if valid_iban(account) else None


class ValidationService:
    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        *,
        settings: ValidationSettings | None = None,
        clock: Callable[[], dt.datetime] = utc_now,
        today: Callable[[], dt.date] | None = None,
        new_id: Callable[[], UUID] = uuid4,
    ) -> None:
        self._uow_factory = uow_factory
        self.settings = settings or ValidationSettings()
        self._clock = clock
        # Norwegian calendar date; the invoice dates are local dates.
        self._today = today or (lambda: dt.datetime.now().date())  # noqa: DTZ005
        self._new_id = new_id

    # --- validation ----------------------------------------------------------------

    def validate(
        self, scope: EntityScope, invoice_id: UUID, *, actor: str = SYSTEM_ACTOR
    ) -> ValidationRun:
        with self._uow_factory() as uow:
            run = self.validate_in(uow, scope, invoice_id, actor=actor)
            uow.commit()
        return run

    def validate_all(self, scope: EntityScope, *, actor: str = SYSTEM_ACTOR) -> list[ValidationRun]:
        """Validate every invoice of the entity again (e.g. after a register change)."""
        with self._uow_factory() as uow:
            runs = [
                self.validate_in(uow, scope, invoice_id, actor=actor)
                for invoice_id in uow.invoices(scope).list_ids()
            ]
            uow.commit()
        return runs

    def validate_in(
        self, uow: UnitOfWork, scope: EntityScope, invoice_id: UUID, *, actor: str
    ) -> ValidationRun:
        """One run inside the caller's unit of work; the caller commits."""
        now = self._clock()
        entity = uow.entities.get(scope.entity_id)
        invoices = uow.invoices(scope)
        record = invoices.get(invoice_id)
        statuses = self._register(uow, scope, invoice_id, record.invoice, now, actor)
        context = ValidationContext(
            invoice_id=invoice_id,
            invoice=record.invoice,
            today=self._today(),
            entity_org_number=entity.org_number,
            settings=self.settings,
            account_statuses=statuses,
            reference=uow.references(scope).current(),
            other_invoices=tuple(
                header for header in invoices.headers() if header.invoice_id != invoice_id
            ),
        )
        findings = tuple(validate(context))
        repository = uow.validations(scope)
        run = repository.add_run(
            ValidationRun(
                run_id=self._new_id(),
                invoice_id=invoice_id,
                revision=record.revision,
                run_number=repository.next_run_number(invoice_id),
                ruleset_version=RULESET_VERSION,
                settings_sha256=self.settings.settings_hash(),
                summary=ValidationSummary.of(findings),
                created_at=now,
                created_by=actor,
                findings=findings,
            )
        )
        uow.audit.append(
            AuditDraft(
                event_type=AuditEventType.INVOICE_VALIDATED,
                actor=actor,
                entity_id=scope.entity_id,
                subject_id=str(invoice_id),
                details={
                    "run_id": str(run.run_id),
                    "revision": run.revision,
                    "ruleset_version": run.ruleset_version,
                    "error_count": run.summary.errors,
                    "warning_count": run.summary.warnings,
                    "info_count": run.summary.infos,
                },
            ),
            occurred_at=now,
        )
        return run

    def latest(self, scope: EntityScope, invoice_id: UUID) -> ValidationRun | None:
        """The latest run with its findings; None if the invoice was never validated."""
        with self._uow_factory() as uow:
            uow.invoices(scope).get(invoice_id)  # NotFoundError for a foreign invoice
            return uow.validations(scope).latest(invoice_id)

    def latest_runs(self, scope: EntityScope) -> dict[UUID, ValidationRun]:
        with self._uow_factory() as uow:
            return uow.validations(scope).latest_runs()

    # --- supplier register -----------------------------------------------------------

    def _register(
        self,
        uow: UnitOfWork,
        scope: EntityScope,
        invoice_id: UUID,
        invoice: CanonicalInvoice,
        now: dt.datetime,
        actor: str,
    ) -> dict[str, AccountStatus | None]:
        """Register a new supplier and new payment accounts; return account statuses."""
        stated = payment_accounts(invoice)
        statuses: dict[str, AccountStatus | None] = {account: None for _, account in stated}
        identity = supplier_identity(invoice)
        if identity is None:
            return statuses
        org_number, vat_id = identity
        repository = uow.suppliers(scope)
        supplier = repository.find(org_number=org_number, foreign_vat_id=vat_id)
        if supplier is None:
            supplier = repository.add(
                supplier_id=self._new_id(),
                name=_value(invoice.supplier.name) or org_number or vat_id or "?",
                org_number=org_number,
                foreign_vat_id=vat_id,
                created_at=now,
                actor=actor,
            )
            self._audit_supplier(
                uow, scope, supplier.supplier_id, actor, now, AuditEventType.SUPPLIER_CREATED, {}
            )
        known = {account.account: account for account in repository.accounts(supplier.supplier_id)}
        for path, account in stated:
            existing = known.get(account)
            if existing is not None:
                statuses[account] = existing.status
                continue
            kind = _account_kind(path, account)
            if kind is None:
                continue  # wrong check digit: flagged by ID-002/ID-004, never registered
            added = repository.add_account(
                account_id=self._new_id(),
                supplier_id=supplier.supplier_id,
                kind=kind,
                account=account,
                first_seen_invoice_id=invoice_id,
                created_at=now,
            )
            known[account] = added
            statuses[account] = added.status
            self._audit_supplier(
                uow,
                scope,
                supplier.supplier_id,
                actor,
                now,
                AuditEventType.SUPPLIER_ACCOUNT_ADDED,
                {"account_id": str(added.account_id), "account_kind": str(kind)},
            )
        return statuses

    @staticmethod
    def _audit_supplier(
        uow: UnitOfWork,
        scope: EntityScope,
        supplier_id: UUID,
        actor: str,
        now: dt.datetime,
        event_type: AuditEventType,
        details: dict[str, object],
    ) -> None:
        uow.audit.append(
            AuditDraft(
                event_type=event_type,
                actor=actor,
                entity_id=scope.entity_id,
                subject_id=str(supplier_id),
                details=details,
            ),
            occurred_at=now,
        )

    def suppliers(self, scope: EntityScope) -> list[SupplierView]:
        with self._uow_factory() as uow:
            repository = uow.suppliers(scope)
            return [
                SupplierView(record, tuple(repository.accounts(record.supplier_id)))
                for record in repository.list()
            ]

    def set_account_status(
        self,
        scope: EntityScope,
        account_id: UUID,
        status: AccountStatus,
        *,
        expected: AccountStatus,
        actor: str = USER_ACTOR,
    ) -> BankAccountRecord:
        """Verify or block a payment account (a deliberate user action).

        The invoices that state the account are validated again in the same
        unit of work, so BANK-001 reflects the new status at once.
        """
        if status not in _MANUAL_STATUSES or status == expected:
            raise InvoiceFlowError("INVALID_INPUT", "error.invalid_input")
        now = self._clock()
        with self._uow_factory() as uow:
            repository = uow.suppliers(scope)
            current = repository.get_account(account_id)
            if current.status != expected:
                raise ConflictError()
            updated = repository.set_account_status(
                account_id, status, expected=expected, changed_at=now, actor=actor
            )
            self._audit_supplier(
                uow,
                scope,
                updated.supplier_id,
                actor,
                now,
                AuditEventType.SUPPLIER_ACCOUNT_STATUS_CHANGED,
                {
                    "account_id": str(account_id),
                    "account_status": str(status),
                    "previous_account_status": str(expected),
                },
            )
            supplier = repository.get(updated.supplier_id)
            invoices = uow.invoices(scope)
            candidates = [
                header.invoice_id
                for header in invoices.headers()
                if supplier.org_number is None or header.supplier_org_number == supplier.org_number
            ]
            for invoice_id in candidates:
                stated = {
                    account for _, account in payment_accounts(invoices.get(invoice_id).invoice)
                }
                if updated.account in stated:
                    self.validate_in(uow, scope, invoice_id, actor=actor)
            uow.commit()
        return updated
