"""Deterministic validation of canonical invoices (Phase 08a)."""
