"""Contracts of the validation engine (Phase 08a, docs/DATA_MODEL.md §7). No I/O.

A finding names a rule, its version and severity, the field it concerns and
a translation key. Its parameters are short codes, numbers or dates; free
text from the document can never become part of a finding.
"""

import datetime as dt
import hashlib
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from decimal import Decimal
from enum import StrEnum
from types import MappingProxyType
from typing import Annotated
from uuid import UUID

from pydantic import Field, StringConstraints

from invoiceflow.application.reference.model import EMPTY_REFERENCE, ReferenceData
from invoiceflow.domain.base import ContractModel
from invoiceflow.domain.canonical import canonical_json_bytes
from invoiceflow.domain.invoice import CanonicalInvoice, InvoiceType
from invoiceflow.domain.types import CurrencyCode, Money

# Bumped whenever a rule is added, removed or changes meaning.
RULESET_VERSION = "1.1"  # 1.1: MVA-002 and ACC-001-003 (Phase 08b)
MAX_FINDINGS = 200


class Severity(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


class RuleId(StrEnum):
    REQ_001 = "REQ-001"
    REQ_002 = "REQ-002"
    ENT_001 = "ENT-001"
    SUM_001 = "SUM-001"
    SUM_002 = "SUM-002"
    MVA_001 = "MVA-001"
    MVA_002 = "MVA-002"
    MVA_003 = "MVA-003"
    DAT_001 = "DAT-001"
    DAT_002 = "DAT-002"
    ID_001 = "ID-001"
    ID_002 = "ID-002"
    ID_003 = "ID-003"
    ID_004 = "ID-004"
    DUP_001 = "DUP-001"
    DUP_002 = "DUP-002"
    BANK_001 = "BANK-001"
    CRN_001 = "CRN-001"
    CUR_001 = "CUR-001"
    ACC_001 = "ACC-001"
    ACC_002 = "ACC-002"
    ACC_003 = "ACC-003"


class AccountStatus(StrEnum):
    """Status of a supplier's payment account in the register (BANK-001)."""

    UNVERIFIED = "unverified"
    VERIFIED = "verified"
    BLOCKED = "blocked"


ParamValue = Annotated[str, StringConstraints(pattern=r"^[0-9A-Za-z.:_-]{1,40}$")]
FieldPath = Annotated[str, StringConstraints(pattern=r"^[a-z_]{1,32}(\.[a-z0-9_]{1,32}){0,3}$")]
MessageKey = Annotated[str, StringConstraints(pattern=r"^validation\.[a-z0-9_.]{1,60}$")]


class ValidationFinding(ContractModel):
    rule_id: RuleId
    rule_version: Annotated[int, Field(strict=True, ge=1, le=1000)] = 1
    severity: Severity
    field_path: FieldPath | None = None
    message_key: MessageKey
    params: Mapping[str, ParamValue] = Field(default_factory=dict, max_length=8)


class ValidationSettings(ContractModel):
    """Configurable limits; hashed into every run so results can be reproduced."""

    vat_tolerance: Money = Decimal("0.01")
    max_invoice_age_days: Annotated[int, Field(strict=True, ge=1, le=3650)] = 365
    base_currency: CurrencyCode = "NOK"

    def settings_hash(self) -> str:
        return hashlib.sha256(canonical_json_bytes(self.model_dump(mode="json"))).hexdigest()


@dataclass(frozen=True, slots=True)
class InvoiceHeader:
    """What duplicate checks need to know about another invoice of the entity."""

    invoice_id: UUID
    invoice_type: InvoiceType | None
    invoice_number: str | None
    supplier_org_number: str | None
    gross_amount: Decimal | None
    invoice_date: dt.date | None


@dataclass(frozen=True, slots=True)
class ValidationContext:
    """Everything one validation run reads; built by the service, read by the rules."""

    invoice_id: UUID
    invoice: CanonicalInvoice
    today: dt.date
    entity_org_number: str | None
    settings: ValidationSettings
    # Register status of each payment account on the invoice (account -> status);
    # None when the account is not in the supplier register.
    account_statuses: Mapping[str, AccountStatus | None] = field(
        default_factory=lambda: MappingProxyType({})
    )
    # Other invoices of the same entity; the invoice itself is never included.
    other_invoices: Sequence[InvoiceHeader] = ()
    # Chart of accounts, VAT codes and dimensions of the entity (Phase 08b).
    reference: ReferenceData = EMPTY_REFERENCE


@dataclass(frozen=True, slots=True)
class ValidationSummary:
    errors: int
    warnings: int
    infos: int

    @classmethod
    def of(cls, findings: Sequence[ValidationFinding]) -> "ValidationSummary":
        def count(severity: Severity) -> int:
            return sum(1 for finding in findings if finding.severity is severity)

        return cls(count(Severity.ERROR), count(Severity.WARNING), count(Severity.INFO))


class AccountKind(StrEnum):
    BBAN = "bban"  # Norwegian 11-digit account number
    IBAN = "iban"


@dataclass(frozen=True, slots=True)
class SupplierRecord:
    supplier_id: UUID
    entity_id: UUID
    name: str
    org_number: str | None
    foreign_vat_id: str | None
    created_at: dt.datetime


@dataclass(frozen=True, slots=True)
class BankAccountRecord:
    account_id: UUID
    supplier_id: UUID
    kind: AccountKind
    account: str
    status: AccountStatus
    first_seen_invoice_id: UUID | None
    created_at: dt.datetime
    status_changed_at: dt.datetime | None = None
    status_changed_by: str | None = None


@dataclass(frozen=True, slots=True)
class ValidationRun:
    """One stored validation of an invoice revision with its findings."""

    run_id: UUID
    invoice_id: UUID
    revision: int
    run_number: int
    ruleset_version: str
    settings_sha256: str
    summary: ValidationSummary
    created_at: dt.datetime
    created_by: str
    findings: tuple[ValidationFinding, ...] = ()
