"""Persistence ports used by application services (docs/ARCHITECTURE.md §3.1).

Concrete adapters live in ``invoiceflow.persistence`` and are composed only in
``invoiceflow.bootstrap``.
"""

import datetime as dt
from collections.abc import Callable, Mapping, Sequence
from contextlib import AbstractContextManager
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from types import TracebackType
from typing import Protocol
from uuid import UUID

from invoiceflow.application.audit import AuditDraft, AuditRecord, ChainVerification
from invoiceflow.application.backup.model import (
    BackupHeader,
    BackupRecord,
    DatabaseCopy,
    Manifest,
    ManifestEntry,
)
from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentRecord,
    DocumentType,
    ImportOutcome,
    IntegrityStatus,
    RejectReason,
)
from invoiceflow.application.errors import StorageError
from invoiceflow.application.export.model import (
    BatchStatus,
    ExportBatchRecord,
    ExportItemRecord,
    ExportMapping,
    ExportSheet,
    ItemStatus,
)
from invoiceflow.application.processing_model import (
    DerivedFileRecord,
    JobRecord,
    JobStatus,
    OcrPageRecord,
    OcrSettings,
    PageRecord,
    ProcessingErrorCode,
    ProcessingLimits,
)
from invoiceflow.application.reference.model import (
    AccountEntry,
    DimensionEntry,
    ImportRecord,
    ReferenceData,
    ReferenceKind,
    SupplierDefaults,
    VatCodeEntry,
)
from invoiceflow.application.review.model import ApprovalRecord, OverrideRecord
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.validation.model import (
    AccountKind,
    AccountStatus,
    BankAccountRecord,
    InvoiceHeader,
    SupplierRecord,
    ValidationRun,
)
from invoiceflow.domain.invoice import CanonicalInvoice


@dataclass(frozen=True, slots=True)
class EntityRecord:
    entity_id: UUID
    name: str
    org_number: str | None
    default_currency: str
    created_at: dt.datetime


@dataclass(frozen=True, slots=True)
class InvoiceRecord:
    """One invoice revision with its ownership and integrity metadata.

    The canonical invoice is the content; everything else is workflow data
    kept outside the contract.
    """

    invoice_id: UUID
    entity_id: UUID
    revision: int
    content_sha256: str
    workflow_status: str
    invoice: CanonicalInvoice


class EntityRepository(Protocol):
    def add(
        self,
        *,
        entity_id: UUID,
        name: str,
        org_number: str | None,
        default_currency: str,
        created_at: dt.datetime,
    ) -> EntityRecord: ...

    def get(self, entity_id: UUID) -> EntityRecord: ...

    def list(self) -> list[EntityRecord]: ...


class InvoiceRepository(Protocol):
    """Every method is restricted to the scope the repository was created for."""

    def add(
        self, *, invoice_id: UUID, invoice: CanonicalInvoice, recorded_at: dt.datetime, actor: str
    ) -> InvoiceRecord: ...

    def replace(
        self,
        *,
        invoice_id: UUID,
        invoice: CanonicalInvoice,
        expected_revision: int,
        recorded_at: dt.datetime,
        actor: str,
    ) -> InvoiceRecord: ...

    def get(self, invoice_id: UUID) -> InvoiceRecord: ...

    def get_revision(self, invoice_id: UUID, revision: int) -> InvoiceRecord: ...

    def list_ids(self) -> list[UUID]: ...

    def ids_for_document(self, document_id: UUID) -> list[UUID]: ...

    def ids_by_supplier_and_number(self, supplier_org_number: str, number: str) -> list[UUID]: ...

    def add_findings(
        self, invoice_id: UUID, revision: int, codes: Sequence[str], created_at: dt.datetime
    ) -> None: ...

    def findings(self, invoice_id: UUID) -> list[tuple[int, str]]: ...

    def headers(self) -> list[InvoiceHeader]: ...

    def set_status(self, invoice_id: UUID, status: str, *, expected_revision: int) -> None: ...


# Aliases, because inside the repository classes ``list`` is a method name.
Suppliers = list[SupplierRecord]
BankAccounts = list[BankAccountRecord]


class SupplierRepository(Protocol):
    """Supplier register of one entity (Phase 08a); rows are never deleted."""

    def find(
        self, *, org_number: str | None, foreign_vat_id: str | None
    ) -> SupplierRecord | None: ...

    def get(self, supplier_id: UUID) -> SupplierRecord: ...

    def add(
        self,
        *,
        supplier_id: UUID,
        name: str,
        org_number: str | None,
        foreign_vat_id: str | None,
        created_at: dt.datetime,
        actor: str,
    ) -> SupplierRecord: ...

    def list(self) -> Suppliers: ...

    def accounts(self, supplier_id: UUID) -> BankAccounts: ...

    def get_account(self, account_id: UUID) -> BankAccountRecord: ...

    def add_account(
        self,
        *,
        account_id: UUID,
        supplier_id: UUID,
        kind: AccountKind,
        account: str,
        first_seen_invoice_id: UUID | None,
        created_at: dt.datetime,
    ) -> BankAccountRecord: ...

    def set_account_status(
        self,
        account_id: UUID,
        status: AccountStatus,
        *,
        expected: AccountStatus,
        changed_at: dt.datetime,
        actor: str,
    ) -> BankAccountRecord: ...


class ValidationRepository(Protocol):
    """Append-only validation runs of one entity's invoices."""

    def add_run(self, run: ValidationRun) -> ValidationRun: ...

    def next_run_number(self, invoice_id: UUID) -> int: ...

    def latest(self, invoice_id: UUID) -> ValidationRun | None: ...

    def latest_runs(self) -> dict[UUID, ValidationRun]: ...


ReferenceEntries = Sequence[AccountEntry] | Sequence[VatCodeEntry] | Sequence[DimensionEntry]


class ReferenceRepository(Protocol):
    """Reference data snapshots and supplier standard posting of one entity (Phase 08b)."""

    def add_import(self, record: ImportRecord, entries: ReferenceEntries) -> ImportRecord: ...

    def latest_imports(self) -> dict[ReferenceKind, ImportRecord]: ...

    def current(self) -> ReferenceData: ...

    def defaults(self, supplier_id: UUID) -> SupplierDefaults | None: ...

    def add_defaults(self, entry_id: UUID, defaults: SupplierDefaults) -> SupplierDefaults: ...


Decisions = list[ApprovalRecord]
Overrides = list[OverrideRecord]


class ReviewRepository(Protocol):
    """Approval decisions and finding overrides of one entity (Phase 09)."""

    def add_decision(self, record: ApprovalRecord) -> ApprovalRecord: ...

    def next_sequence(self, invoice_id: UUID) -> int: ...

    def decisions(self, invoice_id: UUID) -> Decisions: ...

    def add_override(self, record: OverrideRecord) -> OverrideRecord: ...

    def overrides(self, invoice_id: UUID, revision: int) -> Overrides: ...


Batches = list[ExportBatchRecord]
Items = list[ExportItemRecord]


class ExportRepository(Protocol):
    """Export mappings, batches and items of one entity (Phase 10)."""

    def mapping(self) -> ExportMapping | None: ...

    def add_mapping(
        self, mapping_id: UUID, mapping: ExportMapping, actor: str
    ) -> ExportMapping: ...

    def next_sequence(self) -> int: ...

    def add_batch(self, batch: ExportBatchRecord, items: Sequence[ExportItemRecord]) -> None: ...

    def get_batch(self, batch_id: UUID) -> ExportBatchRecord: ...

    def batches(self) -> Batches: ...

    def open_batches(self) -> Batches: ...

    def items(self, batch_id: UUID) -> Items: ...

    def latest_items(self) -> dict[UUID, ExportItemRecord]: ...

    def finish(
        self,
        batch_id: UUID,
        status: BatchStatus,
        item_status: ItemStatus,
        *,
        file_sha256: str | None,
        completed_at: dt.datetime,
    ) -> ExportBatchRecord: ...

    def supersede(self, item_id: int, *, updated_at: dt.datetime) -> None: ...


class ExportWriter(Protocol):
    """Turns the export table into the bytes of one file format."""

    def render(self, sheet: ExportSheet) -> bytes: ...


class ExportFileStore(Protocol):
    """The export folder; a finished file name exists only with complete content."""

    def write(self, entity_id: UUID, name: str, data: bytes) -> str: ...

    def read(self, entity_id: UUID, name: str) -> bytes | None: ...

    def discard_temporary(self, entity_id: UUID) -> int: ...

    def save_copy(self, data: bytes, destination: Path) -> None: ...


# (from_document_id, to_document_id, link_type). An alias, because inside the
# repository classes the name ``list`` is the method, not the builtin.
DocumentLinks = list[tuple[UUID, UUID, str]]


class DocumentRepository(Protocol):
    """Documents of one entity; another entity's document reads as missing."""

    def add(self, record: DocumentRecord) -> DocumentRecord: ...

    def get(self, document_id: UUID) -> DocumentRecord: ...

    def find_by_sha256(self, sha256: str) -> DocumentRecord | None: ...

    def list(self) -> list[DocumentRecord]: ...

    def set_type(
        self, document_id: UUID, document_type: DocumentType, *, expected: DocumentType
    ) -> DocumentRecord: ...

    def set_integrity(
        self, document_id: UUID, status: IntegrityStatus, *, checked_at: dt.datetime
    ) -> None: ...

    def add_link(
        self,
        from_document_id: UUID,
        to_document_id: UUID,
        link_type: str,
        *,
        created_at: dt.datetime,
        actor: str,
    ) -> bool: ...

    def links(self, document_id: UUID) -> DocumentLinks: ...


__all__ = ["StorageError"]  # re-exported for adapters


class StagingError(Exception):
    """A source file could not be copied into staging; nothing was stored."""

    def __init__(self, reason: RejectReason) -> None:
        super().__init__(str(reason))
        self.reason = reason


@dataclass(frozen=True, slots=True)
class StagedFile:
    """A private, fsynced copy of a source file with its hash, ready to publish."""

    token: str
    sha256: str
    size_bytes: int
    header: bytes


@dataclass(frozen=True, slots=True)
class StoreRecovery:
    staging_removed: int
    orphans_moved: int
    missing_paths: frozenset[str]
    failed: int = 0


class DocumentStore(Protocol):
    """Content-addressed original archive per entity (docs/ARCHITECTURE.md).

    Files are written to staging, verified and atomically published; they are
    never modified or deleted afterwards.
    """

    def stage(self, source: Path, entity_id: UUID, max_bytes: int) -> StagedFile: ...

    def publish(self, staged: StagedFile, entity_id: UUID, sha256: str, extension: str) -> str: ...

    def quarantine(self, staged: StagedFile, entity_id: UUID, quarantine_id: UUID) -> str: ...

    def discard(self, staged: StagedFile) -> None: ...

    def verify(self, storage_path: str, sha256: str) -> IntegrityStatus: ...

    def resolve(self, storage_path: str) -> Path: ...

    def list_candidates(self, directory: Path) -> list[Path]: ...

    def recover(self, entity_id: UUID, known_paths: frozenset[str]) -> StoreRecovery: ...


class ProcessingRepository(Protocol):
    """Processing jobs, pages and derived files of one entity."""

    def add_job(self, job: JobRecord) -> JobRecord: ...

    def get_job(self, job_id: UUID) -> JobRecord: ...

    def find_succeeded(self, idempotency_key: str) -> JobRecord | None: ...

    def find_unfinished(self, idempotency_key: str) -> JobRecord | None: ...

    def next_attempt(self, idempotency_key: str) -> int: ...

    def latest_jobs(self, *, ocr: bool = False) -> dict[UUID, JobRecord]: ...

    def unfinished_jobs(self) -> list[JobRecord]: ...

    def succeeded_job_ids(self) -> frozenset[UUID]: ...

    def finish_job(
        self,
        job_id: UUID,
        *,
        status: JobStatus,
        finished_at: dt.datetime,
        error_code: ProcessingErrorCode | None = None,
        page_count: int | None = None,
        active_content: bool | None = None,
    ) -> JobRecord: ...

    def add_pages(self, pages: Sequence[PageRecord]) -> None: ...

    def add_derived_files(self, files: Sequence[DerivedFileRecord]) -> None: ...

    def pages(self, job_id: UUID) -> list[PageRecord]: ...

    def derived_files(self, job_id: UUID) -> list[DerivedFileRecord]: ...

    def add_ocr_pages(self, pages: Sequence[OcrPageRecord]) -> None: ...

    def ocr_pages(self, job_id: UUID) -> list[OcrPageRecord]: ...


class WorkOutputError(Exception):
    """The worker's output folder does not hold what its report promised."""

    def __init__(self, code: ProcessingErrorCode) -> None:
        super().__init__(str(code))
        self.code = code


@dataclass(frozen=True, slots=True)
class WorkFile:
    """A file the worker wrote, checked but not yet published."""

    name: str
    size_bytes: int
    sha256: str
    header: bytes


@dataclass(frozen=True, slots=True)
class DerivedRecovery:
    work_removed: int
    derived_moved: int
    failed: int = 0


class DerivedStore(Protocol):
    """Derived files (page images, text layers) kept apart from the originals."""

    def create_work_dir(self, entity_id: UUID, job_id: UUID) -> Path: ...

    def inspect(
        self, work_dir: Path, names: Sequence[str], max_total_bytes: int
    ) -> dict[str, WorkFile]: ...

    def read(self, work_dir: Path, name: str, max_bytes: int) -> bytes: ...

    def work_file(self, work_dir: Path, name: str) -> Path: ...

    def put_work_file(self, work_dir: Path, name: str, data: bytes) -> None: ...

    def publish(
        self,
        entity_id: UUID,
        document_id: UUID,
        job_id: UUID,
        work_dir: Path,
        files: Mapping[str, WorkFile],
    ) -> dict[str, str]: ...

    def discard_work(self, work_dir: Path) -> None: ...

    def recover(self, entity_id: UUID, succeeded_jobs: frozenset[UUID]) -> DerivedRecovery: ...

    def read_published(self, storage_path: str, sha256: str, max_bytes: int) -> bytes | None: ...


@dataclass(frozen=True, slots=True)
class OcrInput:
    """A page image copied into the work folder, with the hash it must have."""

    page_number: int
    name: str
    sha256: str
    width_px: int
    height_px: int


@dataclass(frozen=True, slots=True)
class OcrTask:
    """The OCR part of a worker task (Phase 05).

    The service names the pages; the processor fills in where the OCR engine
    and its language data are, so the service never runs a program itself.
    """

    settings: OcrSettings
    pages: tuple[OcrInput, ...]
    page_timeout_seconds: float  # for one page; the task's limits bound the whole run
    executable: Path | None = None
    tessdata: Path | None = None
    engine_version: str | None = None


@dataclass(frozen=True, slots=True)
class WorkerTask:
    """Everything the worker receives: a path to read, an empty folder to write."""

    source: Path
    sha256: str
    document_format: DocumentFormat
    output_dir: Path
    limits: ProcessingLimits
    ocr: OcrTask | None = None  # set for an OCR task: read page images, not the original


class WorkerExit(StrEnum):
    COMPLETED = "completed"
    TIMED_OUT = "timed_out"
    MEMORY_LIMIT = "memory_limit"
    CRASHED = "crashed"
    CANCELLED = "cancelled"
    INVALID_RESULT = "invalid_result"


@dataclass(frozen=True, slots=True)
class WorkerOutcome:
    """How the worker ended; ``payload`` is its unvalidated JSON report."""

    exit: WorkerExit
    payload: bytes | None = None


class DocumentProcessor(Protocol):
    """Runs one task in an isolated, resource-limited process (ADR-0010)."""

    def engine_for(self, document_format: DocumentFormat) -> tuple[str, str]: ...

    def ocr_engine(self, settings: OcrSettings) -> tuple[str, str] | None:
        """Engine and version for OCR, or ``None`` when OCR is not installed."""
        ...

    def run(self, task: WorkerTask, should_stop: Callable[[], bool]) -> WorkerOutcome: ...


class BackupRepository(Protocol):
    """Register of backup files (Phase 12); not scoped to an entity."""

    def add(self, record: BackupRecord) -> BackupRecord: ...

    def list(self) -> list[BackupRecord]: ...

    def find(self, file_sha256: str) -> BackupRecord | None: ...

    def mark_deleted(self, backup_id: UUID, *, deleted_at: dt.datetime, actor: str) -> None: ...


class DatabaseSnapshotter(Protocol):
    """Consistent copies of the live database and checks of restored ones."""

    def snapshot(self, target: Path) -> DatabaseCopy: ...

    def inspect(self, path: Path) -> DatabaseCopy: ...


class BackupArchive(Protocol):
    """Encrypted backup files, the data folder and restore targets."""

    def workspace(self) -> AbstractContextManager[Path]: ...

    def discard_workspaces(self) -> int: ...

    def data_files(self) -> list[tuple[str, Path]]: ...

    def derive_key(self, passphrase: bytes, header: BackupHeader) -> bytes: ...

    def write(
        self,
        destination: Path,
        header: BackupHeader,
        key: bytes,
        files: Sequence[tuple[str, Path]],
        manifest: Callable[[tuple[ManifestEntry, ...]], Manifest],
    ) -> tuple[str, int, Manifest]: ...

    def read_header(self, source: Path) -> BackupHeader: ...

    def extract(
        self, source: Path, header: BackupHeader, key: bytes, target: Path
    ) -> tuple[Manifest, dict[str, tuple[str, int]]]: ...

    def prepare_target(self, target: Path) -> None: ...

    def clear(self, target: Path) -> None: ...

    def file_sha256(self, path: Path) -> str: ...

    def delete(self, path: Path) -> None: ...


class ScanFolder(Protocol):
    """The watched folder scanner software writes into (Phase 11a)."""

    def ready_files(self, folder: Path) -> list[Path]: ...

    def set_aside(self, folder: Path, source: Path, outcome: ImportOutcome) -> None: ...

    def write_file(self, destination: Path, data: bytes) -> None: ...


class AuditLog(Protocol):
    def append(self, draft: AuditDraft, *, occurred_at: dt.datetime) -> AuditRecord: ...

    def head(self) -> str: ...

    def verify(self) -> ChainVerification: ...


class UnitOfWork(Protocol):
    """One database transaction. Nothing is stored unless ``commit`` is called."""

    entities: EntityRepository
    audit: AuditLog
    backups: BackupRepository

    def invoices(self, scope: EntityScope) -> InvoiceRepository: ...

    def documents(self, scope: EntityScope) -> DocumentRepository: ...

    def processing(self, scope: EntityScope) -> ProcessingRepository: ...

    def suppliers(self, scope: EntityScope) -> SupplierRepository: ...

    def validations(self, scope: EntityScope) -> ValidationRepository: ...

    def references(self, scope: EntityScope) -> ReferenceRepository: ...

    def reviews(self, scope: EntityScope) -> ReviewRepository: ...

    def exports(self, scope: EntityScope) -> ExportRepository: ...

    def commit(self) -> None: ...

    def __enter__(self) -> "UnitOfWork": ...

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None: ...


class UnitOfWorkFactory(Protocol):
    def __call__(self) -> UnitOfWork: ...
