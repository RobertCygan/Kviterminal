"""Crash-safe export of approved invoices (Phase 10, ADR-0036).

Order (``DATA_MODEL.md`` §3.5):

1. One transaction stores the batch and a ``pending`` item per invoice. The
   database refuses an invoice that is not approved, whose approval is not the
   latest decision of its current content, or that already has an active export.
2. The file is written to a temporary name, flushed and renamed.
3. One transaction marks the items ``exported``, the batch ``written`` with the
   file's SHA-256 and the invoices ``exported``, with audit events.

A batch still ``created`` after a crash is finished from the file if the
renamed file exists (it is complete by construction), otherwise marked failed.
Recovery runs at startup and before every export.
"""

import datetime as dt
import threading
import unicodedata
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.errors import ConflictError
from invoiceflow.application.export.model import (
    MAX_REASON,
    MIN_REASON,
    STANDARD_MAPPING,
    BatchStatus,
    Cell,
    ExportBatchRecord,
    ExportCandidate,
    ExportColumn,
    ExportError,
    ExportErrorCode,
    ExportItemRecord,
    ExportMapping,
    ExportRecovery,
    ExportSheet,
    ExportSource,
    ExportTarget,
    ItemStatus,
    build_rows,
    check_columns,
    file_name,
    headers,
    kind_of,
    totals,
)
from invoiceflow.application.ports import (
    ExportFileStore,
    ExportWriter,
    InvoiceRecord,
    StorageError,
    UnitOfWork,
    UnitOfWorkFactory,
)
from invoiceflow.application.review.model import ApprovalRecord, Decision, WorkflowStatus
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import utc_now
from invoiceflow.application.validation.service import USER_ACTOR
from invoiceflow.domain.canonical import format_utc, sha256_hex

# Translation lookup with named parameters (``invoiceflow.i18n.t``).
Label = Callable[..., str]


def _reason(text: str) -> str:
    value = text.strip()
    if not MIN_REASON <= len(value) <= MAX_REASON:
        raise ExportError("reason")
    allowed = {"\n", "\t"}
    if any(c not in allowed and unicodedata.category(c) in ("Cc", "Cf") for c in value):
        raise ExportError("reason")
    return value


def _approval(record: InvoiceRecord, decisions: Sequence[ApprovalRecord]) -> ApprovalRecord | None:
    """The approval the export relies on: the latest decision, on this content."""
    if not decisions:
        return None
    latest = decisions[-1]
    if (
        latest.decision is not Decision.APPROVED
        or latest.revision != record.revision
        or latest.content_sha256 != record.content_sha256
    ):
        return None
    return latest


def _local_date(moment: dt.datetime) -> dt.date:
    # The day as the person saw it on this computer when approving.
    return moment.astimezone().date()


class ExportService:
    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        writers: dict[ExportTarget, ExportWriter],
        files: ExportFileStore,
        label: Label,
        *,
        clock: Callable[[], dt.datetime] = utc_now,
        new_id: Callable[[], UUID] = uuid4,
    ) -> None:
        self._uow_factory = uow_factory
        self._writers = writers
        self._files = files
        self._label = label
        self._clock = clock
        self._new_id = new_id
        # Exports and recovery of this application instance never overlap.
        self._lock = threading.Lock()

    # --- reading -----------------------------------------------------------------------

    def ready(self, scope: EntityScope) -> list[ExportCandidate]:
        """Approved invoices that a normal export would include."""
        with self._uow_factory() as uow:
            return [
                ExportCandidate(
                    invoice_id=source.invoice_id,
                    supplier_name=_text(source.invoice.supplier.name),
                    invoice_number=_text(source.invoice.invoice_number),
                    invoice_date=_text(source.invoice.invoice_date),
                    gross_amount=_text(source.invoice.totals.gross_amount),
                    currency=_text(source.invoice.currency),
                )
                for source, _ in self._approved(uow, scope)
            ]

    def batches(self, scope: EntityScope) -> list[ExportBatchRecord]:
        with self._uow_factory() as uow:
            return uow.exports(scope).batches()

    def mapping(self, scope: EntityScope) -> ExportMapping:
        with self._uow_factory() as uow:
            return uow.exports(scope).mapping() or STANDARD_MAPPING

    def set_mapping(
        self,
        scope: EntityScope,
        columns: Sequence[ExportColumn],
        *,
        expected_version: int,
        actor: str = USER_ACTOR,
    ) -> ExportMapping:
        """Store a new version of the entity's columns."""
        chosen = check_columns(columns)
        headers(chosen, self._label)
        now = self._clock()
        with self._uow_factory() as uow:
            exports = uow.exports(scope)
            current = exports.mapping() or STANDARD_MAPPING
            if current.version != expected_version:
                raise ConflictError()
            mapping = exports.add_mapping(
                self._new_id(), ExportMapping(current.version + 1, chosen, now), actor
            )
            self._audit(
                uow,
                scope,
                actor,
                now,
                AuditEventType.EXPORT_MAPPING_SET,
                {"mapping_version": mapping.version, "column_count": len(chosen)},
            )
            uow.commit()
        return mapping

    # --- exporting ---------------------------------------------------------------------

    def export(
        self, scope: EntityScope, target: ExportTarget, *, actor: str = USER_ACTOR
    ) -> ExportBatchRecord:
        """Export every approved invoice that has not been exported."""
        with self._lock:
            self._recover(scope, actor)
            now = self._clock()
            with self._uow_factory() as uow:
                approved = self._approved(uow, scope)
                if not approved:
                    raise ExportError("nothing_to_export")
                batch = self._open(uow, scope, target, approved, None, actor, now)
                uow.commit()
            return self._write(scope, batch, [source for source, _ in approved], actor)

    def reexport(
        self,
        scope: EntityScope,
        batch_id: UUID,
        reason: str,
        *,
        target: ExportTarget | None = None,
        actor: str = USER_ACTOR,
    ) -> ExportBatchRecord:
        """Export the invoices of an earlier batch again, with a reason.

        Only invoices whose latest export is in that batch are included; their
        earlier export is marked ``superseded`` in the same transaction.
        """
        text = _reason(reason)
        with self._lock:
            self._recover(scope, actor)
            now = self._clock()
            with self._uow_factory() as uow:
                exports = uow.exports(scope)
                # Recovery above leaves no batch open, so this one is finished.
                original = exports.get_batch(batch_id)
                latest = exports.latest_items()
                invoices = uow.invoices(scope)
                reviews = uow.reviews(scope)
                chosen: list[tuple[ExportSource, ApprovalRecord]] = []
                for item in exports.items(batch_id):
                    if latest[item.invoice_id].item_id != item.item_id or item.status not in (
                        ItemStatus.EXPORTED,
                        ItemStatus.FAILED,
                    ):
                        continue
                    record = invoices.get(item.invoice_id)
                    if record.workflow_status != WorkflowStatus.EXPORTED:
                        continue  # Never exported: a normal export includes it.
                    # An exported invoice takes no new decisions: its approval is final.
                    approval = next(
                        d
                        for d in reviews.decisions(item.invoice_id)
                        if d.approval_id == item.approval_id
                    )
                    exports.supersede(item.item_id or 0, updated_at=now)
                    chosen.append(
                        (
                            ExportSource(
                                record.invoice_id, record.invoice, _local_date(approval.decided_at)
                            ),
                            approval,
                        )
                    )
                if not chosen:
                    raise ExportError("nothing_to_export")
                batch = self._open(uow, scope, target or original.target, chosen, text, actor, now)
                uow.commit()
            return self._write(scope, batch, [source for source, _ in chosen], actor)

    def save_copy(self, scope: EntityScope, batch_id: UUID, destination: Path) -> None:
        """Copy a written file where the person chose, after checking its hash."""
        with self._uow_factory() as uow:
            batch = uow.exports(scope).get_batch(batch_id)
        if batch.status is not BatchStatus.WRITTEN:
            raise ExportError("not_written")
        data = self._files.read(scope.entity_id, batch.file_name)
        if data is None:
            raise ExportError("file_missing")
        if sha256_hex(data) != batch.file_sha256:
            raise ExportError("file_changed")
        try:
            self._files.save_copy(data, destination)
        except StorageError as exc:
            raise ExportError("copy_failed") from exc

    def recover(self, scope: EntityScope, *, actor: str = "system") -> ExportRecovery:
        """Finish or fail batches interrupted by a crash (startup)."""
        with self._lock:
            return self._recover(scope, actor)

    # --- steps -------------------------------------------------------------------------

    def _approved(
        self, uow: UnitOfWork, scope: EntityScope
    ) -> list[tuple[ExportSource, ApprovalRecord]]:
        invoices = uow.invoices(scope)
        reviews = uow.reviews(scope)
        approved: list[tuple[ExportSource, ApprovalRecord]] = []
        for invoice_id in invoices.list_ids():
            record = invoices.get(invoice_id)
            if record.workflow_status != WorkflowStatus.APPROVED:
                continue
            approval = _approval(record, reviews.decisions(invoice_id))
            if approval is None:
                continue
            source = ExportSource(invoice_id, record.invoice, _local_date(approval.decided_at))
            approved.append((source, approval))
        return approved

    def _open(
        self,
        uow: UnitOfWork,
        scope: EntityScope,
        target: ExportTarget,
        chosen: Sequence[tuple[ExportSource, ApprovalRecord]],
        reason: str | None,
        actor: str,
        now: dt.datetime,
    ) -> ExportBatchRecord:
        exports = uow.exports(scope)
        mapping = exports.mapping() or STANDARD_MAPPING
        headers(mapping.columns, self._label)  # Refuse a duplicate header before writing.
        sequence = exports.next_sequence()
        batch = ExportBatchRecord(
            batch_id=self._new_id(),
            sequence=sequence,
            target=target,
            mapping_version=mapping.version,
            columns=mapping.columns,
            status=BatchStatus.CREATED,
            file_name=file_name(sequence, now, target),
            file_sha256=None,
            item_count=len(chosen),
            is_reexport=reason is not None,
            reexport_reason=reason,
            audit_anchor=uow.audit.head(),
            created_at=now,
            created_by=actor,
        )
        exports.add_batch(
            batch,
            [
                ExportItemRecord(
                    batch_id=batch.batch_id,
                    invoice_id=source.invoice_id,
                    approval_id=approval.approval_id,
                    revision=approval.revision,
                    content_sha256=approval.content_sha256,
                    target=target,
                    status=ItemStatus.PENDING,
                    created_at=now,
                    updated_at=now,
                )
                for source, approval in chosen
            ],
        )
        return batch

    def _sheet(self, batch: ExportBatchRecord, sources: Sequence[ExportSource]) -> ExportSheet:
        label = self._label
        rows = build_rows(sources, batch.columns, label)
        summary: list[tuple[str, Cell]] = [
            (label("export.summary.sequence"), batch.sequence),
            (label("export.summary.created_at"), format_utc(batch.created_at)),
            (label("export.summary.target"), label(f"export.target.{batch.target}")),
            (label("export.summary.mapping"), batch.mapping_version),
            (
                label("export.summary.reexport"),
                label("export.yes" if batch.is_reexport else "export.no"),
            ),
            (label("export.summary.invoices"), len(sources)),
            (label("export.summary.rows"), len(rows)),
        ]
        for currency, sums in sorted(totals(sources).items()):
            for key, value in (
                ("count", sums.invoice_count),
                ("net", sums.net),
                ("vat", sums.vat),
                ("gross", sums.gross),
                ("posted", sums.posted),
            ):
                summary.append((label(f"export.summary.{key}", currency=currency or "-"), value))
        summary.append((label("export.summary.anchor"), batch.audit_anchor))
        return ExportSheet(
            headers=headers(batch.columns, label),
            kinds=tuple(kind_of(column.field) for column in batch.columns),
            rows=rows,
            summary=tuple(summary),
            sheet_name=label("export.sheet.invoices"),
            summary_name=label("export.sheet.summary"),
        )

    def _write(
        self,
        scope: EntityScope,
        batch: ExportBatchRecord,
        sources: Sequence[ExportSource],
        actor: str,
    ) -> ExportBatchRecord:
        try:
            data = self._writers[batch.target].render(self._sheet(batch, sources))
            digest = self._files.write(scope.entity_id, batch.file_name, data)
        except Exception as exc:  # Any writer or disk failure fails the batch.
            self._fail(scope, batch, ExportErrorCode.WRITE_FAILED, actor)
            raise ExportError("write_failed") from exc
        return self._complete(scope, batch, digest, actor, recovered=False)

    def _complete(
        self,
        scope: EntityScope,
        batch: ExportBatchRecord,
        digest: str,
        actor: str,
        *,
        recovered: bool,
    ) -> ExportBatchRecord:
        now = self._clock()
        with self._uow_factory() as uow:
            exports = uow.exports(scope)
            items = exports.items(batch.batch_id)
            finished = exports.finish(
                batch.batch_id,
                BatchStatus.WRITTEN,
                ItemStatus.EXPORTED,
                file_sha256=digest,
                completed_at=now,
            )
            invoices = uow.invoices(scope)
            for item in items:
                if not batch.is_reexport:
                    invoices.set_status(
                        item.invoice_id, WorkflowStatus.EXPORTED, expected_revision=item.revision
                    )
                uow.audit.append(
                    AuditDraft(
                        event_type=AuditEventType.INVOICE_EXPORTED,
                        actor=actor,
                        entity_id=scope.entity_id,
                        subject_id=str(item.invoice_id),
                        details={
                            "batch_id": str(batch.batch_id),
                            "approval_id": str(item.approval_id),
                            "revision": item.revision,
                            "content_sha256": item.content_sha256,
                            "target": str(batch.target),
                            "is_reexport": batch.is_reexport,
                        },
                    ),
                    occurred_at=now,
                )
            self._audit(
                uow,
                scope,
                actor,
                now,
                AuditEventType.EXPORT_COMPLETED,
                {
                    "batch_id": str(batch.batch_id),
                    "target": str(batch.target),
                    "item_count": len(items),
                    "file_sha256": digest,
                    "audit_anchor": batch.audit_anchor,
                    "mapping_version": batch.mapping_version,
                    "is_reexport": batch.is_reexport,
                    "recovered": recovered,
                },
            )
            uow.commit()
        return finished

    def _fail(
        self, scope: EntityScope, batch: ExportBatchRecord, code: ExportErrorCode, actor: str
    ) -> None:
        now = self._clock()
        with self._uow_factory() as uow:
            uow.exports(scope).finish(
                batch.batch_id,
                BatchStatus.FAILED,
                ItemStatus.FAILED,
                file_sha256=None,
                completed_at=now,
            )
            self._audit(
                uow,
                scope,
                actor,
                now,
                AuditEventType.EXPORT_FAILED,
                {
                    "batch_id": str(batch.batch_id),
                    "target": str(batch.target),
                    "item_count": batch.item_count,
                    "export_error": str(code),
                },
            )
            uow.commit()

    def _recover(self, scope: EntityScope, actor: str) -> ExportRecovery:
        removed = self._files.discard_temporary(scope.entity_id)
        with self._uow_factory() as uow:
            open_batches = uow.exports(scope).open_batches()
        completed = failed = 0
        for batch in open_batches:
            data = self._files.read(scope.entity_id, batch.file_name)
            if data is None:
                self._fail(scope, batch, ExportErrorCode.INTERRUPTED, actor)
                failed += 1
            else:
                self._complete(scope, batch, sha256_hex(data), actor, recovered=True)
                completed += 1
        return ExportRecovery(completed, failed, removed)

    @staticmethod
    def _audit(
        uow: UnitOfWork,
        scope: EntityScope,
        actor: str,
        now: dt.datetime,
        event: AuditEventType,
        details: dict[str, object],
    ) -> None:
        uow.audit.append(
            AuditDraft(
                event_type=event,
                actor=actor,
                entity_id=scope.entity_id,
                subject_id=str(scope.entity_id),
                details=details,
            ),
            occurred_at=now,
        )


def _text(field: Any) -> Any:
    return None if field is None else field.value
