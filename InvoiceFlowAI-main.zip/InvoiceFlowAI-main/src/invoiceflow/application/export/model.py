"""Export of approved invoices to Excel and CSV files (Phase 10, ADR-0036). No I/O.

The export is a table: one row per accounting line (konteringslinje) with the
invoice's header values repeated, or one row for an invoice without one. The
columns and their headers are chosen per entity (versioned mapping); the
values always come from the approved revision.

Every text value is untrusted invoice content. :func:`neutralize` makes sure
spreadsheet programs treat it as text, never as a formula. Amounts stay
``Decimal`` until a writer formats them.
"""

import datetime as dt
import json
import unicodedata
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from decimal import Decimal
from enum import StrEnum
from typing import Any
from uuid import UUID

from invoiceflow.application.errors import InvoiceFlowError
from invoiceflow.domain.invoice import CanonicalInvoice, InvoiceType

MAX_HEADER = 40
MIN_REASON = 10
MAX_REASON = 500
STANDARD_MAPPING_VERSION = 0
# Leading characters that make Excel, LibreOffice or Google Sheets read a cell
# as a formula or DDE command (OWASP "CSV injection"), including full-width forms.
FORMULA_PREFIXES = (
    "=",
    "+",
    "-",
    "@",
    "\t",
    "\r",
    "\n",
    "\N{FULLWIDTH EQUALS SIGN}",
    "\N{FULLWIDTH PLUS SIGN}",
    "\N{FULLWIDTH HYPHEN-MINUS}",
    "\N{FULLWIDTH COMMERCIAL AT}",
)


class ExportTarget(StrEnum):
    EXCEL = "excel"
    CSV = "csv"

    @property
    def suffix(self) -> str:
        return "xlsx" if self is ExportTarget.EXCEL else "csv"


class BatchStatus(StrEnum):
    CREATED = "created"  # Batch and pending items stored; the file is being written
    WRITTEN = "written"
    FAILED = "failed"


class ItemStatus(StrEnum):
    PENDING = "pending"
    EXPORTED = "exported"
    FAILED = "failed"
    SUPERSEDED = "superseded"  # Replaced by a later re-export


class ExportErrorCode(StrEnum):
    WRITE_FAILED = "write_failed"
    INTERRUPTED = "interrupted"  # Found unfinished at startup, without its file


class FieldKind(StrEnum):
    TEXT = "text"
    MONEY = "money"
    DATE = "date"
    NUMBER = "number"


class ExportField(StrEnum):
    INVOICE_ID = "invoice_id"
    SUPPLIER_NAME = "supplier_name"
    SUPPLIER_ORG_NUMBER = "supplier_org_number"
    INVOICE_TYPE = "invoice_type"
    INVOICE_NUMBER = "invoice_number"
    INVOICE_DATE = "invoice_date"
    DUE_DATE = "due_date"
    CURRENCY = "currency"
    NET_TOTAL = "net_total"
    VAT_TOTAL = "vat_total"
    GROSS_TOTAL = "gross_total"
    KID = "kid"
    BANK_ACCOUNT = "bank_account"
    IBAN = "iban"
    BUYER_REFERENCE = "buyer_reference"
    LINE_NUMBER = "line_number"
    ACCOUNT = "account"
    VAT_CODE = "vat_code"
    LINE_NET_AMOUNT = "line_net_amount"
    COST_CENTER = "cost_center"
    DEPARTMENT = "department"
    PROJECT = "project"
    APPROVED_ON = "approved_on"


FIELD_KINDS = {
    ExportField.INVOICE_DATE: FieldKind.DATE,
    ExportField.DUE_DATE: FieldKind.DATE,
    ExportField.APPROVED_ON: FieldKind.DATE,
    ExportField.NET_TOTAL: FieldKind.MONEY,
    ExportField.VAT_TOTAL: FieldKind.MONEY,
    ExportField.GROSS_TOTAL: FieldKind.MONEY,
    ExportField.LINE_NET_AMOUNT: FieldKind.MONEY,
    ExportField.LINE_NUMBER: FieldKind.NUMBER,
}

STANDARD_FIELDS = (
    ExportField.SUPPLIER_NAME,
    ExportField.SUPPLIER_ORG_NUMBER,
    ExportField.INVOICE_TYPE,
    ExportField.INVOICE_NUMBER,
    ExportField.INVOICE_DATE,
    ExportField.DUE_DATE,
    ExportField.CURRENCY,
    ExportField.GROSS_TOTAL,
    ExportField.KID,
    ExportField.BANK_ACCOUNT,
    ExportField.LINE_NUMBER,
    ExportField.ACCOUNT,
    ExportField.VAT_CODE,
    ExportField.LINE_NET_AMOUNT,
    ExportField.COST_CENTER,
    ExportField.DEPARTMENT,
    ExportField.PROJECT,
    ExportField.INVOICE_ID,
)


def kind_of(field: ExportField) -> FieldKind:
    return FIELD_KINDS.get(field, FieldKind.TEXT)


class ExportError(InvoiceFlowError):
    """An export action was refused; ``reason`` is a stable code."""

    def __init__(self, reason: str, **params: object) -> None:
        super().__init__("EXPORT_REFUSED", f"export.error.{reason}", **params)
        self.reason = reason


def neutralize(text: str) -> str:
    """Text that a spreadsheet program shows as text, never runs as a formula."""
    return "'" + text if text.startswith(FORMULA_PREFIXES) else text


def check_header(text: str) -> str:
    """A person's column header: trimmed, short, plain and never a formula."""
    value = text.strip()
    if not 1 <= len(value) <= MAX_HEADER or value.startswith(FORMULA_PREFIXES):
        raise ExportError("header")
    if any(unicodedata.category(c) in ("Cc", "Cf") for c in value):
        raise ExportError("header")
    return value


@dataclass(frozen=True, slots=True)
class ExportColumn:
    field: ExportField
    header: str | None = None  # None: the standard Norwegian header


@dataclass(frozen=True, slots=True)
class ExportMapping:
    """Columns of one entity's export; version 0 is the built-in standard."""

    version: int
    columns: tuple[ExportColumn, ...]
    created_at: dt.datetime | None = None


STANDARD_MAPPING = ExportMapping(
    STANDARD_MAPPING_VERSION, tuple(ExportColumn(field) for field in STANDARD_FIELDS)
)


def check_columns(columns: Sequence[ExportColumn]) -> tuple[ExportColumn, ...]:
    """At least one column, each field at most once, headers checked."""
    if not columns or len({c.field for c in columns}) != len(columns):
        raise ExportError("columns")
    return tuple(
        ExportColumn(c.field, None if c.header is None else check_header(c.header)) for c in columns
    )


def columns_json(columns: Sequence[ExportColumn]) -> str:
    return json.dumps(
        [{"field": c.field.value, "header": c.header} for c in columns],
        ensure_ascii=False,
        separators=(",", ":"),
    )


def parse_columns(text: str) -> tuple[ExportColumn, ...]:
    return tuple(
        ExportColumn(ExportField(item["field"]), item["header"]) for item in json.loads(text)
    )


def headers(columns: Sequence[ExportColumn], label: Callable[[str], str]) -> tuple[str, ...]:
    """The header row; two columns with the same header are refused."""
    texts = tuple(
        c.header if c.header is not None else label(f"export.column.{c.field}") for c in columns
    )
    if len({text.casefold() for text in texts}) != len(texts):
        raise ExportError("duplicate_header")
    return texts


@dataclass(frozen=True, slots=True)
class ExportSource:
    """One approved invoice as it is exported."""

    invoice_id: UUID
    invoice: CanonicalInvoice
    approved_on: dt.date


Cell = str | Decimal | dt.date | int | None


@dataclass(frozen=True, slots=True)
class ExportSheet:
    """Everything a writer needs; values are not yet formatted or neutralized."""

    headers: tuple[str, ...]
    kinds: tuple[FieldKind, ...]
    rows: tuple[tuple[Cell, ...], ...]
    # (label, value) lines of the control sheet (Excel only).
    summary: tuple[tuple[str, Cell], ...]
    sheet_name: str
    summary_name: str


def _value(field: Any) -> Any:
    return None if field is None else field.value


def _sign(invoice: CanonicalInvoice) -> int:
    """Credit notes are stored with positive totals and exported as negative (ADR-0020)."""
    return -1 if _value(invoice.invoice_type) == InvoiceType.CREDIT_NOTE else 1


def _signed(amount: Decimal | None, sign: int) -> Decimal | None:
    if amount is None:
        return None
    # Adding zero turns a negated zero into plain zero.
    return (amount if sign > 0 else -amount) + 0


def _header_values(source: ExportSource, label: Callable[[str], str]) -> dict[ExportField, Cell]:
    invoice = source.invoice
    payment = invoice.payment
    kind = _value(invoice.invoice_type)
    sign = _sign(invoice)
    return {
        ExportField.INVOICE_ID: str(source.invoice_id),
        ExportField.SUPPLIER_NAME: _value(invoice.supplier.name),
        ExportField.SUPPLIER_ORG_NUMBER: _value(invoice.supplier.org_number),
        ExportField.INVOICE_TYPE: None if kind is None else label(f"export.type.{kind}"),
        ExportField.INVOICE_NUMBER: _value(invoice.invoice_number),
        ExportField.INVOICE_DATE: _value(invoice.invoice_date),
        ExportField.DUE_DATE: _value(invoice.due_date),
        ExportField.CURRENCY: _value(invoice.currency),
        ExportField.NET_TOTAL: _signed(_value(invoice.totals.net_amount), sign),
        ExportField.VAT_TOTAL: _signed(_value(invoice.totals.vat_amount), sign),
        ExportField.GROSS_TOTAL: _signed(_value(invoice.totals.gross_amount), sign),
        ExportField.KID: None if payment is None else _value(payment.kid),
        ExportField.BANK_ACCOUNT: None if payment is None else _value(payment.bank_account),
        ExportField.IBAN: None if payment is None else _value(payment.iban),
        ExportField.BUYER_REFERENCE: _value(invoice.buyer_reference),
        ExportField.APPROVED_ON: source.approved_on,
    }


def build_rows(
    sources: Iterable[ExportSource],
    columns: Sequence[ExportColumn],
    label: Callable[[str], str],
) -> tuple[tuple[Cell, ...], ...]:
    rows: list[tuple[Cell, ...]] = []
    for source in sources:
        base = _header_values(source, label)
        sign = _sign(source.invoice)
        for line in source.invoice.accounting_lines or (None,):
            values = dict(base)
            values[ExportField.LINE_NUMBER] = None if line is None else line.line_number
            values[ExportField.ACCOUNT] = None if line is None else _value(line.account)
            values[ExportField.VAT_CODE] = None if line is None else _value(line.vat_code)
            values[ExportField.LINE_NET_AMOUNT] = (
                None if line is None else _signed(_value(line.net_amount), sign)
            )
            values[ExportField.COST_CENTER] = None if line is None else _value(line.cost_center)
            values[ExportField.DEPARTMENT] = None if line is None else _value(line.department)
            values[ExportField.PROJECT] = None if line is None else _value(line.project)
            rows.append(tuple(values[column.field] for column in columns))
    return tuple(rows)


@dataclass(frozen=True, slots=True)
class CurrencyTotals:
    invoice_count: int
    net: Decimal
    vat: Decimal
    gross: Decimal
    posted: Decimal  # Sum of the accounting lines


def totals(sources: Iterable[ExportSource]) -> dict[str, CurrencyTotals]:
    """Signed control totals per currency (an invoice without currency counts as '')."""
    result: dict[str, CurrencyTotals] = {}
    for source in sources:
        invoice = source.invoice
        sign = _sign(invoice)
        currency = _value(invoice.currency) or ""
        before = result.get(currency, CurrencyTotals(0, *(Decimal("0.00"),) * 4))

        def amount(field: Any, sign: int = sign) -> Decimal:
            return _signed(_value(field), sign) or Decimal(0)

        result[currency] = CurrencyTotals(
            before.invoice_count + 1,
            before.net + amount(invoice.totals.net_amount),
            before.vat + amount(invoice.totals.vat_amount),
            before.gross + amount(invoice.totals.gross_amount),
            before.posted + sum((amount(line.net_amount) for line in invoice.accounting_lines), 0),
        )
    return result


@dataclass(frozen=True, slots=True)
class ExportBatchRecord:
    batch_id: UUID
    sequence: int
    target: ExportTarget
    mapping_version: int
    columns: tuple[ExportColumn, ...]
    status: BatchStatus
    file_name: str
    file_sha256: str | None
    item_count: int
    is_reexport: bool
    reexport_reason: str | None
    audit_anchor: str
    created_at: dt.datetime
    created_by: str
    completed_at: dt.datetime | None = None


@dataclass(frozen=True, slots=True)
class ExportItemRecord:
    batch_id: UUID
    invoice_id: UUID
    approval_id: UUID
    revision: int
    content_sha256: str
    target: ExportTarget
    status: ItemStatus
    created_at: dt.datetime
    updated_at: dt.datetime
    item_id: int | None = None


@dataclass(frozen=True, slots=True)
class ExportCandidate:
    """An approved invoice that is ready for export (export page)."""

    invoice_id: UUID
    supplier_name: str | None
    invoice_number: str | None
    invoice_date: dt.date | None
    gross_amount: Decimal | None
    currency: str | None


@dataclass(frozen=True, slots=True)
class ExportRecovery:
    completed: int = 0
    failed: int = 0
    temporary_removed: int = 0


def file_name(sequence: int, created_at: dt.datetime, target: ExportTarget) -> str:
    """Fixed, clean name: never built from invoice or user text."""
    return f"fakturaeksport-{sequence:05d}-{created_at:%Y%m%d-%H%M%S}.{target.suffix}"
