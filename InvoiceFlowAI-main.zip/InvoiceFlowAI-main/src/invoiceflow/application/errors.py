"""Safe errors crossing application boundaries."""

from types import MappingProxyType


class InvoiceFlowError(Exception):
    """Carry a stable code and a translation key, never input contents."""

    def __init__(self, code: str, message_key: str, **params: object) -> None:
        super().__init__(code)
        self.code = code
        self.message_key = message_key
        self.params = params


class ConfigError(InvoiceFlowError):
    """Reject invalid bootstrap configuration without exposing its contents."""

    def __init__(self) -> None:
        super().__init__("CONFIG_INVALID", "error.config")


class DatabaseError(InvoiceFlowError):
    """Database lifecycle failure; the stored data is never repaired silently."""

    MESSAGE_KEYS = MappingProxyType(
        {
            "DATABASE_UNAVAILABLE": "error.database_unavailable",
            "DATABASE_INTEGRITY_FAILED": "error.database_integrity",
            "DATABASE_UNRECOGNIZED": "error.database_unrecognized",
            "DATABASE_NEWER_SCHEMA": "error.database_newer",
            "DATABASE_BACKUP_FAILED": "error.database_backup",
            "DATABASE_MIGRATION_FAILED": "error.database_migration",
            "AUDIT_CHAIN_INVALID": "error.audit_chain",
        }
    )

    def __init__(self, code: str) -> None:
        super().__init__(code, self.MESSAGE_KEYS[code])


class NotFoundError(InvoiceFlowError):
    """Unknown identifier, or an identifier owned by another accounting entity.

    Both cases deliberately look identical, so a caller cannot probe which
    identifiers exist in other entities.
    """

    def __init__(self) -> None:
        super().__init__("NOT_FOUND", "error.not_found")


class ConflictError(InvoiceFlowError):
    """The stored state changed since the caller read it (optimistic locking)."""

    def __init__(self) -> None:
        super().__init__("REVISION_CONFLICT", "error.revision_conflict")


class DataIntegrityError(InvoiceFlowError):
    """Stored data does not match its own hash; it is reported, never repaired."""

    def __init__(self) -> None:
        super().__init__("DATA_INTEGRITY_FAILED", "error.data_integrity")


class StorageError(InvoiceFlowError):
    """The document archive failed or is inconsistent; the import was not recorded.

    The detail is for developers only and never shown or logged with file names.
    """

    def __init__(self, detail: str = "") -> None:
        super().__init__("STORAGE_UNAVAILABLE", "error.storage")
        self.detail = detail
