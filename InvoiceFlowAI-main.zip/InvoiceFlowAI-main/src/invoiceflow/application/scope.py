"""Explicit accounting-entity scope (ADR-0022)."""

from dataclasses import dataclass
from uuid import UUID


@dataclass(frozen=True, slots=True)
class EntityScope:
    """The accounting entity every repository operation is restricted to.

    There is no default scope: callers must always name the entity, so data
    from different entities cannot be mixed by omission.
    """

    entity_id: UUID

    def __post_init__(self) -> None:
        if not isinstance(self.entity_id, UUID):
            msg = "entity_id must be a UUID"
            raise TypeError(msg)
