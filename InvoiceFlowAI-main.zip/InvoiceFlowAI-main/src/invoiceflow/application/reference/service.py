"""Reference data import, supplier standard posting and posting suggestions (Phase 08b).

Imports are validated completely before anything is stored and become a new
snapshot (ADR-0034). A posting suggestion is a new invoice revision with
calculated accounting lines; values a person entered are never replaced.
"""

import datetime as dt
import hashlib
import stat
from collections.abc import Callable, Mapping
from pathlib import Path
from types import MappingProxyType
from typing import Protocol
from uuid import UUID, uuid4

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.errors import InvoiceFlowError
from invoiceflow.application.ports import InvoiceRecord, UnitOfWork, UnitOfWorkFactory
from invoiceflow.application.reference.csv_import import PARSERS, ReferenceImportError
from invoiceflow.application.reference.model import (
    MAX_REFERENCE_FILE_BYTES,
    Dimension,
    ImportRecord,
    ReferenceData,
    ReferenceKind,
    SupplierDefaults,
)
from invoiceflow.application.reference.posting import has_manual_posting, with_suggestion
from invoiceflow.application.review.model import WorkflowStatus
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import SYSTEM_ACTOR, revise_in, utc_now
from invoiceflow.application.validation.service import USER_ACTOR, supplier_identity
from invoiceflow.domain.invoice import CanonicalInvoice


class InvoiceValidator(Protocol):
    def validate_in(
        self, uow: UnitOfWork, scope: EntityScope, invoice_id: UUID, *, actor: str
    ) -> object: ...


def _read(source: Path) -> bytes:
    """A regular file up to the limit; links, folders and devices are refused."""
    try:
        info = source.lstat()
        if not stat.S_ISREG(info.st_mode):
            raise ReferenceImportError("not_a_file")
        if info.st_size > MAX_REFERENCE_FILE_BYTES:
            raise ReferenceImportError("too_large")
        with source.open("rb") as handle:
            data = handle.read(MAX_REFERENCE_FILE_BYTES + 1)
    except OSError:
        raise ReferenceImportError("unreadable") from None
    if len(data) > MAX_REFERENCE_FILE_BYTES:
        raise ReferenceImportError("too_large")
    return data


class ReferenceService:
    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        *,
        validator: InvoiceValidator | None = None,
        clock: Callable[[], dt.datetime] = utc_now,
        new_id: Callable[[], UUID] = uuid4,
    ) -> None:
        self._uow_factory = uow_factory
        self._validator = validator
        self._clock = clock
        self._new_id = new_id

    # --- reference data ------------------------------------------------------------

    def import_file(
        self, scope: EntityScope, kind: ReferenceKind, source: Path, *, actor: str = USER_ACTOR
    ) -> ImportRecord:
        data = _read(source)
        entries = PARSERS[kind](data)
        now = self._clock()
        record = ImportRecord(
            import_id=self._new_id(),
            kind=kind,
            sha256=hashlib.sha256(data).hexdigest(),
            row_count=len(entries),
            created_at=now,
            created_by=actor,
        )
        with self._uow_factory() as uow:
            uow.entities.get(scope.entity_id)
            uow.references(scope).add_import(record, entries)
            uow.audit.append(
                AuditDraft(
                    event_type=AuditEventType.REFERENCE_IMPORTED,
                    actor=actor,
                    entity_id=scope.entity_id,
                    subject_id=str(scope.entity_id),
                    details={
                        "reference_kind": str(kind),
                        "row_count": record.row_count,
                        "sha256": record.sha256,
                    },
                ),
                occurred_at=now,
            )
            uow.commit()
        return record

    def status(self, scope: EntityScope) -> dict[ReferenceKind, ImportRecord]:
        with self._uow_factory() as uow:
            return uow.references(scope).latest_imports()

    def reference(self, scope: EntityScope) -> ReferenceData:
        with self._uow_factory() as uow:
            return uow.references(scope).current()

    # --- supplier standard posting ---------------------------------------------------

    def defaults(self, scope: EntityScope, supplier_id: UUID) -> SupplierDefaults | None:
        with self._uow_factory() as uow:
            uow.suppliers(scope).get(supplier_id)
            return uow.references(scope).defaults(supplier_id)

    def set_defaults(
        self,
        scope: EntityScope,
        supplier_id: UUID,
        *,
        account: str | None,
        vat_code: str | None,
        dimensions: Mapping[Dimension, str] | None = None,
        actor: str = USER_ACTOR,
    ) -> SupplierDefaults:
        """Set the supplier's standard posting and suggest again for its invoices."""
        now = self._clock()
        chosen = {key: value for key, value in (dimensions or {}).items() if value}
        with self._uow_factory() as uow:
            supplier = uow.suppliers(scope).get(supplier_id)
            references = uow.references(scope)
            _check_values(references.current(), account, vat_code, chosen, now.date())
            stored = references.add_defaults(
                self._new_id(),
                SupplierDefaults(
                    supplier_id=supplier_id,
                    account=account,
                    vat_code=vat_code,
                    dimensions=MappingProxyType(chosen),
                    set_at=now,
                    set_by=actor,
                ),
            )
            uow.audit.append(
                AuditDraft(
                    event_type=AuditEventType.SUPPLIER_DEFAULTS_SET,
                    actor=actor,
                    entity_id=scope.entity_id,
                    subject_id=str(supplier_id),
                ),
                occurred_at=now,
            )
            invoices = uow.invoices(scope)
            for header in invoices.headers():
                if (
                    supplier.org_number is not None
                    and header.supplier_org_number != supplier.org_number
                ):
                    continue
                invoice = invoices.get(header.invoice_id).invoice
                if supplier_identity(invoice) != (supplier.org_number, supplier.foreign_vat_id):
                    continue
                self.suggest_in(uow, scope, header.invoice_id, actor=actor, replace=True)
            uow.commit()
        return stored

    # --- posting suggestions -----------------------------------------------------------

    def _defaults_for(
        self, uow: UnitOfWork, scope: EntityScope, invoice: CanonicalInvoice
    ) -> SupplierDefaults | None:
        identity = supplier_identity(invoice)
        if identity is None:
            return None
        supplier = uow.suppliers(scope).find(org_number=identity[0], foreign_vat_id=identity[1])
        return None if supplier is None else uow.references(scope).defaults(supplier.supplier_id)

    def prepare(
        self, uow: UnitOfWork, scope: EntityScope, invoice: CanonicalInvoice
    ) -> CanonicalInvoice:
        """The invoice with a posting suggestion, before it is registered."""
        if invoice.accounting_lines:
            return invoice
        reference = uow.references(scope).current()
        return with_suggestion(invoice, self._defaults_for(uow, scope, invoice), reference)

    def suggest_in(
        self,
        uow: UnitOfWork,
        scope: EntityScope,
        invoice_id: UUID,
        *,
        actor: str,
        replace: bool,
    ) -> InvoiceRecord | None:
        """A new revision with a fresh suggestion, then a validation run.

        Nothing changes when the invoice was posted by hand, when it already
        has a posting and ``replace`` is false, or when the suggestion is the same.
        """
        record = uow.invoices(scope).get(invoice_id)
        invoice = record.invoice
        if record.workflow_status == WorkflowStatus.EXPORTED:
            return None  # Exported content is final (Phase 10).
        if has_manual_posting(invoice) or (invoice.accounting_lines and not replace):
            return None
        reference = uow.references(scope).current()
        suggested = with_suggestion(invoice, self._defaults_for(uow, scope, invoice), reference)
        if suggested == invoice:
            return None
        revised = revise_in(
            uow,
            scope,
            invoice_id,
            suggested,
            expected_revision=record.revision,
            actor=actor,
            now=self._clock(),
        )
        if self._validator is not None:
            self._validator.validate_in(uow, scope, invoice_id, actor=actor)
        return revised

    def suggest(
        self, scope: EntityScope, invoice_id: UUID, *, actor: str = SYSTEM_ACTOR
    ) -> InvoiceRecord | None:
        with self._uow_factory() as uow:
            revised = self.suggest_in(uow, scope, invoice_id, actor=actor, replace=True)
            uow.commit()
        return revised


def _check_values(
    reference: ReferenceData,
    account: str | None,
    vat_code: str | None,
    dimensions: Mapping[Dimension, str],
    today: dt.date,
) -> None:
    """Standard posting must use values that exist in the entity's current data."""
    if account is not None:
        entry = None if reference.accounts is None else reference.accounts.get(account)
        if entry is None or not entry.is_active:
            raise InvoiceFlowError("INVALID_INPUT", "reference.error.unknown_account")
    if vat_code is not None:
        code = reference.vat_code(vat_code, today)
        if code is None or code not in reference.input_codes_on(today):
            raise InvoiceFlowError("INVALID_INPUT", "reference.error.unknown_vat_code")
    for dimension, value in dimensions.items():
        found = (
            None if reference.dimensions is None else reference.dimensions.get((dimension, value))
        )
        if found is None or not found.is_active:
            raise InvoiceFlowError("INVALID_INPUT", "reference.error.unknown_dimension")
