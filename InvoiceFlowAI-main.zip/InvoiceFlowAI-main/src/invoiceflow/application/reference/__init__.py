"""Reference data: chart of accounts, VAT codes, dimensions and posting (Phase 08b)."""
