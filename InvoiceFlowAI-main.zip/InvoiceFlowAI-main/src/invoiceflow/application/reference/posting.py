"""Posting suggestion (konteringsforslag) for one invoice (Phase 08b). Pure, no I/O.

One accounting line per VAT rate on the invoice. The account and dimensions
come from the supplier's standard posting; the VAT code is the supplier's
standard code when its rate fits, otherwise the only valid input code with
that rate. Anything ambiguous is left empty for a person to decide: the
rules ACC-002 and ACC-003 then report it.
"""

import datetime as dt
from decimal import Decimal
from typing import Any

from invoiceflow.application.reference.model import (
    Dimension,
    ReferenceData,
    SupplierDefaults,
)
from invoiceflow.domain.invoice import AccountingLine, CanonicalInvoice
from invoiceflow.domain.provenance import FieldValue, ValueSource

PRODUCER = "regel/kontering/1"
_PROVENANCE = {"source": "calculated", "producer": PRODUCER}
_DIMENSION_FIELDS = {
    Dimension.COST_CENTER: "cost_center",
    Dimension.DEPARTMENT: "department",
    Dimension.PROJECT: "project",
}


def _value(field: FieldValue[Any] | None) -> Any:
    return None if field is None else field.value


def _calculated(value: object) -> dict[str, object]:
    return {"value": value, "provenance": dict(_PROVENANCE)}


def net_by_rate(invoice: CanonicalInvoice) -> list[tuple[Decimal | None, Decimal, tuple[int, ...]]]:
    """(rate, net amount, source line numbers) per VAT rate, ordered by rate.

    From the lines when every line has an amount and a rate; else from the VAT
    summary; else the total net amount with an unknown rate.
    """
    lines = invoice.lines
    if lines and all(
        _value(line.net_amount) is not None and _value(line.vat_rate) is not None for line in lines
    ):
        groups: dict[Decimal, tuple[Decimal, list[int]]] = {}
        for line in lines:
            rate, amount = _value(line.vat_rate), _value(line.net_amount)
            total, numbers = groups.get(rate, (Decimal("0.00"), []))
            groups[rate] = (total + amount, [*numbers, line.line_number])
        return [(rate, total, tuple(numbers)) for rate, (total, numbers) in sorted(groups.items())]
    entries = [
        (_value(entry.vat_rate), _value(entry.taxable_amount)) for entry in invoice.vat_breakdown
    ]
    if entries and all(rate is not None and base is not None for rate, base in entries):
        totals: dict[Decimal, Decimal] = {}
        for rate, base in entries:
            totals[rate] = totals.get(rate, Decimal("0.00")) + base
        return [(rate, total, ()) for rate, total in sorted(totals.items())]
    net = _value(invoice.totals.net_amount)
    return [] if net is None else [(None, net, ())]


def _vat_code(
    rate: Decimal | None,
    day: dt.date | None,
    defaults: SupplierDefaults | None,
    reference: ReferenceData,
) -> str | None:
    if rate is None or day is None or reference.vat_codes is None:
        return None
    if defaults is not None and defaults.vat_code is not None:
        entry = reference.vat_code(defaults.vat_code, day)
        if entry is not None and entry.rate == rate:
            return entry.code
    candidates = {entry.code for entry in reference.input_codes_on(day) if entry.rate == rate}
    return candidates.pop() if len(candidates) == 1 else None


def suggest_accounting(
    invoice: CanonicalInvoice,
    defaults: SupplierDefaults | None,
    reference: ReferenceData,
) -> tuple[AccountingLine, ...]:
    day = _value(invoice.invoice_date)
    suggested = []
    for number, (rate, amount, sources) in enumerate(net_by_rate(invoice), start=1):
        data: dict[str, object] = {
            "line_number": number,
            "net_amount": _calculated(amount),
            "source_line_numbers": sources,
        }
        if defaults is not None and defaults.account is not None:
            data["account"] = _calculated(defaults.account)
        code = _vat_code(rate, day, defaults, reference)
        if code is not None:
            data["vat_code"] = _calculated(code)
        if defaults is not None:
            for dimension, value in defaults.dimensions.items():
                data[_DIMENSION_FIELDS[dimension]] = _calculated(value)
        suggested.append(AccountingLine.model_validate(data))
    return tuple(suggested)


def has_manual_posting(invoice: CanonicalInvoice) -> bool:
    """True when a person has set any posting value; a suggestion never replaces it."""
    for line in invoice.accounting_lines:
        for name in ("account", "vat_code", "net_amount", "cost_center", "department", "project"):
            field = getattr(line, name)
            if field is not None and field.provenance.source is ValueSource.MANUAL:
                return True
    return False


def with_suggestion(
    invoice: CanonicalInvoice,
    defaults: SupplierDefaults | None,
    reference: ReferenceData,
) -> CanonicalInvoice:
    """The invoice with suggested accounting lines; unchanged if posted by hand."""
    if has_manual_posting(invoice):
        return invoice
    lines = suggest_accounting(invoice, defaults, reference)
    data = invoice.model_dump(mode="json")
    data["accounting_lines"] = [line.model_dump(mode="json") for line in lines]
    return CanonicalInvoice.model_validate(data)  # re-checks the line references
