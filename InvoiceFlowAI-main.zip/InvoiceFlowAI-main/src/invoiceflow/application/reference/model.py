"""Reference data of an accounting entity (Phase 08b, ADR-0034). No I/O.

Chart of accounts, VAT codes and dimensions are data with validity, imported
per entity from the entity's own ERP. Nothing here is a built-in Norwegian
default: rates and codes always come from an import.
"""

import datetime as dt
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from decimal import Decimal
from enum import StrEnum
from types import MappingProxyType
from uuid import UUID

MAX_REFERENCE_FILE_BYTES = 5 * 1024 * 1024
MAX_REFERENCE_ROWS = 20_000


class ReferenceKind(StrEnum):
    CHART = "chart"  # Kontoplan
    VAT_CODES = "vat_codes"  # MVA-koder
    DIMENSIONS = "dimensions"  # Kostnadssted, avdeling, prosjekt


class Dimension(StrEnum):
    COST_CENTER = "cost_center"
    DEPARTMENT = "department"
    PROJECT = "project"


class VatDirection(StrEnum):
    INPUT = "input"  # Inngående MVA (kjøp)
    OUTPUT = "output"  # Utgående MVA (salg)


@dataclass(frozen=True, slots=True)
class AccountEntry:
    account: str
    name: str
    default_vat_code: str | None = None
    is_active: bool = True


@dataclass(frozen=True, slots=True)
class VatCodeEntry:
    code: str
    rate: Decimal
    direction: VatDirection
    valid_from: dt.date
    valid_to: dt.date | None = None
    saft_code: str | None = None
    name: str | None = None

    def valid_on(self, day: dt.date) -> bool:
        return self.valid_from <= day and (self.valid_to is None or day <= self.valid_to)


@dataclass(frozen=True, slots=True)
class DimensionEntry:
    dimension: Dimension
    code: str
    name: str
    is_active: bool = True


@dataclass(frozen=True, slots=True)
class ImportRecord:
    """One successful import: a snapshot that replaces the previous one of its kind."""

    import_id: UUID
    kind: ReferenceKind
    sha256: str
    row_count: int
    created_at: dt.datetime
    created_by: str


@dataclass(frozen=True, slots=True)
class ReferenceData:
    """The current snapshot of each kind; ``None`` when that kind was never imported."""

    accounts: Mapping[str, AccountEntry] | None = None
    vat_codes: Sequence[VatCodeEntry] | None = None
    dimensions: Mapping[tuple[Dimension, str], DimensionEntry] | None = None

    def input_codes_on(self, day: dt.date) -> list[VatCodeEntry]:
        return [
            entry
            for entry in self.vat_codes or ()
            if entry.direction is VatDirection.INPUT and entry.valid_on(day)
        ]

    def vat_code(self, code: str, day: dt.date) -> VatCodeEntry | None:
        for entry in self.vat_codes or ():
            if entry.code == code and entry.valid_on(day):
                return entry
        return None


EMPTY_REFERENCE = ReferenceData()


@dataclass(frozen=True, slots=True)
class SupplierDefaults:
    """Standard posting for a supplier; the latest row for the supplier applies."""

    supplier_id: UUID
    account: str | None = None
    vat_code: str | None = None
    dimensions: Mapping[Dimension, str] = field(default_factory=lambda: MappingProxyType({}))
    set_at: dt.datetime | None = None
    set_by: str | None = None
