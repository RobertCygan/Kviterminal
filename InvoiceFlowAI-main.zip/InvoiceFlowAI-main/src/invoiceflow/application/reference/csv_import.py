"""Read reference data from CSV (Phase 08b). Pure: bytes in, entries out.

A CSV file is untrusted input. The whole file is validated before anything is
stored; the first error rejects the file with its line and column, never with
the cell's content. Cells are text: nothing is evaluated, and name cells that
would start a spreadsheet formula are refused, so they cannot become formulas
in a later export (F10).

Format: UTF-8 (optional BOM), semicolon separated, a header line with the
Norwegian column names below, in any order.
"""

import csv
import datetime as dt
import io
import re
import unicodedata
from collections.abc import Callable, Mapping, Sequence
from decimal import Decimal, InvalidOperation

from invoiceflow.application.errors import InvoiceFlowError
from invoiceflow.application.reference.model import (
    MAX_REFERENCE_FILE_BYTES,
    MAX_REFERENCE_ROWS,
    AccountEntry,
    Dimension,
    DimensionEntry,
    ReferenceKind,
    VatCodeEntry,
    VatDirection,
)

_CODE = re.compile(r"[0-9A-Za-z._-]{1,20}")
_RATE = re.compile(r"[0-9]{1,3}([.,][0-9]{1,2})?")
_ISO_DATE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
_NORWEGIAN_DATE = re.compile(r"([0-9]{2})\.([0-9]{2})\.([0-9]{4})")
_FORMULA_START = ("=", "+", "-", "@")
_MAX_NAME = 300

_COLUMNS: Mapping[ReferenceKind, tuple[frozenset[str], frozenset[str]]] = {
    # (required, optional)
    ReferenceKind.CHART: (frozenset({"konto", "navn"}), frozenset({"mva_kode", "aktiv"})),
    ReferenceKind.VAT_CODES: (
        frozenset({"kode", "sats", "retning", "gyldig_fra"}),
        frozenset({"gyldig_til", "saft_kode", "navn"}),
    ),
    ReferenceKind.DIMENSIONS: (
        frozenset({"dimensjon", "kode", "navn"}),
        frozenset({"aktiv"}),
    ),
}
_DIRECTIONS = {"inngående": VatDirection.INPUT, "utgående": VatDirection.OUTPUT}
_DIMENSIONS = {
    "kostnadssted": Dimension.COST_CENTER,
    "avdeling": Dimension.DEPARTMENT,
    "prosjekt": Dimension.PROJECT,
}
_FLAGS = {"ja": True, "nei": False}


class ReferenceImportError(InvoiceFlowError):
    """The file was refused; ``reason`` is a stable code, line and column locate it."""

    def __init__(self, reason: str, line: int = 0, column: str = "") -> None:
        super().__init__(
            "REFERENCE_IMPORT_REFUSED",
            f"reference.error.{reason}",
            line=line,
            column=column,
        )
        self.reason = reason
        self.line = line
        self.column = column


def _text(value: str, line: int, column: str, *, name: bool = False) -> str:
    value = value.strip()
    for char in value:
        if unicodedata.category(char) in ("Cc", "Cf"):
            raise ReferenceImportError("control_character", line, column)
    if name and value.startswith(_FORMULA_START):
        raise ReferenceImportError("formula", line, column)
    return value


def _required(row: Mapping[str, str], column: str, line: int, *, name: bool = False) -> str:
    value = _text(row.get(column) or "", line, column, name=name)
    if not value:
        raise ReferenceImportError("missing_value", line, column)
    if name and len(value) > _MAX_NAME:
        raise ReferenceImportError("too_long", line, column)
    return value


def _optional(row: Mapping[str, str], column: str, line: int, *, name: bool = False) -> str | None:
    value = _text(row.get(column) or "", line, column, name=name)
    if name and len(value) > _MAX_NAME:
        raise ReferenceImportError("too_long", line, column)
    return value or None


def _code(value: str, line: int, column: str) -> str:
    if not _CODE.fullmatch(value):
        raise ReferenceImportError("invalid_code", line, column)
    return value


def _optional_code(value: str | None, line: int, column: str) -> str | None:
    return None if value is None else _code(value, line, column)


def _choice[T](value: str, choices: Mapping[str, T], line: int, column: str) -> T:
    try:
        return choices[value.casefold()]
    except KeyError:
        raise ReferenceImportError("invalid_choice", line, column) from None


def _flag(value: str | None, line: int) -> bool:
    return True if value is None else _choice(value, _FLAGS, line, "aktiv")


def _date(value: str, line: int, column: str) -> dt.date:
    try:
        if _ISO_DATE.fullmatch(value):
            return dt.date.fromisoformat(value)
        match = _NORWEGIAN_DATE.fullmatch(value)
        if match:
            day, month, year = (int(part) for part in match.groups())
            return dt.date(year, month, day)
    except ValueError:
        pass
    raise ReferenceImportError("invalid_date", line, column)


def _rate(value: str, line: int) -> Decimal:
    if not _RATE.fullmatch(value):
        raise ReferenceImportError("invalid_rate", line, "sats")
    try:
        rate = Decimal(value.replace(",", "."))
    except InvalidOperation:  # pragma: no cover - the pattern admits only numbers
        raise ReferenceImportError("invalid_rate", line, "sats") from None
    if rate > 100:
        raise ReferenceImportError("invalid_rate", line, "sats")
    return rate


def _rows(kind: ReferenceKind, data: bytes) -> list[tuple[int, dict[str, str]]]:
    if len(data) > MAX_REFERENCE_FILE_BYTES:
        raise ReferenceImportError("too_large")
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise ReferenceImportError("encoding") from None
    if "\x00" in text:
        raise ReferenceImportError("control_character")
    reader = csv.reader(io.StringIO(text, newline=""), delimiter=";", strict=True)
    try:
        header = next(reader, None)
        if header is None:
            raise ReferenceImportError("empty")
        columns = [_text(name, 1, "").casefold() for name in header]
        required, optional = _COLUMNS[kind]
        missing = sorted(required - set(columns))
        if missing:
            raise ReferenceImportError("missing_column", 1, missing[0])
        unknown = sorted(set(columns) - required - optional)
        if unknown or len(set(columns)) != len(columns):
            raise ReferenceImportError("unknown_column", 1)
        rows: list[tuple[int, dict[str, str]]] = []
        for cells in reader:
            line = reader.line_num
            if not any(cell.strip() for cell in cells):
                continue
            if len(cells) != len(columns):
                raise ReferenceImportError("column_count", line)
            if len(rows) >= MAX_REFERENCE_ROWS:
                raise ReferenceImportError("too_many_rows", line)
            rows.append((line, dict(zip(columns, cells, strict=True))))
    except csv.Error:
        raise ReferenceImportError("malformed", reader.line_num) from None
    if not rows:
        raise ReferenceImportError("empty")
    return rows


def _unique(keys: Sequence[tuple[int, object]], column: str) -> None:
    seen: set[object] = set()
    for line, key in keys:
        if key in seen:
            raise ReferenceImportError("duplicate", line, column)
        seen.add(key)


def parse_chart(data: bytes) -> tuple[AccountEntry, ...]:
    entries: list[AccountEntry] = []
    keys: list[tuple[int, object]] = []
    for line, row in _rows(ReferenceKind.CHART, data):
        account = _code(_required(row, "konto", line), line, "konto")
        entries.append(
            AccountEntry(
                account=account,
                name=_required(row, "navn", line, name=True),
                default_vat_code=_optional_code(_optional(row, "mva_kode", line), line, "mva_kode"),
                is_active=_flag(_optional(row, "aktiv", line), line),
            )
        )
        keys.append((line, account))
    _unique(keys, "konto")
    return tuple(entries)


def parse_vat_codes(data: bytes) -> tuple[VatCodeEntry, ...]:
    entries: list[tuple[int, VatCodeEntry]] = []
    for line, row in _rows(ReferenceKind.VAT_CODES, data):
        code = _code(_required(row, "kode", line), line, "kode")
        valid_from = _date(_required(row, "gyldig_fra", line), line, "gyldig_fra")
        until = _optional(row, "gyldig_til", line)
        valid_to = None if until is None else _date(until, line, "gyldig_til")
        direction = _choice(_required(row, "retning", line), _DIRECTIONS, line, "retning")
        if valid_to is not None and valid_to < valid_from:
            raise ReferenceImportError("invalid_period", line, "gyldig_til")
        entries.append(
            (
                line,
                VatCodeEntry(
                    code=code,
                    rate=_rate(_required(row, "sats", line), line),
                    direction=direction,
                    valid_from=valid_from,
                    valid_to=valid_to,
                    saft_code=_optional_code(_optional(row, "saft_kode", line), line, "saft_kode"),
                    name=_optional(row, "navn", line, name=True),
                ),
            )
        )
    # The same code may appear for several periods, but they must not overlap.
    by_code: dict[str, list[VatCodeEntry]] = {}
    for line, entry in entries:
        for other in by_code.get(entry.code, []):
            end = dt.date.max if entry.valid_to is None else entry.valid_to
            other_end = dt.date.max if other.valid_to is None else other.valid_to
            if entry.valid_from <= other_end and other.valid_from <= end:
                raise ReferenceImportError("overlapping_period", line, "gyldig_fra")
        by_code.setdefault(entry.code, []).append(entry)
    return tuple(entry for _, entry in entries)


def parse_dimensions(data: bytes) -> tuple[DimensionEntry, ...]:
    entries: list[DimensionEntry] = []
    keys: list[tuple[int, object]] = []
    for line, row in _rows(ReferenceKind.DIMENSIONS, data):
        dimension = _choice(_required(row, "dimensjon", line), _DIMENSIONS, line, "dimensjon")
        code = _code(_required(row, "kode", line), line, "kode")
        entries.append(
            DimensionEntry(
                dimension=dimension,
                code=code,
                name=_required(row, "navn", line, name=True),
                is_active=_flag(_optional(row, "aktiv", line), line),
            )
        )
        keys.append((line, (dimension, code)))
    _unique(keys, "kode")
    return tuple(entries)


PARSERS: Mapping[ReferenceKind, Callable[[bytes], tuple[object, ...]]] = {
    ReferenceKind.CHART: parse_chart,
    ReferenceKind.VAT_CODES: parse_vat_codes,
    ReferenceKind.DIMENSIONS: parse_dimensions,
}
