"""Isolated page analysis of stored documents (Phase 04, ADR-0010).

Crash model
-----------
1. One unit of work: a job row with status ``running`` and the audit event
   ``document.processing_started``, then commit.
2. Check the original against its hash; the worker runs in its own process
   and writes only into a fresh work folder.
3. Validate the report and every file it names; check the original again.
4. Move the files into the job's derived folder.
5. One unit of work: pages, derived files, the final job status and
   ``document.processing_finished``, then commit.

A crash before 5 leaves a ``running`` job and possibly derived files without
rows. Startup reconciliation (:meth:`ProcessingService.reconcile`) marks such
jobs as interrupted, removes work folders and moves unreferenced derived files
aside; no job is ever reported as succeeded without all of its pages and
files.

OCR (Phase 05, ADR-0040) is a second job per document with the same crash
model. It reads the page images of the document's successful page analysis,
copied into its work folder and checked against their hashes, and recognises
the pages without a text layer that have ink and are not separator sheets.
"""

import contextlib
import dataclasses
import datetime as dt
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from typing import Protocol
from uuid import UUID, uuid4

from pydantic import ValidationError

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentRecord,
    DocumentStatus,
    ImportOutcome,
    ImportResult,
    ImportSource,
    IntegrityStatus,
)
from invoiceflow.application.ehf import (
    attachment_display_name,
    duplicate_key,
    ordered,
    recipient_findings,
    report_findings,
)
from invoiceflow.application.errors import ConflictError, InvoiceFlowError, StorageError
from invoiceflow.application.ports import (
    DerivedStore,
    DocumentProcessor,
    DocumentStore,
    OcrInput,
    OcrTask,
    UnitOfWork,
    UnitOfWorkFactory,
    WorkerExit,
    WorkerOutcome,
    WorkerTask,
    WorkFile,
    WorkOutputError,
)
from invoiceflow.application.processing_model import (
    MAX_OCR_WORDS,
    DerivedFileRecord,
    DerivedKind,
    EhfReport,
    InvoiceFindingCode,
    JobRecord,
    JobStatus,
    OcrLayer,
    OcrPageRecord,
    OcrReport,
    OcrSettings,
    PageRecord,
    PageText,
    ProcessingErrorCode,
    ProcessingLimits,
    ProcessingRecovery,
    ProcessingStep,
    TextLayer,
    TextSource,
    WorkerResult,
    idempotency_key,
    ocr_input_name,
)
from invoiceflow.application.scan.model import PageKind, classify
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import SYSTEM_ACTOR, utc_now
from invoiceflow.domain.invoice import CanonicalInvoice

_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
# Codes only the worker itself may report; anything else in a report is invalid.
WORKER_CODES = frozenset(
    {
        ProcessingErrorCode.ENCRYPTED,
        ProcessingErrorCode.CORRUPT,
        ProcessingErrorCode.NO_PAGES,
        ProcessingErrorCode.TOO_MANY_PAGES,
        ProcessingErrorCode.PAGE_TOO_LARGE,
        ProcessingErrorCode.TOO_MUCH_TEXT,
        ProcessingErrorCode.OUTPUT_TOO_LARGE,
        ProcessingErrorCode.UNSUPPORTED_FORMAT,
        ProcessingErrorCode.MEMORY_LIMIT,
        ProcessingErrorCode.SOURCE_CHANGED,
    }
)
# Codes the EHF reader may report (Phase 15).
EHF_WORKER_CODES = frozenset(
    {
        ProcessingErrorCode.INVALID_XML,
        ProcessingErrorCode.UNSUPPORTED_VERSION,
        ProcessingErrorCode.UNSUPPORTED_FORMAT,
        ProcessingErrorCode.TOO_MANY_LINES,
        ProcessingErrorCode.TOO_MANY_ATTACHMENTS,
        ProcessingErrorCode.ATTACHMENT_TOO_LARGE,
        ProcessingErrorCode.MEMORY_LIMIT,
        ProcessingErrorCode.SOURCE_CHANGED,
        ProcessingErrorCode.SOURCE_MISSING,
    }
)
# Codes the OCR worker may report (Phase 05).
OCR_WORKER_CODES = frozenset(
    {
        ProcessingErrorCode.OCR_FAILED,
        ProcessingErrorCode.TOO_MUCH_TEXT,
        ProcessingErrorCode.OUTPUT_TOO_LARGE,
        ProcessingErrorCode.MEMORY_LIMIT,
        ProcessingErrorCode.SOURCE_CHANGED,
    }
)
_OCR_FORMATS = frozenset(
    {DocumentFormat.PDF, DocumentFormat.PNG, DocumentFormat.JPEG, DocumentFormat.TIFF}
)
MAX_RENDER_BYTES = 256 * 1024 * 1024
MAX_TIMEOUT_SECONDS = 3600.0
_ACCEPTED_ATTACHMENTS = frozenset({ImportOutcome.IMPORTED, ImportOutcome.DUPLICATE})
_EXITS: dict[WorkerExit, tuple[JobStatus, ProcessingErrorCode]] = {
    WorkerExit.TIMED_OUT: (JobStatus.TIMED_OUT, ProcessingErrorCode.TIMED_OUT),
    WorkerExit.CANCELLED: (JobStatus.CANCELLED, ProcessingErrorCode.CANCELLED),
    WorkerExit.MEMORY_LIMIT: (JobStatus.FAILED, ProcessingErrorCode.MEMORY_LIMIT),
    WorkerExit.CRASHED: (JobStatus.FAILED, ProcessingErrorCode.WORKER_CRASHED),
    WorkerExit.INVALID_RESULT: (JobStatus.FAILED, ProcessingErrorCode.INVALID_RESULT),
}


def png_size(header: bytes) -> tuple[int, int] | None:
    """Width and height from a PNG signature and IHDR chunk; no decoding."""
    if len(header) < 24 or not header.startswith(_PNG_SIGNATURE) or header[12:16] != b"IHDR":
        return None
    return int.from_bytes(header[16:20], "big"), int.from_bytes(header[20:24], "big")


def max_text_bytes(limits: ProcessingLimits) -> int:
    """Generous bound for one text layer file: text plus four numbers per character."""
    return 4096 + 96 * limits.max_chars_per_page


def max_ocr_bytes(limits: ProcessingLimits) -> int:
    """Bound for one OCR file: the text plus a box, confidence and line per word."""
    return 4096 + 4 * limits.max_chars_per_page + 192 * MAX_OCR_WORDS


def needs_ocr(page: PageRecord) -> bool:
    """A page without a text layer that has ink and is not a separator sheet.

    Only an entirely empty page is skipped. A page the scan view calls blank
    (at most a few per mille dark) may still hold one short line, so it is
    recognised; that costs little and loses nothing.
    """
    if page.has_text_layer or classify(page) is PageKind.SEPARATOR:
        return False
    return page.dark_permille != 0


class _RejectedError(Exception):
    def __init__(self, code: ProcessingErrorCode, status: JobStatus = JobStatus.FAILED) -> None:
        super().__init__(str(code))
        self.code = code
        self.status = status


class AttachmentImporter(Protocol):
    """Imports an EHF attachment like any other file (``DocumentService``)."""

    def import_file(
        self,
        scope: EntityScope,
        source: Path,
        *,
        origin: ImportSource,
        actor: str,
        name: str | None,
    ) -> ImportResult: ...


class InvoiceValidator(Protocol):
    """Validates a newly registered invoice in the same unit of work (Phase 08a)."""

    def validate_in(
        self, uow: UnitOfWork, scope: EntityScope, invoice_id: UUID, *, actor: str
    ) -> object: ...


class InvoicePoster(Protocol):
    """Adds a posting suggestion before an invoice is registered (Phase 08b)."""

    def prepare(
        self, uow: UnitOfWork, scope: EntityScope, invoice: CanonicalInvoice
    ) -> CanonicalInvoice: ...


class InvoiceExtractor(Protocol):
    """Registers draft invoices from the text of an analysed document (Phase 06)."""

    def readable(self, document: DocumentRecord) -> bool: ...

    def register(
        self,
        scope: EntityScope,
        document: DocumentRecord,
        pages: Sequence[PageRecord],
        layers: Mapping[int, TextLayer | OcrLayer],
        *,
        actor: str,
    ) -> list[UUID]: ...


class ProcessingService:
    def __init__(
        self,
        uow_factory: UnitOfWorkFactory,
        store: DocumentStore,
        derived: DerivedStore,
        processor: DocumentProcessor,
        *,
        attachments: AttachmentImporter | None = None,
        validator: InvoiceValidator | None = None,
        poster: InvoicePoster | None = None,
        extractor: InvoiceExtractor | None = None,
        limits: ProcessingLimits | None = None,
        ocr_settings: OcrSettings | None = None,
        clock: Callable[[], dt.datetime] = utc_now,
        new_id: Callable[[], UUID] = uuid4,
    ) -> None:
        self._uow_factory = uow_factory
        self._store = store
        self._derived = derived
        self._processor = processor
        self._attachments = attachments
        self._validator = validator
        self._poster = poster
        self._extractor = extractor
        self.limits = limits or ProcessingLimits()
        self.ocr_settings = ocr_settings or OcrSettings()
        self._clock = clock
        self._new_id = new_id

    # -- queries -----------------------------------------------------------

    def latest_jobs(self, scope: EntityScope) -> dict[UUID, JobRecord]:
        with self._uow_factory() as uow:
            return uow.processing(scope).latest_jobs()

    def pages(self, scope: EntityScope, job_id: UUID) -> list[PageRecord]:
        with self._uow_factory() as uow:
            return uow.processing(scope).pages(job_id)

    def derived_files(self, scope: EntityScope, job_id: UUID) -> list[DerivedFileRecord]:
        with self._uow_factory() as uow:
            return uow.processing(scope).derived_files(job_id)

    def latest_ocr_jobs(self, scope: EntityScope) -> dict[UUID, JobRecord]:
        with self._uow_factory() as uow:
            return uow.processing(scope).latest_jobs(ocr=True)

    def ocr_pages(self, scope: EntityScope, job_id: UUID) -> list[OcrPageRecord]:
        with self._uow_factory() as uow:
            return uow.processing(scope).ocr_pages(job_id)

    def ocr_available(self) -> bool:
        return self._processor.ocr_engine(self.ocr_settings) is not None

    def page_texts(self, scope: EntityScope, document_id: UUID) -> list[PageText]:
        """Text of every page of the latest analysis: text layer, else OCR, else none.

        Files are read only if their hash still matches; the text is for
        display and is never logged.
        """
        found = self.page_layers(scope, document_id)
        if found is None:
            return []
        pages, layers, confidences = found
        texts = []
        for page in pages:
            layer = layers.get(page.page_number, False)
            if isinstance(layer, TextLayer):
                texts.append(PageText(page.page_number, TextSource.TEXT_LAYER, layer.text))
            elif isinstance(layer, OcrLayer) or page.page_number in confidences:
                text = layer.text() if isinstance(layer, OcrLayer) else None
                confidence = confidences.get(page.page_number)
                texts.append(PageText(page.page_number, TextSource.OCR, text, confidence))
            elif layer is None:  # a text layer that can no longer be read
                texts.append(PageText(page.page_number, TextSource.TEXT_LAYER, None))
            else:
                texts.append(PageText(page.page_number, TextSource.NONE, ""))
        return texts

    def page_layers(
        self, scope: EntityScope, document_id: UUID
    ) -> tuple[list[PageRecord], dict[int, TextLayer | OcrLayer | None], dict[int, int]] | None:
        """Pages of the latest analysis with their text layer, else their OCR words.

        ``None`` without a successful analysis. A layer whose file is missing
        or changed maps to ``None``; the OCR confidence per page comes along.
        """
        with self._uow_factory() as uow:
            repository = uow.processing(scope)
            analysis = repository.latest_jobs().get(document_id)
            if (
                analysis is None
                or analysis.status is not JobStatus.SUCCEEDED
                or analysis.step is not ProcessingStep.PAGE_ANALYSIS
            ):
                return None
            pages = repository.pages(analysis.job_id)
            text_files = {
                record.page_number: record
                for record in repository.derived_files(analysis.job_id)
                if record.kind is DerivedKind.TEXT_LAYER
            }
            ocr_job = repository.latest_jobs(ocr=True).get(document_id)
            recognised = {}
            if ocr_job is not None and ocr_job.status is JobStatus.SUCCEEDED:
                recognised = {
                    record.page_number: record
                    for record in repository.ocr_pages(ocr_job.job_id)
                    if record.source_job_id == analysis.job_id
                }
        layers: dict[int, TextLayer | OcrLayer | None] = {}
        for page in pages:
            number = page.page_number
            if number in text_files:
                layers[number] = self._published(
                    text_files[number], TextLayer, max_text_bytes(self.limits)
                )
            elif number in recognised:
                layers[number] = self._published(
                    recognised[number], OcrLayer, max_ocr_bytes(self.limits)
                )
        confidences = {number: record.mean_confidence for number, record in recognised.items()}
        return pages, layers, confidences

    # -- extraction (Phase 06) -------------------------------------------------------

    def extract(
        self, scope: EntityScope, document_id: UUID, *, actor: str = SYSTEM_ACTOR
    ) -> list[UUID]:
        """Draft invoices from the document's text; ids of the invoices registered now."""
        if self._extractor is None:
            return []
        with self._uow_factory() as uow:
            document = uow.documents(scope).get(document_id)
        found = self.page_layers(scope, document_id)
        if found is None:
            return []
        pages, layers, _ = found
        readable = {number: layer for number, layer in layers.items() if layer is not None}
        return self._extractor.register(scope, document, pages, readable, actor=actor)

    def extract_pending(
        self,
        scope: EntityScope,
        *,
        actor: str = SYSTEM_ACTOR,
        should_stop: Callable[[], bool] = lambda: False,
    ) -> list[UUID]:
        """Every analysed document without an invoice yet (oldest first)."""
        if self._extractor is None:
            return []
        with self._uow_factory() as uow:
            jobs = uow.processing(scope).latest_jobs()
            invoices = uow.invoices(scope)
            pending = [
                record.document_id
                for record in reversed(uow.documents(scope).list())
                if self._extractor.readable(record)
                and (job := jobs.get(record.document_id)) is not None
                and job.status is JobStatus.SUCCEEDED
                and not invoices.ids_for_document(record.document_id)
            ]
        created = []
        for document_id in pending:
            if should_stop():
                break
            created += self.extract(scope, document_id, actor=actor)
        return created

    def _published[Layer: (TextLayer, OcrLayer)](
        self, record: DerivedFileRecord | OcrPageRecord, model: type[Layer], max_bytes: int
    ) -> Layer | None:
        data = self._derived.read_published(record.storage_path, record.sha256, max_bytes)
        if data is None:
            return None
        try:
            return model.model_validate_json(data)
        except ValidationError:
            return None

    # -- processing ----------------------------------------------------------

    def process(
        self,
        scope: EntityScope,
        document_id: UUID,
        *,
        actor: str = SYSTEM_ACTOR,
        should_stop: Callable[[], bool] = lambda: False,
    ) -> JobRecord:
        """Analyse one stored document; an earlier success is returned as is."""
        with self._uow_factory() as uow:
            document = uow.documents(scope).get(document_id)
        if document.status is not DocumentStatus.STORED or document.detected_format is None:
            # Quarantined files are never opened again.
            raise InvoiceFlowError("DOCUMENT_NOT_PROCESSABLE", "processing.not_processable")
        job = self._start(scope, document, actor)
        if job.status is JobStatus.SUCCEEDED:
            return job
        return self._run(scope, document, job, actor, should_stop)

    def process_pending(
        self,
        scope: EntityScope,
        *,
        actor: str = SYSTEM_ACTOR,
        should_stop: Callable[[], bool] = lambda: False,
    ) -> list[JobRecord]:
        """Analyse every stored document that has no job for the current settings.

        Failed documents are not retried here (a password-protected file stays
        refused); :meth:`process` retries one explicitly. ``should_stop`` is
        asked between documents and while a worker runs.
        """
        with self._uow_factory() as uow:
            documents = [
                record
                for record in uow.documents(scope).list()
                if record.status is DocumentStatus.STORED and record.detected_format is not None
            ]
            repository = uow.processing(scope)
            pending = [
                record
                for record in reversed(documents)  # oldest first
                if repository.next_attempt(self._key(record)) == 1
            ]
        results = []
        for record in pending:
            if should_stop():
                break
            results.append(
                self.process(scope, record.document_id, actor=actor, should_stop=should_stop)
            )
        results += self.recognise_pending(scope, actor=actor, should_stop=should_stop)
        if not should_stop():
            self.extract_pending(scope, actor=actor, should_stop=should_stop)
        return results

    def recognise_pending(
        self,
        scope: EntityScope,
        *,
        actor: str = SYSTEM_ACTOR,
        should_stop: Callable[[], bool] = lambda: False,
    ) -> list[JobRecord]:
        """OCR of every analysed document that has no OCR job for the current engine."""
        engine = self._processor.ocr_engine(self.ocr_settings)
        if engine is None:
            return []
        with self._uow_factory() as uow:
            repository = uow.processing(scope)
            pending = [
                record
                for record in reversed(uow.documents(scope).list())  # oldest first
                if record.status is DocumentStatus.STORED
                and record.detected_format in _OCR_FORMATS
                and repository.next_attempt(self._ocr_key(record, engine)) == 1
            ]
        results = []
        for record in pending:
            if should_stop():
                break
            job = self.recognise(scope, record.document_id, actor=actor, should_stop=should_stop)
            if job is not None:
                results.append(job)
        return results

    def recognise(
        self,
        scope: EntityScope,
        document_id: UUID,
        *,
        actor: str = SYSTEM_ACTOR,
        should_stop: Callable[[], bool] = lambda: False,
    ) -> JobRecord | None:
        """OCR of the analysed pages that need it; ``None`` when there is nothing to do.

        Nothing to do means: OCR is not installed, the document has no
        successful page analysis for the current settings, or every page has a
        text layer or is blank. An earlier success is returned as is.
        """
        engine = self._processor.ocr_engine(self.ocr_settings)
        if engine is None:
            return None
        with self._uow_factory() as uow:
            document = uow.documents(scope).get(document_id)
            if (
                document.status is not DocumentStatus.STORED
                or document.detected_format not in _OCR_FORMATS
            ):
                return None
            repository = uow.processing(scope)
            analysis = repository.find_succeeded(self._key(document))
            if analysis is None:
                return None
            renders = {
                record.page_number: record
                for record in repository.derived_files(analysis.job_id)
                if record.kind is DerivedKind.PAGE_RENDER
            }
            targets = [
                page
                for page in repository.pages(analysis.job_id)
                if needs_ocr(page) and page.page_number in renders
            ]
        if not targets:
            return None
        settings_hash = self.ocr_settings.settings_hash(self.limits)
        job = self._start_job(
            scope,
            document,
            actor,
            step=ProcessingStep.OCR,
            engine=engine,
            key=self._ocr_key(document, engine),
            settings_hash=settings_hash,
        )
        if job.status is JobStatus.SUCCEEDED:
            return job
        return self._run_ocr(scope, document, job, analysis, targets, renders, actor, should_stop)

    def reconcile(self, scope: EntityScope, *, actor: str = SYSTEM_ACTOR) -> ProcessingRecovery:
        """After a crash: finish interrupted jobs and tidy their folders."""
        with self._uow_factory() as uow:
            unfinished = uow.processing(scope).unfinished_jobs()
        for job in unfinished:
            self._finish_failed(scope, job, actor, ProcessingErrorCode.INTERRUPTED)
        with self._uow_factory() as uow:
            succeeded = uow.processing(scope).succeeded_job_ids()
        recovery = self._derived.recover(scope.entity_id, succeeded)
        return ProcessingRecovery(
            len(unfinished), recovery.work_removed, recovery.derived_moved, recovery.failed
        )

    # -- steps ---------------------------------------------------------------

    @staticmethod
    def _step(document: DocumentRecord) -> ProcessingStep:
        if document.detected_format == DocumentFormat.XML:
            return ProcessingStep.EHF_EXTRACTION
        return ProcessingStep.PAGE_ANALYSIS

    def _ocr_key(self, document: DocumentRecord, engine: tuple[str, str]) -> str:
        return idempotency_key(
            document.document_id,
            ProcessingStep.OCR,
            *engine,
            self.ocr_settings.settings_hash(self.limits),
        )

    def _key(self, document: DocumentRecord) -> str:
        engine, version = self._processor.engine_for(DocumentFormat(document.detected_format))
        return idempotency_key(
            document.document_id,
            self._step(document),
            engine,
            version,
            self.limits.settings_hash(),
        )

    def _start(self, scope: EntityScope, document: DocumentRecord, actor: str) -> JobRecord:
        return self._start_job(
            scope,
            document,
            actor,
            step=self._step(document),
            engine=self._processor.engine_for(DocumentFormat(document.detected_format)),
            key=self._key(document),
            settings_hash=self.limits.settings_hash(),
        )

    def _start_job(
        self,
        scope: EntityScope,
        document: DocumentRecord,
        actor: str,
        *,
        step: ProcessingStep,
        engine: tuple[str, str],
        key: str,
        settings_hash: str,
    ) -> JobRecord:
        engine_name, version = engine
        now = self._clock()
        with self._uow_factory() as uow:
            repository = uow.processing(scope)
            done = repository.find_succeeded(key)
            if done is not None:
                return done
            if repository.find_unfinished(key) is not None:
                raise InvoiceFlowError("PROCESSING_RUNNING", "processing.running")
            job = JobRecord(
                job_id=self._new_id(),
                entity_id=scope.entity_id,
                document_id=document.document_id,
                step=step,
                idempotency_key=key,
                attempt=repository.next_attempt(key),
                status=JobStatus.RUNNING,
                engine=engine_name,
                engine_version=version,
                settings_hash=settings_hash,
                queued_at=now,
                started_at=now,
            )
            try:
                repository.add_job(job)
            except ConflictError as exc:
                raise InvoiceFlowError("PROCESSING_RUNNING", "processing.running") from exc
            uow.audit.append(
                AuditDraft(
                    event_type=AuditEventType.PROCESSING_STARTED,
                    actor=actor,
                    entity_id=scope.entity_id,
                    subject_id=str(document.document_id),
                    details={
                        "job_id": str(job.job_id),
                        "attempt": job.attempt,
                        "step": str(job.step),
                    },
                ),
                occurred_at=now,
            )
            uow.commit()
        return job

    def _run(
        self,
        scope: EntityScope,
        document: DocumentRecord,
        job: JobRecord,
        actor: str,
        should_stop: Callable[[], bool],
    ) -> JobRecord:
        integrity = self._store.verify(document.storage_path, document.sha256)
        if integrity is not IntegrityStatus.OK:
            code = (
                ProcessingErrorCode.SOURCE_MISSING
                if integrity is IntegrityStatus.MISSING
                else ProcessingErrorCode.SOURCE_CHANGED
            )
            return self._finish_failed(scope, job, actor, code)
        try:
            work = self._derived.create_work_dir(scope.entity_id, job.job_id)
        except StorageError:
            return self._finish_failed(scope, job, actor, ProcessingErrorCode.STORAGE_FAILED)
        try:
            if job.step is ProcessingStep.EHF_EXTRACTION:
                return self._run_ehf(scope, document, job, actor, work, should_stop)
            try:
                result, pages, files = self._analyse(document, job, work, should_stop)
                if self._store.verify(document.storage_path, document.sha256) is not (
                    IntegrityStatus.OK
                ):
                    raise _RejectedError(ProcessingErrorCode.SOURCE_CHANGED)
                published = self._derived.publish(
                    scope.entity_id, document.document_id, job.job_id, work, files
                )
            except _RejectedError as rejected:
                return self._finish_failed(scope, job, actor, rejected.code, rejected.status)
            except WorkOutputError as error:
                return self._finish_failed(scope, job, actor, error.code)
            except StorageError:
                return self._finish_failed(scope, job, actor, ProcessingErrorCode.STORAGE_FAILED)
            try:
                return self._finish_succeeded(scope, job, actor, result, pages, files, published)
            except Exception:
                # The files stay unreferenced; reconciliation moves them aside. If
                # the database itself failed, the job stays running until then.
                with contextlib.suppress(Exception):
                    self._finish_failed(scope, job, actor, ProcessingErrorCode.STORAGE_FAILED)
                raise
        finally:
            self._derived.discard_work(work)

    # -- OCR (Phase 05) ------------------------------------------------------------

    def _run_ocr(
        self,
        scope: EntityScope,
        document: DocumentRecord,
        job: JobRecord,
        analysis: JobRecord,
        targets: list[PageRecord],
        renders: dict[int, DerivedFileRecord],
        actor: str,
        should_stop: Callable[[], bool],
    ) -> JobRecord:
        try:
            work = self._derived.create_work_dir(scope.entity_id, job.job_id)
        except StorageError:
            return self._finish_failed(scope, job, actor, ProcessingErrorCode.STORAGE_FAILED)
        try:
            try:
                task = self._ocr_task(document, targets, renders, work)
                report = self._analyse_ocr(document, job, task, should_stop)
                names = [page.file for page in report.pages]
                files = self._derived.inspect(work, names, self.limits.max_output_bytes)
                published = self._derived.publish(
                    scope.entity_id, document.document_id, job.job_id, work, files
                )
            except _RejectedError as rejected:
                return self._finish_failed(scope, job, actor, rejected.code, rejected.status)
            except WorkOutputError as error:
                return self._finish_failed(scope, job, actor, error.code)
            except StorageError:
                return self._finish_failed(scope, job, actor, ProcessingErrorCode.STORAGE_FAILED)
            try:
                return self._finish_ocr(scope, job, analysis, actor, report, files, published)
            except Exception:
                with contextlib.suppress(Exception):
                    self._finish_failed(scope, job, actor, ProcessingErrorCode.STORAGE_FAILED)
                raise
        finally:
            self._derived.discard_work(work)

    def _ocr_task(
        self,
        document: DocumentRecord,
        targets: list[PageRecord],
        renders: dict[int, DerivedFileRecord],
        work: Path,
    ) -> WorkerTask:
        """Copy each page image into the work folder after checking its hash."""
        inputs = []
        for page in targets:
            render = renders[page.page_number]
            data = self._derived.read_published(
                render.storage_path, render.sha256, MAX_RENDER_BYTES
            )
            if data is None or png_size(data[:24]) != (page.width_px, page.height_px):
                raise _RejectedError(ProcessingErrorCode.SOURCE_CHANGED)
            name = ocr_input_name(page.page_number)
            self._derived.put_work_file(work, name, data)
            inputs.append(
                OcrInput(page.page_number, name, render.sha256, page.width_px, page.height_px)
            )
        # The whole run may take one page's time per page, up to an hour.
        limits = dataclasses.replace(
            self.limits,
            timeout_seconds=min(MAX_TIMEOUT_SECONDS, self.limits.timeout_seconds * len(inputs)),
        )
        return WorkerTask(
            source=self._store.resolve(document.storage_path),
            sha256=document.sha256,
            document_format=DocumentFormat(document.detected_format),
            output_dir=work,
            limits=limits,
            ocr=OcrTask(self.ocr_settings, tuple(inputs), self.limits.timeout_seconds),
        )

    def _analyse_ocr(
        self,
        document: DocumentRecord,
        job: JobRecord,
        task: WorkerTask,
        should_stop: Callable[[], bool],
    ) -> OcrReport:
        """The validated report; every OCR file it names must agree with it."""
        try:
            outcome = self._processor.run(task, should_stop)
        except OSError:
            outcome = WorkerOutcome(WorkerExit.CRASHED)
        if outcome.exit is not WorkerExit.COMPLETED or outcome.payload is None:
            status, code = _EXITS.get(outcome.exit, _EXITS[WorkerExit.INVALID_RESULT])
            raise _RejectedError(code, status)
        try:
            report = OcrReport.model_validate_json(outcome.payload)
        except ValidationError as exc:
            raise _RejectedError(ProcessingErrorCode.INVALID_RESULT) from exc
        if (
            report.engine != job.engine
            or report.engine_version != job.engine_version
            or report.sha256 != document.sha256
            or (report.error_code is not None and report.error_code not in OCR_WORKER_CODES)
        ):
            raise _RejectedError(ProcessingErrorCode.INVALID_RESULT)
        if report.error_code is not None:
            raise _RejectedError(report.error_code)
        expected = [page.page_number for page in task.ocr.pages] if task.ocr else []
        if [page.page_number for page in report.pages] != expected:
            raise _RejectedError(ProcessingErrorCode.INVALID_RESULT)
        for page in report.pages:
            data = self._derived.read(task.output_dir, page.file, max_ocr_bytes(self.limits))
            try:
                layer = OcrLayer.model_validate_json(data)
            except ValidationError as exc:
                raise _RejectedError(ProcessingErrorCode.INVALID_RESULT) from exc
            low = sum(word.confidence < self.ocr_settings.low_confidence for word in layer.words)
            consistent = (
                layer.page_number == page.page_number
                and layer.language == self.ocr_settings.language
                and len(layer.words) == page.word_count
                and layer.line_count == page.line_count
                and len(layer.text()) == page.char_count
                and page.char_count <= self.limits.max_chars_per_page
                and layer.mean_confidence() == page.mean_confidence
                and low == page.low_confidence_words
            )
            if not consistent:
                raise _RejectedError(ProcessingErrorCode.INVALID_RESULT)
        return report

    def _finish_ocr(
        self,
        scope: EntityScope,
        job: JobRecord,
        analysis: JobRecord,
        actor: str,
        report: OcrReport,
        files: dict[str, WorkFile],
        published: dict[str, str],
    ) -> JobRecord:
        now = self._clock()
        records = [
            OcrPageRecord(
                job_id=job.job_id,
                document_id=job.document_id,
                source_job_id=analysis.job_id,
                page_number=page.page_number,
                word_count=page.word_count,
                line_count=page.line_count,
                char_count=page.char_count,
                mean_confidence=page.mean_confidence,
                low_confidence_words=page.low_confidence_words,
                storage_path=published[page.file],
                sha256=files[page.file].sha256,
                size_bytes=files[page.file].size_bytes,
                producer=job.producer,
                created_at=now,
            )
            for page in report.pages
        ]
        words = sum(record.word_count for record in records)
        weighted = sum(record.mean_confidence * record.word_count for record in records)
        with self._uow_factory() as uow:
            repository = uow.processing(scope)
            repository.add_ocr_pages(records)
            finished = repository.finish_job(
                job.job_id,
                status=JobStatus.SUCCEEDED,
                finished_at=now,
                page_count=len(records),
                active_content=False,
            )
            self._audit_finished(
                uow,
                scope,
                finished,
                actor,
                now,
                extra={
                    "word_count": words,
                    "mean_confidence": round(weighted / words) if words else 0,
                },
            )
            uow.commit()
        return finished

    # -- EHF (Phase 15) ------------------------------------------------------------

    def _run_ehf(
        self,
        scope: EntityScope,
        document: DocumentRecord,
        job: JobRecord,
        actor: str,
        work: Path,
        should_stop: Callable[[], bool],
    ) -> JobRecord:
        try:
            report, invoice = self._analyse_ehf(document, job, work, should_stop)
            if self._store.verify(document.storage_path, document.sha256) is not (
                IntegrityStatus.OK
            ):
                raise _RejectedError(ProcessingErrorCode.SOURCE_CHANGED)
            attachment_ids, refused = self._import_attachments(scope, report, work, actor)
        except _RejectedError as rejected:
            return self._finish_failed(scope, job, actor, rejected.code, rejected.status)
        except WorkOutputError as error:
            return self._finish_failed(scope, job, actor, error.code)
        except StorageError:
            return self._finish_failed(scope, job, actor, ProcessingErrorCode.STORAGE_FAILED)
        try:
            return self._finish_ehf(
                scope, document, job, actor, report, invoice, attachment_ids, refused
            )
        except Exception:
            with contextlib.suppress(Exception):
                self._finish_failed(scope, job, actor, ProcessingErrorCode.STORAGE_FAILED)
            raise

    def _analyse_ehf(
        self,
        document: DocumentRecord,
        job: JobRecord,
        work: Path,
        should_stop: Callable[[], bool],
    ) -> tuple[EhfReport, CanonicalInvoice]:
        task = WorkerTask(
            source=self._store.resolve(document.storage_path),
            sha256=document.sha256,
            document_format=DocumentFormat.XML,
            output_dir=work,
            limits=self.limits,
        )
        try:
            outcome = self._processor.run(task, should_stop)
        except OSError:
            outcome = WorkerOutcome(WorkerExit.CRASHED)
        if outcome.exit is not WorkerExit.COMPLETED or outcome.payload is None:
            status, code = _EXITS.get(outcome.exit, _EXITS[WorkerExit.INVALID_RESULT])
            raise _RejectedError(code, status)
        try:
            report = EhfReport.model_validate_json(outcome.payload)
        except ValidationError as exc:
            raise _RejectedError(ProcessingErrorCode.INVALID_RESULT) from exc
        if (
            report.engine != job.engine
            or report.engine_version != job.engine_version
            or report.sha256 != document.sha256
            or (report.error_code is not None and report.error_code not in EHF_WORKER_CODES)
        ):
            raise _RejectedError(ProcessingErrorCode.INVALID_RESULT)
        if report.error_code is not None:
            raise _RejectedError(report.error_code)
        data = dict(report.invoice or {}) | {"document_id": str(document.document_id)}
        try:
            invoice = CanonicalInvoice.model_validate(data)
        except ValidationError as exc:
            raise _RejectedError(ProcessingErrorCode.INVALID_RESULT) from exc
        if report.attachments:
            files = self._derived.inspect(
                work, [item.file for item in report.attachments], self.limits.max_output_bytes
            )
            for item in report.attachments:
                if files[item.file].size_bytes != item.size_bytes:
                    raise _RejectedError(ProcessingErrorCode.INVALID_RESULT)
        return report, invoice

    def _import_attachments(
        self, scope: EntityScope, report: EhfReport, work: Path, actor: str
    ) -> tuple[list[UUID], int]:
        """Each attachment goes through the normal import (signature, quarantine)."""
        linked: list[UUID] = []
        refused = 0
        for index, item in enumerate(report.attachments, start=1):
            if self._attachments is None:
                refused += 1
                continue
            result = self._attachments.import_file(
                scope,
                self._derived.work_file(work, item.file),
                origin=ImportSource.EHF_ATTACHMENT,
                actor=actor,
                name=attachment_display_name(item, index),
            )
            if result.document_id is not None:
                linked.append(result.document_id)
            if result.outcome not in _ACCEPTED_ATTACHMENTS:
                refused += 1
        return linked, refused

    def _finish_ehf(
        self,
        scope: EntityScope,
        document: DocumentRecord,
        job: JobRecord,
        actor: str,
        report: EhfReport,
        invoice: CanonicalInvoice,
        attachment_ids: list[UUID],
        refused: int,
    ) -> JobRecord:
        """Invoice, findings, links and the final job status in one transaction."""
        now = self._clock()
        with self._uow_factory() as uow:
            entity = uow.entities.get(scope.entity_id)
            invoices = uow.invoices(scope)
            codes = report_findings(report, invoice, refused_attachments=refused)
            codes += recipient_findings(invoice, entity.org_number)
            key = duplicate_key(invoice)
            if key is not None and invoices.ids_by_supplier_and_number(*key):
                codes.append(InvoiceFindingCode.POSSIBLE_DUPLICATE)
            codes = ordered(codes)
            # A new parser version must not register the same document twice.
            if not invoices.ids_for_document(document.document_id):
                invoice_id = self._new_id()
                if self._poster is not None:
                    invoice = self._poster.prepare(uow, scope, invoice)
                record = invoices.add(
                    invoice_id=invoice_id, invoice=invoice, recorded_at=now, actor=actor
                )
                uow.audit.append(
                    AuditDraft(
                        event_type=AuditEventType.INVOICE_CREATED,
                        actor=actor,
                        entity_id=scope.entity_id,
                        subject_id=str(invoice_id),
                        details={
                            "revision": record.revision,
                            "content_sha256": record.content_sha256,
                            "schema_version": invoice.schema_version,
                        },
                    ),
                    occurred_at=now,
                )
                invoices.add_findings(invoice_id, record.revision, codes, now)
                if self._validator is not None:
                    self._validator.validate_in(uow, scope, invoice_id, actor=actor)
            documents = uow.documents(scope)
            for attachment_id in dict.fromkeys(attachment_ids):
                documents.add_link(
                    document.document_id,
                    attachment_id,
                    "attachment",
                    created_at=now,
                    actor=actor,
                )
            finished = uow.processing(scope).finish_job(
                job.job_id, status=JobStatus.SUCCEEDED, finished_at=now, active_content=False
            )
            self._audit_finished(
                uow,
                scope,
                finished,
                actor,
                now,
                extra={
                    "line_count": len(invoice.lines),
                    "attachment_count": len(attachment_ids),
                    "finding_count": len(codes),
                },
            )
            uow.commit()
        return finished

    def _analyse(
        self,
        document: DocumentRecord,
        job: JobRecord,
        work: Path,
        should_stop: Callable[[], bool],
    ) -> tuple[WorkerResult, list[PageRecord], dict[str, WorkFile]]:
        task = WorkerTask(
            source=self._store.resolve(document.storage_path),
            sha256=document.sha256,
            document_format=DocumentFormat(document.detected_format),
            output_dir=work,
            limits=self.limits,
        )
        try:
            outcome = self._processor.run(task, should_stop)
        except OSError:
            outcome = WorkerOutcome(WorkerExit.CRASHED)
        if outcome.exit is not WorkerExit.COMPLETED or outcome.payload is None:
            status, code = _EXITS.get(outcome.exit, _EXITS[WorkerExit.INVALID_RESULT])
            raise _RejectedError(code, status)
        result = self._validated(outcome.payload, document, job)
        if result.error_code is not None:  # WorkerResult: set exactly for errors
            raise _RejectedError(result.error_code)
        return result, *self._collect(result, document, job, task)

    def _validated(self, payload: bytes, document: DocumentRecord, job: JobRecord) -> WorkerResult:
        try:
            result = WorkerResult.model_validate_json(payload)
        except ValidationError as exc:
            raise _RejectedError(ProcessingErrorCode.INVALID_RESULT) from exc
        limits = self.limits
        trustworthy = (
            result.engine == job.engine
            and result.engine_version == job.engine_version
            and result.sha256 == document.sha256
            and (result.error_code is None or result.error_code in WORKER_CODES)
            and result.page_count <= limits.max_pages
            and all(
                page.width_px * page.height_px <= limits.max_pixels
                and page.text_chars <= limits.max_chars_per_page
                for page in result.pages
            )
        )
        if not trustworthy:
            raise _RejectedError(ProcessingErrorCode.INVALID_RESULT)
        return result

    def _collect(
        self, result: WorkerResult, document: DocumentRecord, job: JobRecord, task: WorkerTask
    ) -> tuple[list[PageRecord], dict[str, WorkFile]]:
        """Check every file the report names before anything is published."""
        names = [page.render_file for page in result.pages]
        names += [page.text_file for page in result.pages if page.text_file is not None]
        files = self._derived.inspect(task.output_dir, names, self.limits.max_output_bytes)
        pages = []
        for page in result.pages:
            if png_size(files[page.render_file].header) != (page.width_px, page.height_px):
                raise _RejectedError(ProcessingErrorCode.INVALID_RESULT)
            if page.text_file is not None:
                data = self._derived.read(
                    task.output_dir, page.text_file, max_text_bytes(self.limits)
                )
                try:
                    layer = TextLayer.model_validate_json(data)
                except ValidationError as exc:
                    raise _RejectedError(ProcessingErrorCode.INVALID_RESULT) from exc
                if layer.page_number != page.page_number or len(layer.text) != page.text_chars:
                    raise _RejectedError(ProcessingErrorCode.INVALID_RESULT)
            pages.append(
                PageRecord(
                    job_id=job.job_id,
                    document_id=document.document_id,
                    page_number=page.page_number,
                    width_px=page.width_px,
                    height_px=page.height_px,
                    rotation_degrees=page.rotation_degrees,
                    text_layer_chars=page.text_chars,
                    dark_permille=page.dark_permille,
                    center_dark_permille=page.center_dark_permille,
                )
            )
        return pages, files

    def _finish_succeeded(
        self,
        scope: EntityScope,
        job: JobRecord,
        actor: str,
        result: WorkerResult,
        pages: list[PageRecord],
        files: dict[str, WorkFile],
        published: dict[str, str],
    ) -> JobRecord:
        now = self._clock()
        derived = []
        for page in result.pages:
            entries = [(page.render_file, DerivedKind.PAGE_RENDER)]
            if page.text_file is not None:
                entries.append((page.text_file, DerivedKind.TEXT_LAYER))
            for name, kind in entries:
                derived.append(
                    DerivedFileRecord(
                        file_id=self._new_id(),
                        job_id=job.job_id,
                        document_id=job.document_id,
                        page_number=page.page_number,
                        kind=kind,
                        storage_path=published[name],
                        sha256=files[name].sha256,
                        size_bytes=files[name].size_bytes,
                        producer=job.producer,
                        created_at=now,
                    )
                )
        with self._uow_factory() as uow:
            repository = uow.processing(scope)
            repository.add_pages(pages)
            repository.add_derived_files(derived)
            finished = repository.finish_job(
                job.job_id,
                status=JobStatus.SUCCEEDED,
                finished_at=now,
                page_count=result.page_count,
                active_content=result.active_content,
            )
            self._audit_finished(uow, scope, finished, actor, now)
            uow.commit()
        return finished

    def _finish_failed(
        self,
        scope: EntityScope,
        job: JobRecord,
        actor: str,
        code: ProcessingErrorCode,
        status: JobStatus = JobStatus.FAILED,
    ) -> JobRecord:
        now = self._clock()
        with self._uow_factory() as uow:
            finished = uow.processing(scope).finish_job(
                job.job_id, status=status, finished_at=now, error_code=code
            )
            self._audit_finished(uow, scope, finished, actor, now)
            uow.commit()
        return finished

    @staticmethod
    def _audit_finished(
        uow: UnitOfWork,
        scope: EntityScope,
        job: JobRecord,
        actor: str,
        now: dt.datetime,
        extra: dict[str, object] | None = None,
    ) -> None:
        details: dict[str, object] = {
            "job_id": str(job.job_id),
            "step": str(job.step),
            "job_status": str(job.status),
        }
        if job.error_code is not None:
            details["error_code"] = str(job.error_code)
        if job.page_count is not None:
            details["page_count"] = job.page_count
        if job.active_content is not None:
            details["active_content"] = job.active_content
        details |= extra or {}
        uow.audit.append(
            AuditDraft(
                event_type=AuditEventType.PROCESSING_FINISHED,
                actor=actor,
                entity_id=scope.entity_id,
                subject_id=str(job.document_id),
                details=details,
            ),
            occurred_at=now,
        )
