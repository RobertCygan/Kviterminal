"""Checks on an EHF invoice before it is registered (Phase 15). Pure, no I/O.

The arithmetic rules follow EN 16931 (BR-CO-10, -13, -14, -15, -16): a
deviation is recorded as a finding with a stable code so the invoice is
reviewed, never silently corrected or dropped.
"""

from collections.abc import Sequence
from decimal import Decimal

from invoiceflow.application.processing_model import (
    EhfAttachment,
    EhfMonetary,
    EhfReport,
    InvoiceFindingCode,
)
from invoiceflow.domain.invoice import CanonicalInvoice

# Display names for attachments that state no file name, by stated MIME type.
_EXTENSIONS = {
    "application/pdf": ".pdf",
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/tiff": ".tif",
}


def _decimal(text: str | None) -> Decimal | None:
    return None if text is None else Decimal(text)


def arithmetic_findings(amounts: EhfMonetary) -> list[InvoiceFindingCode]:
    """Totals that do not add up; a missing amount is not a finding here."""
    findings = []
    line_sum = _decimal(amounts.line_sum)
    line_extension = _decimal(amounts.line_extension)
    tax_exclusive = _decimal(amounts.tax_exclusive)
    tax_amount = _decimal(amounts.tax_amount)
    tax_inclusive = _decimal(amounts.tax_inclusive)
    payable = _decimal(amounts.payable)
    allowance = _decimal(amounts.allowance_total) or Decimal(0)
    charge = _decimal(amounts.charge_total) or Decimal(0)
    prepaid = _decimal(amounts.prepaid) or Decimal(0)
    rounding = _decimal(amounts.rounding) or Decimal(0)
    subtotal_sum = _decimal(amounts.tax_subtotal_sum)
    if line_sum is not None and line_extension is not None and line_sum != line_extension:
        findings.append(InvoiceFindingCode.LINE_SUM_MISMATCH)  # BR-CO-10
    if (
        line_extension is not None
        and tax_exclusive is not None
        and line_extension - allowance + charge != tax_exclusive
    ):
        findings.append(InvoiceFindingCode.NET_MISMATCH)  # BR-CO-13
    if tax_amount is not None and subtotal_sum is not None and tax_amount != subtotal_sum:
        findings.append(InvoiceFindingCode.VAT_MISMATCH)  # BR-CO-14
    if (
        tax_exclusive is not None
        and tax_amount is not None
        and tax_inclusive is not None
        and tax_exclusive + tax_amount != tax_inclusive
    ):
        findings.append(InvoiceFindingCode.GROSS_MISMATCH)  # BR-CO-15
    if (
        tax_inclusive is not None
        and payable is not None
        and tax_inclusive - prepaid + rounding != payable
    ):
        findings.append(InvoiceFindingCode.PAYABLE_MISMATCH)  # BR-CO-16
    if payable is not None and payable < 0:
        findings.append(InvoiceFindingCode.NEGATIVE_TOTAL)
    return findings


def recipient_findings(
    invoice: CanonicalInvoice, entity_org_number: str | None
) -> list[InvoiceFindingCode]:
    """Is the invoice addressed to this accounting entity?

    Without an organisation number on the entity nothing can be compared.
    """
    if entity_org_number is None:
        return []
    customer = invoice.customer
    org = None
    if customer is not None and customer.org_number is not None:
        org = customer.org_number.value
    if org is None:
        return [InvoiceFindingCode.MISSING_RECIPIENT]
    if org != entity_org_number:
        return [InvoiceFindingCode.WRONG_RECIPIENT]
    return []


def duplicate_key(invoice: CanonicalInvoice) -> tuple[str, str] | None:
    """(supplier organisation number, invoice number), when both are known."""
    org = invoice.supplier.org_number.value if invoice.supplier.org_number else None
    number = invoice.invoice_number.value if invoice.invoice_number else None
    if org is None or number is None:
        return None
    return org, number


def report_findings(
    report: EhfReport, invoice: CanonicalInvoice, *, refused_attachments: int
) -> list[InvoiceFindingCode]:
    """Everything the report itself shows, in a stable order."""
    findings = []
    if report.monetary is not None:
        findings += arithmetic_findings(report.monetary)
        currency = invoice.currency.value if invoice.currency else None
        if currency is not None and any(code != currency for code in report.monetary.currencies):
            findings.append(InvoiceFindingCode.CURRENCY_MISMATCH)
    if report.unreadable_values:
        findings.append(InvoiceFindingCode.UNREADABLE_VALUE)
    required = (
        invoice.invoice_number,
        invoice.invoice_date,
        invoice.currency,
        invoice.supplier.name,
        invoice.totals.gross_amount,
    )
    if any(field is None for field in required):
        findings.append(InvoiceFindingCode.MISSING_REQUIRED)
    if report.external_attachments:
        findings.append(InvoiceFindingCode.EXTERNAL_ATTACHMENT)
    if refused_attachments:
        findings.append(InvoiceFindingCode.ATTACHMENT_REFUSED)
    return findings


def attachment_display_name(attachment: EhfAttachment, index: int) -> str:
    """The stated file name, or a neutral one with an extension from the MIME type.

    Neither is trusted: the import still checks the file's signature against
    the extension and quarantines a mismatch.
    """
    if attachment.filename:
        return attachment.filename
    return f"vedlegg-{index:02d}" + _EXTENSIONS.get(attachment.mime_code or "", ".bin")


def ordered(codes: Sequence[InvoiceFindingCode]) -> list[InvoiceFindingCode]:
    """Each code once, in enumeration order (stable for display and tests)."""
    order = list(InvoiceFindingCode)
    return sorted(set(codes), key=order.index)
