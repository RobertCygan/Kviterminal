"""Image adapter on Pillow for PNG, JPEG and TIFF. Runs only in the worker.

Pillow is told exactly which decoder to use (the format detected from the
signature at import), the pixel limit is set explicitly and exceeding it is
an error, never a warning (docs/SECURITY.md §8.1). Only TIFF has several
pages; other formats always have one, even if they contain animation frames.
"""

import io
import struct
import warnings
from collections.abc import Iterator
from importlib import metadata

from PIL import Image, ImageOps, UnidentifiedImageError

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.processing_model import (
    PAGE_METRICS_VERSION,
    ProcessingErrorCode,
    ProcessingLimits,
)
from invoiceflow.processing.parser import ParsedPage, ParserError, check_page_size

ENGINE = "pillow"
DISTRIBUTION = "pillow"
_DECODERS = {DocumentFormat.PNG: "PNG", DocumentFormat.JPEG: "JPEG", DocumentFormat.TIFF: "TIFF"}
# EXIF orientation -> clockwise rotation needed for display (mirrored values ignored).
_ROTATION = {3: 180, 6: 90, 8: 270}
_ORIENTATION_TAG = 0x0112
_LIBRARY_ERRORS = (
    UnidentifiedImageError,
    OSError,
    SyntaxError,
    ValueError,
    EOFError,
    TypeError,
    KeyError,
    IndexError,
    struct.error,
)


# Page metrics (Phase 11a): measured on a greyscale copy at most 512 pixels
# wide, so the cost does not grow with the resolution. A pixel darker than the
# threshold counts as ink; at this size thin printed text still does. A 5 %
# margin is left out, because scanners often leave dark edges.
_METRIC_SIZE = (512, 512)
_DARK_BELOW = 200
_MARGIN = (0.05, 0.05, 0.95, 0.95)
_CENTER = (0.2, 0.3, 0.8, 0.7)  # left, top, right, bottom as shares of the page


def _dark_permille(image: Image.Image, area: tuple[float, float, float, float]) -> int:
    width, height = image.size
    left, top, right, bottom = area
    region = image.crop(
        (round(left * width), round(top * height), round(right * width), round(bottom * height))
    )
    histogram = region.histogram()
    total = sum(histogram)
    return 0 if total == 0 else round(1000 * sum(histogram[:_DARK_BELOW]) / total)


def page_metrics(image: Image.Image) -> tuple[int, int]:
    """Share of dark pixels (per mille) inside the margins and in the central area."""
    small = ImageOps.grayscale(image)
    small.thumbnail(_METRIC_SIZE)
    return _dark_permille(small, _MARGIN), _dark_permille(small, _CENTER)


class PillowDocument:
    def __init__(self, image: Image.Image, page_count: int, limits: ProcessingLimits) -> None:
        self._image = image
        self._limits = limits
        self.page_count = page_count
        self.active_content = False

    def pages(self) -> Iterator[ParsedPage]:
        for index in range(self.page_count):
            yield self._page(index)

    def _page(self, index: int) -> ParsedPage:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            try:
                self._image.seek(index)
                check_page_size(*self._image.size, self._limits)
                orientation = self._image.getexif().get(_ORIENTATION_TAG, 1)
                self._image.load()
                frame = ImageOps.exif_transpose(self._image)
                if frame.mode not in ("L", "RGB"):
                    frame = frame.convert("RGBA" if "A" in frame.getbands() else "RGB")
                    if frame.mode == "RGBA":
                        background = Image.new("RGB", frame.size, (255, 255, 255))
                        background.paste(frame, mask=frame.getchannel("A"))
                        frame = background
                check_page_size(*frame.size, self._limits)
                dark, center = page_metrics(frame)
                buffer = io.BytesIO()
                frame.save(buffer, format="PNG")
            except ParserError:
                raise
            except (Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
                raise ParserError(ProcessingErrorCode.PAGE_TOO_LARGE) from exc
            except _LIBRARY_ERRORS as exc:
                raise ParserError(ProcessingErrorCode.CORRUPT) from exc
        return ParsedPage(
            page_number=index + 1,
            width_px=frame.width,
            height_px=frame.height,
            rotation_degrees=_ROTATION.get(orientation, 0) if isinstance(orientation, int) else 0,
            text="",
            boxes=(),
            png=buffer.getvalue(),
            dark_permille=dark,
            center_dark_permille=center,
        )

    def close(self) -> None:
        self._image.close()


class PillowParser:
    """Implements :class:`invoiceflow.processing.parser.DocumentParser` for images."""

    engine = ENGINE
    formats = frozenset(_DECODERS)

    def __init__(self) -> None:
        self.engine_version = f"{metadata.version(DISTRIBUTION)}+{PAGE_METRICS_VERSION}"

    def open(
        self, data: bytes, document_format: DocumentFormat, limits: ProcessingLimits
    ) -> PillowDocument:
        decoder = _DECODERS.get(document_format)
        if decoder is None:
            raise ParserError(ProcessingErrorCode.UNSUPPORTED_FORMAT)
        # The worker processes one document per process, so the global is safe.
        Image.MAX_IMAGE_PIXELS = limits.max_pixels
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            try:
                image = Image.open(io.BytesIO(data), formats=[decoder])
            except (Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
                raise ParserError(ProcessingErrorCode.PAGE_TOO_LARGE) from exc
            except _LIBRARY_ERRORS as exc:
                raise ParserError(ProcessingErrorCode.CORRUPT) from exc
            try:
                check_page_size(*image.size, limits)
                frames = 1
                if document_format is DocumentFormat.TIFF:
                    frames = image.n_frames
                if not isinstance(frames, int) or frames < 1:
                    raise ParserError(ProcessingErrorCode.NO_PAGES)
                if frames > limits.max_pages:
                    raise ParserError(ProcessingErrorCode.TOO_MANY_PAGES)
            except ParserError:
                image.close()
                raise
            except _LIBRARY_ERRORS as exc:
                image.close()
                raise ParserError(ProcessingErrorCode.CORRUPT) from exc
        return PillowDocument(image, frames, limits)
