"""Body of the isolated worker process (ADR-0010, ADR-0031).

The worker receives a :class:`~invoiceflow.application.ports.WorkerTask` from
the parent, reads the original itself, checks its hash, writes page images and
text layers into its empty output folder and sends back one JSON report. It
has no database, no secrets and no network client; it never sends Python
objects back, so the parent never unpickles anything from it.

A library failure on a malformed file is reported as ``corrupt`` with no
library message; ``MemoryError`` (the memory limit was hit) as
``memory_limit``.
"""

import hashlib
import json
import os
import sys
from collections.abc import Mapping
from multiprocessing.connection import Connection
from pathlib import Path

from invoiceflow.application.document_model import MAX_DOCUMENT_BYTES, DocumentFormat
from invoiceflow.application.ports import WorkerTask
from invoiceflow.application.processing_model import (
    RESULT_VERSION,
    ProcessingErrorCode,
    render_name,
    text_name,
)
from invoiceflow.processing.parser import DocumentParser, ParsedPage, ParserError

MAX_RESULT_BYTES = 1024 * 1024


def default_parsers() -> dict[DocumentFormat, DocumentParser]:
    # Imported here so that the parent never loads a PDF or image library.
    from invoiceflow.processing.image_pillow import PillowParser
    from invoiceflow.processing.pdf_pdfium import PdfiumParser

    pdf, image = PdfiumParser(), PillowParser()
    return {fmt: pdf for fmt in pdf.formats} | {fmt: image for fmt in image.formats}


def _read_original(path: Path) -> bytes:
    with path.open("rb") as handle:
        data = handle.read(MAX_DOCUMENT_BYTES + 1)
    if len(data) > MAX_DOCUMENT_BYTES:
        raise ParserError(ProcessingErrorCode.SOURCE_CHANGED)
    return data


def _checked_original(task: WorkerTask) -> bytes:
    data = _read_original(task.source)
    if hashlib.sha256(data).hexdigest() != task.sha256:
        raise ParserError(ProcessingErrorCode.SOURCE_CHANGED)
    return data


def _analyse_xml(task: WorkerTask) -> bytes:
    """EHF files go to the XML reader; imported here like the other adapters."""
    from invoiceflow.processing.ehf import ENGINE, analyse_ehf, engine_version

    try:
        data = _checked_original(task)
    except ParserError as exc:
        error = {"status": "error", "error_code": str(exc.code)}
    except OSError:
        error = {"status": "error", "error_code": str(ProcessingErrorCode.SOURCE_MISSING)}
    else:
        return analyse_ehf(task, data)
    report = {
        "result_version": RESULT_VERSION,
        "engine": ENGINE,
        "engine_version": engine_version(),
        "sha256": task.sha256,
    } | error
    return json.dumps(report, separators=(",", ":")).encode("ascii")


def _write_new(directory: Path, name: str, content: bytes) -> None:
    # "x" refuses an existing file, so nothing outside the folder can be reached
    # through a planted name; the names themselves come from fixed patterns.
    with (directory / name).open("xb") as handle:
        handle.write(content)


def _store_page(page: ParsedPage, directory: Path) -> tuple[dict[str, object], int]:
    render = render_name(page.page_number)
    _write_new(directory, render, page.png)
    written = len(page.png)
    text_file = None
    if page.text:
        text_file = text_name(page.page_number)
        layer = json.dumps(
            {
                "result_version": RESULT_VERSION,
                "page_number": page.page_number,
                "text": page.text,
                "boxes": [list(box) for box in page.boxes],
            },
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        _write_new(directory, text_file, layer)
        written += len(layer)
    entry: dict[str, object] = {
        "page_number": page.page_number,
        "width_px": page.width_px,
        "height_px": page.height_px,
        "rotation_degrees": page.rotation_degrees,
        "text_chars": len(page.text),
        "render_file": render,
        "text_file": text_file,
        "dark_permille": page.dark_permille,
        "center_dark_permille": page.center_dark_permille,
    }
    return entry, written


def analyse(
    task: WorkerTask, parsers: Mapping[DocumentFormat, DocumentParser] | None = None
) -> bytes:
    """Run one task and return the JSON report. Never raises for bad input."""
    if task.ocr is not None:
        from invoiceflow.processing.ocr_tesseract import analyse_ocr

        return analyse_ocr(task)
    if task.document_format is DocumentFormat.XML:
        return _analyse_xml(task)
    parsers = default_parsers() if parsers is None else parsers
    parser = parsers[task.document_format]
    report: dict[str, object] = {
        "result_version": RESULT_VERSION,
        "engine": parser.engine,
        "engine_version": parser.engine_version,
        "sha256": task.sha256,
    }
    try:
        data = _checked_original(task)
        document = parser.open(data, task.document_format, task.limits)
        del data
        try:
            pages = []
            written = 0
            for page in document.pages():
                entry, size = _store_page(page, task.output_dir)
                written += size
                if written > task.limits.max_output_bytes:
                    raise ParserError(ProcessingErrorCode.OUTPUT_TOO_LARGE)
                pages.append(entry)
            report |= {
                "status": "ok",
                "page_count": document.page_count,
                "active_content": bool(document.active_content),
                "pages": pages,
            }
        finally:
            document.close()
    except ParserError as exc:
        report |= {"status": "error", "error_code": str(exc.code)}
    except MemoryError:
        report |= {"status": "error", "error_code": str(ProcessingErrorCode.MEMORY_LIMIT)}
    except Exception:  # library failure on a hostile file; no message is kept
        report |= {"status": "error", "error_code": str(ProcessingErrorCode.CORRUPT)}
    return json.dumps(report, separators=(",", ":")).encode("ascii")


def limit_own_resources(memory_bytes: int) -> None:
    """POSIX fallback for development; Windows uses a Job Object (ADR-0031)."""
    if sys.platform == "win32":
        return
    import resource  # POSIX only

    resource.setrlimit(resource.RLIMIT_AS, (memory_bytes, memory_bytes))


def serve(
    connection: Connection, parsers: Mapping[DocumentFormat, DocumentParser] | None = None
) -> None:
    """Receive one task, run it, send the report, exit."""
    try:
        # Sent by the parent only after the resource limits were applied to us.
        task = connection.recv()
        if not isinstance(task, WorkerTask):
            return
        limit_own_resources(task.limits.memory_bytes)
        os.chdir(task.output_dir)
        payload = analyse(task, parsers)
        connection.send_bytes(payload)
    finally:
        connection.close()


def child_main(connection: Connection) -> None:  # pragma: no cover - runs in the worker
    serve(connection)
