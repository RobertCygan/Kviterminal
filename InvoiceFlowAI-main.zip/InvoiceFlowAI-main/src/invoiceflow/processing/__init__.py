"""Isolated document processing (Phase 04, ADR-0010, ADR-0023, ADR-0031).

Everything in this package except :mod:`invoiceflow.processing.isolation` and
:mod:`invoiceflow.processing.win_job` runs inside the worker process. Only the
adapters import a PDF or image library.
"""
