"""PDF adapter on pypdfium2/PDFium (D-11 = C, ADR-0023). Runs only in the worker.

PDFium never runs JavaScript or other actions unless a form environment is
initialised, and this adapter never does that (``may_draw_forms=False``).
Active content is only *detected* and reported, so it can be flagged.
"""

import io
import re
from collections.abc import Iterator
from importlib import metadata

import pypdfium2 as pdfium
import pypdfium2.raw as pdfium_c

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.processing_model import (
    PAGE_METRICS_VERSION,
    ProcessingErrorCode,
    ProcessingLimits,
)
from invoiceflow.processing.image_pillow import page_metrics
from invoiceflow.processing.parser import (
    Box,
    ParsedPage,
    ParserError,
    check_page_size,
    normalise_box,
    scaled_size,
    text_and_boxes,
)

ENGINE = "pypdfium2"
DISTRIBUTION = "pypdfium2"

# Names of PDF features that can act on their own when a viewer opens the file.
_ACTIVE_NAMES = frozenset(
    {
        b"JavaScript",
        b"JS",
        b"Launch",
        b"EmbeddedFile",
        b"EmbeddedFiles",
        b"RichMedia",
        b"XFA",
        b"SubmitForm",
        b"ImportData",
    }
)
_PLAIN_NAME = re.compile(
    rb"/(JavaScript|JS|Launch|EmbeddedFiles?|RichMedia|XFA|SubmitForm|ImportData)(?![A-Za-z0-9#])"
)
# A name may hide its letters as #xx escapes (/J#61vaScript).
_ESCAPED_NAME = re.compile(rb"/[A-Za-z0-9]*#[0-9A-Fa-f]{2}[A-Za-z0-9#]*")
_ESCAPE = re.compile(rb"#([0-9A-Fa-f]{2})")


def scan_active_names(data: bytes) -> bool:
    """True if the raw file names an active feature (plain or #-escaped).

    A heuristic over uncompressed bytes; names inside compressed object
    streams are covered only by the API checks in :class:`PdfiumDocument`.
    """
    if _PLAIN_NAME.search(data):
        return True
    for match in _ESCAPED_NAME.finditer(data):
        name = _ESCAPE.sub(lambda escape: bytes([int(escape.group(1), 16)]), match.group()[1:])
        if name in _ACTIVE_NAMES:
            return True
    return False


def _page_has_launch_link(page: pdfium.PdfPage) -> bool:
    position = pdfium_c.c_int(0)
    link = pdfium_c.FPDF_LINK()
    while pdfium_c.FPDFLink_Enumerate(page, position, link):
        action = pdfium_c.FPDFLink_GetAction(link)
        if action and pdfium_c.FPDFAction_GetType(action) == pdfium_c.PDFACTION_LAUNCH:
            return True
    return False


class PdfiumDocument:
    """Pages are produced one at a time, so memory stays bounded per page."""

    def __init__(self, document: pdfium.PdfDocument, data: bytes, limits: ProcessingLimits):
        self._document = document
        self._limits = limits
        self.page_count = len(document)
        self.active_content = (
            pdfium_c.FPDFDoc_GetJavaScriptActionCount(document) > 0
            or pdfium_c.FPDFDoc_GetAttachmentCount(document) > 0
            or scan_active_names(data)
        )

    def pages(self) -> Iterator[ParsedPage]:
        for index in range(self.page_count):
            try:
                page = self._document[index]
            except pdfium.PdfiumError as exc:
                raise ParserError(ProcessingErrorCode.CORRUPT) from exc
            try:
                yield self._page(page, index + 1)
            finally:
                page.close()

    def _page(self, page: pdfium.PdfPage, number: int) -> ParsedPage:
        limits = self._limits
        width, height = page.get_size()  # already swapped for a rotated page
        check_page_size(*scaled_size(width, height, limits.dpi), limits)
        rotation = page.get_rotation()
        if _page_has_launch_link(page):
            self.active_content = True
        textpage = page.get_textpage()
        try:
            count = textpage.count_chars()
            if count < 0:
                raise ParserError(ProcessingErrorCode.CORRUPT)
            if count > limits.max_chars_per_page:
                raise ParserError(ProcessingErrorCode.TOO_MUCH_TEXT)
            bitmap = page.render(scale=limits.dpi / 72, may_draw_forms=False)
            try:
                check_page_size(bitmap.width, bitmap.height, limits)
                converter = bitmap.get_posconv(page)
                units: list[tuple[int, Box]] = []
                for char_index in range(count):
                    code = pdfium_c.FPDFText_GetUnicode(textpage, char_index)
                    left, bottom, right, top = textpage.get_charbox(char_index)
                    x0, y0 = converter.to_bitmap(left, top)
                    x1, y1 = converter.to_bitmap(right, bottom)
                    units.append((code, normalise_box(x0, y0, x1, y1, bitmap.width, bitmap.height)))
                text, boxes = text_and_boxes(units)
                image = bitmap.to_pil()
                dark, center = page_metrics(image)
                buffer = io.BytesIO()
                image.save(buffer, format="PNG")
                return ParsedPage(
                    page_number=number,
                    width_px=bitmap.width,
                    height_px=bitmap.height,
                    rotation_degrees=rotation if rotation in (0, 90, 180, 270) else 0,
                    text=text,
                    boxes=boxes,
                    png=buffer.getvalue(),
                    dark_permille=dark,
                    center_dark_permille=center,
                )
            finally:
                bitmap.close()
        finally:
            textpage.close()

    def close(self) -> None:
        self._document.close()


class PdfiumParser:
    """Implements :class:`invoiceflow.processing.parser.DocumentParser` for PDF."""

    engine = ENGINE
    formats = frozenset({DocumentFormat.PDF})

    def __init__(self) -> None:
        self.engine_version = f"{metadata.version(DISTRIBUTION)}+{PAGE_METRICS_VERSION}"

    def open(
        self, data: bytes, document_format: DocumentFormat, limits: ProcessingLimits
    ) -> PdfiumDocument:
        if document_format not in self.formats:
            raise ParserError(ProcessingErrorCode.UNSUPPORTED_FORMAT)
        try:
            document = pdfium.PdfDocument(data)
        except pdfium.PdfiumError as exc:
            code = getattr(exc, "err_code", None)
            if code in (pdfium_c.FPDF_ERR_PASSWORD, pdfium_c.FPDF_ERR_SECURITY):
                raise ParserError(ProcessingErrorCode.ENCRYPTED) from None
            raise ParserError(ProcessingErrorCode.CORRUPT) from None
        try:
            # Also refuse files that open without a password but are encrypted.
            if pdfium_c.FPDF_GetSecurityHandlerRevision(document) != -1:
                raise ParserError(ProcessingErrorCode.ENCRYPTED)
            if len(document) == 0:
                raise ParserError(ProcessingErrorCode.NO_PAGES)
            if len(document) > limits.max_pages:
                raise ParserError(ProcessingErrorCode.TOO_MANY_PAGES)
            return PdfiumDocument(document, data, limits)
        except BaseException:
            document.close()
            raise
