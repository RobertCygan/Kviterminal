"""Run one worker task in a separate, resource-limited process (ADR-0010, ADR-0031).

Sequence
--------
1. Start a fresh ``spawn`` process. It waits for its task and has not touched
   the document yet.
2. Windows: put it into a Job Object with the memory limit, a process limit
   of one and kill-on-close. Only then send the task, so the limits are in
   force before the first byte of the document is parsed.
3. Wait for the report with a deadline; stop on request. On a timeout, a
   cancel or an unexpected exit the process is killed and waited for.
4. Read the report as raw bytes with a size limit. Nothing coming from the
   worker is ever unpickled.

The worker process is never reused: one process per document. An OCR task
(Phase 05) may start one more process, Tesseract, inside the same job.
"""

import dataclasses
import multiprocessing
import sys
import threading
import time
from collections.abc import Callable
from importlib import metadata
from multiprocessing.connection import Connection

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.ports import WorkerExit, WorkerOutcome, WorkerTask
from invoiceflow.application.processing_model import (
    EHF_PARSER_VERSION,
    OCR_ENGINE,
    PAGE_METRICS_VERSION,
    OcrSettings,
)
from invoiceflow.processing.tesseract_install import TesseractInstall, locate
from invoiceflow.processing.win_job import JobObject
from invoiceflow.processing.worker import MAX_RESULT_BYTES, child_main

# A crash this close to the memory limit is reported as hitting the limit.
_MEMORY_SHARE = 0.9
_ENGINES = {
    DocumentFormat.PDF: ("pypdfium2", "pypdfium2"),
    DocumentFormat.PNG: ("pillow", "pillow"),
    DocumentFormat.JPEG: ("pillow", "pillow"),
    DocumentFormat.TIFF: ("pillow", "pillow"),
}
_EHF_ENGINE = "ehf"


class IsolatedDocumentProcessor:
    """Implements :class:`invoiceflow.application.ports.DocumentProcessor`."""

    def __init__(
        self,
        *,
        target: Callable[[Connection], None] = child_main,
        poll_interval: float = 0.05,
        locate_tesseract: Callable[[], TesseractInstall | None] = locate,
    ) -> None:
        self._context = multiprocessing.get_context("spawn")
        self._target = target
        self._poll_interval = poll_interval
        self._locate_tesseract = locate_tesseract
        self._tesseract: TesseractInstall | None = None
        self._located = False
        self._lock = threading.Lock()
        self.last_pid: int | None = None  # for tests: the process must be gone

    def engine_for(self, document_format: DocumentFormat) -> tuple[str, str]:
        document_format = DocumentFormat(document_format)
        if document_format is DocumentFormat.XML:
            # The XML reader is our own code; its version names the parser too.
            return _EHF_ENGINE, f"{EHF_PARSER_VERSION}+{metadata.version('defusedxml')}"
        engine, distribution = _ENGINES[document_format]
        return engine, f"{metadata.version(distribution)}+{PAGE_METRICS_VERSION}"

    def _install(self) -> TesseractInstall | None:
        """Looked for once per run of the application; installing needs a restart."""
        with self._lock:
            if not self._located:
                self._tesseract = self._locate_tesseract()
                self._located = True
            return self._tesseract

    def ocr_engine(self, settings: OcrSettings) -> tuple[str, str] | None:
        install = self._install()
        version = None if install is None else install.engine_version(settings)
        return None if version is None else (OCR_ENGINE, version)

    def prepared(self, task: WorkerTask) -> WorkerTask | None:
        """The task with the OCR engine filled in; ``None`` if OCR is not installed."""
        if task.ocr is None:
            return task
        install = self._install()
        version = None if install is None else install.engine_version(task.ocr.settings)
        if install is None or version is None:
            return None
        ocr = dataclasses.replace(
            task.ocr,
            executable=install.executable,
            tessdata=install.tessdata,
            engine_version=version,
        )
        return dataclasses.replace(task, ocr=ocr)

    def run(self, task: WorkerTask, should_stop: Callable[[], bool]) -> WorkerOutcome:
        ready = self.prepared(task)
        if ready is None:
            return WorkerOutcome(WorkerExit.CRASHED)
        task = ready
        processes = 1 if task.ocr is None else 2  # the worker, and for OCR Tesseract
        parent, child = self._context.Pipe(duplex=True)
        process = self._context.Process(
            target=self._target, args=(child,), name="invoiceflow-worker", daemon=True
        )
        job: JobObject | None = None
        try:
            process.start()
            child.close()
            self.last_pid = process.pid
            if sys.platform == "win32":
                job = JobObject(task.limits.memory_bytes, processes)
                job.assign(process.sentinel)
            try:
                parent.send(task)
            except OSError:
                return WorkerOutcome(WorkerExit.CRASHED)
            return self._wait(parent, process, job, task, should_stop)
        finally:
            parent.close()
            if process.is_alive():
                self._kill(process, job)
            process.join(10)
            if job is not None:
                job.close()  # kills anything left in the job
            if not process.is_alive():
                process.close()

    def _wait(
        self,
        parent: Connection,
        process: multiprocessing.process.BaseProcess,
        job: JobObject | None,
        task: WorkerTask,
        should_stop: Callable[[], bool],
    ) -> WorkerOutcome:
        deadline = time.monotonic() + task.limits.timeout_seconds
        while True:
            if parent.poll(self._poll_interval):
                try:
                    payload = parent.recv_bytes(MAX_RESULT_BYTES)
                except (EOFError, ConnectionError):
                    return self._ended(process, job, task)
                except OSError:
                    # Longer than allowed, or a broken pipe: never trust it.
                    return WorkerOutcome(WorkerExit.INVALID_RESULT)
                return WorkerOutcome(WorkerExit.COMPLETED, payload)
            if not process.is_alive():
                if parent.poll(0):
                    continue  # the report arrived just before the exit
                return self._ended(process, job, task)
            if should_stop():
                self._kill(process, job)
                return WorkerOutcome(WorkerExit.CANCELLED)
            if time.monotonic() > deadline:
                self._kill(process, job)
                return WorkerOutcome(WorkerExit.TIMED_OUT)

    @staticmethod
    def _ended(
        process: multiprocessing.process.BaseProcess, job: JobObject | None, task: WorkerTask
    ) -> WorkerOutcome:
        process.join(10)
        if job is not None and job.peak_memory() >= task.limits.memory_bytes * _MEMORY_SHARE:
            return WorkerOutcome(WorkerExit.MEMORY_LIMIT)
        return WorkerOutcome(WorkerExit.CRASHED)

    @staticmethod
    def _kill(process: multiprocessing.process.BaseProcess, job: JobObject | None) -> None:
        if job is not None:
            job.terminate()
        else:
            process.kill()
        process.join(10)
