"""EHF / PEPPOL BIS Billing 3.0 reader. Runs only in the worker (Phase 15, ADR-0019).

The file is parsed with ``defusedxml`` (no DTD, no entities, no external
references) under fixed limits on depth and element count. Values are mapped
to the canonical invoice with provenance ``extracted``; every value carries the
XPath it came from and the text exactly as written. A value that does not fit
its canonical type is kept as ``None`` with that raw text, never guessed.

Embedded attachments are decoded into the worker's output folder; their stated
MIME type and file name are reported, never trusted. External attachment
references are counted and never fetched.
"""

import base64
import binascii
import io
import json
from collections.abc import Callable
from decimal import Decimal, InvalidOperation
from importlib import metadata
from typing import Any
from uuid import UUID

import defusedxml.ElementTree as DefusedET
from defusedxml import DefusedXmlException
from defusedxml.ElementTree import ParseError
from pydantic import TypeAdapter, ValidationError

from invoiceflow.application.ports import WorkerTask
from invoiceflow.application.processing_model import (
    EHF_PARSER_VERSION,
    MAX_ATTACHMENT_BYTES,
    MAX_EHF_ATTACHMENTS,
    ProcessingErrorCode,
    attachment_name,
)
from invoiceflow.domain.invoice import (
    MAX_INVOICE_LINES,
    MAX_VAT_BREAKDOWN_ENTRIES,
    CanonicalInvoice,
    InvoiceType,
)
from invoiceflow.domain.types import (
    BankAccount,
    Bic,
    CountryCode,
    CurrencyCode,
    Flag,
    ForeignVatId,
    Iban,
    Identifier,
    IsoDate,
    Kid,
    LongText,
    Money,
    OrgNumber,
    PostalCode,
    Quantity,
    ShortText,
    UnitPrice,
    UnitText,
    VatRate,
)
from invoiceflow.processing.parser import ParserError

ENGINE = "ehf"
# An ElementTree element; typed loosely so that no module but defusedxml's is
# imported from the XML packages (ADR-0019, Bandit B405).
Element = Any
MAX_DEPTH = 64
MAX_ELEMENTS = 500_000
MAX_RAW_TEXT = 2000

UBL_INVOICE = "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
UBL_CREDIT_NOTE = "urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2"
CAC = "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
CBC = "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
CUSTOMIZATION = "urn:cen.eu:en16931:2017#compliant#urn:fdc:peppol.eu:2017:poacc:billing:3.0"
PROFILE = "urn:fdc:peppol.eu:2017:poacc:billing:01:1.0"
ORG_NUMBER_SCHEME = "0192"  # Norwegian organisation number (Enhetsregisteret)
PLACEHOLDER_DOCUMENT = UUID(int=0)  # the main process sets the real document id


def engine_version() -> str:
    return f"{EHF_PARSER_VERSION}+{metadata.version('defusedxml')}"


def _tag(namespace: str, name: str) -> str:
    return f"{{{namespace}}}{name}"


def _path(spec: str) -> list[str]:
    """``cac:Party/cbc:Name`` -> Clark names, for ElementTree lookups."""
    names = []
    for part in spec.split("/"):
        prefix, name = part.split(":")
        names.append(_tag(CAC if prefix == "cac" else CBC, name))
    return names


def _find(element: Element | None, spec: str) -> Element | None:
    for name in _path(spec):
        if element is None:
            return None
        element = element.find(name)
    return element


def _find_all(element: Element, spec: str) -> list[Element]:
    *parents, last = spec.split("/")
    parent = _find(element, "/".join(parents)) if parents else element
    if parent is None:
        return []
    return parent.findall(_path(last)[0])


def parse_xml(data: bytes) -> Element:
    """Build the tree with ``defusedxml`` and refuse deep or huge documents."""
    depth = 0
    elements = 0
    root = None
    try:
        for event, element in DefusedET.iterparse(
            io.BytesIO(data),
            events=("start", "end"),
            forbid_dtd=True,
            forbid_entities=True,
            forbid_external=True,
        ):
            if event == "start":
                depth += 1
                elements += 1
                if depth > MAX_DEPTH or elements > MAX_ELEMENTS:
                    raise ParserError(ProcessingErrorCode.INVALID_XML)
                if root is None:
                    root = element
            else:
                depth -= 1
    except (DefusedXmlException, ParseError, UnicodeError, ValueError) as exc:
        raise ParserError(ProcessingErrorCode.INVALID_XML) from exc
    if root is None:
        raise ParserError(ProcessingErrorCode.INVALID_XML)
    return root


class _Mapper:
    """Collects canonical values with evidence; counts what could not be read."""

    _adapters: dict[object, TypeAdapter] = {}  # noqa: RUF012 - shared, read-only cache

    def __init__(self, root_name: str, producer: str) -> None:
        self.root_name = root_name
        self.producer = producer
        self.unreadable = 0

    def _adapter(self, kind: object) -> TypeAdapter:
        if kind not in self._adapters:
            self._adapters[kind] = TypeAdapter(kind)
        return self._adapters[kind]

    def value(
        self,
        kind: object,
        raw: str | None,
        xpath: str,
        convert: Callable[[str], Any] = lambda text: text,
    ) -> dict[str, object] | None:
        """A FieldValue as plain data, or ``None`` if the element is absent."""
        if raw is None:
            return None
        evidence = {"source_ref": xpath[:200], "raw_text": raw[:MAX_RAW_TEXT]}
        provenance = {
            "source": "extracted",
            "producer": self.producer,
            "confidence": 1.0,
            "evidence": evidence,
        }
        try:
            candidate = convert(raw.strip())
            value = self._adapter(kind).dump_python(
                self._adapter(kind).validate_python(candidate), mode="json"
            )
        except (ValidationError, ValueError, InvalidOperation, TypeError):
            self.unreadable += 1
            value = None
        return {"value": value, "provenance": provenance}

    def text(self, element: Element | None, spec: str, base: str, kind: object, **kw: Any):
        found = _find(element, spec) if element is not None else None
        if found is None:
            return None
        return self.value(kind, found.text or "", f"{base}/{spec}", **kw)


def _plain(element: Element | None) -> str:
    # An element without children is falsy, so never write "element or default".
    return "" if element is None or element.text is None else element.text.strip()


def _decimal(text: str) -> Decimal:
    """XML schema decimal: digits with an optional sign and point, nothing else."""
    body = text.lstrip("+-")
    if not body or body.count(".") > 1 or not body.replace(".", "").isdigit():
        msg = "not an XML decimal"
        raise ValueError(msg)
    return Decimal(text)


def _amount_text(element: Element | None) -> str | None:
    if element is None or element.text is None:
        return None
    text = element.text.strip()
    try:
        _decimal(text)
    except ValueError:
        return None
    return text


def _party(mapper: _Mapper, party: Element | None, base: str) -> dict[str, object] | None:
    if party is None:
        return None
    name = mapper.text(party, "cac:PartyLegalEntity/cbc:RegistrationName", base, ShortText)
    if name is None:
        name = mapper.text(party, "cac:PartyName/cbc:Name", base, ShortText)
    org = None
    legal = _find(party, "cac:PartyLegalEntity/cbc:CompanyID")
    if legal is not None:
        org = mapper.value(
            OrgNumber, legal.text or "", f"{base}/cac:PartyLegalEntity/cbc:CompanyID"
        )
    vat_registered = None
    foreign_vat = None
    for index, scheme in enumerate(_find_all(party, "cac:PartyTaxScheme"), start=1):
        company = _find(scheme, "cbc:CompanyID")
        tax = _find(scheme, "cac:TaxScheme/cbc:ID")
        if company is None or tax is None or (tax.text or "").strip() != "VAT":
            continue
        xpath = f"{base}/cac:PartyTaxScheme[{index}]/cbc:CompanyID"
        vat_id = (company.text or "").strip()
        vat_registered = mapper.value(Flag, company.text or "", xpath, convert=lambda _: True)
        if not vat_id.startswith("NO"):
            foreign_vat = mapper.value(ForeignVatId, company.text or "", xpath)
        break
    address = None
    postal = _find(party, "cac:PostalAddress")
    if postal is not None:
        address_base = f"{base}/cac:PostalAddress"
        address = {
            "street": mapper.text(postal, "cbc:StreetName", address_base, ShortText),
            "postal_code": mapper.text(postal, "cbc:PostalZone", address_base, PostalCode),
            "city": mapper.text(postal, "cbc:CityName", address_base, ShortText),
            "country_code": mapper.text(
                postal, "cac:Country/cbc:IdentificationCode", address_base, CountryCode
            ),
        }
    return {
        "name": name,
        "org_number": org,
        "vat_registered": vat_registered,
        "foreign_vat_id": foreign_vat,
        "address": address,
    }


def _payment(mapper: _Mapper, root: Element, base: str) -> dict[str, object] | None:
    means = _find(root, "cac:PaymentMeans")
    if means is None:
        return None
    payment_base = f"{base}/cac:PaymentMeans[1]"
    account = _find(means, "cac:PayeeFinancialAccount/cbc:ID")
    bank_account = iban = None
    if account is not None:
        text = account.text or ""
        xpath = f"{payment_base}/cac:PayeeFinancialAccount/cbc:ID"
        compact = text.replace(" ", "").replace(".", "")
        if compact.isdigit():
            bank_account = mapper.value(BankAccount, text, xpath, convert=lambda _: compact)
        else:
            iban = mapper.value(Iban, text, xpath, convert=lambda raw: raw.replace(" ", ""))
    return {
        "kid": mapper.text(means, "cbc:PaymentID", payment_base, Kid),
        "bank_account": bank_account,
        "iban": iban,
        "bic": mapper.text(
            means,
            "cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch/cbc:ID",
            payment_base,
            Bic,
        ),
    }


def _lines(mapper: _Mapper, root: Element, base: str, credit: bool) -> list[dict[str, object]]:
    line_name = "CreditNoteLine" if credit else "InvoiceLine"
    quantity_name = "cbc:CreditedQuantity" if credit else "cbc:InvoicedQuantity"
    elements = root.findall(_tag(CAC, line_name))
    if len(elements) > MAX_INVOICE_LINES:
        raise ParserError(ProcessingErrorCode.TOO_MANY_LINES)
    lines = []
    for number, line in enumerate(elements, start=1):
        line_base = f"{base}/cac:{line_name}[{number}]"
        quantity = _find(line, quantity_name)
        unit = None
        if quantity is not None and quantity.get("unitCode"):
            unit = mapper.value(
                UnitText, quantity.get("unitCode") or "", f"{line_base}/{quantity_name}/@unitCode"
            )
        lines.append(
            {
                "line_number": number,
                "description": mapper.text(line, "cac:Item/cbc:Name", line_base, LongText),
                "quantity": mapper.text(line, quantity_name, line_base, Quantity, convert=_decimal),
                "unit": unit,
                "unit_price": mapper.text(
                    line, "cac:Price/cbc:PriceAmount", line_base, UnitPrice, convert=_decimal
                ),
                "net_amount": mapper.text(
                    line, "cbc:LineExtensionAmount", line_base, Money, convert=_decimal
                ),
                "vat_rate": mapper.text(
                    line,
                    "cac:Item/cac:ClassifiedTaxCategory/cbc:Percent",
                    line_base,
                    VatRate,
                    convert=_decimal,
                ),
            }
        )
    return lines


def _tax_total(root: Element, currency: str | None) -> tuple[int, Element | None]:
    """The TaxTotal in the document currency (the one with subtotals)."""
    totals = root.findall(_tag(CAC, "TaxTotal"))
    for index, total in enumerate(totals, start=1):
        if total.find(_tag(CAC, "TaxSubtotal")) is not None:
            return index, total
    for index, total in enumerate(totals, start=1):
        amount = total.find(_tag(CBC, "TaxAmount"))
        if amount is not None and amount.get("currencyID") == currency:
            return index, total
    return 0, None


def _sum(texts: list[str | None]) -> str | None:
    values = [Decimal(text) for text in texts if text is not None]
    if not values or len(values) != len(texts):
        return None
    return str(sum(values, Decimal(0)))


def map_invoice(root: Element, producer: str) -> tuple[dict[str, object], dict[str, object], int]:
    """Canonical invoice (as data), amounts for checks and the unreadable count."""
    credit = root.tag == _tag(UBL_CREDIT_NOTE, "CreditNote")
    if not credit and root.tag != _tag(UBL_INVOICE, "Invoice"):
        raise ParserError(ProcessingErrorCode.UNSUPPORTED_FORMAT)
    customization = _plain(_find(root, "cbc:CustomizationID"))
    profile = _plain(_find(root, "cbc:ProfileID"))
    if (
        customization != CUSTOMIZATION and not customization.startswith(CUSTOMIZATION + "#")
    ) or profile != PROFILE:
        raise ParserError(ProcessingErrorCode.UNSUPPORTED_VERSION)
    base = "/CreditNote" if credit else "/Invoice"
    mapper = _Mapper(base, producer)
    type_code = "cbc:CreditNoteTypeCode" if credit else "cbc:InvoiceTypeCode"
    kind = InvoiceType.CREDIT_NOTE if credit else InvoiceType.INVOICE
    type_element = _find(root, type_code)
    currency_element = _find(root, "cbc:DocumentCurrencyCode")
    currency = None if currency_element is None else (currency_element.text or "").strip()

    tax_index, tax_total = _tax_total(root, currency)
    tax_base = f"{base}/cac:TaxTotal[{tax_index}]"
    subtotals = [] if tax_total is None else tax_total.findall(_tag(CAC, "TaxSubtotal"))
    if len(subtotals) > MAX_VAT_BREAKDOWN_ENTRIES:
        raise ParserError(ProcessingErrorCode.TOO_MANY_LINES)
    breakdown = []
    for index, subtotal in enumerate(subtotals, start=1):
        sub_base = f"{tax_base}/cac:TaxSubtotal[{index}]"
        breakdown.append(
            {
                "vat_rate": mapper.text(
                    subtotal, "cac:TaxCategory/cbc:Percent", sub_base, VatRate, convert=_decimal
                ),
                "taxable_amount": mapper.text(
                    subtotal, "cbc:TaxableAmount", sub_base, Money, convert=_decimal
                ),
                "vat_amount": mapper.text(
                    subtotal, "cbc:TaxAmount", sub_base, Money, convert=_decimal
                ),
            }
        )
    monetary = _find(root, "cac:LegalMonetaryTotal")
    money_base = f"{base}/cac:LegalMonetaryTotal"
    supplier = _party(
        mapper,
        _find(root, "cac:AccountingSupplierParty/cac:Party"),
        f"{base}/cac:AccountingSupplierParty/cac:Party",
    )
    lines = _lines(mapper, root, base, credit)
    invoice: dict[str, object] = {
        "document_id": str(PLACEHOLDER_DOCUMENT),
        "invoice_type": None
        if type_element is None
        else mapper.value(
            InvoiceType, type_element.text or "", f"{base}/{type_code}", convert=lambda _: kind
        ),
        "invoice_number": mapper.text(root, "cbc:ID", base, Identifier),
        "invoice_date": mapper.text(root, "cbc:IssueDate", base, IsoDate),
        "due_date": mapper.text(root, "cbc:DueDate", base, IsoDate)
        or mapper.text(root, "cac:PaymentMeans/cbc:PaymentDueDate", base, IsoDate),
        "currency": mapper.text(root, "cbc:DocumentCurrencyCode", base, CurrencyCode),
        "referenced_invoice_number": mapper.text(
            root, "cac:BillingReference/cac:InvoiceDocumentReference/cbc:ID", base, Identifier
        ),
        "buyer_reference": mapper.text(root, "cbc:BuyerReference", base, ShortText),
        "supplier": supplier or {},
        "customer": _party(
            mapper,
            _find(root, "cac:AccountingCustomerParty/cac:Party"),
            f"{base}/cac:AccountingCustomerParty/cac:Party",
        ),
        "payment": _payment(mapper, root, base),
        "lines": lines,
        "vat_breakdown": breakdown,
        "totals": {
            "net_amount": mapper.text(
                monetary, "cbc:TaxExclusiveAmount", money_base, Money, convert=_decimal
            ),
            "vat_amount": None
            if tax_total is None
            else mapper.text(tax_total, "cbc:TaxAmount", tax_base, Money, convert=_decimal),
            "rounding_amount": mapper.text(
                monetary, "cbc:PayableRoundingAmount", money_base, Money, convert=_decimal
            ),
            "gross_amount": mapper.text(
                monetary, "cbc:PayableAmount", money_base, Money, convert=_decimal
            ),
        },
    }
    line_tag = "CreditNoteLine" if credit else "InvoiceLine"
    line_amounts = [
        _amount_text(_find(line, "cbc:LineExtensionAmount"))
        for line in root.findall(_tag(CAC, line_tag))
    ]

    def total(name: str) -> str | None:
        return _amount_text(_find(monetary, f"cbc:{name}"))

    # Amounts in the document currency; a second TaxTotal in the accounting
    # currency (BT-111) is allowed by the specification and not compared.
    scopes = [monetary, tax_total, *root.findall(_tag(CAC, line_tag))]
    currencies = sorted(
        {
            element.get("currencyID", "")
            for scope in scopes
            if scope is not None
            for element in scope.iter()
            if element.get("currencyID") is not None
        }
    )
    amounts = {
        "line_sum": _sum(line_amounts),
        "line_extension": total("LineExtensionAmount"),
        "allowance_total": total("AllowanceTotalAmount"),
        "charge_total": total("ChargeTotalAmount"),
        "tax_exclusive": total("TaxExclusiveAmount"),
        "tax_amount": None
        if tax_total is None
        else _amount_text(_find(tax_total, "cbc:TaxAmount")),
        "tax_subtotal_sum": _sum(
            [_amount_text(_find(subtotal, "cbc:TaxAmount")) for subtotal in subtotals]
        )
        if subtotals
        else None,
        "tax_inclusive": total("TaxInclusiveAmount"),
        "prepaid": total("PrepaidAmount"),
        "rounding": total("PayableRoundingAmount"),
        "payable": total("PayableAmount"),
        "currencies": [code for code in currencies if len(code) == 3 and code.isupper()][:10],
    }
    return invoice, amounts, mapper.unreadable


def _strip_empty(data: object) -> object:
    """Drop absent optional parts so the canonical model sees ``None``, not ``{}``."""
    if isinstance(data, dict):
        cleaned = {key: _strip_empty(value) for key, value in data.items()}
        # ``value`` stays even when it is None: that is an unreadable value with evidence.
        return {key: value for key, value in cleaned.items() if value is not None or key == "value"}
    if isinstance(data, list):
        return [_strip_empty(item) for item in data]
    return data


def extract_attachments(root: Element, task: WorkerTask) -> tuple[list[dict[str, object]], int]:
    """Decode embedded attachments into the output folder; count external ones."""
    references = root.findall(_tag(CAC, "AdditionalDocumentReference"))
    attachments = []
    external = 0
    for reference in references:
        binary = _find(reference, "cac:Attachment/cbc:EmbeddedDocumentBinaryObject")
        if binary is None:
            if _find(reference, "cac:Attachment/cac:ExternalReference") is not None:
                external += 1  # a URI is never fetched
            continue
        if len(attachments) >= MAX_EHF_ATTACHMENTS:
            raise ParserError(ProcessingErrorCode.TOO_MANY_ATTACHMENTS)
        text = "".join((binary.text or "").split())
        if len(text) // 4 * 3 > MAX_ATTACHMENT_BYTES:
            raise ParserError(ProcessingErrorCode.ATTACHMENT_TOO_LARGE)
        try:
            content = base64.b64decode(text, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise ParserError(ProcessingErrorCode.INVALID_XML) from exc
        if not content:
            continue
        if len(content) > MAX_ATTACHMENT_BYTES:
            raise ParserError(ProcessingErrorCode.ATTACHMENT_TOO_LARGE)
        name = attachment_name(len(attachments) + 1)
        with (task.output_dir / name).open("xb") as handle:
            handle.write(content)
        filename = (binary.get("filename") or "").strip()[:255] or None
        mime = (binary.get("mimeCode") or "").strip()[:100] or None
        attachments.append(
            {"file": name, "filename": filename, "mime_code": mime, "size_bytes": len(content)}
        )
    return attachments, external


def analyse_ehf(task: WorkerTask, data: bytes) -> bytes:
    """Read one EHF file and return the JSON report. Never raises for bad input."""
    version = engine_version()
    report: dict[str, object] = {
        "result_version": 1,
        "engine": ENGINE,
        "engine_version": version,
        "sha256": task.sha256,
    }
    try:
        root = parse_xml(data)
        invoice, amounts, unreadable = map_invoice(root, f"{ENGINE}/{version}")
        invoice = _strip_empty(invoice)  # type: ignore[assignment]
        # Validate here as well, so a mapping error is reported as a code.
        try:
            CanonicalInvoice.model_validate(invoice)
        except ValidationError as exc:
            raise ParserError(ProcessingErrorCode.INVALID_XML) from exc
        attachments, external = extract_attachments(root, task)
        report |= {
            "status": "ok",
            "invoice": invoice,
            "monetary": _strip_empty(amounts),
            "attachments": attachments,
            "unreadable_values": unreadable,
            "external_attachments": external,
        }
    except ParserError as exc:
        report |= {"status": "error", "error_code": str(exc.code)}
    except MemoryError:
        report |= {"status": "error", "error_code": str(ProcessingErrorCode.MEMORY_LIMIT)}
    except Exception:  # an unexpected failure on hostile input; no message is kept
        report |= {"status": "error", "error_code": str(ProcessingErrorCode.INVALID_XML)}
    return json.dumps(report, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
