"""The ``DocumentParser`` port used inside the worker process (ADR-0023).

An adapter turns the bytes of one original into pages: size, rotation, text
layer with character boxes and a PNG image per page. Any adapter must pass
the shared contract tests in ``tests/contract``; swapping the PDF library
means writing one new adapter, nothing else.
"""

from collections.abc import Iterator
from dataclasses import dataclass
from typing import Protocol

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.processing_model import ProcessingErrorCode, ProcessingLimits

Box = tuple[float, float, float, float]


class ParserError(Exception):
    """The document is refused for a stable reason; no library text is kept."""

    def __init__(self, code: ProcessingErrorCode) -> None:
        super().__init__(str(code))
        self.code = code


@dataclass(frozen=True, slots=True)
class ParsedPage:
    """One page; boxes are normalised to the rendered image (origin top left)."""

    page_number: int
    width_px: int
    height_px: int
    rotation_degrees: int
    text: str
    boxes: tuple[Box, ...]
    png: bytes
    dark_permille: int = 0
    center_dark_permille: int = 0


class OpenedDocument(Protocol):
    page_count: int
    active_content: bool

    def pages(self) -> Iterator[ParsedPage]: ...

    def close(self) -> None: ...


class DocumentParser(Protocol):
    engine: str
    engine_version: str
    formats: frozenset[DocumentFormat]

    def open(
        self, data: bytes, document_format: DocumentFormat, limits: ProcessingLimits
    ) -> OpenedDocument: ...


def scaled_size(width: float, height: float, dpi: int) -> tuple[int, int]:
    """Pixel size of a page given in points (1/72 inch) at ``dpi``."""
    scale = dpi / 72
    return max(1, round(width * scale)), max(1, round(height * scale))


def check_page_size(width_px: int, height_px: int, limits: ProcessingLimits) -> None:
    """Refuse a page before any pixel is allocated for it."""
    if width_px * height_px > limits.max_pixels or max(width_px, height_px) > 100_000:
        raise ParserError(ProcessingErrorCode.PAGE_TOO_LARGE)


def normalise_box(x0: float, y0: float, x1: float, y1: float, width: int, height: int) -> Box:
    """Clamp a pixel box to the image and scale it to 0-1 with five decimals."""

    def unit(value: float, size: int) -> float:
        return round(min(max(value / size, 0.0), 1.0), 5)

    left, right = sorted((unit(x0, width), unit(x1, width)))
    top, bottom = sorted((unit(y0, height), unit(y1, height)))
    return left, top, right, bottom


def text_and_boxes(units: list[tuple[int, Box]]) -> tuple[str, tuple[Box, ...]]:
    """Join UTF-16 code units into text with exactly one box per character.

    A surrogate pair becomes one character with the box of its first unit; a
    lone surrogate or a control character other than tab and line breaks
    becomes U+FFFD, so the text is always valid and printable.
    """
    characters: list[str] = []
    boxes: list[Box] = []
    index = 0
    while index < len(units):
        code, box = units[index]
        if 0xD800 <= code <= 0xDBFF and index + 1 < len(units):
            low = units[index + 1][0]
            if 0xDC00 <= low <= 0xDFFF:
                code = 0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                index += 1
        if 0xD800 <= code <= 0xDFFF or (code < 0x20 and code not in (0x09, 0x0A, 0x0D)):
            code = 0xFFFD
        characters.append(chr(code))
        boxes.append(box)
        index += 1
    return "".join(characters), tuple(boxes)
