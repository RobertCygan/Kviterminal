"""Finding Tesseract and naming its exact version (Phase 05, ADR-0040).

Tesseract is a separate program, not a Python package. It is looked for only
in fixed places: next to the application (bundled from F13), in
``%ProgramFiles%\\Tesseract-OCR`` and, outside Windows, on ``PATH`` for
development. On Windows ``PATH`` is never searched, so a ``tesseract.exe`` in
the current or a user-writable folder is not picked up.

The engine version names the program version, our output format and a hash
of each language file, so new language data means a new OCR run.
"""

import hashlib
import os
import re
import shutil
import subprocess  # nosec B404
import sys
from dataclasses import dataclass
from pathlib import Path

from invoiceflow.application.processing_model import OCR_FORMAT_VERSION, OcrSettings
from invoiceflow.processing.ocr_tesseract import child_environment

PROBE_TIMEOUT_SECONDS = 15.0
MAX_PROBE_BYTES = 64 * 1024
_VERSION = re.compile(r"tesseract v?([0-9]+\.[0-9]+\.[0-9]+(?:\.[0-9]+)?)")
_LANGUAGES_HEADER = re.compile(r'List of available languages in "(.+)" \([0-9]+\):')
_LANGUAGE = re.compile(r"[a-z]{3}")
MIN_MAJOR_VERSION = 5


@dataclass(frozen=True, slots=True)
class TesseractInstall:
    executable: Path
    version: str
    tessdata: Path
    languages: frozenset[str]

    def engine_version(self, settings: OcrSettings) -> str | None:
        """``5.3.4+ocr1+1a2b3c4d``; ``None`` if a language file is missing."""
        digest = hashlib.sha256()
        for language in settings.language.split("+"):
            path = self.tessdata / f"{language}.traineddata"
            if language not in self.languages or not path.is_file():
                return None
            with path.open("rb") as handle:
                while chunk := handle.read(1024 * 1024):
                    digest.update(chunk)
        return f"{self.version[:16]}+{OCR_FORMAT_VERSION}+{digest.hexdigest()[:8]}"


def default_candidates() -> list[Path]:
    if sys.platform == "win32":
        program_files = Path(os.environ.get("PROGRAMFILES", r"C:\Program Files"))
        return [
            Path(sys.executable).resolve().parent / "tesseract" / "tesseract.exe",
            program_files / "Tesseract-OCR" / "tesseract.exe",
        ]
    found = shutil.which("tesseract")
    return [Path(found)] if found else []


def _output(executable: Path, *arguments: str) -> str | None:
    try:
        completed = subprocess.run(  # noqa: S603  # nosec B603
            [str(executable), *arguments],
            capture_output=True,
            timeout=PROBE_TIMEOUT_SECONDS,
            env=child_environment(None),
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if completed.returncode != 0:
        return None
    return (completed.stdout + completed.stderr)[:MAX_PROBE_BYTES].decode("utf-8", "replace")


def probe(executable: Path) -> TesseractInstall | None:
    """Version and language data of one ``tesseract`` program, or ``None``."""
    if not executable.is_file():
        return None
    version_text = _output(executable, "--version")
    languages_text = _output(executable, "--list-langs")
    if version_text is None or languages_text is None:
        return None
    version = _VERSION.search(version_text)
    lines = languages_text.splitlines()
    header = _LANGUAGES_HEADER.fullmatch(lines[0].strip()) if lines else None
    if version is None or header is None:
        return None
    if int(version.group(1).split(".")[0]) < MIN_MAJOR_VERSION:
        return None
    languages = frozenset(line.strip() for line in lines[1:] if _LANGUAGE.fullmatch(line.strip()))
    tessdata = Path(header.group(1))
    if not tessdata.is_absolute():
        tessdata = executable.parent / tessdata
    return TesseractInstall(executable, version.group(1), tessdata, languages)


def locate(candidates: list[Path] | None = None) -> TesseractInstall | None:
    """The first usable Tesseract among the candidates."""
    for candidate in default_candidates() if candidates is None else candidates:
        install = probe(candidate)
        if install is not None:
            return install
    return None
