"""OCR of page images with Tesseract inside the worker (Phase 05, ADR-0040).

The worker reads the page images the service copied into its folder, checks
each against its hash and runs ``tesseract`` once per page as a child
process: no shell, fixed arguments, a minimal environment, the PNG on
standard input, TSV on standard output and a deadline. On Windows the child
runs in the worker's Job Object (two active processes allowed), so the memory
limit and kill-on-close apply to it too.

The TSV is parsed here, in the worker. Only words with a box, a confidence and
a line number leave it, as one ``ocr-0001.json`` per page; the recognised text
is data and never reaches a log or the audit chain.
"""

import hashlib
import json
import os
import subprocess  # nosec B404
import unicodedata
from pathlib import Path
from typing import NamedTuple

from invoiceflow.application.ports import OcrInput, OcrTask, WorkerTask
from invoiceflow.application.processing_model import (
    MAX_CONFIDENCE,
    MAX_OCR_WORDS,
    MAX_WORD_CHARS,
    OCR_ENGINE,
    RESULT_VERSION,
    OcrSettings,
    ProcessingErrorCode,
    ocr_name,
)
from invoiceflow.processing.parser import ParserError, normalise_box

MAX_INPUT_BYTES = 256 * 1024 * 1024
MAX_TSV_BYTES = 16 * 1024 * 1024
TSV_COLUMNS = (
    "level",
    "page_num",
    "block_num",
    "par_num",
    "line_num",
    "word_num",
    "left",
    "top",
    "width",
    "height",
    "conf",
    "text",
)
_WORD_LEVEL = "5"
_UNPRINTABLE = frozenset({"Cc", "Cf", "Cs", "Co", "Cn"})


class Word(NamedTuple):
    text: str
    box: tuple[float, float, float, float]
    confidence: int
    line: int


def child_environment(tessdata: Path | None) -> dict[str, str]:
    """Only what Tesseract needs; one thread keeps memory and results predictable."""
    environment = {"OMP_THREAD_LIMIT": "1"}
    if tessdata is not None:
        environment["TESSDATA_PREFIX"] = str(tessdata)
    if "SYSTEMROOT" in os.environ:  # Windows system libraries
        environment["SYSTEMROOT"] = os.environ["SYSTEMROOT"]
    return environment


def run_tesseract(
    executable: Path, tessdata: Path | None, settings: OcrSettings, png: bytes, timeout: float
) -> bytes:
    """TSV output for one page image; any failure is ``ocr_failed`` without detail."""
    command = [
        str(executable),
        "stdin",
        "stdout",
        "-l",
        settings.language,
        "--psm",
        str(settings.page_segmentation),
        # A parameter, not the "tsv" config file, which a data folder may lack.
        "-c",
        "tessedit_create_tsv=1",
    ]
    try:
        completed = subprocess.run(  # noqa: S603  # nosec B603
            command,
            input=png,
            capture_output=True,
            timeout=timeout,
            env=child_environment(tessdata),
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise ParserError(ProcessingErrorCode.OCR_FAILED) from exc
    if completed.returncode != 0:
        raise ParserError(ProcessingErrorCode.OCR_FAILED)
    if len(completed.stdout) > MAX_TSV_BYTES:
        raise ParserError(ProcessingErrorCode.OUTPUT_TOO_LARGE)
    return completed.stdout


def clean_word(text: str) -> str:
    """NFC, no control or private characters, no outer spaces, bounded length."""
    text = " ".join(unicodedata.normalize("NFC", text).split())
    return "".join(
        "\N{REPLACEMENT CHARACTER}" if unicodedata.category(char) in _UNPRINTABLE else char
        for char in text
    )[:MAX_WORD_CHARS]


def _number(value: str) -> int:
    number = int(value)
    if number < 0:
        raise ValueError("negative")
    return number


def parse_tsv(data: bytes, width_px: int, height_px: int) -> list[Word]:
    """Words in reading order with normalised boxes and their line number."""
    rows = data.decode("utf-8", errors="replace").splitlines()
    if not rows or tuple(rows[0].split("\t")) != TSV_COLUMNS:
        raise ParserError(ProcessingErrorCode.OCR_FAILED)
    words: list[Word] = []
    line = -1
    last_key: tuple[int, int, int] | None = None
    for row in rows[1:]:
        fields = row.split("\t")
        if len(fields) != len(TSV_COLUMNS):
            raise ParserError(ProcessingErrorCode.OCR_FAILED)
        if fields[0] != _WORD_LEVEL:
            continue
        text = clean_word(fields[11])
        if not text:
            continue
        try:
            key = (_number(fields[2]), _number(fields[3]), _number(fields[4]))
            left, top, width, height = (_number(value) for value in fields[6:10])
            confidence = float(fields[10])
        except ValueError as exc:
            raise ParserError(ProcessingErrorCode.OCR_FAILED) from exc
        if confidence != confidence:  # NaN
            raise ParserError(ProcessingErrorCode.OCR_FAILED)
        if key != last_key:
            line += 1
            last_key = key
        if len(words) == MAX_OCR_WORDS:
            raise ParserError(ProcessingErrorCode.TOO_MUCH_TEXT)
        words.append(
            Word(
                text,
                normalise_box(left, top, left + width, top + height, width_px, height_px),
                min(max(round(confidence), 0), MAX_CONFIDENCE),
                line,
            )
        )
    return words


def page_text(words: list[Word]) -> str:
    """The same text as ``OcrLayer.text``: words by spaces, lines by line breaks."""
    lines: list[list[str]] = []
    for word in words:
        if word.line == len(lines):
            lines.append([])
        lines[-1].append(word.text)
    return "\n".join(" ".join(line) for line in lines)


def _read_input(directory: Path, page: OcrInput) -> bytes:
    with (directory / page.name).open("rb") as handle:
        data = handle.read(MAX_INPUT_BYTES + 1)
    if len(data) > MAX_INPUT_BYTES or hashlib.sha256(data).hexdigest() != page.sha256:
        raise ParserError(ProcessingErrorCode.SOURCE_CHANGED)
    return data


def _recognise_page(
    task: WorkerTask, ocr: OcrTask, page: OcrInput
) -> tuple[dict[str, object], bytes]:
    if ocr.executable is None:
        raise ParserError(ProcessingErrorCode.OCR_FAILED)
    png = _read_input(task.output_dir, page)
    tsv = run_tesseract(ocr.executable, ocr.tessdata, ocr.settings, png, ocr.page_timeout_seconds)
    del png
    words = parse_tsv(tsv, page.width_px, page.height_px)
    text = page_text(words)
    if len(text) > task.limits.max_chars_per_page:
        raise ParserError(ProcessingErrorCode.TOO_MUCH_TEXT)
    layer = json.dumps(
        {
            "result_version": RESULT_VERSION,
            "page_number": page.page_number,
            "language": ocr.settings.language,
            "words": [word._asdict() for word in words],
        },
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    confidences = [word.confidence for word in words]
    entry: dict[str, object] = {
        "page_number": page.page_number,
        "file": ocr_name(page.page_number),
        "word_count": len(words),
        "line_count": words[-1].line + 1 if words else 0,
        "char_count": len(text),
        "mean_confidence": round(sum(confidences) / len(confidences)) if confidences else 0,
        "low_confidence_words": sum(
            confidence < ocr.settings.low_confidence for confidence in confidences
        ),
    }
    return entry, layer


def analyse_ocr(task: WorkerTask) -> bytes:
    """Recognise every named page image and return the JSON report."""
    ocr = task.ocr
    report: dict[str, object] = {
        "result_version": RESULT_VERSION,
        "engine": OCR_ENGINE,
        "engine_version": ocr.engine_version if ocr is not None else "unknown",
        "sha256": task.sha256,
    }
    try:
        if ocr is None or not ocr.pages:
            raise ParserError(ProcessingErrorCode.OCR_FAILED)
        pages = []
        written = 0
        for page in ocr.pages:
            entry, layer = _recognise_page(task, ocr, page)
            written += len(layer)
            if written > task.limits.max_output_bytes:
                raise ParserError(ProcessingErrorCode.OUTPUT_TOO_LARGE)
            with (task.output_dir / ocr_name(page.page_number)).open("xb") as handle:
                handle.write(layer)
            pages.append(entry)
        report |= {"status": "ok", "pages": pages}
    except ParserError as exc:
        report |= {"status": "error", "error_code": str(exc.code)}
    except OSError:
        report |= {"status": "error", "error_code": str(ProcessingErrorCode.SOURCE_CHANGED)}
    except MemoryError:
        report |= {"status": "error", "error_code": str(ProcessingErrorCode.MEMORY_LIMIT)}
    return json.dumps(report, separators=(",", ":")).encode("ascii")
