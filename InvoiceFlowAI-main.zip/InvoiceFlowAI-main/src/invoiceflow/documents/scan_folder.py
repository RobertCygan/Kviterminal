"""The watched scan folder on the local file system (Phase 11a).

Scanner software writes files into the inbox folder. A file is handed over
only when it has kept the same size and modification time since the previous
look and is a little older than that, so a file still being written is never
imported half. After import the file is moved out of the way, into
``importert`` (imported or already known) or ``avvist`` (refused or put in
quarantine); the original stays in the archive either way.
"""

import contextlib
import os
import stat
import time
import uuid
from collections.abc import Callable
from pathlib import Path

from invoiceflow.application.document_model import ImportOutcome
from invoiceflow.application.ports import StorageError

IMPORTED_FOLDER = "importert"
REFUSED_FOLDER = "avvist"
_REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)


def _is_link(info: os.stat_result) -> bool:
    if stat.S_ISLNK(info.st_mode):
        return True
    return bool((getattr(info, "st_file_attributes", 0) or 0) & _REPARSE_POINT)


class FileScanFolder:
    """Implements :class:`invoiceflow.application.ports.ScanFolder`."""

    def __init__(
        self,
        *,
        min_age_seconds: float = 2.0,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self._min_age = min_age_seconds
        self._clock = clock
        self._seen: dict[Path, tuple[int, int]] = {}

    def ready_files(self, folder: Path) -> list[Path]:
        """Regular files directly in ``folder`` that did not change since the last look."""
        current: dict[Path, tuple[int, int]] = {}
        ready = []
        now = self._clock()
        try:
            with os.scandir(folder) as entries:
                for entry in entries:
                    info = entry.stat(follow_symlinks=False)
                    if _is_link(info) or not stat.S_ISREG(info.st_mode):
                        continue
                    if entry.name.startswith(("~", ".")):
                        continue  # temporary files of scanner software
                    path = Path(entry.path)
                    signature = (info.st_size, info.st_mtime_ns)
                    current[path] = signature
                    stable = self._seen.get(path) == signature and info.st_size > 0
                    if stable and now - info.st_mtime_ns / 1e9 >= self._min_age:
                        ready.append(path)
        except OSError as exc:
            msg = "scan folder could not be read"
            raise StorageError(msg) from exc
        self._seen = current
        return sorted(ready, key=lambda path: path.name)

    def set_aside(self, folder: Path, source: Path, outcome: ImportOutcome) -> None:
        """Move a handled file into ``importert`` or ``avvist``; never overwrite."""
        target_dir = folder / (
            IMPORTED_FOLDER
            if outcome in (ImportOutcome.IMPORTED, ImportOutcome.DUPLICATE)
            else REFUSED_FOLDER
        )
        try:
            target_dir.mkdir(exist_ok=True)
            if _is_link(os.lstat(target_dir)):
                msg = "set-aside folder is a link"
                raise StorageError(msg)
            target = target_dir / source.name
            if os.path.lexists(target):
                target = target_dir / f"{source.stem}-{uuid.uuid4().hex[:8]}{source.suffix}"
            os.rename(source, target)  # same folder tree: never copies, never replaces
        except OSError as exc:
            msg = "scanned file could not be moved"
            raise StorageError(msg) from exc
        finally:
            self._seen.pop(source, None)

    def write_file(self, destination: Path, data: bytes) -> None:
        """Write a file where the person chose (the separator sheet)."""
        temporary = destination.with_name(f".{uuid.uuid4().hex}.part")
        try:
            with temporary.open("xb") as handle:
                handle.write(data)
            os.replace(temporary, destination)
        except OSError as exc:
            with contextlib.suppress(OSError):
                temporary.unlink(missing_ok=True)
            msg = "file could not be written"
            raise StorageError(msg) from exc
