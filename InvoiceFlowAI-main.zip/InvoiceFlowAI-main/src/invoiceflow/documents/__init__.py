"""File-system adapters for the document archive (Phase 03)."""
