"""Content-addressed original archive on the local file system (ADR-0029).

Layout below the store root (``<data>/documents``)::

    <entity_hex>/staging/<uuid>.part          private copies being imported
    <entity_hex>/originals/ab/cd/<sha256>.ext  published originals, read-only
    <entity_hex>/quarantine/<uuid>.bin         suspicious files, never opened again
    <entity_hex>/orphans/<name>                originals found without a database row

Paths are built only from identifiers and hashes, never from user file names.
Nothing in this module deletes an original or quarantined file.
"""

import contextlib
import hashlib
import os
import stat
import sys
import threading
import time
from collections.abc import Callable
from pathlib import Path
from uuid import UUID, uuid4

from invoiceflow.application.document_model import HEADER_BYTES, IntegrityStatus, RejectReason
from invoiceflow.application.ports import StagedFile, StagingError, StorageError, StoreRecovery

CHUNK_SIZE = 1024 * 1024
_READ_ONLY = stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH
_REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
# On Windows a file being replaced cannot be opened for a moment, so concurrent
# imports of the same content must not check and publish at the same time.
# One application instance per data directory (QLockFile) makes this enough.
_PUBLISH_LOCK = threading.Lock()
# Antivirus, search indexing or backup software can hold a new file open for a
# moment on Windows, so renaming or deleting it fails with PermissionError.
_LOCK_RETRY_DELAYS = (0.05, 0.1, 0.2, 0.4, 0.8)


def _is_link(info: os.stat_result) -> bool:
    """Symbolic links and, on Windows, junctions and other reparse points."""
    if stat.S_ISLNK(info.st_mode):
        return True
    return bool((getattr(info, "st_file_attributes", 0) or 0) & _REPARSE_POINT)


def _fsync_directory(directory: Path) -> None:
    # Windows cannot open directories for fsync; NTFS journals the rename.
    if sys.platform == "win32":
        return
    descriptor = os.open(directory, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _retry_locked[T](operation: Callable[[], T], sleep: Callable[[float], None]) -> T:
    """Run a rename or delete again while another program briefly holds the file."""
    for delay in _LOCK_RETRY_DELAYS:
        try:
            return operation()
        except PermissionError:
            sleep(delay)
    return operation()


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(CHUNK_SIZE):
            digest.update(chunk)
    return digest.hexdigest()


class FileDocumentStore:
    """Implements :class:`invoiceflow.application.ports.DocumentStore`."""

    def __init__(
        self,
        root: Path,
        *,
        new_id: Callable[[], UUID] = uuid4,
        fsync: Callable[[int], None] = os.fsync,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self.root = root
        self._new_id = new_id
        self._fsync = fsync
        self._sleep = sleep

    # -- paths ------------------------------------------------------------

    def _entity_dir(self, entity_id: UUID) -> Path:
        return self.root / entity_id.hex

    def _relative(self, path: Path) -> str:
        return path.relative_to(self.root).as_posix()

    def resolve(self, storage_path: str) -> Path:
        """Absolute path of a stored file; rejects anything outside the root."""
        candidate = (self.root / storage_path).resolve()
        if not candidate.is_relative_to(self.root.resolve()) or ".." in storage_path.split("/"):
            msg = "storage path outside the archive"
            raise StorageError(msg)
        return candidate

    def _directory(self, path: Path) -> Path:
        path.mkdir(parents=True, exist_ok=True)
        info = os.lstat(path)
        if _is_link(info) or not path.resolve().is_relative_to(self.root.resolve()):
            msg = "archive directory is a link"
            raise StorageError(msg)
        return path

    # -- import -------------------------------------------------------------

    def stage(self, source: Path, entity_id: UUID, max_bytes: int) -> StagedFile:
        try:
            before = os.lstat(source)
        except OSError as exc:
            raise StagingError(RejectReason.UNREADABLE) from exc
        if _is_link(before) or not stat.S_ISREG(before.st_mode):
            raise StagingError(RejectReason.NOT_A_FILE)
        if before.st_size == 0:
            raise StagingError(RejectReason.EMPTY)
        if before.st_size > max_bytes:
            raise StagingError(RejectReason.TOO_LARGE)
        staging = self._directory(self._entity_dir(entity_id) / "staging")
        target = staging / f"{self._new_id().hex}.part"
        digest = hashlib.sha256()
        header = b""
        total = 0
        try:
            with source.open("rb") as reader, target.open("xb") as writer:
                while chunk := reader.read(CHUNK_SIZE):
                    total += len(chunk)
                    if total > max_bytes:
                        raise StagingError(RejectReason.TOO_LARGE)
                    if len(header) < HEADER_BYTES:
                        header = (header + chunk)[:HEADER_BYTES]
                    digest.update(chunk)
                    writer.write(chunk)
                writer.flush()
                self._fsync(writer.fileno())
            after = os.stat(source)
        except StagingError:
            target.unlink(missing_ok=True)
            raise
        except OSError as exc:
            target.unlink(missing_ok=True)
            raise StagingError(RejectReason.UNREADABLE) from exc
        if (after.st_size, after.st_mtime_ns) != (before.st_size, before.st_mtime_ns) or (
            total != before.st_size
        ):
            target.unlink(missing_ok=True)
            raise StagingError(RejectReason.CHANGED)
        if total == 0:
            target.unlink(missing_ok=True)
            raise StagingError(RejectReason.EMPTY)
        return StagedFile(self._relative(target), digest.hexdigest(), total, header)

    def publish(self, staged: StagedFile, entity_id: UUID, sha256: str, extension: str) -> str:
        if sha256 != staged.sha256 or not extension.isalnum():
            msg = "inconsistent publish request"
            raise StorageError(msg)
        directory = self._directory(
            self._entity_dir(entity_id) / "originals" / sha256[:2] / sha256[2:4]
        )
        final = directory / f"{sha256}.{extension}"
        temporary = self.resolve(staged.token)
        with _PUBLISH_LOCK:
            return self._publish(temporary, final, directory, sha256)

    def _publish(self, temporary: Path, final: Path, directory: Path, sha256: str) -> str:
        try:
            if final.exists():
                # Content-addressed: an identical earlier copy (e.g. after a crash)
                # is reused; a different content under the same name is corruption.
                if _hash_file(final) != sha256:
                    msg = "existing original does not match its hash"
                    raise StorageError(msg)
                temporary.unlink(missing_ok=True)
                return self._relative(final)
            if _hash_file(temporary) != sha256:
                msg = "staged copy changed before publishing"
                raise StorageError(msg)
            try:
                _retry_locked(lambda: os.replace(temporary, final), self._sleep)
            except OSError:
                # Windows refuses to replace a read-only copy that another
                # writer published first; identical content is success.
                if not final.exists() or _hash_file(final) != sha256:
                    raise
                temporary.unlink(missing_ok=True)
                return self._relative(final)
            os.chmod(final, _READ_ONLY)
            _fsync_directory(directory)
        except OSError as exc:
            msg = "original could not be published"
            raise StorageError(msg) from exc
        return self._relative(final)

    def quarantine(self, staged: StagedFile, entity_id: UUID, quarantine_id: UUID) -> str:
        directory = self._directory(self._entity_dir(entity_id) / "quarantine")
        final = directory / f"{quarantine_id.hex}.bin"
        source = self.resolve(staged.token)
        try:
            _retry_locked(lambda: os.replace(source, final), self._sleep)
            os.chmod(final, _READ_ONLY)
            _fsync_directory(directory)
        except OSError as exc:
            msg = "file could not be quarantined"
            raise StorageError(msg) from exc
        return self._relative(final)

    def discard(self, staged: StagedFile) -> None:
        # On failure, startup reconciliation removes staging leftovers.
        with contextlib.suppress(OSError):
            self.resolve(staged.token).unlink(missing_ok=True)

    # -- checks ---------------------------------------------------------------

    def verify(self, storage_path: str, sha256: str) -> IntegrityStatus:
        try:
            path = self.resolve(storage_path)
            # resolve() follows links, so compare with the path as stored: a link
            # anywhere in it (e.g. an original replaced by a link to an identical
            # file) is never an intact original.
            if path != self.root.resolve() / storage_path:
                return IntegrityStatus.MISMATCH
            info = os.lstat(path)
            if _is_link(info) or not stat.S_ISREG(info.st_mode):
                return IntegrityStatus.MISMATCH
            return IntegrityStatus.OK if _hash_file(path) == sha256 else IntegrityStatus.MISMATCH
        except FileNotFoundError:
            return IntegrityStatus.MISSING
        except (OSError, StorageError):
            return IntegrityStatus.MISMATCH

    def list_candidates(self, directory: Path) -> list[Path]:
        """Regular files directly in ``directory``; links and folders are skipped."""
        candidates = []
        try:
            with os.scandir(directory) as entries:
                for entry in entries:
                    info = entry.stat(follow_symlinks=False)
                    if not _is_link(info) and stat.S_ISREG(info.st_mode):
                        candidates.append(Path(entry.path))
        except OSError as exc:
            msg = "inbox could not be read"
            raise StorageError(msg) from exc
        return sorted(candidates, key=lambda path: path.name)

    def recover(self, entity_id: UUID, known_paths: frozenset[str]) -> StoreRecovery:
        base = self._entity_dir(entity_id)
        staging_removed = 0
        orphans_moved = 0
        failed = 0
        staging = base / "staging"
        if staging.is_dir():
            for leftover in staging.glob("*.part"):
                try:
                    _retry_locked(lambda path=leftover: path.unlink(missing_ok=True), self._sleep)
                except OSError:
                    failed += 1  # a locked leftover must not stop the application
                    continue
                staging_removed += 1
        for folder in ("originals", "quarantine"):
            root = base / folder
            if not root.is_dir():
                continue
            for path in sorted(root.rglob("*")):
                if not path.is_file() or _is_link(os.lstat(path)):
                    continue
                if self._relative(path) in known_paths:
                    continue
                orphans = self._directory(base / "orphans")
                target = orphans / f"{self._new_id().hex}-{path.name}"
                try:
                    _retry_locked(
                        lambda path=path, target=target: os.replace(path, target), self._sleep
                    )
                except OSError:
                    failed += 1  # stays where it is; nothing is deleted
                    continue
                orphans_moved += 1
        missing = frozenset(
            storage_path for storage_path in known_paths if not (self.root / storage_path).is_file()
        )
        return StoreRecovery(staging_removed, orphans_moved, missing, failed)
