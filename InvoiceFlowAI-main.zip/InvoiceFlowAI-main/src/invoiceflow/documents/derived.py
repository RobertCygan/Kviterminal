"""Derived files (page images, text layers) apart from the originals (Phase 04).

Layout below the store root (``<data>/documents``), next to the F03 folders::

    <entity_hex>/work/<job_hex>/                    the worker's private output folder
    <entity_hex>/derived/<document_hex>/<job_hex>/  published files, read-only
    <entity_hex>/orphans/derived-<job_hex>-<n>/     published files of a job that never finished

Names inside a job folder come only from the fixed patterns of
``processing_model`` (``page-0001.png``, ``text-0001.json``, for OCR
``ocr-0001.json``, and for EHF ``attachment-01.bin``, which is imported as a
document, not published here); anything else the worker leaves behind is
never published. The page images an OCR job reads are copied into its work
folder as ``input-0001.png`` and discarded with it. Nothing here touches ``originals``
or ``quarantine``, and published derived files are moved, never deleted.
"""

import contextlib
import hashlib
import os
import re
import shutil
import stat
import time
from collections.abc import Callable, Mapping, Sequence
from pathlib import Path
from uuid import UUID

from invoiceflow.application.ports import (
    DerivedRecovery,
    StorageError,
    WorkFile,
    WorkOutputError,
)
from invoiceflow.application.processing_model import ProcessingErrorCode
from invoiceflow.documents.store import _fsync_directory, _is_link, _retry_locked

CHUNK_SIZE = 1024 * 1024
HEADER_BYTES = 32
_READ_ONLY = stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH
_NAME = re.compile(
    r"page-[0-9]{4}\.png|(text|ocr)-[0-9]{4}\.json|attachment-[0-9]{2}\.bin|input-[0-9]{4}\.png"
)
_INPUT = re.compile(r"input-[0-9]{4}\.png")
_HEX32 = re.compile(r"[0-9a-f]{32}")


def _remove_read_only(function: object, target: str, error: BaseException) -> None:
    os.chmod(target, stat.S_IWRITE | stat.S_IREAD)
    os.unlink(target)


class FileDerivedStore:
    """Implements :class:`invoiceflow.application.ports.DerivedStore`."""

    def __init__(self, root: Path, *, sleep: Callable[[float], None] = time.sleep) -> None:
        self.root = root
        self._sleep = sleep

    def _entity_dir(self, entity_id: UUID) -> Path:
        return self.root / entity_id.hex

    def _relative(self, path: Path) -> str:
        return path.relative_to(self.root).as_posix()

    def _directory(self, path: Path) -> Path:
        path.mkdir(parents=True, exist_ok=True)
        if _is_link(os.lstat(path)) or not path.resolve().is_relative_to(self.root.resolve()):
            msg = "archive directory is a link"
            raise StorageError(msg)
        return path

    def _within_work(self, work_dir: Path) -> Path:
        """``<entity_hex>/work/<job_hex>`` below this root, reached without a link."""
        resolved = work_dir.resolve()
        try:
            parts = resolved.relative_to(self.root.resolve()).parts
            is_link = _is_link(os.lstat(work_dir))
        except (ValueError, OSError) as exc:
            msg = "not a work folder of this store"
            raise StorageError(msg) from exc
        if (
            is_link
            or len(parts) != 3
            or parts[1] != "work"
            or not (_HEX32.fullmatch(parts[0]) and _HEX32.fullmatch(parts[2]))
        ):
            msg = "not a work folder of this store"
            raise StorageError(msg)
        return resolved

    # -- worker output -----------------------------------------------------

    def create_work_dir(self, entity_id: UUID, job_id: UUID) -> Path:
        work = self._directory(self._entity_dir(entity_id) / "work")
        target = work / job_id.hex
        try:
            target.mkdir()
        except OSError as exc:
            msg = "work folder could not be created"
            raise StorageError(msg) from exc
        return target

    def _regular_file(self, work_dir: Path, name: str) -> Path:
        if not _NAME.fullmatch(name):
            raise WorkOutputError(ProcessingErrorCode.INVALID_RESULT)
        path = self._within_work(work_dir) / name
        try:
            info = os.lstat(path)
        except FileNotFoundError as exc:
            raise WorkOutputError(ProcessingErrorCode.INVALID_RESULT) from exc
        except OSError as exc:
            msg = "work file could not be read"
            raise StorageError(msg) from exc
        if _is_link(info) or not stat.S_ISREG(info.st_mode) or info.st_size == 0:
            raise WorkOutputError(ProcessingErrorCode.INVALID_RESULT)
        return path

    def inspect(
        self, work_dir: Path, names: Sequence[str], max_total_bytes: int
    ) -> dict[str, WorkFile]:
        """Hash every promised file; refuse links, gaps and oversized output."""
        files: dict[str, WorkFile] = {}
        total = 0
        for name in names:
            path = self._regular_file(work_dir, name)
            digest = hashlib.sha256()
            header = b""
            size = 0
            try:
                with path.open("rb") as handle:
                    while chunk := handle.read(CHUNK_SIZE):
                        size += len(chunk)
                        total += len(chunk)
                        if total > max_total_bytes:
                            raise WorkOutputError(ProcessingErrorCode.OUTPUT_TOO_LARGE)
                        if len(header) < HEADER_BYTES:
                            header = (header + chunk)[:HEADER_BYTES]
                        digest.update(chunk)
            except OSError as exc:
                msg = "work file could not be read"
                raise StorageError(msg) from exc
            files[name] = WorkFile(name, size, digest.hexdigest(), header)
        return files

    def work_file(self, work_dir: Path, name: str) -> Path:
        """A checked worker file (regular, no link, fixed name) for importing it."""
        return self._regular_file(work_dir, name)

    def put_work_file(self, work_dir: Path, name: str, data: bytes) -> None:
        """Give the worker an input file; never replaces anything."""
        if not _INPUT.fullmatch(name):
            msg = "not an input file name"
            raise StorageError(msg)
        path = self._within_work(work_dir) / name
        try:
            with path.open("xb") as handle:
                handle.write(data)
        except OSError as exc:
            msg = "work file could not be written"
            raise StorageError(msg) from exc

    def read(self, work_dir: Path, name: str, max_bytes: int) -> bytes:
        path = self._regular_file(work_dir, name)
        try:
            with path.open("rb") as handle:
                data = handle.read(max_bytes + 1)
        except OSError as exc:
            msg = "work file could not be read"
            raise StorageError(msg) from exc
        if len(data) > max_bytes:
            raise WorkOutputError(ProcessingErrorCode.OUTPUT_TOO_LARGE)
        return data

    def publish(
        self,
        entity_id: UUID,
        document_id: UUID,
        job_id: UUID,
        work_dir: Path,
        files: Mapping[str, WorkFile],
    ) -> dict[str, str]:
        """Move the inspected files into the job's derived folder, read-only.

        Each file is hashed again first: it must be exactly what was inspected.
        """
        target = self._entity_dir(entity_id) / "derived" / document_id.hex / job_id.hex
        self._directory(target.parent)
        try:
            target.mkdir()
        except OSError as exc:
            msg = "derived folder already exists"
            raise StorageError(msg) from exc
        published: dict[str, str] = {}
        for name, expected in files.items():
            source = self._regular_file(work_dir, name)
            try:
                digest = hashlib.sha256()
                with source.open("rb") as handle:
                    while chunk := handle.read(CHUNK_SIZE):
                        digest.update(chunk)
                if digest.hexdigest() != expected.sha256:
                    raise WorkOutputError(ProcessingErrorCode.INVALID_RESULT)
                final = target / name
                _retry_locked(
                    lambda source=source, final=final: os.replace(source, final), self._sleep
                )
                os.chmod(final, _READ_ONLY)
            except OSError as exc:
                msg = "derived file could not be published"
                raise StorageError(msg) from exc
            published[name] = self._relative(final)
        _fsync_directory(target)
        return published

    def read_published(self, storage_path: str, sha256: str, max_bytes: int) -> bytes | None:
        """A published derived file if it is intact; ``None`` if missing, linked or changed."""
        parts = storage_path.split("/")
        if len(parts) != 5 or parts[1] != "derived" or any(p in ("", ".", "..") for p in parts):
            return None
        path = self.root.joinpath(*parts)
        try:
            info = os.lstat(path)
            if _is_link(info) or not stat.S_ISREG(info.st_mode) or info.st_size > max_bytes:
                return None
            with path.open("rb") as handle:
                data = handle.read(max_bytes + 1)
        except OSError:
            return None
        if len(data) > max_bytes or hashlib.sha256(data).hexdigest() != sha256:
            return None
        return data

    def discard_work(self, work_dir: Path) -> None:
        # Unvalidated worker output is scratch data; recovery retries on failure.
        with contextlib.suppress(OSError, StorageError):
            shutil.rmtree(self._within_work(work_dir), onexc=_remove_read_only)

    # -- recovery ------------------------------------------------------------

    def recover(self, entity_id: UUID, succeeded_jobs: frozenset[UUID]) -> DerivedRecovery:
        """Remove work folders; move job folders without a successful job aside."""
        base = self._entity_dir(entity_id)
        work_removed = moved = failed = 0
        work = base / "work"
        if work.is_dir() and not _is_link(os.lstat(work)):
            for folder in sorted(work.iterdir()):
                try:
                    if _is_link(os.lstat(folder)):
                        folder.unlink()
                    else:
                        shutil.rmtree(folder, onexc=_remove_read_only)
                except OSError:
                    failed += 1
                    continue
                work_removed += 1
        derived = base / "derived"
        if derived.is_dir() and not _is_link(os.lstat(derived)):
            succeeded = {job.hex for job in succeeded_jobs}
            for document in sorted(derived.iterdir()):
                if not document.is_dir() or _is_link(os.lstat(document)):
                    continue
                for job in sorted(document.iterdir()):
                    if job.name in succeeded or not _HEX32.fullmatch(job.name):
                        continue
                    orphans = self._directory(base / "orphans")
                    destination = orphans / f"derived-{job.name}-{time.time_ns()}"
                    try:
                        _retry_locked(
                            lambda job=job, destination=destination: os.replace(job, destination),
                            self._sleep,
                        )
                    except OSError:
                        failed += 1
                        continue
                    moved += 1
        return DerivedRecovery(work_removed, moved, failed)
