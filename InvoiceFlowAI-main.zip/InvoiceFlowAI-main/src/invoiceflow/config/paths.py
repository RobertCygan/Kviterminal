"""Explicit data paths; no guessed home directories or registry changes."""

import os
import tempfile
from dataclasses import dataclass
from pathlib import Path

from invoiceflow.application.errors import InvoiceFlowError


@dataclass(frozen=True)
class AppPaths:
    """Root directories reserved for future entity-scoped storage."""

    data: Path

    @classmethod
    def resolve(cls, override: str | Path | None = None) -> "AppPaths":
        """Use the explicit override or LOCALAPPDATA, never a fallback location."""
        base = os.environ.get("LOCALAPPDATA")
        if override is None and not base:
            raise InvoiceFlowError("DATA_DIR_UNAVAILABLE", "error.data_dir")
        try:
            data = Path(override) if override is not None else Path(base) / "InvoiceFlowAI"
            return cls(data.expanduser().resolve())
        except (OSError, ValueError, RuntimeError) as exc:
            raise InvoiceFlowError("DATA_DIR_UNAVAILABLE", "error.data_dir") from exc

    @property
    def config(self) -> Path:
        return self.data / "config"

    @property
    def logs(self) -> Path:
        return self.data / "logs"

    @property
    def config_file(self) -> Path:
        return self.config / "config.json"

    @property
    def database_dir(self) -> Path:
        return self.data / "database"

    @property
    def database_file(self) -> Path:
        return self.database_dir / "invoiceflow.sqlite3"

    @property
    def documents(self) -> Path:
        """Root of the entity-scoped original archive (ADR-0029)."""
        return self.data / "documents"

    @property
    def inbox(self) -> Path:
        """Manually imported folder (D-23); never read recursively."""
        return self.data / "inbox"

    @property
    def exports(self) -> Path:
        """Export files per entity (Phase 10); copies go where the person chooses."""
        return self.data / "exports"

    @property
    def migration_backup_dir(self) -> Path:
        """Pre-migration safety copies; not the encrypted backups of Phase 12."""
        return self.data / "backups" / "pre-migration"

    def ensure(self) -> None:
        """Reject escaping child links and verify actual write access."""
        try:
            for name in ("config", "logs", "database", "backups", "documents", "inbox", "exports"):
                child = self.data / name
                if not child.resolve().is_relative_to(self.data):
                    raise OSError("Directory escapes data root")
                child.mkdir(parents=True, exist_ok=True)
                with tempfile.TemporaryFile(dir=child) as probe:
                    probe.write(b"probe")
            for child in (
                self.config_file,
                self.logs / "invoiceflow.log",
                self.data / "instance.lock",
                self.database_file,
                self.migration_backup_dir,
            ):
                if child.is_symlink():
                    raise OSError("File links are not supported")
        except (OSError, ValueError, RuntimeError) as exc:
            raise InvoiceFlowError("DATA_DIR_UNAVAILABLE", "error.data_dir") from exc

    def is_synced(self) -> bool:
        """Detect configured OneDrive roots using path components, not prefixes."""
        for name in ("OneDrive", "OneDriveCommercial", "OneDriveConsumer"):
            value = os.environ.get(name)
            if value and self.data.is_relative_to(Path(value).expanduser().resolve()):
                return True
        return False
