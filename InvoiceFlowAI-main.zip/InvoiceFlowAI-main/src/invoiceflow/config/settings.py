"""Strict, bounded bootstrap configuration with atomic creation."""

import os
import tempfile
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, ValidationError, field_validator

from invoiceflow.application.errors import ConfigError, InvoiceFlowError


class BootstrapConfig(BaseModel):
    """Only nonsensitive bootstrap settings are allowed."""

    model_config = ConfigDict(extra="forbid", strict=True, frozen=True)
    schema_version: Literal[1] = 1
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    locale: Literal["nb-NO"] = "nb-NO"

    @field_validator("schema_version", mode="before")
    @classmethod
    def strict_version(cls, value: object) -> object:
        if type(value) is not int:
            raise ValueError("Expected integer schema version")
        return value


def load_config(path: Path) -> BootstrapConfig:
    """Never replace invalid existing files; caller owns the instance lock."""
    temporary = None
    try:
        if path.exists():
            with path.open("rb") as source:
                raw = source.read(65537)
            if len(raw) > 65536:
                raise ConfigError()
            return BootstrapConfig.model_validate_json(raw)
        config = BootstrapConfig()
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, prefix=".config-", delete=False
        ) as target:
            temporary = Path(target.name)
            target.write(config.model_dump_json(indent=2) + "\n")
            target.flush()
            os.fsync(target.fileno())
        os.replace(temporary, path)
        return config
    except (ValidationError, UnicodeError) as exc:
        raise ConfigError() from exc
    except OSError as exc:
        raise InvoiceFlowError("DATA_DIR_UNAVAILABLE", "error.data_dir") from exc
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
