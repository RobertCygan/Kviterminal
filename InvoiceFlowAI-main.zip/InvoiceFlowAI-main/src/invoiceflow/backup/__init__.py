"""File adapters of the backup (Phase 12): encryption, archive and data folder."""
