"""AES-256-GCM in independent chunks with an scrypt key (Phase 12, ADR-0037).

Chunk ``i`` is encrypted with nonce ``prefix || i`` (8 + 4 bytes) and the
associated data ``SHA-256(header) || i || final``. Reordered, dropped,
duplicated or truncated chunks, a changed header and a wrong key all fail
authentication. The last chunk is marked final (it is empty only for empty
input), so a file cut at a chunk boundary is detected.
"""

import hashlib
import struct
from typing import BinaryIO

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from invoiceflow.application.backup.model import KEY_BYTES, BackupError, BackupHeader

TAG_BYTES = 16
MAX_CHUNKS = 2**32 - 1


def derive_key(passphrase: bytes, header: BackupHeader) -> bytes:
    """scrypt with the header's parameters; memory is bounded by the header checks."""
    memory = 128 * header.scrypt_r * header.scrypt_n * (header.scrypt_p + 1) + 16 * 1024 * 1024
    return hashlib.scrypt(
        passphrase,
        salt=header.salt,
        n=header.scrypt_n,
        r=header.scrypt_r,
        p=header.scrypt_p,
        maxmem=memory,
        dklen=KEY_BYTES,
    )


def _associated(header_hash: bytes, index: int, final: bool) -> bytes:
    return header_hash + struct.pack(">IB", index, int(final))


class EncryptingWriter:
    """A write-only stream that encrypts into ``raw`` chunk by chunk."""

    def __init__(self, raw: BinaryIO, key: bytes, header: BackupHeader) -> None:
        self._raw = raw
        self._cipher = AESGCM(key)
        self._prefix = header.nonce_prefix
        self._header_hash = hashlib.sha256(header.to_bytes()).digest()
        self._chunk = header.chunk_size
        self._buffer = bytearray()
        self._index = 0
        self._closed = False

    def write(self, data: bytes) -> int:
        if self._closed:
            msg = "stream is closed"
            raise ValueError(msg)
        self._buffer += data
        while len(self._buffer) > self._chunk:
            self._emit(bytes(self._buffer[: self._chunk]), final=False)
            del self._buffer[: self._chunk]
        return len(data)

    def _emit(self, plain: bytes, *, final: bool) -> None:
        if self._index > MAX_CHUNKS:
            raise BackupError("too_large")
        nonce = self._prefix + struct.pack(">I", self._index)
        associated = _associated(self._header_hash, self._index, final)
        self._raw.write(self._cipher.encrypt(nonce, plain, associated))
        self._index += 1

    def close(self) -> None:
        """Write the rest as the final chunk; the stream is complete only after this."""
        if not self._closed:
            self._emit(bytes(self._buffer), final=True)
            self._buffer.clear()
            self._closed = True


class DecryptingReader:
    """A read-only stream that authenticates every chunk before returning it."""

    def __init__(self, raw: BinaryIO, key: bytes, header: BackupHeader) -> None:
        self._raw = raw
        self._cipher = AESGCM(key)
        self._prefix = header.nonce_prefix
        self._header_hash = hashlib.sha256(header.to_bytes()).digest()
        self._size = header.chunk_size + TAG_BYTES
        self._pending = self._raw.read(self._size)
        self._buffer = bytearray()
        self._index = 0
        self.finished = False

    def _next(self) -> None:
        current = self._pending
        self._pending = self._raw.read(self._size) if len(current) == self._size else b""
        final = not self._pending
        if len(current) < TAG_BYTES or self._index > MAX_CHUNKS:
            raise BackupError("damaged")
        nonce = self._prefix + struct.pack(">I", self._index)
        try:
            plain = self._cipher.decrypt(
                nonce, current, _associated(self._header_hash, self._index, final)
            )
        except InvalidTag as exc:
            # The first chunk fails with a wrong passphrase and with a changed file alike.
            raise BackupError("passphrase_or_damaged" if self._index == 0 else "damaged") from exc
        self._buffer += plain
        self._index += 1
        self.finished = final

    def read(self, size: int = -1) -> bytes:
        while not self.finished and (size < 0 or len(self._buffer) < size):
            self._next()
        if size < 0:
            size = len(self._buffer)
        data = bytes(self._buffer[:size])
        del self._buffer[:size]
        return data
