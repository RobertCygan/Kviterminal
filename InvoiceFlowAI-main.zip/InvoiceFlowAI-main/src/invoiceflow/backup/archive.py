"""Backup files on disk: write, read, restore and the data folder (Phase 12, ADR-0037).

File layout::

    MAGIC (8 bytes) | header length (4 bytes, big endian) | header (JSON) | encrypted tar

The tar archive holds the files below the data directory and ends with
``manifest.json``. Reading never trusts it: every member must be a regular
file with a known, relative path, appear once, and stay within the limits.
A backup is written to a temporary name and renamed when complete.
"""

import contextlib
import hashlib
import os
import shutil
import stat
import struct
import tarfile
from collections.abc import Callable, Iterator, Sequence
from pathlib import Path
from typing import BinaryIO
from uuid import uuid4

from invoiceflow.application.backup.model import (
    MAGIC,
    MANIFEST_NAME,
    MAX_HEADER,
    MAX_MEMBER_BYTES,
    MAX_MEMBERS,
    BackupError,
    BackupHeader,
    Manifest,
    ManifestEntry,
    check_member,
)
from invoiceflow.backup.crypto import DecryptingReader, EncryptingWriter, derive_key
from invoiceflow.config.paths import AppPaths

CHUNK = 1024 * 1024
MAX_MANIFEST_BYTES = 256 * 1024 * 1024
_REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
# Folders below an entity's document folder that hold temporary work only.
_SKIPPED = frozenset({"staging", "work"})


def _is_link(path: Path) -> bool:
    info = os.lstat(path)
    if stat.S_ISLNK(info.st_mode):
        return True
    return bool((getattr(info, "st_file_attributes", 0) or 0) & _REPARSE_POINT)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(CHUNK):
            digest.update(block)
    return digest.hexdigest()


class _HashingReader:
    """Hands a file to tarfile and hashes exactly what it reads."""

    def __init__(self, handle: BinaryIO) -> None:
        self._handle = handle
        self.digest = hashlib.sha256()

    def read(self, size: int = -1) -> bytes:
        data = self._handle.read(size)
        self.digest.update(data)
        return data


class _HashingWriter:
    def __init__(self, handle: BinaryIO) -> None:
        self._handle = handle
        self.digest = hashlib.sha256()
        self.size = 0

    def write(self, data: bytes) -> int:
        self._handle.write(data)
        self.digest.update(data)
        self.size += len(data)
        return len(data)


class FileBackupArchive:
    """Implements :class:`invoiceflow.application.ports.BackupArchive`."""

    def __init__(self, paths: AppPaths, *, fsync: Callable[[int], None] = os.fsync) -> None:
        self._paths = paths
        self._fsync = fsync

    # --- the data folder ---------------------------------------------------------------

    @property
    def _work_root(self) -> Path:
        return self._paths.data / "backups" / "work"

    @contextlib.contextmanager
    def workspace(self) -> Iterator[Path]:
        """A private folder for the database copy; removed afterwards (it is unencrypted)."""
        work = self._work_root / uuid4().hex
        work.mkdir(parents=True)
        try:
            yield work
        finally:
            shutil.rmtree(work, ignore_errors=True)

    def discard_workspaces(self) -> int:
        """Remove work folders left by a crash: they can hold an unencrypted database copy."""
        if not self._work_root.is_dir():
            return 0
        removed = 0
        for path in self._work_root.iterdir():
            if path.is_dir() and not _is_link(path):
                shutil.rmtree(path, ignore_errors=True)
                removed += 1
        return removed

    def data_files(self) -> list[tuple[str, Path]]:
        """Documents (without temporary work), export files and the configuration."""
        files: list[tuple[str, Path]] = []
        data = self._paths.data
        for top in ("documents", "exports"):
            root = data / top
            if not root.is_dir():
                continue
            for directory, names, file_names in os.walk(root):
                current = Path(directory)
                relative = current.relative_to(data)
                if len(relative.parts) == 2 and top == "documents":
                    names[:] = [n for n in names if n not in _SKIPPED]
                names[:] = sorted(n for n in names if not _is_link(current / n))
                for name in sorted(file_names):
                    path = current / name
                    if _is_link(path) or not stat.S_ISREG(os.lstat(path).st_mode):
                        continue
                    if name.startswith("."):
                        continue  # Temporary files of the export folder
                    files.append((check_member((relative / name).as_posix()), path))
        config = self._paths.config_file
        if config.is_file() and not _is_link(config):
            files.append(("config/config.json", config))
        return files

    # --- writing -----------------------------------------------------------------------

    def derive_key(self, passphrase: bytes, header: BackupHeader) -> bytes:
        return derive_key(passphrase, header)

    def write(
        self,
        destination: Path,
        header: BackupHeader,
        key: bytes,
        files: Sequence[tuple[str, Path]],
        manifest: Callable[[tuple[ManifestEntry, ...]], Manifest],
    ) -> tuple[str, int, Manifest]:
        """Write the backup; returns its SHA-256, size and manifest."""
        if destination.exists():
            raise BackupError("exists")
        temporary = destination.with_name(f".{uuid4().hex}.part")
        header_bytes = header.to_bytes()
        try:
            with temporary.open("xb") as raw:
                output = _HashingWriter(raw)
                output.write(MAGIC + struct.pack(">I", len(header_bytes)) + header_bytes)
                stream = EncryptingWriter(output, key, header)  # type: ignore[arg-type]
                entries = self._tar(stream, files, manifest)
                stream.close()
                raw.flush()
                self._fsync(raw.fileno())
            os.replace(temporary, destination)
        except BackupError:
            temporary.unlink(missing_ok=True)
            raise
        except OSError as exc:
            with contextlib.suppress(OSError):
                temporary.unlink(missing_ok=True)
            raise BackupError("write_failed") from exc
        return output.digest.hexdigest(), output.size, entries

    @staticmethod
    def _tar(
        stream: EncryptingWriter,
        files: Sequence[tuple[str, Path]],
        manifest: Callable[[tuple[ManifestEntry, ...]], Manifest],
    ) -> Manifest:
        entries: list[ManifestEntry] = []
        with tarfile.open(fileobj=stream, mode="w|", format=tarfile.PAX_FORMAT) as archive:  # type: ignore[call-overload]
            for name, path in files:
                with path.open("rb") as handle:
                    size = os.fstat(handle.fileno()).st_size
                    info = tarfile.TarInfo(name)
                    info.size = size
                    info.mode = 0o600
                    reader = _HashingReader(handle)
                    archive.addfile(info, reader)  # type: ignore[arg-type]
                    entries.append(ManifestEntry(name, reader.digest.hexdigest(), size))
            content = manifest(tuple(entries))
            data = content.to_bytes()
            info = tarfile.TarInfo(MANIFEST_NAME)
            info.size = len(data)
            info.mode = 0o600
            archive.addfile(info, _BytesReader(data))  # type: ignore[arg-type]
        return content

    # --- reading -----------------------------------------------------------------------

    def read_header(self, source: Path) -> BackupHeader:
        try:
            with source.open("rb") as raw:
                return self._header(raw)
        except OSError as exc:
            raise BackupError("unreadable") from exc

    @staticmethod
    def _header(raw: BinaryIO) -> BackupHeader:
        start = raw.read(len(MAGIC) + 4)
        if len(start) != len(MAGIC) + 4 or not start.startswith(MAGIC):
            raise BackupError("not_a_backup")
        (length,) = struct.unpack(">I", start[len(MAGIC) :])
        if not 0 < length <= MAX_HEADER:
            raise BackupError("damaged")
        data = raw.read(length)
        if len(data) != length:
            raise BackupError("damaged")
        return BackupHeader.from_bytes(data)

    def extract(
        self, source: Path, header: BackupHeader, key: bytes, target: Path
    ) -> tuple[Manifest, dict[str, tuple[str, int]]]:
        """Decrypt and unpack into ``target``; returns the manifest and what was written."""
        written: dict[str, tuple[str, int]] = {}
        manifest: Manifest | None = None
        try:
            with source.open("rb") as raw:
                if self._header(raw) != header:
                    raise BackupError("damaged")
                stream = DecryptingReader(raw, key, header)
                with tarfile.open(fileobj=stream, mode="r|") as archive:  # type: ignore[call-overload]
                    for count, member in enumerate(archive, start=1):
                        if manifest is not None or count > MAX_MEMBERS:
                            raise BackupError("damaged")  # Nothing may follow the manifest.
                        if not member.isreg() or not 0 <= member.size <= MAX_MEMBER_BYTES:
                            raise BackupError("damaged")
                        handle = archive.extractfile(member)
                        if handle is None:
                            raise BackupError("damaged")
                        if member.name == MANIFEST_NAME:
                            if member.size > MAX_MANIFEST_BYTES:
                                raise BackupError("damaged")
                            manifest = Manifest.from_bytes(handle.read(member.size))
                            continue
                        name = check_member(member.name)
                        if name in written:
                            raise BackupError("damaged")
                        written[name] = self._unpack(handle, member.size, target / name)
                # The tar end may leave zero padding; nothing else may follow.
                if stream.read().strip(b"\0") or not stream.finished:
                    raise BackupError("damaged")
        except tarfile.TarError as exc:
            raise BackupError("damaged") from exc
        except OSError as exc:
            raise BackupError("write_failed") from exc
        if manifest is None:
            raise BackupError("damaged")
        return manifest, written

    @staticmethod
    def _unpack(handle: BinaryIO, size: int, path: Path) -> tuple[str, int]:
        path.parent.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256()
        total = 0
        with path.open("xb") as output:
            while block := handle.read(min(CHUNK, size - total)):
                output.write(block)
                digest.update(block)
                total += len(block)
        if total != size:
            raise BackupError("damaged")
        return digest.hexdigest(), total

    # --- restore target and files --------------------------------------------------------

    def prepare_target(self, target: Path) -> None:
        """An empty folder outside the application's own data directory."""
        try:
            resolved = target.resolve()
            data = self._paths.data.resolve()
            if resolved == data or resolved.is_relative_to(data) or data.is_relative_to(resolved):
                raise BackupError("target_inside_data")
            target.mkdir(parents=True, exist_ok=True)
            if _is_link(target) or any(target.iterdir()):
                raise BackupError("not_empty")
        except OSError as exc:
            raise BackupError("write_failed") from exc

    def clear(self, target: Path) -> None:
        """Remove what a failed restore wrote into the (previously empty) target."""
        for child in target.iterdir():
            if child.is_dir() and not _is_link(child):
                shutil.rmtree(child, ignore_errors=True)
            else:
                with contextlib.suppress(OSError):
                    child.unlink()

    def file_sha256(self, path: Path) -> str:
        try:
            return _sha256(path)
        except OSError as exc:
            raise BackupError("unreadable") from exc

    def delete(self, path: Path) -> None:
        try:
            path.unlink()
        except OSError as exc:
            raise BackupError("delete_failed") from exc


class _BytesReader:
    def __init__(self, data: bytes) -> None:
        self._data = memoryview(data)
        self._position = 0

    def read(self, size: int = -1) -> bytes:
        end = len(self._data) if size < 0 else self._position + size
        chunk = bytes(self._data[self._position : end])
        self._position += len(chunk)
        return chunk
