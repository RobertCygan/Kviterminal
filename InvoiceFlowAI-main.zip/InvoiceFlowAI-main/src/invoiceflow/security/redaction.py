"""Defense in depth for technical log messages; never log invoice contents."""

import re

PATTERNS = (
    re.compile(r"(?i)\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]){10,30}\b"),
    re.compile(r"(?<![\w-])\d{4}[. ]\d{2}[. ]\d{5}(?![\w-])"),
    re.compile(r"(?<![\w-])(?:\d{11}|\d{9})(?![\w-])"),
    re.compile(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}"),
    re.compile(r"(?i)(?:[A-Z]:[\\/]|/)(?:Users|home)[\\/][^\s\"]+"),
)


def redact(value: str) -> str:
    """Mask identifier patterns while preserving UUIDs, codes and timestamps."""
    for pattern in PATTERNS:
        value = pattern.sub("«maskert»", value)
    return value
