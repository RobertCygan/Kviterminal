"""InvoiceFlow AI - local, secure invoice processing for Windows."""

__version__ = "0.1.0.dev0"
