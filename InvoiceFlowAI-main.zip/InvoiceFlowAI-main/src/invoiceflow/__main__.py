"""Windows-safe command line entry point."""

import argparse
import multiprocessing
import sys

from invoiceflow.application.errors import InvoiceFlowError
from invoiceflow.i18n import t


class ArgumentParser(argparse.ArgumentParser):
    """Avoid echoing untrusted command-line input in parser errors."""

    def format_help(self) -> str:
        return t("cli.help_text")

    def error(self, message: str) -> None:
        raise InvoiceFlowError("ARGUMENTS_INVALID", "error.arguments")


def main(argv: list[str] | None = None) -> int:
    """Return stable exit codes and never expose a traceback to the user."""
    multiprocessing.freeze_support()
    arguments = sys.argv[1:] if argv is None else argv
    parser = ArgumentParser(add_help=False, description=t("cli.description"), usage=t("cli.usage"))
    parser.add_argument("--help", action="help", help=t("cli.help"))
    parser.add_argument("--self-test", action="store_true", help=t("cli.self_test"))
    parser.add_argument("--data-dir", help=t("cli.data_dir"))
    self_test = "--self-test" in arguments
    try:
        options = parser.parse_args(arguments)
        from invoiceflow.bootstrap.app import run

        return run(options.data_dir, options.self_test)
    except InvoiceFlowError as exc:
        if self_test:
            print(t("self_test.failed", code=exc.code))
            return 1
        message = t(exc.message_key, **exc.params)
        print(t("error.cli", message=message, code=exc.code), file=sys.stderr)
        if exc.code == "ALREADY_RUNNING":
            return 3
        return 1 if exc.code == "UNEXPECTED" else 2
    except Exception:
        print(
            t("self_test.failed", code="UNEXPECTED") if self_test else t("error.unexpected"),
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
