"""Composition root and lifecycle; no business functionality."""

import logging
import os
import sys
from uuid import uuid4

from invoiceflow import __version__
from invoiceflow.application.errors import InvoiceFlowError
from invoiceflow.bootstrap.logging_setup import close_logging, setup_logging
from invoiceflow.config.paths import AppPaths
from invoiceflow.config.settings import load_config
from invoiceflow.i18n import t


def run(data_dir: str | None, self_test: bool = False) -> int:
    """Own the data lock through shutdown and restore global exception hooks."""
    if self_test:
        os.environ["QT_QPA_PLATFORM"] = "offscreen"
    # Load Qt only after choosing the headless platform.
    from PySide6.QtCore import QLockFile
    from PySide6.QtWidgets import QApplication

    from invoiceflow.bootstrap.persistence import (
        open_archive,
        open_database,
        run_persistence_self_test,
    )
    from invoiceflow.bootstrap.self_test import run_self_test
    from invoiceflow.ui.dialogs import error_dialog
    from invoiceflow.ui.main_window import MainWindow

    paths = AppPaths.resolve(data_dir)
    paths.ensure()
    lock = QLockFile(str(paths.data / "instance.lock"))
    lock.setStaleLockTime(0)
    if not lock.tryLock(0):
        if lock.error() == QLockFile.LockError.LockFailedError:
            raise InvoiceFlowError("ALREADY_RUNNING", "error.running")
        raise InvoiceFlowError("DATA_DIR_UNAVAILABLE", "error.data_dir")
    logger = None
    window = None
    database = None
    previous_hook = sys.excepthook
    failed = False
    try:
        config = load_config(paths.config_file)
        logger = setup_logging(paths.logs, config.log_level)
        try:
            database, initialization = open_database(paths)
        except InvoiceFlowError as exc:
            logger.error("database.error", extra={"code": exc.code})
            raise
        if initialization.created:
            logger.log(max(logger.level, logging.INFO), "database.created")
        elif initialization.migrated_from is not None:
            logger.log(max(logger.level, logging.INFO), "database.migrated")
        archive = open_archive(database, paths)
        recovery = archive.reconcile_all()
        if (
            recovery.staging_removed
            or recovery.orphans_moved
            or recovery.missing
            or recovery.failed
        ):
            # Counts only: never file names, paths or document identifiers.
            logger.warning(
                "documents.recovered",
                extra={
                    "code": f"staging_{recovery.staging_removed}"
                    f"_orphans_{recovery.orphans_moved}_missing_{len(recovery.missing)}"
                    f"_failed_{recovery.failed}"
                },
            )
        processing = archive.reconcile_processing()
        if processing.interrupted or processing.derived_moved or processing.failed:
            # Counts only, like the document recovery above.
            logger.warning(
                "processing.recovered",
                extra={
                    "code": f"interrupted_{processing.interrupted}"
                    f"_moved_{processing.derived_moved}_failed_{processing.failed}"
                },
            )
        exports = archive.reconcile_exports()
        if exports.completed or exports.failed or exports.temporary_removed:
            # Counts only, like the recoveries above.
            logger.warning(
                "exports.recovered",
                extra={
                    "code": f"completed_{exports.completed}_failed_{exports.failed}"
                    f"_temporary_{exports.temporary_removed}"
                },
            )
        if archive.reconcile_backups():
            # An interrupted backup left an unencrypted database copy; it is gone now.
            logger.warning("backups.recovered")
        app = QApplication.instance() or QApplication(["InvoiceFlowAI"])
        app.setApplicationName(t("app.title"))
        synced = paths.is_synced()
        window = MainWindow(
            __version__,
            str(paths.data),
            synced,
            archive,
            archive,
            archive,
            archive,
            archive,
            archive,
            archive,
        )

        def report_exception(exc_type: type[BaseException], exc: BaseException, tb: object) -> None:
            nonlocal failed
            failed = True
            correlation_id = str(uuid4())
            # Exception messages can contain arbitrary input: omit them entirely.
            logger.error(
                "app.error",
                extra={
                    "code": "UNEXPECTED",
                    "correlation_id": correlation_id,
                    "exception_type": exc_type.__name__,
                },
            )
            if not self_test:
                error_dialog("UNEXPECTED", correlation_id, window).exec()
            app.exit(1)

        sys.excepthook = report_exception
        logger.log(max(logger.level, logging.INFO), "app.started")
        if synced:
            logger.warning("DATA_DIR_SYNCED")
        if self_test:
            run_persistence_self_test(paths)
            run_self_test(app, window)
            if failed:
                print(t("self_test.failed", code="UNEXPECTED"))
                return 1
            print(t("self_test.ok"))
            return 0
        window.show()
        result = app.exec()
        return 1 if failed else result
    except InvoiceFlowError:
        raise
    except Exception as exc:
        correlation_id = str(uuid4())
        if logger is not None:
            logger.error(
                "app.error",
                extra={
                    "code": "UNEXPECTED",
                    "exception_type": type(exc).__name__,
                    "correlation_id": correlation_id,
                },
            )
        if not self_test and window is not None:
            error_dialog("UNEXPECTED", correlation_id, window).exec()
        raise InvoiceFlowError("UNEXPECTED", "error.unexpected") from exc
    finally:
        sys.excepthook = previous_hook
        if window is not None:
            window.close()
            page = window.documents_page
            if page is not None and not page.shutdown() and logger is not None:
                logger.warning("documents.shutdown_timeout")
        if database is not None:
            database.close()
        if logger is not None:
            logger.log(max(logger.level, logging.INFO), "app.stopped")
            close_logging(logger)
        lock.unlock()
