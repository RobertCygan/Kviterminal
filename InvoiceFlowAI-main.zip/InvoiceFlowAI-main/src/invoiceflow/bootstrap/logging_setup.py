"""Private JSON event logging without third-party log propagation."""

import json
import logging
from datetime import UTC, datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path

from invoiceflow.security.redaction import redact


class RedactionFilter(logging.Filter):
    """Drop traceback and arguments before any handler can format them."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = redact(record.getMessage())
        record.args = ()
        record.exc_info = None
        record.exc_text = None
        record.stack_info = None
        return True


class JsonFormatter(logging.Formatter):
    """Serialize only an explicit allowlist of event metadata."""

    def format(self, record: logging.LogRecord) -> str:
        event = {
            "timestamp": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "event": record.getMessage(),
        }
        for key in ("code", "correlation_id", "exception_type"):
            if hasattr(record, key):
                event[key] = redact(str(getattr(record, key)))
        return json.dumps(event, ensure_ascii=False)


def setup_logging(directory: Path, level: str) -> logging.Logger:
    """Install masking on every application handler and disable propagation."""
    logger = logging.getLogger("invoiceflow")
    close_logging(logger)
    logger.setLevel(level)
    logger.propagate = False
    handler = RotatingFileHandler(
        directory / "invoiceflow.log", maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    handler.addFilter(RedactionFilter())
    handler.setFormatter(JsonFormatter())
    logger.addHandler(handler)
    return logger


def close_logging(logger: logging.Logger) -> None:
    """Release file handles, including on Windows and repeated test runs."""
    for handler in logger.handlers[:]:
        handler.close()
        logger.removeHandler(handler)
