"""Fully synthetic EHF / PEPPOL BIS Billing 3.0 documents for the self-test and tests.

The organisation numbers below are made up (with valid check digits where it
matters) and belong to nobody. Never used for real invoices.
"""

import base64
from collections.abc import Sequence
from dataclasses import dataclass, field
from decimal import ROUND_HALF_UP, Decimal
from html import escape as _html_escape

CUSTOMIZATION = "urn:cen.eu:en16931:2017#compliant#urn:fdc:peppol.eu:2017:poacc:billing:3.0"
PROFILE = "urn:fdc:peppol.eu:2017:poacc:billing:01:1.0"
SUPPLIER_ORG = "123456785"
CUSTOMER_ORG = "314159268"


def escape(text: str) -> str:
    return _html_escape(text, quote=False)


def quoteattr(text: str) -> str:
    return '"' + _html_escape(text, quote=True) + '"'


def _vat(amount: Decimal, rate: str) -> Decimal:
    return (amount * Decimal(rate) / 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


@dataclass(frozen=True)
class Line:
    name: str
    quantity: str
    unit_price: str
    vat_percent: str = "25"
    unit: str = "EA"

    @property
    def amount(self) -> Decimal:
        return (Decimal(self.quantity) * Decimal(self.unit_price)).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )


@dataclass(frozen=True)
class Attachment:
    content: bytes
    filename: str = "faktura.pdf"
    mime_code: str = "application/pdf"


@dataclass(frozen=True)
class SyntheticEhf:
    number: str = "EHF-2026-001"
    issue_date: str = "2026-10-01"
    due_date: str = "2026-10-15"
    currency: str = "NOK"
    supplier_name: str = "Syntetisk Leverandør AS"
    supplier_org: str = SUPPLIER_ORG
    customer_name: str = "Syntetisk Mottaker AS"
    customer_org: str | None = CUSTOMER_ORG
    kid: str = "1234567890128"
    account: str = "12345678903"
    buyer_reference: str = "Ref-42"
    lines: Sequence[Line] = (
        Line("Konsulenttimer", "10", "1000.00"),
        Line("Reise", "1", "500.00"),
    )
    attachments: Sequence[Attachment] = ()
    credit_note: bool = False
    referenced_invoice: str | None = None
    # Overrides for tests of the arithmetic checks.
    payable_override: str | None = None
    tax_override: str | None = None
    extra: str = field(default="")

    def by_rate(self) -> dict[str, Decimal]:
        rates: dict[str, Decimal] = {}
        for line in self.lines:
            rates[line.vat_percent] = rates.get(line.vat_percent, Decimal("0.00")) + line.amount
        return rates

    def totals(self) -> tuple[Decimal, Decimal, Decimal]:
        """VAT per rate on the taxable amount, as BIS Billing 3.0 calculates it."""
        net = sum((line.amount for line in self.lines), Decimal("0.00"))
        tax = sum((_vat(amount, rate) for rate, amount in self.by_rate().items()), Decimal("0.00"))
        return net, tax, net + tax


def _party(kind: str, name: str, org: str | None) -> str:
    company_id = "" if org is None else f'<cbc:CompanyID schemeID="0192">{org}</cbc:CompanyID>'
    company = (
        f"<cac:PartyLegalEntity><cbc:RegistrationName>{escape(name)}</cbc:RegistrationName>"
        f"{company_id}</cac:PartyLegalEntity>"
    )
    tax = (
        f"<cac:PartyTaxScheme><cbc:CompanyID>NO{org}MVA</cbc:CompanyID>"
        "<cac:TaxScheme><cbc:ID>VAT</cbc:ID></cac:TaxScheme></cac:PartyTaxScheme>"
        if org is not None and kind == "Supplier"
        else ""
    )
    return (
        f"<cac:Accounting{kind}Party><cac:Party>"
        f'<cbc:EndpointID schemeID="0192">{org or "000000000"}</cbc:EndpointID>'
        f"<cac:PartyName><cbc:Name>{escape(name)}</cbc:Name></cac:PartyName>"
        "<cac:PostalAddress><cbc:StreetName>Storgata 1</cbc:StreetName>"
        "<cbc:CityName>Narvik</cbc:CityName><cbc:PostalZone>8514</cbc:PostalZone>"
        "<cac:Country><cbc:IdentificationCode>NO</cbc:IdentificationCode></cac:Country>"
        f"</cac:PostalAddress>{tax}{company}"
        f"</cac:Party></cac:Accounting{kind}Party>"
    )


def build_ehf(spec: SyntheticEhf | None = None) -> bytes:
    """A complete, valid BIS Billing 3.0 invoice or credit note as UTF-8 bytes."""
    spec = spec or SyntheticEhf()
    root = "CreditNote" if spec.credit_note else "Invoice"
    line_tag = "CreditNoteLine" if spec.credit_note else "InvoiceLine"
    quantity_tag = "CreditedQuantity" if spec.credit_note else "InvoicedQuantity"
    type_tag = "CreditNoteTypeCode" if spec.credit_note else "InvoiceTypeCode"
    type_code = "381" if spec.credit_note else "380"
    cur = quoteattr(spec.currency)
    net, tax, gross = spec.totals()
    tax_text = spec.tax_override or str(tax)
    payable = spec.payable_override or str(gross)
    subtotals = "".join(
        f"<cac:TaxSubtotal><cbc:TaxableAmount currencyID={cur}>{amount}</cbc:TaxableAmount>"
        f"<cbc:TaxAmount currencyID={cur}>{_vat(amount, rate)}</cbc:TaxAmount>"
        f"<cac:TaxCategory><cbc:ID>S</cbc:ID><cbc:Percent>{rate}</cbc:Percent>"
        "<cac:TaxScheme><cbc:ID>VAT</cbc:ID></cac:TaxScheme></cac:TaxCategory></cac:TaxSubtotal>"
        for rate, amount in spec.by_rate().items()
    )
    lines = "".join(
        f"<cac:{line_tag}><cbc:ID>{number}</cbc:ID>"
        f'<cbc:{quantity_tag} unitCode="{line.unit}">{line.quantity}</cbc:{quantity_tag}>'
        f"<cbc:LineExtensionAmount currencyID={cur}>{line.amount}</cbc:LineExtensionAmount>"
        f"<cac:Item><cbc:Name>{escape(line.name)}</cbc:Name><cac:ClassifiedTaxCategory>"
        f"<cbc:ID>S</cbc:ID><cbc:Percent>{line.vat_percent}</cbc:Percent>"
        "<cac:TaxScheme><cbc:ID>VAT</cbc:ID></cac:TaxScheme></cac:ClassifiedTaxCategory></cac:Item>"
        f"<cac:Price><cbc:PriceAmount currencyID={cur}>{line.unit_price}</cbc:PriceAmount>"
        f"</cac:Price></cac:{line_tag}>"
        for number, line in enumerate(spec.lines, start=1)
    )
    attachments = "".join(
        f"<cac:AdditionalDocumentReference><cbc:ID>V{number}</cbc:ID><cac:Attachment>"
        f"<cbc:EmbeddedDocumentBinaryObject mimeCode={quoteattr(item.mime_code)} "
        f"filename={quoteattr(item.filename)}>"
        f"{base64.b64encode(item.content).decode('ascii')}</cbc:EmbeddedDocumentBinaryObject>"
        "</cac:Attachment></cac:AdditionalDocumentReference>"
        for number, item in enumerate(spec.attachments, start=1)
    )
    reference = (
        ""
        if spec.referenced_invoice is None
        else "<cac:BillingReference><cac:InvoiceDocumentReference>"
        f"<cbc:ID>{escape(spec.referenced_invoice)}</cbc:ID>"
        "</cac:InvoiceDocumentReference></cac:BillingReference>"
    )
    due = "" if spec.credit_note else f"<cbc:DueDate>{spec.due_date}</cbc:DueDate>"
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f'<{root} xmlns="urn:oasis:names:specification:ubl:schema:xsd:{root}-2"'
        ' xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"'
        ' xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">'
        f"<cbc:CustomizationID>{CUSTOMIZATION}</cbc:CustomizationID>"
        f"<cbc:ProfileID>{PROFILE}</cbc:ProfileID>"
        f"<cbc:ID>{escape(spec.number)}</cbc:ID><cbc:IssueDate>{spec.issue_date}</cbc:IssueDate>"
        f"{due}<cbc:{type_tag}>{type_code}</cbc:{type_tag}>"
        f"<cbc:DocumentCurrencyCode>{spec.currency}</cbc:DocumentCurrencyCode>"
        f"<cbc:BuyerReference>{escape(spec.buyer_reference)}</cbc:BuyerReference>"
        f"{reference}{attachments}{spec.extra}"
        f"{_party('Supplier', spec.supplier_name, spec.supplier_org)}"
        f"{_party('Customer', spec.customer_name, spec.customer_org)}"
        "<cac:PaymentMeans><cbc:PaymentMeansCode>30</cbc:PaymentMeansCode>"
        f"<cbc:PaymentID>{spec.kid}</cbc:PaymentID>"
        f"<cac:PayeeFinancialAccount><cbc:ID>{spec.account}</cbc:ID></cac:PayeeFinancialAccount>"
        "</cac:PaymentMeans>"
        f"<cac:TaxTotal><cbc:TaxAmount currencyID={cur}>{tax_text}</cbc:TaxAmount>{subtotals}"
        "</cac:TaxTotal>"
        f"<cac:LegalMonetaryTotal><cbc:LineExtensionAmount currencyID={cur}>{net}"
        f"</cbc:LineExtensionAmount><cbc:TaxExclusiveAmount currencyID={cur}>{net}"
        f"</cbc:TaxExclusiveAmount><cbc:TaxInclusiveAmount currencyID={cur}>{gross}"
        f"</cbc:TaxInclusiveAmount><cbc:PayableAmount currencyID={cur}>{payable}"
        "</cbc:PayableAmount></cac:LegalMonetaryTotal>"
        f"{lines}</{root}>"
    )
    return xml.encode("utf-8")
