"""Database and document-archive composition, and the persistence self-test.

Only the composition root imports concrete persistence and storage adapters.
"""

import os
import secrets
import shutil
import stat
from decimal import Decimal
from pathlib import Path
from uuid import UUID, uuid4

from invoiceflow.application.backup.model import BackupError
from invoiceflow.application.backup.service import BackupService
from invoiceflow.application.document_model import ImportOutcome, IntegrityStatus
from invoiceflow.application.documents import DocumentService
from invoiceflow.application.errors import NotFoundError
from invoiceflow.application.export.model import ExportError, ExportTarget
from invoiceflow.application.export.service import ExportService
from invoiceflow.application.extraction.service import ExtractionService
from invoiceflow.application.processing import ProcessingService
from invoiceflow.application.processing_model import DerivedKind, JobRecord, JobStatus
from invoiceflow.application.reference.model import ReferenceKind
from invoiceflow.application.reference.service import ReferenceService
from invoiceflow.application.review.model import WorkflowStatus
from invoiceflow.application.review.service import ReviewService
from invoiceflow.application.scan.service import ScanService
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import EntityService, InvoiceService
from invoiceflow.application.validation.model import AccountStatus
from invoiceflow.application.validation.service import ValidationService
from invoiceflow.backup.archive import FileBackupArchive
from invoiceflow.bootstrap.archive import LocalArchiveController
from invoiceflow.bootstrap.synthetic_ehf import build_ehf
from invoiceflow.bootstrap.synthetic_pdf import batch_pdf, synthetic_invoice_pdf, text_pdf
from invoiceflow.bootstrap.synthetic_reference import CHART_CSV, VAT_CODES_CSV
from invoiceflow.config.paths import AppPaths
from invoiceflow.documents.derived import FileDerivedStore
from invoiceflow.documents.scan_folder import FileScanFolder
from invoiceflow.documents.store import FileDocumentStore
from invoiceflow.domain.canonical import content_sha256
from invoiceflow.domain.invoice import CanonicalInvoice
from invoiceflow.export.csv_writer import CsvWriter
from invoiceflow.export.files import FileExportStore
from invoiceflow.export.xlsx_writer import XlsxWriter
from invoiceflow.i18n import t
from invoiceflow.persistence.backup import SqliteSnapshotter
from invoiceflow.persistence.database import Database
from invoiceflow.persistence.engine import EXPECTED_SETTINGS
from invoiceflow.persistence.migrator import InitializationResult, initialize_database
from invoiceflow.processing.isolation import IsolatedDocumentProcessor

SELF_TEST_DOCUMENT_ID = UUID("00000000-0000-4000-8000-000000000001")


def open_database(paths: AppPaths) -> tuple[Database, InitializationResult]:
    """Create or migrate the application database, then open it."""
    result = initialize_database(paths.database_file, paths.migration_backup_dir)
    return Database(paths.database_file), result


def open_document_service(database: Database, paths: AppPaths) -> DocumentService:
    return DocumentService(database.unit_of_work, FileDocumentStore(paths.documents))


def open_validation_service(database: Database) -> ValidationService:
    return ValidationService(database.unit_of_work)


def open_reference_service(database: Database) -> ReferenceService:
    return ReferenceService(database.unit_of_work, validator=open_validation_service(database))


def open_processing_service(database: Database, paths: AppPaths) -> ProcessingService:
    """Page analysis, OCR and EHF import in an isolated worker process, and draft
    invoices from the text (Phases 04, 05, 06 and 15)."""
    validator = open_validation_service(database)
    poster = open_reference_service(database)
    return ProcessingService(
        database.unit_of_work,
        FileDocumentStore(paths.documents),
        FileDerivedStore(paths.documents),
        IsolatedDocumentProcessor(),
        attachments=open_document_service(database, paths),
        validator=validator,
        poster=poster,
        extractor=ExtractionService(database.unit_of_work, validator=validator, poster=poster),
    )


def open_export_service(database: Database, paths: AppPaths) -> ExportService:
    """Excel and CSV files in the entity's export folder (Phase 10)."""
    return ExportService(
        database.unit_of_work,
        {ExportTarget.EXCEL: XlsxWriter(), ExportTarget.CSV: CsvWriter()},
        FileExportStore(paths.exports),
        t,
    )


def open_backup_service(database: Database, paths: AppPaths) -> BackupService:
    """Encrypted backups of the whole data directory (Phase 12)."""
    return BackupService(
        database.unit_of_work, SqliteSnapshotter(database.path), FileBackupArchive(paths)
    )


def open_archive(database: Database, paths: AppPaths) -> LocalArchiveController:
    return LocalArchiveController(
        EntityService(database.unit_of_work),
        open_document_service(database, paths),
        paths.inbox,
        open_processing_service(database, paths),
        InvoiceService(database.unit_of_work),
        open_validation_service(database),
        open_reference_service(database),
        ReviewService(
            database.unit_of_work,
            open_validation_service(database),
            derived=FileDerivedStore(paths.documents),
        ),
        open_export_service(database, paths),
        open_backup_service(database, paths),
        ScanService(
            open_document_service(database, paths),
            open_processing_service(database, paths),
            FileScanFolder(),
            paths.inbox,
        ),
    )


# A minimal, valid and fully synthetic PDF with a text layer (Phase 04 analyses it).
SYNTHETIC_PDF = text_pdf(["Selvtest - syntetisk faktura"])


def synthetic_invoice(
    invoice_number: str = "SELVTEST-1", document_id: UUID = SELF_TEST_DOCUMENT_ID
) -> CanonicalInvoice:
    """Small, fully synthetic invoice used only by the self-test."""
    calculated = {"source": "calculated", "producer": "selvtest/1"}
    return CanonicalInvoice.model_validate(
        {
            "document_id": str(document_id),
            "invoice_number": {"value": invoice_number, "provenance": calculated},
            "invoice_date": {"value": "2026-01-02", "provenance": calculated},
            "currency": {"value": "NOK", "provenance": calculated},
            "supplier": {"name": {"value": "Syntetisk Leverandør AS", "provenance": calculated}},
            "lines": [
                {
                    "line_number": 1,
                    "quantity": {"value": "3", "provenance": calculated},
                    "unit_price": {"value": "0.012500", "provenance": calculated},
                }
            ],
            "totals": {
                "net_amount": {"value": "987.60", "provenance": calculated},
                "vat_amount": {"value": "246.90", "provenance": calculated},
                "gross_amount": {"value": "1234.50", "provenance": calculated},
            },
        }
    )


def _remove_tree(path: Path) -> None:
    """rmtree that also removes the read-only originals of the document archive."""

    def make_writable(function: object, target: str, error: BaseException) -> None:
        os.chmod(target, stat.S_IWRITE | stat.S_IREAD)
        os.unlink(target)

    shutil.rmtree(path, onexc=make_writable)


def run_persistence_self_test(paths: AppPaths) -> None:
    """Exercise migration, import, isolated processing, invoices and the audit chain.

    Runs in a temporary database and archive below the data directory; the
    application database and archive are never touched. Raises
    ``RuntimeError`` on any deviation.
    """
    probe = paths.data / f".selftest-{uuid4().hex}"
    probe.mkdir()
    # A restore must go outside the backed-up data directory (here: the probe).
    restored = paths.data / f".selftest-{uuid4().hex}"
    database: Database | None = None
    try:
        path = probe / "selftest.sqlite3"
        result = initialize_database(path, probe / "backups")
        if not result.created or not result.audit.valid:
            raise RuntimeError("database initialisation")
        database = Database(path)
        if database.settings() != EXPECTED_SETTINGS:
            raise RuntimeError("database settings")
        entities = EntityService(database.unit_of_work)
        invoices = InvoiceService(database.unit_of_work)
        documents = DocumentService(database.unit_of_work, FileDocumentStore(probe / "documents"))
        owner = EntityScope(entities.create(name="Selvtest A").entity_id)
        other = EntityScope(entities.create(name="Selvtest B").entity_id)

        sources = probe / "kilde"
        sources.mkdir()
        pdf = sources / "selvtest.pdf"
        pdf.write_bytes(SYNTHETIC_PDF)
        (sources / "forkledd.pdf").write_bytes(b"MZ syntetisk, ikke en PDF")
        (sources / "tom.pdf").write_bytes(b"")
        imported = documents.import_file(owner, pdf)
        outcomes = [
            imported.outcome,
            documents.import_file(owner, pdf).outcome,
            documents.import_file(other, pdf).outcome,
            documents.import_file(owner, sources / "forkledd.pdf").outcome,
            documents.import_file(owner, sources / "tom.pdf").outcome,
        ]
        expected = [
            ImportOutcome.IMPORTED,
            ImportOutcome.DUPLICATE,
            ImportOutcome.IMPORTED,
            ImportOutcome.QUARANTINED,
            ImportOutcome.REJECTED,
        ]
        if outcomes != expected or imported.document_id is None or not pdf.exists():
            raise RuntimeError("document import")
        statuses = documents.verify_integrity(owner)
        if set(statuses.values()) != {IntegrityStatus.OK}:
            raise RuntimeError("document integrity")

        # The real isolated worker (spawned, resource-limited) analyses the PDF.
        validation = ValidationService(database.unit_of_work)
        references = ReferenceService(database.unit_of_work, validator=validation)
        processing = ProcessingService(
            database.unit_of_work,
            FileDocumentStore(probe / "documents"),
            FileDerivedStore(probe / "documents"),
            IsolatedDocumentProcessor(),
            attachments=documents,
            validator=validation,
            poster=references,
        )
        # Synthetic reference data (Phase 08b): chart of accounts and VAT codes.
        for kind, text in (
            (ReferenceKind.CHART, CHART_CSV),
            (ReferenceKind.VAT_CODES, VAT_CODES_CSV),
        ):
            source = sources / f"{kind}.csv"
            source.write_text(text, encoding="utf-8")
            if references.import_file(owner, kind, source).row_count < 2:
                raise RuntimeError("reference import")
        job = processing.process(owner, imported.document_id)
        pages = processing.pages(owner, job.job_id)
        if (
            job.status is not JobStatus.SUCCEEDED
            or job.page_count != 1
            or [page.text_layer_chars > 0 for page in pages] != [True]
            or len(processing.derived_files(owner, job.job_id)) != 2
            or processing.process(owner, imported.document_id) != job
        ):
            raise RuntimeError("document processing")
        ocr = processing.ocr_available()
        if ocr:
            _self_test_ocr(processing, documents, owner, job, sources, probe)

        # An EHF invoice is read in the worker and registered as a draft invoice.
        ehf = sources / "selvtest.xml"
        ehf.write_bytes(build_ehf())
        ehf_document = documents.import_file(owner, ehf).document_id
        if ehf_document is None:
            raise RuntimeError("ehf import")
        ehf_job = processing.process(owner, ehf_document)
        summary = invoices.summaries(owner).get(ehf_document)
        if (
            ehf_job.status is not JobStatus.SUCCEEDED
            or summary is None
            or summary.gross_amount != Decimal("13125.00")
            or summary.findings
        ):
            raise RuntimeError("ehf processing")

        # Validation: the new payment account is unverified until a user confirms
        # it, and the posting has no account until the supplier has a standard.
        run = validation.latest(owner, summary.invoice_id)
        if run is None or [f.rule_id.value for f in run.findings] != ["BANK-001", "ACC-002"]:
            raise RuntimeError("validation")
        (view,) = validation.suppliers(owner)
        (account,) = view.accounts
        validation.set_account_status(
            owner, account.account_id, AccountStatus.VERIFIED, expected=AccountStatus.UNVERIFIED
        )
        references.set_defaults(owner, view.supplier.supplier_id, account="6300", vat_code="1")
        run = validation.latest(owner, summary.invoice_id)
        if run is None or run.revision != 2 or run.findings:
            raise RuntimeError("validation after verification")

        # Approval binds the content; a later correction withdraws it (Phase 09).
        review = ReviewService(database.unit_of_work, validation)
        review.approve(owner, summary.invoice_id, expected_revision=2)
        review.edit(owner, summary.invoice_id, "buyer_reference", "Selvtest", expected_revision=2)
        approved = review.view(owner, summary.invoice_id)
        if approved.record.workflow_status != WorkflowStatus.DRAFT or [
            d.decision.value for d in approved.decisions
        ] != ["approved", "revoked"]:
            raise RuntimeError("approval")

        # Export (Phase 10): the approved content once to Excel, a second export
        # finds nothing, and the exported invoice can no longer change.
        exports = ExportService(
            database.unit_of_work,
            {ExportTarget.EXCEL: XlsxWriter(), ExportTarget.CSV: CsvWriter()},
            FileExportStore(probe / "exports"),
            t,
        )
        review.approve(owner, summary.invoice_id, expected_revision=3)
        batch = exports.export(owner, ExportTarget.EXCEL)
        copy = probe / "kopi.xlsx"
        exports.save_copy(owner, batch.batch_id, copy)
        try:
            exports.export(owner, ExportTarget.CSV)
        except ExportError:
            pass
        else:
            raise RuntimeError("double export")
        if (
            batch.item_count != 1
            or not copy.read_bytes().startswith(b"PK")
            or review.view(owner, summary.invoice_id).record.workflow_status
            != WorkflowStatus.EXPORTED
        ):
            raise RuntimeError("export")

        invoice = synthetic_invoice(document_id=imported.document_id)
        record = invoices.register(owner, invoice)
        stored = invoices.get(owner, record.invoice_id)
        if stored.invoice != invoice or stored.content_sha256 != content_sha256(invoice):
            raise RuntimeError("round trip")
        try:
            invoices.get(other, record.invoice_id)
        except NotFoundError:
            pass
        else:
            raise RuntimeError("entity isolation")
        revised = invoices.revise(
            owner,
            record.invoice_id,
            synthetic_invoice("SELVTEST-2", imported.document_id),
            expected_revision=1,
        )
        first = invoices.get_revision(owner, record.invoice_id, 1)
        if revised.revision != 2 or first.invoice != invoice:
            raise RuntimeError("revisions")
        # Scanned batch (Phase 11a): a finished file in the scan folder is imported,
        # set aside and analysed; a separator sheet splits it, a blank page is skipped.
        scan_inbox = probe / "skann"
        scan_inbox.mkdir()
        scanning = ScanService(documents, processing, FileScanFolder(min_age_seconds=0), scan_inbox)
        (scan_inbox / "bunke.pdf").write_bytes(
            batch_pdf(["Selvtest faktura A", "blank", "separator", "Selvtest faktura B"])
        )
        scanning.poll(owner)  # first look: the file must not change before the next
        polled = scanning.poll(owner)
        batches = [v for v in scanning.batches(owner) if v.document.display_name == "bunke.pdf"]
        if (
            (polled.imported, polled.processed) != (1, 1)
            or len(batches) != 1
            or batches[0].split.parts != ((1, 1), (4, 4))
            or not (scan_inbox / "importert" / "bunke.pdf").is_file()
        ):
            raise RuntimeError("scanned batch")

        # Field extraction (Phase 06): a laid-out invoice becomes a draft invoice.
        _self_test_extraction(database, documents, validation, references, owner, sources, probe)

        # Encrypted backup (Phase 12): restore into an empty folder passes every
        # check, and a changed byte is refused.
        backups = BackupService(
            database.unit_of_work, SqliteSnapshotter(path), FileBackupArchive(AppPaths(probe))
        )
        passphrase = secrets.token_urlsafe(16)  # Thrown away with the probe
        (probe / "sikkerhet").mkdir()
        made = backups.create(probe / "sikkerhet", passphrase, passphrase)
        backup_file = probe / "sikkerhet" / made.file_name
        check = backups.restore(backup_file, passphrase, restored)
        if not check.known or check.file_count != made.file_count:
            raise RuntimeError("backup")
        damaged = bytearray(backup_file.read_bytes())
        damaged[-100] ^= 1
        changed = probe / "sikkerhet" / "endret.ifbak"
        changed.write_bytes(bytes(damaged))
        try:
            backups.verify(changed, passphrase)
        except BackupError:
            pass
        else:
            raise RuntimeError("damaged backup")

        with database.unit_of_work() as uow:
            verification = uow.audit.verify()
        expected = SELF_TEST_EVENTS + EXTRACTION_SELF_TEST_EVENTS
        expected += OCR_SELF_TEST_EVENTS if ocr else 0
        if not verification.valid or verification.events_checked != expected:
            raise RuntimeError("audit chain")
    finally:
        if database is not None:
            database.close()
        # Fails on Windows if any file handle were still open.
        _remove_tree(probe)
        if restored.exists():
            _remove_tree(restored)


# database.created, 2 x entity.created, 5 document events, processing started/finished,
# EHF: document.imported, processing started/finished, invoice.created,
# supplier.created, supplier.account_added, invoice.validated;
# 2 x reference.imported; supplier.account_status_changed, invoice.validated;
# supplier.defaults_set, invoice.revised, invoice.validated; invoice.validated,
# invoice.approved; invoice.revised, invoice.approval_revoked, invoice.validated;
# invoice.validated, invoice.approved; invoice.exported, export.completed;
# invoice.created/revised; document.imported, processing started/finished (scan);
# backup.created, backup.restored, backup.verified
SELF_TEST_EVENTS = 41
# With Tesseract (Phase 05): document.imported, processing started/finished,
# OCR started/finished.
OCR_SELF_TEST_EVENTS = 5
# Extraction (Phase 06): document.imported, processing started/finished,
# invoice.created, supplier.created, supplier.account_added, invoice.validated.
EXTRACTION_SELF_TEST_EVENTS = 7


def _self_test_extraction(
    database: Database,
    documents: DocumentService,
    validation: ValidationService,
    references: ReferenceService,
    owner: EntityScope,
    sources: Path,
    probe: Path,
) -> None:
    extracting = ProcessingService(
        database.unit_of_work,
        FileDocumentStore(probe / "documents"),
        FileDerivedStore(probe / "documents"),
        IsolatedDocumentProcessor(),
        validator=validation,
        poster=references,
        extractor=ExtractionService(database.unit_of_work, validator=validation, poster=references),
    )
    source = sources / "laget-faktura.pdf"
    source.write_bytes(synthetic_invoice_pdf())
    document_id = documents.import_file(owner, source).document_id
    if document_id is None:
        raise RuntimeError("extraction import")
    extracting.process(owner, document_id)
    created = extracting.extract(owner, document_id)
    with database.unit_of_work() as uow:
        invoice = uow.invoices(owner).get(created[0]).invoice if len(created) == 1 else None
    if (
        invoice is None
        or invoice.invoice_number is None
        or invoice.invoice_number.value != "ST-2026-1"
        or invoice.totals.gross_amount is None
        or invoice.totals.gross_amount.value != Decimal("1000.00")
        or invoice.payment is None
        or invoice.payment.kid is None
        or invoice.payment.kid.value != "20260417005"
        or extracting.extract(owner, document_id) != []
    ):
        raise RuntimeError("extraction")


def _self_test_ocr(
    processing: ProcessingService,
    documents: DocumentService,
    owner: EntityScope,
    job: JobRecord,
    sources: Path,
    probe: Path,
) -> None:
    """The page image of the synthetic PDF, imported as a scan, must be read back."""
    render = next(
        record
        for record in processing.derived_files(owner, job.job_id)
        if record.kind is DerivedKind.PAGE_RENDER
    )
    data = FileDerivedStore(probe / "documents").read_published(
        render.storage_path, render.sha256, 64 * 1024 * 1024
    )
    if data is None:
        raise RuntimeError("ocr source")
    scan = sources / "skannet.png"
    scan.write_bytes(data)
    scanned = documents.import_file(owner, scan).document_id
    if scanned is None:
        raise RuntimeError("ocr import")
    processing.process(owner, scanned)
    recognised = processing.recognise(owner, scanned)
    texts = processing.page_texts(owner, scanned)
    if (
        recognised is None
        or recognised.status is not JobStatus.SUCCEEDED
        or len(texts) != 1
        or "syntetisk faktura" not in (texts[0].text or "").lower()
    ):
        raise RuntimeError("ocr")
