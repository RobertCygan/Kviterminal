"""Exercise the same real Qt window used for interactive startup."""

from PySide6.QtWidgets import QApplication

from invoiceflow.i18n import t
from invoiceflow.i18n.catalog_nb_no import NAVIGATION
from invoiceflow.ui.main_window import MainWindow


def run_self_test(app: QApplication, window: MainWindow) -> None:
    """Raise on broken navigation or an unexpected shell title."""
    if window.windowTitle() != t("app.title") or window.pages.count() != len(NAVIGATION):
        raise RuntimeError("Invalid shell")
    for index in range(len(NAVIGATION)):
        window.navigation.setCurrentRow(index)
        app.processEvents()
        if window.pages.currentIndex() != index:
            raise RuntimeError("Navigation failed")
    window.navigation.setCurrentRow(0)
    window.close()
