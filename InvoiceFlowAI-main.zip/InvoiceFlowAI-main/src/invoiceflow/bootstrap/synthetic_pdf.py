"""Minimal, fully synthetic PDF files for the self-test and the test suite.

Written by hand (no PDF library) so that the bytes are known exactly. Never
used for real documents.
"""

from collections.abc import Sequence

from invoiceflow.application.scan.separator import (
    build_pdf,
    pdf_text,
    separator_content,
    stream,
)

__all__ = [
    "batch_pdf",
    "build_pdf",
    "layout_pdf",
    "lines_pdf",
    "stream",
    "synthetic_invoice_pdf",
    "text_pdf",
]


def text_pdf(
    texts: Sequence[str],
    *,
    media_box: bytes = b"[0 0 595 842]",
    page_extra: bytes = b"",
    catalog_extra: bytes = b"",
    trailer_extra: bytes = b"",
) -> bytes:
    """One A4 page per text, set in Helvetica at 12 pt near the top left."""
    count = len(texts)
    kids = b" ".join(b"%d 0 R" % (4 + 2 * index) for index in range(count))
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R " + catalog_extra + b">>",
        b"<< /Type /Pages /Kids [" + kids + b"] /Count %d >>" % count,
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
    ]
    for index, text in enumerate(texts):
        content = b"BT /F1 12 Tf 72 770 Td " + pdf_text(text) + b" Tj ET"
        objects.append(
            b"<< /Type /Page /Parent 2 0 R /MediaBox "
            + media_box
            + b" "
            + page_extra
            + b"/Resources << /Font << /F1 3 0 R >> >> /Contents %d 0 R >>" % (5 + 2 * index)
        )
        objects.append(stream(content))
    return build_pdf(objects, trailer_extra=trailer_extra)


def batch_pdf(pages: Sequence[str]) -> bytes:
    """A synthetic scanned batch: ``"blank"``, ``"separator"`` or the text of a page."""
    count = len(pages)
    kids = b" ".join(b"%d 0 R" % (4 + 2 * index) for index in range(count))
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [" + kids + b"] /Count %d >>" % count,
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
    ]
    for index, page in enumerate(pages):
        if page == "blank":
            content = b""
        elif page == "separator":
            content = separator_content()
        else:
            # A dense block of text, like a printed invoice.
            line = pdf_text(page)
            content = (
                b"BT /F1 14 Tf 60 780 Td 16 TL" + b" " + b" ".join([line + b" '"] * 40) + b" ET"
            )
        objects.append(
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            b"/Resources << /Font << /F1 3 0 R >> >> /Contents %d 0 R >>" % (5 + 2 * index)
        )
        objects.append(stream(content))
    return build_pdf(objects)


def lines_pdf(lines: Sequence[str], *, font_size: int = 11) -> bytes:
    """One A4 page with the lines below each other, like a printed invoice."""
    leading = round(font_size * 1.6)
    body = b" ".join(pdf_text(line) + b" Tj T*" for line in lines)
    content = b"BT /F1 %d Tf 60 780 Td %d TL " % (font_size, leading) + body + b" ET"
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [4 0 R] /Count 1 >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
        b"/Resources << /Font << /F1 3 0 R >> >> /Contents 5 0 R >>",
        stream(content),
    ]
    return build_pdf(objects)


def layout_pdf(
    pages: Sequence[Sequence[tuple[float, float, str]] | str], *, font_size: int = 10
) -> bytes:
    """Pages of text placed at ``(x, y)`` points from the top left, like a laid-out invoice.

    A page given as ``"separator"`` is the separator sheet of a scanned batch.
    """
    count = len(pages)
    kids = b" ".join(b"%d 0 R" % (4 + 2 * index) for index in range(count))
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [" + kids + b"] /Count %d >>" % count,
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
    ]
    for index, items in enumerate(pages):
        if isinstance(items, str):
            content = separator_content()
        else:
            content = b" ".join(
                b"BT /F1 %d Tf %.1f %.1f Td " % (font_size, x, 842 - y) + pdf_text(text) + b" Tj ET"
                for x, y, text in items
            )
        objects.append(
            b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
            b"/Resources << /Font << /F1 3 0 R >> >> /Contents %d 0 R >>" % (5 + 2 * index)
        )
        objects.append(stream(content))
    return build_pdf(objects)


def synthetic_invoice_pdf() -> bytes:
    """A laid-out synthetic invoice (Phase 06 self-test); no real company or account."""
    return layout_pdf(
        (
            (
                (50, 50, "Selvtest Leverandør AS"),
                (50, 64, "Org.nr. NO 999 999 999 MVA"),
                (400, 50, "FAKTURA"),
                (350, 130, "Fakturanummer: ST-2026-1"),
                (350, 144, "Fakturadato: 24.10.2026"),
                (350, 158, "Forfallsdato: 07.11.2026"),
                (350, 310, "Sum eks. MVA"),
                (480, 310, "800,00"),
                (350, 324, "MVA 25 %"),
                (480, 324, "200,00"),
                (350, 338, "Å betale NOK"),
                (480, 338, "1 000,00"),
                (50, 400, "Kontonummer: 1234.56.78903"),
                (50, 414, "KID: 20260417005"),
            ),
        )
    )
