"""Fully synthetic reference data files for the self-test, tests and examples.

The codes and rates are examples only; they are not a Norwegian standard
chart of accounts or the official VAT codes. A real entity imports its own
files from its ERP (Å-18).
"""

CHART_CSV = (
    "konto;navn;mva_kode;aktiv\n"
    "6300;Leie lokale;1;ja\n"
    "6800;Kontorrekvisita;1;ja\n"
    "6860;Møte, kurs, oppdatering;1;ja\n"
    "7140;Reisekostnad;1;ja\n"
    "6900;Utgått konto;;nei\n"
)

VAT_CODES_CSV = (
    "kode;sats;retning;gyldig_fra;gyldig_til;saft_kode;navn\n"
    "1;25;inngående;2026-01-01;;1;Syntetisk: inngående, høy sats\n"
    "11;15;inngående;2026-01-01;;11;Syntetisk: inngående, middels sats\n"
    "13;12;inngående;2026-01-01;;13;Syntetisk: inngående, lav sats\n"
    "0;0;inngående;2026-01-01;;0;Syntetisk: ingen MVA\n"
    "3;25;utgående;2026-01-01;;3;Syntetisk: utgående, høy sats\n"
)

DIMENSIONS_CSV = (
    "dimensjon;kode;navn;aktiv\n"
    "avdeling;10;Syntetisk avdeling Narvik;ja\n"
    "kostnadssted;100;Syntetisk kostnadssted;ja\n"
    "prosjekt;P1;Syntetisk prosjekt;ja\n"
)
