"""Compose the document archive for the GUI (D-22, D-23, D-24, Phase 04).

Exactly one accounting entity can be active. With none, only creating the
first entity is possible; with several (not supported by the UI in Phase 03)
import is disabled instead of choosing one implicitly.
"""

import threading
from collections.abc import Sequence
from pathlib import Path
from uuid import UUID

from invoiceflow.application.backup.model import BackupCheck, BackupRecord
from invoiceflow.application.backup.service import BackupService
from invoiceflow.application.document_model import (
    DocumentRecord,
    DocumentType,
    ImportResult,
    RecoveryReport,
)
from invoiceflow.application.documents import DocumentService
from invoiceflow.application.errors import InvoiceFlowError
from invoiceflow.application.export.model import (
    ExportBatchRecord,
    ExportCandidate,
    ExportColumn,
    ExportMapping,
    ExportRecovery,
    ExportTarget,
)
from invoiceflow.application.export.service import ExportService
from invoiceflow.application.processing import ProcessingService
from invoiceflow.application.processing_model import JobRecord, PageText, ProcessingRecovery
from invoiceflow.application.reference.model import (
    Dimension,
    ImportRecord,
    ReferenceData,
    ReferenceKind,
    SupplierDefaults,
)
from invoiceflow.application.reference.service import ReferenceService
from invoiceflow.application.review.service import ReviewService, ReviewView
from invoiceflow.application.scan.service import BatchView, ScanPoll, ScanService
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import EntityService, InvoiceService, InvoiceSummary
from invoiceflow.application.validation.model import (
    AccountStatus,
    ValidationFinding,
    ValidationRun,
)
from invoiceflow.application.validation.service import SupplierView, ValidationService
from invoiceflow.domain.invoice import AccountingLine
from invoiceflow.ui.documents_page import EntityState


class LocalArchiveController:
    """Implements :class:`invoiceflow.ui.documents_page.ArchiveController`."""

    def __init__(
        self,
        entities: EntityService,
        documents: DocumentService,
        inbox: Path,
        processing: ProcessingService,
        invoices: InvoiceService,
        validation: ValidationService,
        references: ReferenceService,
        review: ReviewService,
        exports: ExportService,
        backups: BackupService,
        scanning: ScanService,
    ) -> None:
        self._entities = entities
        self._documents = documents
        self._inbox = inbox
        self._processing = processing
        self._invoices = invoices
        self._validation = validation
        self._references = references
        self._review = review
        self._exports = exports
        self._backups = backups
        self._scanning = scanning
        self._stop = threading.Event()

    def request_stop(self) -> None:
        """Stop imports after the current file and kill a running worker (shutdown)."""
        self._stop.set()

    def entity_state(self) -> EntityState:
        records = self._entities.list()
        return EntityState(records[0].name if len(records) == 1 else None, len(records))

    def create_entity(self, name: str, org_number: str | None) -> None:
        if self._entities.list():
            raise InvoiceFlowError("ENTITY_EXISTS", "entity.already_exists")
        self._entities.create(name=name, org_number=org_number)

    def _scope(self) -> EntityScope:
        records = self._entities.list()
        if len(records) != 1:
            # No implicit choice between several entities (no default fallback).
            key = "entity.none" if not records else "entity.multiple"
            raise InvoiceFlowError("ENTITY_REQUIRED", key)
        return EntityScope(records[0].entity_id)

    def list_documents(self) -> list[DocumentRecord]:
        records = self._entities.list()
        if len(records) != 1:
            return []
        return self._documents.list_documents(EntityScope(records[0].entity_id))

    def import_files(self, paths: Sequence[Path]) -> list[ImportResult]:
        return self._documents.import_files(self._scope(), paths, should_stop=self._stop.is_set)

    def import_inbox(self) -> list[ImportResult]:
        return self._documents.import_inbox(
            self._scope(), self._inbox, should_stop=self._stop.is_set
        )

    def set_type(self, document_id: UUID, document_type: DocumentType) -> None:
        self._documents.set_type(self._scope(), document_id, document_type)

    def latest_jobs(self) -> dict[UUID, JobRecord]:
        records = self._entities.list()
        if len(records) != 1:
            return {}
        return self._processing.latest_jobs(EntityScope(records[0].entity_id))

    def latest_ocr_jobs(self) -> dict[UUID, JobRecord]:
        records = self._entities.list()
        if len(records) != 1:
            return {}
        return self._processing.latest_ocr_jobs(EntityScope(records[0].entity_id))

    def ocr_available(self) -> bool:
        return self._processing.ocr_available()

    def page_texts(self, document_id: UUID) -> list[PageText]:
        return self._processing.page_texts(self._scope(), document_id)

    def invoice_summaries(self) -> dict[UUID, InvoiceSummary]:
        records = self._entities.list()
        if len(records) != 1:
            return {}
        return self._invoices.summaries(EntityScope(records[0].entity_id))

    def validation_run(self, invoice_id: UUID) -> ValidationRun | None:
        return self._validation.latest(self._scope(), invoice_id)

    def revalidate(self) -> list[ValidationRun]:
        return self._validation.validate_all(self._scope())

    def suppliers(self) -> list[SupplierView]:
        records = self._entities.list()
        if len(records) != 1:
            return []
        return self._validation.suppliers(EntityScope(records[0].entity_id))

    def set_account_status(
        self, account_id: UUID, status: AccountStatus, expected: AccountStatus
    ) -> None:
        self._validation.set_account_status(self._scope(), account_id, status, expected=expected)

    def posting(self, invoice_id: UUID) -> tuple[AccountingLine, ...]:
        return self._invoices.get(self._scope(), invoice_id).invoice.accounting_lines

    def resuggest(self, invoice_id: UUID) -> None:
        self._references.suggest(self._scope(), invoice_id)

    def reference_status(self) -> dict[ReferenceKind, ImportRecord]:
        records = self._entities.list()
        if len(records) != 1:
            return {}
        return self._references.status(EntityScope(records[0].entity_id))

    def import_reference(self, kind: ReferenceKind, path: Path) -> ImportRecord:
        return self._references.import_file(self._scope(), kind, path)

    def reference_data(self) -> ReferenceData:
        return self._references.reference(self._scope())

    def supplier_defaults(self, supplier_id: UUID) -> SupplierDefaults | None:
        return self._references.defaults(self._scope(), supplier_id)

    def set_supplier_defaults(
        self,
        supplier_id: UUID,
        account: str | None,
        vat_code: str | None,
        dimensions: dict[Dimension, str],
    ) -> None:
        self._references.set_defaults(
            self._scope(), supplier_id, account=account, vat_code=vat_code, dimensions=dimensions
        )

    def review_view(self, invoice_id: UUID) -> ReviewView:
        return self._review.view(self._scope(), invoice_id)

    def review_preview(self, invoice_id: UUID) -> bytes | None:
        return self._review.preview(self._scope(), invoice_id)

    def edit_field(self, invoice_id: UUID, path: str, text: str, revision: int) -> None:
        self._review.edit(self._scope(), invoice_id, path, text, expected_revision=revision)

    def override_finding(
        self, invoice_id: UUID, finding: ValidationFinding, reason: str, revision: int
    ) -> None:
        self._review.override(
            self._scope(), invoice_id, finding, reason, expected_revision=revision
        )

    def approve(self, invoice_id: UUID, revision: int, comment: str | None) -> None:
        self._review.approve(self._scope(), invoice_id, expected_revision=revision, comment=comment)

    def reject(self, invoice_id: UUID, revision: int, comment: str) -> None:
        self._review.reject(self._scope(), invoice_id, expected_revision=revision, comment=comment)

    def revoke(self, invoice_id: UUID, revision: int) -> None:
        self._review.revoke(self._scope(), invoice_id, expected_revision=revision)

    def export_ready(self) -> list[ExportCandidate]:
        records = self._entities.list()
        if len(records) != 1:
            return []
        return self._exports.ready(EntityScope(records[0].entity_id))

    def export_batches(self) -> list[ExportBatchRecord]:
        records = self._entities.list()
        if len(records) != 1:
            return []
        return self._exports.batches(EntityScope(records[0].entity_id))

    def export_invoices(self, target: ExportTarget) -> ExportBatchRecord:
        return self._exports.export(self._scope(), target)

    def reexport(self, batch_id: UUID, reason: str, target: ExportTarget) -> ExportBatchRecord:
        return self._exports.reexport(self._scope(), batch_id, reason, target=target)

    def save_export_copy(self, batch_id: UUID, destination: Path) -> None:
        self._exports.save_copy(self._scope(), batch_id, destination)

    def export_mapping(self) -> ExportMapping:
        return self._exports.mapping(self._scope())

    def set_export_mapping(
        self, columns: list[ExportColumn], expected_version: int
    ) -> ExportMapping:
        return self._exports.set_mapping(self._scope(), columns, expected_version=expected_version)

    def reconcile_exports(self) -> ExportRecovery:
        """Startup recovery of interrupted exports for every entity."""
        totals = [0, 0, 0]
        for record in self._entities.list():
            report = self._exports.recover(EntityScope(record.entity_id))
            for index, value in enumerate(
                (report.completed, report.failed, report.temporary_removed)
            ):
                totals[index] += value
        return ExportRecovery(*totals)

    def backups(self) -> list[BackupRecord]:
        return self._backups.backups()

    def create_backup(self, folder: Path, passphrase: str, confirmation: str) -> BackupRecord:
        return self._backups.create(folder, passphrase, confirmation)

    def verify_backup(self, source: Path, passphrase: str) -> BackupCheck:
        return self._backups.verify(source, passphrase)

    def restore_backup(self, source: Path, passphrase: str, target: Path) -> BackupCheck:
        return self._backups.restore(source, passphrase, target)

    def delete_backup(self, source: Path) -> BackupRecord:
        return self._backups.delete(source)

    def reconcile_backups(self) -> int:
        """Remove unencrypted work folders left by an interrupted backup (startup)."""
        return self._backups.recover()

    def scan_folder(self) -> str:
        return str(self._scanning.inbox)

    def scan_poll(self) -> ScanPoll:
        records = self._entities.list()
        if len(records) != 1:
            return ScanPoll()  # No entity yet: files stay in the folder.
        return self._scanning.poll(EntityScope(records[0].entity_id), should_stop=self._stop.is_set)

    def scan_batches(self) -> list[BatchView]:
        records = self._entities.list()
        if len(records) != 1:
            return []
        return self._scanning.batches(EntityScope(records[0].entity_id))

    def save_separator_sheet(self, destination: Path) -> None:
        self._scanning.save_separator_sheet(destination)

    def process_pending(self) -> list[JobRecord]:
        return self._processing.process_pending(self._scope(), should_stop=self._stop.is_set)

    def process_document(self, document_id: UUID) -> list[JobRecord]:
        """Analysis, then OCR of the pages that need it (Phase 05)."""
        scope = self._scope()
        jobs = [self._processing.process(scope, document_id, should_stop=self._stop.is_set)]
        recognised = self._processing.recognise(scope, document_id, should_stop=self._stop.is_set)
        self._processing.extract(scope, document_id)  # draft invoices (Phase 06)
        return jobs if recognised is None else [*jobs, recognised]

    def reconcile_processing(self) -> ProcessingRecovery:
        """Startup recovery of interrupted jobs for every entity; nothing is deleted."""
        totals = [0, 0, 0, 0]
        for record in self._entities.list():
            report = self._processing.reconcile(EntityScope(record.entity_id))
            for index, value in enumerate(
                (report.interrupted, report.work_removed, report.derived_moved, report.failed)
            ):
                totals[index] += value
        return ProcessingRecovery(*totals)

    def reconcile_all(self) -> RecoveryReport:
        """Startup crash recovery for every entity; nothing is deleted."""
        staging = orphans = failed = 0
        missing: list[UUID] = []
        for record in self._entities.list():
            report = self._documents.reconcile(EntityScope(record.entity_id))
            staging += report.staging_removed
            orphans += report.orphans_moved
            failed += report.failed
            missing.extend(report.missing)
        return RecoveryReport(staging, orphans, tuple(missing), failed)
