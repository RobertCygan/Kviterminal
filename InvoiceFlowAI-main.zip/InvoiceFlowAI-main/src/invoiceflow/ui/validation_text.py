"""Norwegian texts for validation findings and payment accounts (Phase 08a).

Findings carry only codes, numbers and dates; the wording comes from the
translation catalogue and the numbers are formatted here.
"""

from decimal import Decimal, InvalidOperation

from invoiceflow.application.validation.model import (
    AccountKind,
    ValidationFinding,
    ValidationSummary,
)
from invoiceflow.i18n import t
from invoiceflow.i18n.catalog_nb_no import CATALOG
from invoiceflow.i18n.formatting import format_amount, format_percent

_AMOUNTS = frozenset({"expected", "actual"})


def _param(name: str, value: str) -> str:
    try:
        if name in _AMOUNTS:
            return format_amount(Decimal(value))
        if name == "rate":
            return format_percent(Decimal(value))
        if name == "dimension":
            return t(f"dimension.{value}")
    except InvalidOperation:
        return value
    return value


def finding_text(finding: ValidationFinding) -> str:
    """'Feil (SUM-001): ...' with formatted amounts and the field's name."""
    params = {name: _param(name, value) for name, value in finding.params.items()}
    field_key = f"field.{finding.field_path}"
    if field_key in CATALOG:
        params.setdefault("field", t(field_key))
    message = t(finding.message_key, **params)
    severity = t(f"validation.severity.{finding.severity}")
    return t("validation.line", severity=severity, rule=finding.rule_id.value, message=message)


def status_text(summary: ValidationSummary | None) -> str:
    if summary is None:
        return t("validation.status.none")
    parts = []
    if summary.errors:
        parts.append(t("validation.status.errors", count=summary.errors))
    if summary.warnings:
        key = "warning_one" if summary.warnings == 1 else "warnings"
        parts.append(t(f"validation.status.{key}", count=summary.warnings))
    return ", ".join(parts) or t("validation.status.ok")


def format_account(kind: AccountKind, account: str) -> str:
    """1234.56.78903 for Norwegian accounts, groups of four for IBAN."""
    if kind is AccountKind.BBAN and len(account) == 11:
        return f"{account[:4]}.{account[4:6]}.{account[6:]}"
    return " ".join(account[index : index + 4] for index in range(0, len(account), 4))
