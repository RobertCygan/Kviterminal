"""Document inbox: first accounting entity (D-22), import (D-23), type (D-24)
and isolated page analysis with its status (Phase 04), and the text of each
page from its text layer or OCR (Phase 05).

The page talks to an :class:`ArchiveController` composed in ``bootstrap``; it
never touches files or the database itself. All controller calls run on a
worker thread so that the GUI never blocks on disk or SQLite.
"""

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from uuid import UUID

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentRecord,
    DocumentType,
    ImportOutcome,
    ImportResult,
)
from invoiceflow.application.processing_model import (
    JobRecord,
    JobStatus,
    PageText,
    ProcessingErrorCode,
    TextSource,
)
from invoiceflow.application.services import InvoiceSummary
from invoiceflow.application.validation.model import ValidationRun
from invoiceflow.domain.invoice import AccountingLine
from invoiceflow.i18n import t
from invoiceflow.i18n.formatting import format_amount, format_date
from invoiceflow.ui.background import BackgroundTask
from invoiceflow.ui.dialogs import long_text_dialog, text_dialog
from invoiceflow.ui.validation_text import finding_text, status_text
from invoiceflow.ui.widgets import plain_label

TYPE_KEYS = {document_type: f"document.type.{document_type}" for document_type in DocumentType}
COLUMNS = (
    "documents.col.name",
    "documents.col.type",
    "documents.col.format",
    "documents.col.size",
    "documents.col.imported",
    "documents.col.status",
    "documents.col.pages",
    "documents.col.processing",
    "documents.col.text",
    "documents.col.invoice",
    "documents.col.findings",
    "documents.col.validation",
)
FILE_FILTER = "documents.file_filter"
# The document itself was refused; other failures are technical.
REJECTED_CODES = frozenset(
    {
        ProcessingErrorCode.ENCRYPTED,
        ProcessingErrorCode.NO_PAGES,
        ProcessingErrorCode.TOO_MANY_PAGES,
        ProcessingErrorCode.PAGE_TOO_LARGE,
        ProcessingErrorCode.TOO_MUCH_TEXT,
        ProcessingErrorCode.OUTPUT_TOO_LARGE,
        ProcessingErrorCode.UNSUPPORTED_FORMAT,
        ProcessingErrorCode.INVALID_XML,
        ProcessingErrorCode.UNSUPPORTED_VERSION,
        ProcessingErrorCode.TOO_MANY_LINES,
        ProcessingErrorCode.TOO_MANY_ATTACHMENTS,
        ProcessingErrorCode.ATTACHMENT_TOO_LARGE,
    }
)


@dataclass(frozen=True, slots=True)
class EntityState:
    """``name`` is set only when exactly one entity exists (D-22)."""

    name: str | None
    count: int


class ArchiveController(Protocol):
    def entity_state(self) -> EntityState: ...

    def create_entity(self, name: str, org_number: str | None) -> None: ...

    def list_documents(self) -> list[DocumentRecord]: ...

    def import_files(self, paths: Sequence[Path]) -> list[ImportResult]: ...

    def import_inbox(self) -> list[ImportResult]: ...

    def set_type(self, document_id: UUID, document_type: DocumentType) -> None: ...

    def latest_jobs(self) -> dict[UUID, JobRecord]: ...

    def latest_ocr_jobs(self) -> dict[UUID, JobRecord]: ...

    def ocr_available(self) -> bool: ...

    def page_texts(self, document_id: UUID) -> list[PageText]: ...

    def invoice_summaries(self) -> dict[UUID, InvoiceSummary]: ...

    def validation_run(self, invoice_id: UUID) -> ValidationRun | None: ...

    def revalidate(self) -> list[ValidationRun]: ...

    def posting(self, invoice_id: UUID) -> tuple[AccountingLine, ...]: ...

    def resuggest(self, invoice_id: UUID) -> None: ...

    def process_pending(self) -> list[JobRecord]: ...

    def process_document(self, document_id: UUID) -> list[JobRecord]: ...

    def request_stop(self) -> None: ...


def format_size(size_bytes: int) -> str:
    """Integer arithmetic only; one decimal with a Norwegian comma for MB."""
    if size_bytes < 1024:
        return t("documents.size.bytes", value=size_bytes)
    if size_bytes < 1024 * 1024:
        return t("documents.size.kb", value=(size_bytes + 512) // 1024)
    tenths = (size_bytes * 10 + 512 * 1024) // (1024 * 1024)
    return t("documents.size.mb", value=f"{tenths // 10},{tenths % 10}")


def summarize(results: Sequence[ImportResult]) -> str:
    counts = {outcome: 0 for outcome in ImportOutcome}
    for result in results:
        counts[result.outcome] += 1
    return t(
        "documents.summary",
        imported=counts[ImportOutcome.IMPORTED],
        duplicate=counts[ImportOutcome.DUPLICATE],
        quarantined=counts[ImportOutcome.QUARANTINED],
        rejected=counts[ImportOutcome.REJECTED],
        failed=counts[ImportOutcome.FAILED],
    )


def summarize_processing(jobs: Sequence[JobRecord]) -> str:
    counts = {status: 0 for status in JobStatus}
    for job in jobs:
        counts[job.status] += 1
    return t(
        "processing.summary",
        succeeded=counts[JobStatus.SUCCEEDED],
        failed=counts[JobStatus.FAILED],
        timed_out=counts[JobStatus.TIMED_OUT],
        cancelled=counts[JobStatus.CANCELLED],
    )


def processing_text(job: JobRecord | None) -> str:
    """Status of the latest job in plain Norwegian; codes, never library text."""
    if job is None:
        return t("processing.status.none")
    if job.status is JobStatus.SUCCEEDED:
        key = "succeeded_active" if job.active_content else "succeeded"
        return t(f"processing.status.{key}")
    if job.status is JobStatus.FAILED and job.error_code is not None:
        reason = t(f"processing.error.{job.error_code}")
        key = "rejected" if job.error_code in REJECTED_CODES else "failed"
        return t(f"processing.status.{key}", reason=reason)
    return t(f"processing.status.{job.status}")


def ocr_text(job: JobRecord | None) -> str:
    """OCR status of a document; empty when no page needed it."""
    if job is None:
        return ""
    if job.status is JobStatus.SUCCEEDED:
        return t("documents.text.ocr", count=job.page_count or 0)
    if job.error_code is not None and job.status is JobStatus.FAILED:
        return t("documents.text.ocr_failed", reason=t(f"processing.error.{job.error_code}"))
    return t("documents.text.ocr_failed", reason=t(f"processing.status.{job.status}"))


def page_texts_text(texts: Sequence[PageText]) -> str:
    """Every page with where its text comes from; plain text for a read-only view."""
    if not texts:
        return t("text.dialog.none")
    blocks = []
    for page in texts:
        if page.source is TextSource.OCR:
            heading = t("text.page.ocr", page=page.page_number, confidence=page.mean_confidence)
        else:
            heading = t(f"text.page.{page.source}", page=page.page_number)
        body = t("text.page.unreadable") if page.text is None else page.text
        blocks.append(heading + ("\n" + body if body else ""))
    return "\n\n".join(blocks)


def invoice_text(summary: InvoiceSummary | None) -> str:
    """Supplier, number and amount as plain text; empty without an invoice."""
    if summary is None:
        return ""
    parts = [summary.supplier_name or "", summary.invoice_number or ""]
    if summary.gross_amount is not None:
        parts.append(f"{format_amount(summary.gross_amount)} {summary.currency or ''}".strip())
    return " · ".join(part for part in parts if part)


def findings_text(summary: InvoiceSummary | None) -> str:
    if summary is None:
        return ""
    return "; ".join(t(f"finding.{code}") for code in summary.findings)


def validation_text(summary: InvoiceSummary | None) -> str:
    return "" if summary is None else status_text(summary.validation)


def validation_details(run: ValidationRun | None) -> str:
    if run is None:
        return t("validation.dialog.not_run")
    if not run.findings:
        return t("validation.dialog.none")
    return "\n".join(finding_text(finding) for finding in run.findings)


def posting_details(lines: Sequence[AccountingLine]) -> str:
    """The posting suggestion as plain text, one line per accounting line."""
    if not lines:
        return t("posting.none")
    missing = t("posting.missing")
    rows = []
    for line in lines:
        amount = line.net_amount.value if line.net_amount is not None else None
        rows.append(
            t(
                "posting.line",
                number=line.line_number,
                account=line.account.value if line.account is not None else missing,
                vat_code=line.vat_code.value if line.vat_code is not None else missing,
                amount=missing if amount is None else format_amount(amount),
            )
        )
    return "\n".join(rows)


def summarize_validation(runs: Sequence[ValidationRun]) -> str:
    return t("validation.summary", count=len(runs))


def format_label(record: DocumentRecord) -> str:
    if record.detected_format is None:
        return ""
    if record.detected_format is DocumentFormat.XML:
        return t("documents.format.ehf")
    return str(record.detected_format).upper()


class EntityDialog(QDialog):
    """Create the first accounting entity; no business data is invented."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle(t("entity.dialog.title"))
        layout = QFormLayout(self)
        self.name = QLineEdit()
        self.name.setMaxLength(300)
        self.org_number = QLineEdit()
        self.org_number.setMaxLength(9)
        self.org_number.setInputMask("999999999;_")
        layout.addRow(plain_label(t("entity.dialog.name")), self.name)
        layout.addRow(plain_label(t("entity.dialog.org_number")), self.org_number)
        buttons = QDialogButtonBox()
        self.ok_button = buttons.addButton(
            t("button.create"), QDialogButtonBox.ButtonRole.AcceptRole
        )
        buttons.addButton(t("button.cancel"), QDialogButtonBox.ButtonRole.RejectRole)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def values(self) -> tuple[str, str | None]:
        org = self.org_number.text().replace("_", "").strip()
        return self.name.text().strip(), org or None


class DocumentsPage(QWidget):
    def __init__(self, controller: ArchiveController, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._controller = controller
        self._pool = QThreadPool.globalInstance()
        self._tasks: set[BackgroundTask] = set()
        self._documents: list[DocumentRecord] = []
        self._jobs: dict[UUID, JobRecord] = {}
        self._ocr_jobs: dict[UUID, JobRecord] = {}
        self._invoices: dict[UUID, InvoiceSummary] = {}
        self.validation_dialog: QDialog | None = None
        self.text_dialog: QDialog | None = None
        layout = QVBoxLayout(self)
        layout.addWidget(plain_label(t("nav.inbox")))
        self.entity_label = plain_label("")
        layout.addWidget(self.entity_label)
        self.ocr_label = plain_label("")
        self.ocr_label.setVisible(False)
        layout.addWidget(self.ocr_label)
        buttons = QHBoxLayout()
        self.create_entity_button = QPushButton(t("entity.create"))
        self.import_button = QPushButton(t("documents.import_file"))
        self.inbox_button = QPushButton(t("documents.import_inbox"))
        self.type_button = QPushButton(t("documents.set_type"))
        self.process_pending_button = QPushButton(t("documents.process_pending"))
        self.process_selected_button = QPushButton(t("documents.process_selected"))
        self.show_text_button = QPushButton(t("documents.show_text"))
        self.show_validation_button = QPushButton(t("documents.show_validation"))
        self.revalidate_button = QPushButton(t("documents.revalidate"))
        self.resuggest_button = QPushButton(t("documents.resuggest"))
        for button in (
            self.create_entity_button,
            self.import_button,
            self.inbox_button,
            self.type_button,
            self.process_pending_button,
            self.process_selected_button,
            self.show_text_button,
            self.show_validation_button,
            self.revalidate_button,
            self.resuggest_button,
        ):
            buttons.addWidget(button)
        buttons.addStretch()
        layout.addLayout(buttons)
        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels([t(key) for key in COLUMNS])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setAccessibleName(t("documents.table"))
        layout.addWidget(self.table)
        self.status_label = plain_label("")
        layout.addWidget(self.status_label)
        self.create_entity_button.clicked.connect(self._create_entity)
        self.import_button.clicked.connect(self._choose_files)
        self.inbox_button.clicked.connect(
            lambda: self._run(self._controller.import_inbox, summarize)
        )
        self.type_button.clicked.connect(self._change_type)
        self.process_pending_button.clicked.connect(
            lambda: self._run(self._controller.process_pending, summarize_processing)
        )
        self.process_selected_button.clicked.connect(self._process_selected)
        self.show_text_button.clicked.connect(self._show_text)
        self.show_validation_button.clicked.connect(self._show_validation)
        self.resuggest_button.clicked.connect(self._resuggest)
        self.revalidate_button.clicked.connect(
            lambda: self._run(self._controller.revalidate, summarize_validation)
        )
        self.table.itemSelectionChanged.connect(self._update_buttons)
        self._state = EntityState(None, 0)
        self._busy = False
        self.refresh()

    # -- state ------------------------------------------------------------

    def refresh(self) -> None:
        self._run(
            lambda: (
                self._controller.entity_state(),
                self._controller.list_documents(),
                self._controller.latest_jobs(),
                self._controller.invoice_summaries(),
                self._controller.latest_ocr_jobs(),
                self._controller.ocr_available(),
            )
        )

    def _show(
        self,
        state: EntityState,
        documents: list[DocumentRecord],
        jobs: dict[UUID, JobRecord],
        invoices: dict[UUID, InvoiceSummary],
        ocr_jobs: dict[UUID, JobRecord],
        ocr_available: bool,
    ) -> None:
        self._state = state
        self._jobs = jobs
        self._ocr_jobs = ocr_jobs
        self._invoices = invoices
        self.ocr_label.setText("" if ocr_available else t("documents.ocr_missing"))
        self.ocr_label.setVisible(not ocr_available)
        if state.count == 0:
            self.entity_label.setText(t("entity.none"))
        elif state.name is None:
            self.entity_label.setText(t("entity.multiple"))
        else:
            self.entity_label.setText(t("entity.active", name=state.name))
        self._documents = documents
        self.table.setRowCount(len(documents))
        for row, record in enumerate(documents):
            job = jobs.get(record.document_id)
            pages = job.page_count if job is not None and job.page_count is not None else None
            values = (
                record.display_name,
                t(TYPE_KEYS[record.document_type]),
                format_label(record),
                format_size(record.size_bytes),
                format_date(record.imported_at.astimezone().date()),
                t(f"document.status.{record.status}"),
                "" if pages is None else str(pages),
                "" if record.detected_format is None else processing_text(job),
                ocr_text(ocr_jobs.get(record.document_id)),
                invoice_text(invoices.get(record.document_id)),
                findings_text(invoices.get(record.document_id)),
                validation_text(invoices.get(record.document_id)),
            )
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)  # plain text, never interpreted
                item.setData(Qt.ItemDataRole.UserRole, str(record.document_id))
                self.table.setItem(row, column, item)
        self._update_buttons()

    def _update_buttons(self) -> None:
        ready = not self._busy and self._state.name is not None
        self.create_entity_button.setVisible(self._state.count == 0)
        self.create_entity_button.setEnabled(not self._busy)
        self.import_button.setEnabled(ready)
        self.inbox_button.setEnabled(ready)
        selected = self._selected()
        self.type_button.setEnabled(ready and selected is not None)
        self.process_pending_button.setEnabled(ready)
        self.process_selected_button.setEnabled(
            ready and selected is not None and selected.detected_format is not None
        )
        self.show_text_button.setEnabled(
            ready
            and selected is not None
            and selected.document_id in self._jobs
            and selected.detected_format is not DocumentFormat.XML
        )
        self.show_validation_button.setEnabled(
            ready and selected is not None and selected.document_id in self._invoices
        )
        self.revalidate_button.setEnabled(ready and bool(self._invoices))
        self.resuggest_button.setEnabled(
            ready and selected is not None and selected.document_id in self._invoices
        )

    def _selected(self) -> DocumentRecord | None:
        rows = self.table.selectionModel().selectedRows() if self.table.selectionModel() else []
        if not rows or rows[0].row() >= len(self._documents):
            return None
        return self._documents[rows[0].row()]

    # -- actions ------------------------------------------------------------

    def _create_entity(self) -> None:
        dialog = EntityDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        name, org_number = dialog.values()
        self._run(lambda: self._controller.create_entity(name, org_number))

    def _choose_files(self) -> None:
        names, _ = QFileDialog.getOpenFileNames(
            self, t("documents.import_file"), "", t(FILE_FILTER)
        )
        if names:
            paths = [Path(name) for name in names]
            self._run(lambda: self._controller.import_files(paths), summarize)

    def _change_type(self) -> None:
        record = self._selected()
        if record is None:
            return
        labels = [t(TYPE_KEYS[document_type]) for document_type in DocumentType]
        current = list(DocumentType).index(record.document_type)
        label, accepted = QInputDialog.getItem(
            self, t("documents.set_type"), t("documents.choose_type"), labels, current, False
        )
        if not accepted:
            return
        document_type = list(DocumentType)[labels.index(label)]
        self._run(lambda: self._controller.set_type(record.document_id, document_type))

    def _process_selected(self) -> None:
        record = self._selected()
        if record is None:
            return
        self._run(
            lambda: self._controller.process_document(record.document_id), summarize_processing
        )

    def _show_text(self) -> None:
        record = self._selected()
        if record is None:
            return
        self._run(
            lambda: self._controller.page_texts(record.document_id),
            on_result=self._open_text_dialog,
        )

    def _open_text_dialog(self, result: object) -> None:
        texts = result if isinstance(result, list) else []
        self.text_dialog = long_text_dialog(t("text.dialog.title"), page_texts_text(texts), self)
        self.text_dialog.open()

    def _show_validation(self) -> None:
        record = self._selected()
        summary = None if record is None else self._invoices.get(record.document_id)
        if summary is None:
            self.status_label.setText(t("validation.dialog.no_invoice"))
            return
        self._run(
            lambda: (
                self._controller.validation_run(summary.invoice_id),
                self._controller.posting(summary.invoice_id),
            ),
            on_result=self._open_validation_dialog,
        )

    def _open_validation_dialog(self, result: object) -> None:
        run, lines = result if isinstance(result, tuple) else (None, ())
        details = validation_details(run if isinstance(run, ValidationRun) else None)
        posting = t("posting.title") + "\n" + posting_details(lines)
        self.validation_dialog = text_dialog(
            t("validation.dialog.title"), details + "\n\n" + posting, self
        )
        self.validation_dialog.open()

    def _resuggest(self) -> None:
        record = self._selected()
        summary = None if record is None else self._invoices.get(record.document_id)
        if summary is None:
            self.status_label.setText(t("validation.dialog.no_invoice"))
            return
        self._run(
            lambda: self._controller.resuggest(summary.invoice_id),
            on_result=lambda _: self._resuggested(),
        )

    def _resuggested(self) -> None:
        self.status_label.setText(t("posting.resuggested"))
        self.refresh()

    def _run(
        self,
        work: Callable[[], object],
        summary: Callable[[list], str] | None = None,
        on_result: Callable[[object], None] | None = None,
    ) -> None:
        self._busy = True
        self._update_buttons()
        task = BackgroundTask(work, summary, on_result)
        self._tasks.add(task)
        # Bound slots with queued connections: results are always handled on
        # the GUI thread, never on the worker thread that emitted them.
        queued = Qt.ConnectionType.QueuedConnection
        task.signals.done.connect(self._on_done, queued)
        task.signals.failed.connect(self._on_failed, queued)
        self._pool.start(task)

    def _on_done(self, task: BackgroundTask, result: object) -> None:
        self._tasks.discard(task)
        self._busy = False
        if task.on_result is not None:
            self._update_buttons()
            task.on_result(result)
            return
        if isinstance(result, tuple) and len(result) == 6:
            self._show(*result)
            return
        if task.summary is not None and isinstance(result, list):
            self.status_label.setText(task.summary(result))
        self.refresh()

    def _on_failed(self, task: BackgroundTask, message: str) -> None:
        self._tasks.discard(task)
        self._busy = False
        self.status_label.setText(message)
        self._update_buttons()

    def wait_until_idle(self, timeout_ms: int = 10_000) -> bool:
        """For tests and the self-test: finish all background work."""
        return self._pool.waitForDone(timeout_ms)

    def shutdown(self, timeout_ms: int = 10_000) -> bool:
        """Stop imports after the current file and kill a running worker.

        True when all background work ended.
        """
        self._controller.request_stop()
        return self.wait_until_idle(timeout_ms)
