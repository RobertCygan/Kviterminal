"""Safe widgets for all document-derived and translated text."""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel, QWidget


def plain_label(text: str, parent: QWidget | None = None) -> QLabel:
    """Always display literal text, including angle brackets."""
    label = QLabel(text, parent)
    label.setTextFormat(Qt.TextFormat.PlainText)
    label.setWordWrap(True)
    return label
