"""Local dialogs that never interpret rich text or show tracebacks."""

from PySide6.QtWidgets import QDialog, QPlainTextEdit, QPushButton, QVBoxLayout, QWidget

from invoiceflow.i18n import t
from invoiceflow.ui.widgets import plain_label


def text_dialog(title: str, body: str, parent: QWidget | None = None) -> QDialog:
    dialog = QDialog(parent)
    dialog.setWindowTitle(title)
    layout = QVBoxLayout(dialog)
    layout.addWidget(plain_label(body))
    close = QPushButton(t("button.close"))
    close.clicked.connect(dialog.accept)
    layout.addWidget(close)
    return dialog


def long_text_dialog(title: str, body: str, parent: QWidget | None = None) -> QDialog:
    """Read-only, scrollable plain text (document text is shown, never interpreted)."""
    dialog = QDialog(parent)
    dialog.setWindowTitle(title)
    dialog.resize(720, 560)
    layout = QVBoxLayout(dialog)
    view = QPlainTextEdit()
    view.setReadOnly(True)
    view.setPlainText(body)
    view.setAccessibleName(title)
    layout.addWidget(view)
    close = QPushButton(t("button.close"))
    close.clicked.connect(dialog.accept)
    layout.addWidget(close)
    return dialog


def about_dialog(version: str, data_dir: str, parent: QWidget | None = None) -> QDialog:
    return text_dialog(t("menu.about"), t("about.body", version=version, data_dir=data_dir), parent)


def error_dialog(code: str, correlation_id: str, parent: QWidget | None = None) -> QDialog:
    body = (
        t("error.unexpected") + "\n" + t("error.details", code=code, correlation_id=correlation_id)
    )
    return text_dialog(t("error.title"), body, parent)
