"""Reference data of the active accounting entity (Phase 08b).

Import of the chart of accounts, VAT codes and dimensions from CSV, and the
latest import of each kind. Files are read by the service on a worker thread;
a refused file stores nothing and shows a Norwegian message without its content.
"""

from collections.abc import Callable
from pathlib import Path
from typing import Protocol

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from invoiceflow.application.reference.model import ImportRecord, ReferenceKind
from invoiceflow.i18n import t
from invoiceflow.i18n.formatting import format_date
from invoiceflow.ui.background import BackgroundTask
from invoiceflow.ui.widgets import plain_label

COLUMNS = ("reference.col.kind", "reference.col.rows", "reference.col.imported")


class ReferenceController(Protocol):
    def reference_status(self) -> dict[ReferenceKind, ImportRecord]: ...

    def import_reference(self, kind: ReferenceKind, path: Path) -> ImportRecord: ...


def status_values(kind: ReferenceKind, record: ImportRecord | None) -> tuple[str, str, str]:
    label = t(f"reference.kind.{kind}")
    if record is None:
        return (label, "", t("reference.none"))
    return (label, str(record.row_count), format_date(record.created_at.astimezone().date()))


class ReferencePage(QWidget):
    def __init__(self, controller: ReferenceController, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._controller = controller
        self._pool = QThreadPool.globalInstance()
        self._tasks: set[BackgroundTask] = set()
        self._busy = False
        layout = QVBoxLayout(self)
        layout.addWidget(plain_label(t("reference.title")))
        layout.addWidget(plain_label(t("reference.help")))
        buttons = QHBoxLayout()
        self.import_buttons: dict[ReferenceKind, QPushButton] = {}
        for kind in ReferenceKind:
            button = QPushButton(t(f"reference.import.{kind}"))
            button.clicked.connect(lambda _checked=False, kind=kind: self._choose(kind))
            buttons.addWidget(button)
            self.import_buttons[kind] = button
        buttons.addStretch()
        layout.addLayout(buttons)
        self.table = QTableWidget(len(ReferenceKind), len(COLUMNS))
        self.table.setHorizontalHeaderLabels([t(key) for key in COLUMNS])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setAccessibleName(t("reference.table"))
        layout.addWidget(self.table)
        self.status_label = plain_label("")
        layout.addWidget(self.status_label)
        layout.addStretch()
        self.refresh()

    def refresh(self) -> None:
        self._run(self._controller.reference_status, self._show)

    def _show(self, result: object) -> None:
        records = result if isinstance(result, dict) else {}
        for row, kind in enumerate(ReferenceKind):
            for column, value in enumerate(status_values(kind, records.get(kind))):
                self.table.setItem(row, column, QTableWidgetItem(value))

    def _choose(self, kind: ReferenceKind) -> None:
        name, _ = QFileDialog.getOpenFileName(
            self, t(f"reference.import.{kind}"), "", t("reference.file_filter")
        )
        if name:
            self.import_file(kind, Path(name))

    def import_file(self, kind: ReferenceKind, path: Path) -> None:
        self._run(lambda: self._controller.import_reference(kind, path), self._imported)

    def _imported(self, result: object) -> None:
        if isinstance(result, ImportRecord):
            self.status_label.setText(
                t(
                    "reference.imported",
                    kind=t(f"reference.kind.{result.kind}"),
                    count=result.row_count,
                )
            )
        self.refresh()

    def _update_buttons(self) -> None:
        for button in self.import_buttons.values():
            button.setEnabled(not self._busy)

    def _run(self, work: Callable[[], object], on_result: Callable[[object], None]) -> None:
        self._busy = True
        self._update_buttons()
        task = BackgroundTask(work, None, on_result)
        self._tasks.add(task)
        queued = Qt.ConnectionType.QueuedConnection
        task.signals.done.connect(self._on_done, queued)
        task.signals.failed.connect(self._on_failed, queued)
        self._pool.start(task)

    def _on_done(self, task: BackgroundTask, result: object) -> None:
        self._tasks.discard(task)
        self._busy = False
        self._update_buttons()
        if task.on_result is not None:
            task.on_result(result)

    def _on_failed(self, task: BackgroundTask, message: str) -> None:
        self._tasks.discard(task)
        self._busy = False
        self.status_label.setText(message)
        self._update_buttons()

    def wait_until_idle(self, timeout_ms: int = 10_000) -> bool:
        return self._pool.waitForDone(timeout_ms)
