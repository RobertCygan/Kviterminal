"""Export of approved invoices to Excel or CSV (Phase 10).

The page lists the approved invoices that are ready, earlier export files and
their status. Exports, re-exports (with a reason) and copies run through the
controller on a worker thread; invoice text is shown as plain text only.
"""

from collections.abc import Callable
from pathlib import Path
from typing import Protocol
from uuid import UUID

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from invoiceflow.application.export.model import (
    STANDARD_FIELDS,
    ExportBatchRecord,
    ExportCandidate,
    ExportColumn,
    ExportField,
    ExportMapping,
    ExportTarget,
)
from invoiceflow.i18n import t
from invoiceflow.i18n.formatting import format_amount, format_date
from invoiceflow.ui.background import BackgroundTask
from invoiceflow.ui.widgets import plain_label

READY_COLUMNS = (
    "export.col.supplier",
    "export.col.number",
    "export.col.date",
    "export.col.amount",
    "export.col.currency",
)
BATCH_COLUMNS = (
    "export.col.sequence",
    "export.col.created",
    "export.col.target",
    "export.col.count",
    "export.col.status",
    "export.col.kind",
    "export.col.file",
)
AskText = Callable[[str, str, str], str | None]


class ExportController(Protocol):
    def export_ready(self) -> list[ExportCandidate]: ...

    def export_batches(self) -> list[ExportBatchRecord]: ...

    def export_invoices(self, target: ExportTarget) -> ExportBatchRecord: ...

    def reexport(self, batch_id: UUID, reason: str, target: ExportTarget) -> ExportBatchRecord: ...

    def save_export_copy(self, batch_id: UUID, destination: Path) -> None: ...

    def export_mapping(self) -> ExportMapping: ...

    def set_export_mapping(
        self, columns: list[ExportColumn], expected_version: int
    ) -> ExportMapping: ...


def candidate_values(candidate: ExportCandidate) -> tuple[str, ...]:
    return (
        candidate.supplier_name or "",
        candidate.invoice_number or "",
        "" if candidate.invoice_date is None else format_date(candidate.invoice_date),
        "" if candidate.gross_amount is None else format_amount(candidate.gross_amount),
        candidate.currency or "",
    )


def batch_values(batch: ExportBatchRecord) -> tuple[str, ...]:
    local = batch.created_at.astimezone()
    return (
        str(batch.sequence),
        f"{format_date(local.date())} {local:%H:%M}",
        t(f"export.target.{batch.target}"),
        str(batch.item_count),
        t(f"export.status.{batch.status}"),
        t("export.kind.reexport" if batch.is_reexport else "export.kind.first"),
        batch.file_name,
    )


def column_text(column: ExportColumn) -> str:
    standard = t(f"export.column.{column.field}")
    if column.header is None:
        return standard
    return t("export.mapping.custom", header=column.header, field=standard)


class ColumnsDialog(QDialog):
    """Choose, order and name the columns; nothing is stored until OK."""

    def __init__(
        self, mapping: ExportMapping, ask_text: AskText, parent: QWidget | None = None
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(t("export.mapping.title"))
        self._ask_text = ask_text
        layout = QVBoxLayout(self)
        layout.addWidget(plain_label(t("export.mapping.help")))
        self.list = QListWidget()
        self.list.setAccessibleName(t("export.mapping.list"))
        layout.addWidget(self.list)
        buttons = QHBoxLayout()
        self.up_button = QPushButton(t("export.mapping.up"))
        self.down_button = QPushButton(t("export.mapping.down"))
        self.rename_button = QPushButton(t("export.mapping.rename"))
        self.reset_button = QPushButton(t("export.mapping.reset"))
        self.up_button.clicked.connect(lambda: self._move(-1))
        self.down_button.clicked.connect(lambda: self._move(1))
        self.rename_button.clicked.connect(self._rename)
        self.reset_button.clicked.connect(lambda: self._fill(STANDARD_FIELDS, {}, set()))
        for button in (self.up_button, self.down_button, self.rename_button, self.reset_button):
            buttons.addWidget(button)
        buttons.addStretch()
        layout.addLayout(buttons)
        box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        layout.addWidget(box)
        chosen = [column.field for column in mapping.columns]
        names = {column.field: column.header for column in mapping.columns}
        self._fill(chosen, names, set(chosen))

    def _fill(
        self,
        chosen: tuple[ExportField, ...] | list[ExportField],
        names: dict[ExportField, str | None],
        checked: set[ExportField],
    ) -> None:
        if not checked:
            checked = set(chosen)
        self.list.clear()
        ordered = [*chosen, *(f for f in ExportField if f not in chosen)]
        for field in ordered:
            item = QListWidgetItem()
            item.setData(Qt.ItemDataRole.UserRole, (field, names.get(field)))
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(
                Qt.CheckState.Checked if field in checked else Qt.CheckState.Unchecked
            )
            item.setText(column_text(ExportColumn(field, names.get(field))))
            self.list.addItem(item)
        self.list.setCurrentRow(0)

    def _move(self, step: int) -> None:
        row = self.list.currentRow()
        target = row + step
        if row < 0 or not 0 <= target < self.list.count():
            return
        item = self.list.takeItem(row)
        self.list.insertItem(target, item)
        self.list.setCurrentRow(target)

    def _rename(self) -> None:
        item = self.list.currentItem()
        if item is None:
            return
        field, header = item.data(Qt.ItemDataRole.UserRole)
        text = self._ask_text(t("export.mapping.title"), t("export.mapping.header"), header or "")
        if text is None:
            return
        chosen = text.strip() or None
        item.setData(Qt.ItemDataRole.UserRole, (field, chosen))
        item.setText(column_text(ExportColumn(field, chosen)))

    def columns(self) -> list[ExportColumn]:
        result = []
        for row in range(self.list.count()):
            item = self.list.item(row)
            if item.checkState() == Qt.CheckState.Checked:
                field, header = item.data(Qt.ItemDataRole.UserRole)
                result.append(ExportColumn(field, header))
        return result


class ExportPage(QWidget):
    def __init__(self, controller: ExportController, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._controller = controller
        self._pool = QThreadPool.globalInstance()
        self._tasks: set[BackgroundTask] = set()
        # Actions after which the lists may have changed even when they fail.
        self._changing: set[BackgroundTask] = set()
        self._busy = False
        self._ready: list[ExportCandidate] = []
        self._batches: list[ExportBatchRecord] = []
        self._mapping: ExportMapping | None = None
        # Replaceable in tests: questions and file choice without modal dialogs.
        self.ask_text: AskText = self._ask
        self.ask_line: AskText = self._ask_line
        self.choose_file: Callable[[str, str], str | None] = self._choose_file
        self.edit_columns: Callable[[ExportMapping], list[ExportColumn] | None] = self._edit_columns
        layout = QVBoxLayout(self)
        layout.addWidget(plain_label(t("export.title")))
        layout.addWidget(plain_label(t("export.help")))
        self.ready_label = plain_label(t("export.ready", count=0))
        layout.addWidget(self.ready_label)
        self.ready_table = self._table(READY_COLUMNS, "export.ready_table")
        layout.addWidget(self.ready_table)
        actions = QHBoxLayout()
        self.format_combo = QComboBox()
        for target in ExportTarget:
            self.format_combo.addItem(t(f"export.target.{target}"), target)
        # Own catalog text with a mnemonic, so not a plain-text label.
        format_label = QLabel(t("export.format"))
        format_label.setBuddy(self.format_combo)
        self.export_button = QPushButton(t("export.run"))
        self.columns_button = QPushButton(t("export.columns"))
        self.export_button.clicked.connect(self._export)
        self.columns_button.clicked.connect(self._columns)
        for widget in (format_label, self.format_combo, self.export_button, self.columns_button):
            actions.addWidget(widget)
        actions.addStretch()
        layout.addLayout(actions)
        layout.addWidget(plain_label(t("export.history")))
        self.batch_table = self._table(BATCH_COLUMNS, "export.history_table")
        self.batch_table.itemSelectionChanged.connect(self._update_buttons)
        layout.addWidget(self.batch_table)
        batch_actions = QHBoxLayout()
        self.copy_button = QPushButton(t("export.copy"))
        self.reexport_button = QPushButton(t("export.reexport"))
        self.refresh_button = QPushButton(t("export.refresh"))
        self.copy_button.clicked.connect(self._copy)
        self.reexport_button.clicked.connect(self._reexport)
        self.refresh_button.clicked.connect(self.refresh)
        for button in (self.copy_button, self.reexport_button, self.refresh_button):
            batch_actions.addWidget(button)
        batch_actions.addStretch()
        layout.addLayout(batch_actions)
        self.status_label = plain_label("")
        layout.addWidget(self.status_label)
        self.refresh()

    @staticmethod
    def _table(columns: tuple[str, ...], name: str) -> QTableWidget:
        table = QTableWidget(0, len(columns))
        table.setHorizontalHeaderLabels([t(key) for key in columns])
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        table.setAccessibleName(t(name))
        return table

    def refresh(self) -> None:
        self._run(self._load, self._show)

    def _load(self) -> tuple[list[ExportCandidate], list[ExportBatchRecord], ExportMapping]:
        return (
            self._controller.export_ready(),
            self._controller.export_batches(),
            self._controller.export_mapping(),
        )

    def _show(self, result: object) -> None:
        if not isinstance(result, tuple):
            return
        self._ready, self._batches, self._mapping = result
        self.ready_label.setText(t("export.ready", count=len(self._ready)))
        self._fill(self.ready_table, [candidate_values(c) for c in self._ready])
        self._fill(self.batch_table, [batch_values(b) for b in self._batches])
        self._update_buttons()

    @staticmethod
    def _fill(table: QTableWidget, rows: list[tuple[str, ...]]) -> None:
        table.setRowCount(len(rows))
        for row, values in enumerate(rows):
            for column, value in enumerate(values):
                table.setItem(row, column, QTableWidgetItem(value))

    def _selected_batch(self) -> ExportBatchRecord | None:
        rows = self.batch_table.selectionModel().selectedRows()
        if not rows or rows[0].row() >= len(self._batches):
            return None
        return self._batches[rows[0].row()]

    def _target(self) -> ExportTarget:
        return ExportTarget(self.format_combo.currentData())

    def _update_buttons(self) -> None:
        idle = not self._busy
        batch = self._selected_batch()
        self.export_button.setEnabled(idle and bool(self._ready))
        self.columns_button.setEnabled(idle and self._mapping is not None)
        self.copy_button.setEnabled(idle and batch is not None and batch.status == "written")
        self.reexport_button.setEnabled(idle and batch is not None and batch.status != "created")
        self.refresh_button.setEnabled(idle)
        self.format_combo.setEnabled(idle)

    # --- actions ---------------------------------------------------------------------

    def _ask(self, title: str, label: str, initial: str) -> str | None:
        text, accepted = QInputDialog.getMultiLineText(self, title, label, initial)
        return text if accepted else None

    def _ask_line(self, title: str, label: str, initial: str) -> str | None:
        text, accepted = QInputDialog.getText(self, title, label, text=initial)
        return text if accepted else None

    def _choose_file(self, name: str, file_filter: str) -> str | None:
        chosen, _ = QFileDialog.getSaveFileName(self, t("export.copy.title"), name, file_filter)
        return chosen or None

    def _edit_columns(self, mapping: ExportMapping) -> list[ExportColumn] | None:
        dialog = ColumnsDialog(mapping, self.ask_line, self)
        return dialog.columns() if dialog.exec() == QDialog.DialogCode.Accepted else None

    def _export(self) -> None:
        target = self._target()
        self._run(lambda: self._controller.export_invoices(target), self._exported, changes=True)

    def _exported(self, result: object) -> None:
        if isinstance(result, ExportBatchRecord):
            self.status_label.setText(
                t("export.done", count=result.item_count, file=result.file_name)
            )
        self.refresh()

    def _reexport(self) -> None:
        batch = self._selected_batch()
        if batch is None:
            return
        reason = self.ask_text(t("export.reexport.title"), t("export.reexport.label"), "")
        if reason is None:
            return
        target = self._target()
        self._run(
            lambda: self._controller.reexport(batch.batch_id, reason, target),
            self._exported,
            changes=True,
        )

    def _copy(self) -> None:
        batch = self._selected_batch()
        if batch is None:
            return
        file_filter = t(f"export.copy.filter_{batch.target}")
        chosen = self.choose_file(batch.file_name, file_filter)
        if chosen is None:
            return
        destination = Path(chosen)
        self._run(
            lambda: self._controller.save_export_copy(batch.batch_id, destination),
            lambda _result: self.status_label.setText(t("export.copied")),
        )

    def _columns(self) -> None:
        mapping = self._mapping
        if mapping is None:
            return
        columns = self.edit_columns(mapping)
        if columns is None:
            return
        self._run(
            lambda: self._controller.set_export_mapping(columns, mapping.version),
            self._mapping_saved,
        )

    def _mapping_saved(self, result: object) -> None:
        if isinstance(result, ExportMapping):
            self.status_label.setText(t("export.mapping.saved", version=result.version))
        self.refresh()

    # --- background ------------------------------------------------------------------

    def _run(
        self,
        work: Callable[[], object],
        on_result: Callable[[object], None],
        *,
        changes: bool = False,
    ) -> None:
        self._busy = True
        self._update_buttons()
        task = BackgroundTask(work, None, on_result)
        self._tasks.add(task)
        if changes:
            self._changing.add(task)
        queued = Qt.ConnectionType.QueuedConnection
        task.signals.done.connect(self._on_done, queued)
        task.signals.failed.connect(self._on_failed, queued)
        self._pool.start(task)

    def _on_done(self, task: BackgroundTask, result: object) -> None:
        self._tasks.discard(task)
        self._changing.discard(task)
        self._busy = False
        self._update_buttons()
        if task.on_result is not None:
            task.on_result(result)

    def _on_failed(self, task: BackgroundTask, message: str) -> None:
        self._tasks.discard(task)
        self._busy = False
        self.status_label.setText(message)
        self._update_buttons()
        if task in self._changing:
            # A failed export is listed as failed; the message stays visible.
            self._changing.discard(task)
            self._run(self._load, self._show)

    def wait_until_idle(self, timeout_ms: int = 10_000) -> bool:
        return self._pool.waitForDone(timeout_ms)
