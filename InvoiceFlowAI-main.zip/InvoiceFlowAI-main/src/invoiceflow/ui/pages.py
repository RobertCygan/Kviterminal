"""Placeholder pages without business logic or I/O."""

from PySide6.QtWidgets import QVBoxLayout, QWidget

from invoiceflow.i18n import t
from invoiceflow.ui.widgets import plain_label


def placeholder_page(key: str) -> QWidget:
    page = QWidget()
    layout = QVBoxLayout(page)
    layout.addWidget(plain_label(t(key)))
    layout.addWidget(plain_label(t("page.placeholder")))
    layout.addStretch()
    return page
