"""Scanning without a scanner driver (Phase 11a).

Scanner software saves into the inbox folder. While watching is on, the page
asks the controller every few seconds to import finished files, set them
aside and analyse them. The table shows how each multi-page document divides
into parts at separator sheets, and which pages are blank. The separator sheet
itself can be saved for printing.

For checking the thresholds against a real scanner (Phase 11b), the measured
values of each page of the selected document are listed, and pages close to a
threshold are marked. The folder path can be copied into the scanner software.
"""

from collections.abc import Callable
from pathlib import Path
from typing import Protocol

from PySide6.QtCore import Qt, QThreadPool, QTimer
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from invoiceflow.application.processing_model import PageRecord
from invoiceflow.application.scan.model import (
    BLANK_MAX_DARK,
    SEPARATOR_DARK,
    SEPARATOR_MIN_CENTER,
    PageKind,
)
from invoiceflow.application.scan.service import BatchView, ScanPoll
from invoiceflow.i18n import t
from invoiceflow.ui.background import BackgroundTask
from invoiceflow.ui.widgets import plain_label

COLUMNS = (
    "scan.col.file",
    "scan.col.pages",
    "scan.col.parts",
    "scan.col.blank",
    "scan.col.separators",
    "scan.col.near",
)
PAGE_COLUMNS = (
    "scan.page.col.number",
    "scan.page.col.kind",
    "scan.page.col.dark",
    "scan.page.col.center",
    "scan.page.col.text",
    "scan.page.col.near",
)
POLL_MILLISECONDS = 10_000


class ScanController(Protocol):
    def scan_folder(self) -> str: ...

    def scan_poll(self) -> ScanPoll: ...

    def scan_batches(self) -> list[BatchView]: ...

    def save_separator_sheet(self, destination: Path) -> None: ...


def pages_text(numbers: tuple[int, ...]) -> str:
    return ", ".join(str(number) for number in numbers)


def parts_text(view: BatchView) -> str:
    if not view.split.measured:
        return t("scan.not_measured")
    if not view.split.parts:
        return t("scan.no_parts")
    ranges = [
        str(first) if first == last else f"{first}\N{EN DASH}{last}"
        for first, last in view.split.parts
    ]
    return t("scan.parts", count=len(ranges), ranges=", ".join(ranges))


def batch_values(view: BatchView) -> tuple[str, ...]:
    return (
        view.document.display_name,
        str(view.page_count),
        parts_text(view),
        pages_text(view.split.pages_of(PageKind.BLANK)),
        pages_text(view.split.pages_of(PageKind.SEPARATOR)),
        pages_text(view.split.near),
    )


def measure_text(value: int | None) -> str:
    return "\N{EN DASH}" if value is None else str(value)


def page_values(page: PageRecord, kind: PageKind, near: bool) -> tuple[str, ...]:
    return (
        str(page.page_number),
        t(f"scan.kind.{kind.value}"),
        measure_text(page.dark_permille),
        measure_text(page.center_dark_permille),
        str(page.text_layer_chars),
        t("scan.page.near") if near else "",
    )


def thresholds_text() -> str:
    return t(
        "scan.thresholds",
        blank=BLANK_MAX_DARK,
        center=SEPARATOR_MIN_CENTER,
        low=SEPARATOR_DARK[0],
        high=SEPARATOR_DARK[1],
    )


def poll_text(result: ScanPoll) -> str:
    return t(
        "scan.polled",
        imported=result.imported,
        duplicates=result.duplicates,
        refused=result.refused,
        failed=result.failed,
        processed=result.processed,
    )


class ScanPage(QWidget):
    def __init__(self, controller: ScanController, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._controller = controller
        self._pool = QThreadPool.globalInstance()
        self._tasks: set[BackgroundTask] = set()
        self._busy = False
        self._views: list[BatchView] = []
        # Replaceable in tests: the file dialog.
        self.choose_file: Callable[[], str | None] = self._choose_file
        layout = QVBoxLayout(self)
        layout.addWidget(plain_label(t("scan.title")))
        layout.addWidget(plain_label(t("scan.help")))
        self.folder_label = plain_label(t("scan.folder", folder=controller.scan_folder()))
        self.folder_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        folder_row = QHBoxLayout()
        folder_row.addWidget(self.folder_label)
        self.copy_button = QPushButton(t("scan.copy_folder"))
        self.copy_button.clicked.connect(self._copy_folder)
        folder_row.addWidget(self.copy_button)
        folder_row.addStretch()
        layout.addLayout(folder_row)
        actions = QHBoxLayout()
        self.watch_box = QCheckBox(t("scan.watch"))
        self.poll_button = QPushButton(t("scan.poll"))
        self.separator_button = QPushButton(t("scan.separator"))
        self.refresh_button = QPushButton(t("scan.refresh"))
        self.watch_box.toggled.connect(self._watch)
        self.poll_button.clicked.connect(self.poll)
        self.separator_button.clicked.connect(self._save_separator)
        self.refresh_button.clicked.connect(self.refresh)
        for widget in (
            self.watch_box,
            self.poll_button,
            self.separator_button,
            self.refresh_button,
        ):
            actions.addWidget(widget)
        actions.addStretch()
        layout.addLayout(actions)
        layout.addWidget(plain_label(t("scan.batches")))
        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels([t(key) for key in COLUMNS])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setAccessibleName(t("scan.table"))
        self.table.itemSelectionChanged.connect(self._show_pages)
        layout.addWidget(self.table)
        layout.addWidget(plain_label(t("scan.pages")))
        layout.addWidget(plain_label(thresholds_text()))
        self.pages_table = QTableWidget(0, len(PAGE_COLUMNS))
        self.pages_table.setHorizontalHeaderLabels([t(key) for key in PAGE_COLUMNS])
        self.pages_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.pages_table.horizontalHeader().setSectionResizeMode(
            len(PAGE_COLUMNS) - 1, QHeaderView.ResizeMode.Stretch
        )
        self.pages_table.setAccessibleName(t("scan.pages.table"))
        layout.addWidget(self.pages_table)
        self.status_label = plain_label("")
        layout.addWidget(self.status_label)
        self.timer = QTimer(self)
        self.timer.setInterval(POLL_MILLISECONDS)
        self.timer.timeout.connect(self._tick)
        self.refresh()

    # --- watching --------------------------------------------------------------------

    def _watch(self, enabled: bool) -> None:
        if enabled:
            self.timer.start()
            self.status_label.setText(t("scan.watching"))
            self.poll()
        else:
            self.timer.stop()
            self.status_label.setText(t("scan.stopped"))

    def _tick(self) -> None:
        if not self._busy:  # never two polls at once
            self.poll()

    def poll(self) -> None:
        self._run(self._controller.scan_poll, self._polled)

    def _polled(self, result: object) -> None:
        if isinstance(result, ScanPoll):
            if result.imported or result.duplicates or result.refused or result.failed:
                self.status_label.setText(poll_text(result))
            self.refresh()

    # --- table and separator sheet -----------------------------------------------------

    def refresh(self) -> None:
        self._run(self._controller.scan_batches, self._show)

    def _show(self, result: object) -> None:
        selected = self._selected()
        self._views = result if isinstance(result, list) else []
        self.table.setRowCount(len(self._views))
        for row, view in enumerate(self._views):
            for column, value in enumerate(batch_values(view)):
                self.table.setItem(row, column, QTableWidgetItem(value))
            if selected is not None and view.document.document_id == selected.document.document_id:
                self.table.selectRow(row)  # new scans arrive on top: keep the same document
        self._show_pages()

    def _selected(self) -> BatchView | None:
        row = self.table.currentRow()
        return self._views[row] if 0 <= row < len(self._views) else None

    def _show_pages(self) -> None:
        view = self._selected()
        pages = view.pages if view is not None else ()
        if view is None or len(pages) != len(view.split.kinds):
            pages = ()
        self.pages_table.setRowCount(len(pages))
        if view is None:
            return
        near = set(view.split.near)
        for index, (page, kind) in enumerate(zip(pages, view.split.kinds, strict=True)):
            values = page_values(page, kind, page.page_number in near)
            for column, value in enumerate(values):
                self.pages_table.setItem(index, column, QTableWidgetItem(value))

    def _copy_folder(self) -> None:
        QGuiApplication.clipboard().setText(self._controller.scan_folder())
        self.status_label.setText(t("scan.copied"))

    def _choose_file(self) -> str | None:
        name, _ = QFileDialog.getSaveFileName(
            self, t("scan.separator.title"), t("scan.separator.name"), t("scan.separator.filter")
        )
        return name or None

    def _save_separator(self) -> None:
        chosen = self.choose_file()
        if chosen is None:
            return
        destination = Path(chosen)
        self._run(
            lambda: self._controller.save_separator_sheet(destination),
            lambda _result: self.status_label.setText(t("scan.separator.saved")),
        )

    # --- background ------------------------------------------------------------------

    def _update_buttons(self) -> None:
        for button in (self.poll_button, self.separator_button, self.refresh_button):
            button.setEnabled(not self._busy)

    def _run(self, work: Callable[[], object], on_result: Callable[[object], None]) -> None:
        self._busy = True
        self._update_buttons()
        task = BackgroundTask(work, None, on_result)
        self._tasks.add(task)
        queued = Qt.ConnectionType.QueuedConnection
        task.signals.done.connect(self._on_done, queued)
        task.signals.failed.connect(self._on_failed, queued)
        self._pool.start(task)

    def _on_done(self, task: BackgroundTask, result: object) -> None:
        self._tasks.discard(task)
        self._busy = bool(self._tasks)
        self._update_buttons()
        if task.on_result is not None:
            task.on_result(result)

    def _on_failed(self, task: BackgroundTask, message: str) -> None:
        self._tasks.discard(task)
        self._busy = bool(self._tasks)
        self.status_label.setText(message)
        self._update_buttons()

    def wait_until_idle(self, timeout_ms: int = 10_000) -> bool:
        return self._pool.waitForDone(timeout_ms)
