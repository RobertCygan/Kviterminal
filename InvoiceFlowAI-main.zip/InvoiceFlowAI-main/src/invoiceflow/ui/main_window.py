"""Accessible desktop shell; storage is reached only through injected controllers."""

from PySide6.QtGui import QAction
from PySide6.QtWidgets import QHBoxLayout, QListWidget, QMainWindow, QStackedWidget, QWidget

from invoiceflow.i18n import t
from invoiceflow.i18n.catalog_nb_no import NAVIGATION
from invoiceflow.ui.backup_page import BackupController, BackupPage
from invoiceflow.ui.dialogs import about_dialog
from invoiceflow.ui.documents_page import ArchiveController, DocumentsPage
from invoiceflow.ui.export_page import ExportController, ExportPage
from invoiceflow.ui.pages import placeholder_page
from invoiceflow.ui.reference_page import ReferenceController, ReferencePage
from invoiceflow.ui.review_page import ReviewController, ReviewPage
from invoiceflow.ui.scan_page import ScanController, ScanPage
from invoiceflow.ui.suppliers_page import SupplierController, SuppliersPage
from invoiceflow.ui.widgets import plain_label


class MainWindow(QMainWindow):
    """Navigate between the pages; each page is live when its controller is composed."""

    def __init__(
        self,
        version: str,
        data_dir: str,
        synced: bool = False,
        archive: ArchiveController | None = None,
        suppliers: SupplierController | None = None,
        references: ReferenceController | None = None,
        review: ReviewController | None = None,
        exports: ExportController | None = None,
        backups: BackupController | None = None,
        scanning: ScanController | None = None,
    ) -> None:
        super().__init__()
        self.setWindowTitle(t("app.title"))
        self.resize(1000, 650)
        self.navigation = QListWidget()
        self.navigation.setAccessibleName(t("nav.accessible"))
        self.pages = QStackedWidget()
        self.documents_page: DocumentsPage | None = None
        self.suppliers_page: SuppliersPage | None = None
        self.reference_page: ReferencePage | None = None
        self.review_page: ReviewPage | None = None
        self.export_page: ExportPage | None = None
        self.backup_page: BackupPage | None = None
        self.scan_page: ScanPage | None = None
        for key in NAVIGATION:
            self.navigation.addItem(t(key))
            if key == "nav.inbox" and archive is not None:
                self.documents_page = DocumentsPage(archive)
                self.pages.addWidget(self.documents_page)
            elif key == "nav.suppliers" and suppliers is not None:
                self.suppliers_page = SuppliersPage(suppliers)
                self.pages.addWidget(self.suppliers_page)
            elif key == "nav.review" and review is not None:
                self.review_page = ReviewPage(review)
                self.pages.addWidget(self.review_page)
            elif key == "nav.export" and exports is not None:
                self.export_page = ExportPage(exports)
                self.pages.addWidget(self.export_page)
            elif key == "nav.scan" and scanning is not None:
                self.scan_page = ScanPage(scanning)
                self.pages.addWidget(self.scan_page)
            elif key == "nav.backup" and backups is not None:
                self.backup_page = BackupPage(backups)
                self.pages.addWidget(self.backup_page)
            elif key == "nav.settings" and references is not None:
                self.reference_page = ReferencePage(references)
                self.pages.addWidget(self.reference_page)
            else:
                self.pages.addWidget(placeholder_page(key))
        self.navigation.currentRowChanged.connect(self.pages.setCurrentIndex)
        self.navigation.setCurrentRow(0)
        central = QWidget()
        layout = QHBoxLayout(central)
        layout.addWidget(self.navigation, 1)
        layout.addWidget(self.pages, 4)
        self.setCentralWidget(central)
        file_menu = self.menuBar().addMenu(t("menu.file"))
        exit_action = QAction(t("menu.exit"), self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        help_menu = self.menuBar().addMenu(t("menu.help"))
        about = QAction(t("menu.about"), self)
        about.triggered.connect(lambda: about_dialog(version, data_dir, self).exec())
        help_menu.addAction(about)
        self.statusBar().showMessage(t("status.local"))
        if synced:
            self.statusBar().addPermanentWidget(plain_label(t("warning.synced")))
