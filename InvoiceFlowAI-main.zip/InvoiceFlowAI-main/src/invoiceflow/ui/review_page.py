"""Review and approval of invoices (Phase 09).

One invoice at a time: the fields with their source, the posting, the
findings with overrides, the decisions and the history, next to a preview of
the first page of its PDF view. Every value from a document is shown as plain
text. Decisions go through the controller, which binds them to the revision
the page shows; a stale page gets a conflict instead of changing newer content.
"""

import datetime as dt
from collections.abc import Callable
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Protocol
from uuid import UUID

from PySide6.QtCore import QRectF, Qt, QThreadPool
from PySide6.QtGui import QColor, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from invoiceflow.application.review.editing import is_editable
from invoiceflow.application.review.model import NON_OVERRIDABLE
from invoiceflow.application.review.service import ReviewView
from invoiceflow.application.services import InvoiceSummary
from invoiceflow.application.validation.model import Severity, ValidationFinding
from invoiceflow.domain.invoice import CanonicalInvoice
from invoiceflow.domain.provenance import FieldValue, ValueSource
from invoiceflow.i18n import t
from invoiceflow.i18n.formatting import format_amount, format_date
from invoiceflow.ui.background import BackgroundTask
from invoiceflow.ui.validation_text import finding_text, status_text
from invoiceflow.ui.widgets import plain_label

LIST_COLUMNS = (
    "review.col.supplier",
    "review.col.number",
    "review.col.amount",
    "review.col.status",
    "review.col.validation",
)
FIELD_COLUMNS = ("review.col.field", "review.col.value", "review.col.source")
PREVIEW_WIDTH = 420

HEADER_FIELDS = (
    "supplier.name",
    "supplier.org_number",
    "invoice_number",
    "invoice_date",
    "due_date",
    "currency",
    "buyer_reference",
    "referenced_invoice_number",
    "payment.kid",
    "payment.bank_account",
    "payment.iban",
    "totals.net_amount",
    "totals.vat_amount",
    "totals.rounding_amount",
    "totals.gross_amount",
)
POSTING_FIELDS = ("account", "vat_code", "net_amount", "cost_center", "department", "project")


class ReviewController(Protocol):
    def invoice_summaries(self) -> dict[UUID, InvoiceSummary]: ...

    def review_view(self, invoice_id: UUID) -> ReviewView: ...

    def review_preview(self, invoice_id: UUID) -> bytes | None: ...

    def edit_field(self, invoice_id: UUID, path: str, text: str, revision: int) -> None: ...

    def override_finding(
        self, invoice_id: UUID, finding: ValidationFinding, reason: str, revision: int
    ) -> None: ...

    def approve(self, invoice_id: UUID, revision: int, comment: str | None) -> None: ...

    def reject(self, invoice_id: UUID, revision: int, comment: str) -> None: ...

    def revoke(self, invoice_id: UUID, revision: int) -> None: ...


@dataclass(frozen=True, slots=True)
class FieldRow:
    path: str
    label: str
    value: str
    source: str
    bbox: tuple[float, float, float, float] | None = None


def _get(invoice: CanonicalInvoice, path: str) -> FieldValue[Any] | None:
    node: Any = invoice
    for part in path.split("."):
        node = getattr(node, part, None)
        if node is None:
            return None
    return node if isinstance(node, FieldValue) else None


def value_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return t("review.yes") if value else t("review.no")
    if isinstance(value, Decimal):
        return format_amount(value)
    if isinstance(value, dt.date):
        return format_date(value)
    return str(value)


def source_text(field: FieldValue[Any]) -> str:
    provenance = field.provenance
    if provenance.source is ValueSource.MANUAL and provenance.recorded_at is not None:
        return t("review.source.manual_at", date=format_date(provenance.recorded_at.date()))
    return t(f"review.source.{provenance.source.value}")


def _row(path: str, label: str, field: FieldValue[Any] | None) -> FieldRow:
    if field is None:
        return FieldRow(path, label, "", "")
    evidence = field.provenance.evidence
    bbox = None
    if evidence is not None and evidence.bbox is not None and evidence.page_number == 1:
        box = evidence.bbox
        bbox = (box.x0, box.y0, box.x1, box.y1)
    raw = "" if field.value is not None or evidence is None else evidence.raw_text or ""
    shown = value_text(field.value) or (t("review.unreadable", raw=raw) if raw else "")
    return FieldRow(path, label, shown, source_text(field), bbox)


def field_rows(invoice: CanonicalInvoice) -> list[FieldRow]:
    """Header, payment, totals and posting rows of one invoice, in display order."""
    rows = [_row(path, t(f"review.field.{path}"), _get(invoice, path)) for path in HEADER_FIELDS]
    for line in invoice.accounting_lines:
        for name in POSTING_FIELDS:
            rows.append(
                _row(
                    f"accounting_lines.{line.line_number}.{name}",
                    t(
                        "review.field.posting",
                        number=line.line_number,
                        name=t(f"review.field.posting.{name}"),
                    ),
                    getattr(line, name),
                )
            )
    return rows


def history_text(view: ReviewView) -> str:
    lines = [
        t("review.history.revision", revision=record.revision)
        if record.revision != view.record.revision
        else t(
            "review.history.current",
            revision=record.revision,
            status=t(f"review.status.{record.workflow_status}"),
        )
        for record in view.revisions
    ]
    lines += [
        t(
            f"review.history.{decision.decision}",
            revision=decision.revision,
            date=format_date(decision.decided_at.astimezone().date()),
        )
        for decision in view.decisions
    ]
    return "\n".join(lines)


def finding_status(view: ReviewView, finding: ValidationFinding) -> str:
    if finding.rule_id in NON_OVERRIDABLE and finding.severity is Severity.ERROR:
        return t("review.finding.blocking")
    if view.is_overridden(finding):
        return t("review.finding.overridden")
    return ""


class ReviewPage(QWidget):
    def __init__(self, controller: ReviewController, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._controller = controller
        self._pool = QThreadPool.globalInstance()
        self._tasks: set[BackgroundTask] = set()
        self._busy = False
        self._summaries: list[InvoiceSummary] = []
        self._view: ReviewView | None = None
        self._rows: list[FieldRow] = []
        self._findings: list[ValidationFinding] = []
        self._preview: QPixmap | None = None
        # Tests replace this to answer text prompts without a modal dialog.
        self.ask_text: Callable[[str, str, str], str | None] = self._ask

        layout = QVBoxLayout(self)
        layout.addWidget(plain_label(t("nav.review")))
        body = QHBoxLayout()
        layout.addLayout(body)

        self.invoice_table = QTableWidget(0, len(LIST_COLUMNS))
        self.invoice_table.setHorizontalHeaderLabels([t(key) for key in LIST_COLUMNS])
        self._table_defaults(self.invoice_table, t("review.list"))
        body.addWidget(self.invoice_table, 2)

        detail = QVBoxLayout()
        body.addLayout(detail, 3)
        self.preview_label = QLabel()
        self.preview_label.setTextFormat(Qt.TextFormat.PlainText)
        self.preview_label.setAccessibleName(t("review.preview"))
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        detail.addWidget(self.preview_label)

        self.field_table = QTableWidget(0, len(FIELD_COLUMNS))
        self.field_table.setHorizontalHeaderLabels([t(key) for key in FIELD_COLUMNS])
        self._table_defaults(self.field_table, t("review.fields"))
        detail.addWidget(self.field_table)

        self.finding_table = QTableWidget(0, 2)
        self.finding_table.setHorizontalHeaderLabels(
            [t("review.col.finding"), t("review.col.finding_status")]
        )
        self._table_defaults(self.finding_table, t("review.findings"))
        detail.addWidget(self.finding_table)

        self.history_label = plain_label("")
        detail.addWidget(self.history_label)

        buttons = QHBoxLayout()
        self.edit_button = QPushButton(t("review.edit"))
        self.override_button = QPushButton(t("review.override"))
        self.approve_button = QPushButton(t("review.approve"))
        self.reject_button = QPushButton(t("review.reject"))
        self.revoke_button = QPushButton(t("review.revoke"))
        self.refresh_button = QPushButton(t("review.refresh"))
        for button in (
            self.edit_button,
            self.override_button,
            self.approve_button,
            self.reject_button,
            self.revoke_button,
            self.refresh_button,
        ):
            buttons.addWidget(button)
        buttons.addStretch()
        layout.addLayout(buttons)
        self.status_label = plain_label("")
        layout.addWidget(self.status_label)

        self.invoice_table.itemSelectionChanged.connect(self._load_selected)
        self.field_table.itemSelectionChanged.connect(self._field_selected)
        self.finding_table.itemSelectionChanged.connect(self._update_buttons)
        self.field_table.itemActivated.connect(lambda _item: self._edit())
        self.edit_button.clicked.connect(self._edit)
        self.override_button.clicked.connect(self._override)
        self.approve_button.clicked.connect(self._approve)
        self.reject_button.clicked.connect(self._reject)
        self.revoke_button.clicked.connect(self._revoke)
        self.refresh_button.clicked.connect(self.refresh)
        self.refresh()

    @staticmethod
    def _table_defaults(table: QTableWidget, name: str) -> None:
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        table.setAccessibleName(name)

    # --- list ------------------------------------------------------------------------

    def refresh(self) -> None:
        selected = None if self._view is None else self._view.record.invoice_id
        self._run(
            self._controller.invoice_summaries, lambda result: self._show_list(result, selected)
        )

    def _show_list(self, result: object, selected: UUID | None) -> None:
        summaries = list(result.values()) if isinstance(result, dict) else []
        summaries.sort(key=lambda s: (s.supplier_name or "", s.invoice_number or ""))
        self._summaries = summaries
        self.invoice_table.setRowCount(len(summaries))
        for row, summary in enumerate(summaries):
            amount = ""
            if summary.gross_amount is not None:
                amount = f"{format_amount(summary.gross_amount)} {summary.currency or ''}".strip()
            values = (
                summary.supplier_name or "",
                summary.invoice_number or "",
                amount,
                t(f"review.status.{summary.workflow_status}"),
                status_text(summary.validation),
            )
            for column, value in enumerate(values):
                self.invoice_table.setItem(row, column, QTableWidgetItem(value))
        if not summaries:
            self.status_label.setText(t("review.none"))
        for row, summary in enumerate(summaries):
            if summary.invoice_id == selected:
                self.invoice_table.selectRow(row)
                return
        self._update_buttons()

    def _selected_summary(self) -> InvoiceSummary | None:
        model = self.invoice_table.selectionModel()
        rows = model.selectedRows() if model else []
        if not rows or rows[0].row() >= len(self._summaries):
            return None
        return self._summaries[rows[0].row()]

    def _load_selected(self) -> None:
        summary = self._selected_summary()
        if summary is None:
            return
        invoice_id = summary.invoice_id
        self._run(
            lambda: (
                self._controller.review_view(invoice_id),
                self._controller.review_preview(invoice_id),
            ),
            self._show_detail,
        )

    # --- detail ----------------------------------------------------------------------

    def _show_detail(self, result: object) -> None:
        if not isinstance(result, tuple):
            return
        view, image = result
        self._view = view
        self._rows = field_rows(view.record.invoice)
        self.field_table.setRowCount(len(self._rows))
        for index, row in enumerate(self._rows):
            for column, value in enumerate((row.label, row.value, row.source)):
                self.field_table.setItem(index, column, QTableWidgetItem(value))
        self._findings = list(view.run.findings) if view.run is not None else []
        self.finding_table.setRowCount(len(self._findings))
        for index, finding in enumerate(self._findings):
            self.finding_table.setItem(index, 0, QTableWidgetItem(finding_text(finding)))
            self.finding_table.setItem(index, 1, QTableWidgetItem(finding_status(view, finding)))
        self.history_label.setText(history_text(view))
        self._preview = None
        if image:
            pixmap = QPixmap()
            if pixmap.loadFromData(image, "PNG"):
                self._preview = pixmap.scaledToWidth(
                    PREVIEW_WIDTH, Qt.TransformationMode.SmoothTransformation
                )
        self._draw_preview(None)
        self._update_buttons()

    def _draw_preview(self, bbox: tuple[float, float, float, float] | None) -> None:
        if self._preview is None:
            self.preview_label.setPixmap(QPixmap())
            self.preview_label.setText(t("review.no_preview"))
            return
        if bbox is None:
            self.preview_label.setPixmap(self._preview)
            return
        marked = self._preview.copy()
        painter = QPainter(marked)
        painter.setPen(QPen(QColor(220, 0, 0), 2))
        width, height = marked.width(), marked.height()
        x0, y0, x1, y1 = bbox
        painter.drawRect(QRectF(x0 * width, y0 * height, (x1 - x0) * width, (y1 - y0) * height))
        painter.end()
        self.preview_label.setPixmap(marked)

    def _selected_index(self, table: QTableWidget, size: int) -> int | None:
        model = table.selectionModel()
        rows = model.selectedRows() if model else []
        if not rows or rows[0].row() >= size:
            return None
        return rows[0].row()

    def _selected_field(self) -> FieldRow | None:
        index = self._selected_index(self.field_table, len(self._rows))
        return None if index is None else self._rows[index]

    def _selected_finding(self) -> ValidationFinding | None:
        index = self._selected_index(self.finding_table, len(self._findings))
        return None if index is None else self._findings[index]

    def _field_selected(self) -> None:
        row = self._selected_field()
        self._draw_preview(None if row is None else row.bbox)
        self._update_buttons()

    def _update_buttons(self) -> None:
        status = None if self._view is None else self._view.record.workflow_status
        # An exported invoice is final: nothing can be changed or decided again.
        idle = not self._busy and self._view is not None and status != "exported"
        field = self._selected_field()
        finding = self._selected_finding()
        self.edit_button.setEnabled(idle and field is not None and is_editable(field.path))
        self.override_button.setEnabled(
            idle
            and finding is not None
            and finding.severity is Severity.ERROR
            and finding.rule_id not in NON_OVERRIDABLE
            and self._view is not None
            and not self._view.is_overridden(finding)
        )
        self.approve_button.setEnabled(idle and status != "approved")
        self.reject_button.setEnabled(idle and status != "rejected")
        self.revoke_button.setEnabled(idle and status == "approved")
        self.refresh_button.setEnabled(not self._busy)

    # --- actions ---------------------------------------------------------------------

    def _ask(self, title: str, label: str, initial: str) -> str | None:
        text, accepted = QInputDialog.getText(self, title, label, text=initial)
        return text if accepted else None

    def _act(self, work: Callable[[], object], message: str) -> None:
        def done(_result: object) -> None:
            self.status_label.setText(message)
            self.refresh()
            self._load_selected()

        self._run(work, done)

    def _edit(self) -> None:
        view, field = self._view, self._selected_field()
        if view is None or field is None or not is_editable(field.path):
            return
        text = self.ask_text(t("review.edit.title"), field.label, field.value)
        if text is None:
            return
        invoice_id, revision = view.record.invoice_id, view.record.revision
        self._act(
            lambda: self._controller.edit_field(invoice_id, field.path, text, revision),
            t("review.edited"),
        )

    def _override(self) -> None:
        view, finding = self._view, self._selected_finding()
        if view is None or finding is None:
            return
        reason = self.ask_text(t("review.override.title"), t("review.override.label"), "")
        if reason is None:
            return
        invoice_id, revision = view.record.invoice_id, view.record.revision
        self._act(
            lambda: self._controller.override_finding(invoice_id, finding, reason, revision),
            t("review.overridden"),
        )

    def _approve(self) -> None:
        view = self._view
        if view is None:
            return
        invoice_id, revision = view.record.invoice_id, view.record.revision
        self._act(
            lambda: self._controller.approve(invoice_id, revision, None), t("review.approved")
        )

    def _reject(self) -> None:
        view = self._view
        if view is None:
            return
        comment = self.ask_text(t("review.reject.title"), t("review.reject.label"), "")
        if comment is None:
            return
        invoice_id, revision = view.record.invoice_id, view.record.revision
        self._act(
            lambda: self._controller.reject(invoice_id, revision, comment), t("review.rejected")
        )

    def _revoke(self) -> None:
        view = self._view
        if view is None:
            return
        invoice_id, revision = view.record.invoice_id, view.record.revision
        self._act(lambda: self._controller.revoke(invoice_id, revision), t("review.revoked"))

    # --- background ------------------------------------------------------------------

    def _run(self, work: Callable[[], object], on_result: Callable[[object], None]) -> None:
        self._busy = True
        self._update_buttons()
        task = BackgroundTask(work, None, on_result)
        self._tasks.add(task)
        queued = Qt.ConnectionType.QueuedConnection
        task.signals.done.connect(self._on_done, queued)
        task.signals.failed.connect(self._on_failed, queued)
        self._pool.start(task)

    def _on_done(self, task: BackgroundTask, result: object) -> None:
        self._tasks.discard(task)
        self._busy = False
        if task.on_result is not None:
            task.on_result(result)
        self._update_buttons()

    def _on_failed(self, task: BackgroundTask, message: str) -> None:
        self._tasks.discard(task)
        self._busy = False
        self.status_label.setText(message)
        self._update_buttons()

    def wait_until_idle(self, timeout_ms: int = 10_000) -> bool:
        return self._pool.waitForDone(timeout_ms)
