"""Run controller calls off the GUI thread and report back on it."""

from collections.abc import Callable

from PySide6.QtCore import QObject, QRunnable, Signal

from invoiceflow.application.errors import InvoiceFlowError
from invoiceflow.i18n import t


class TaskSignals(QObject):
    done = Signal(object, object)
    failed = Signal(object, str)


class BackgroundTask(QRunnable):
    def __init__(
        self,
        work: Callable[[], object],
        summary: Callable[[list], str] | None,
        on_result: Callable[[object], None] | None = None,
    ) -> None:
        super().__init__()
        self.setAutoDelete(False)  # the page keeps the reference until it is handled
        self.signals = TaskSignals()
        self.summary = summary
        self.on_result = on_result  # called on the GUI thread instead of a refresh
        self._work = work

    def run(self) -> None:
        try:
            result = self._work()
        except InvoiceFlowError as exc:
            self.signals.failed.emit(self, t(exc.message_key, **exc.params))
        except Exception:  # details may contain file contents: show a generic text
            self.signals.failed.emit(self, t("error.unexpected"))
        else:
            self.signals.done.emit(self, result)
