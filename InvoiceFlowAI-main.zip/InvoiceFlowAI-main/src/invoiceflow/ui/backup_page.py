"""Encrypted backup and restore (Phase 12).

The person chooses where a backup is written and gives a passphrase twice; it
is never stored. A check decrypts and verifies a backup without keeping
anything. A restore writes a complete data directory into an empty folder,
never over the running one. All work runs on a worker thread.
"""

from collections.abc import Callable
from pathlib import Path
from typing import Protocol

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from invoiceflow.application.backup.model import BackupCheck, BackupRecord
from invoiceflow.i18n import t
from invoiceflow.i18n.formatting import format_date
from invoiceflow.ui.background import BackgroundTask
from invoiceflow.ui.widgets import plain_label

COLUMNS = (
    "backup.col.created",
    "backup.col.file",
    "backup.col.size",
    "backup.col.files",
    "backup.col.status",
)


class BackupController(Protocol):
    def backups(self) -> list[BackupRecord]: ...

    def create_backup(self, folder: Path, passphrase: str, confirmation: str) -> BackupRecord: ...

    def verify_backup(self, source: Path, passphrase: str) -> BackupCheck: ...

    def restore_backup(self, source: Path, passphrase: str, target: Path) -> BackupCheck: ...

    def delete_backup(self, source: Path) -> BackupRecord: ...


def size_text(byte_count: int) -> str:
    megabytes = byte_count / (1024 * 1024)
    return t("backup.size", size=f"{megabytes:.1f}".replace(".", ","))


def record_values(record: BackupRecord) -> tuple[str, ...]:
    local = record.created_at.astimezone()
    status = (
        t("backup.status.deleted", date=format_date(record.deleted_at.astimezone().date()))
        if record.deleted_at is not None
        else t("backup.status.made")
    )
    return (
        f"{format_date(local.date())} {local:%H:%M}",
        record.file_name,
        size_text(record.byte_count),
        str(record.file_count),
        status,
    )


class BackupPage(QWidget):
    def __init__(self, controller: BackupController, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._controller = controller
        self._pool = QThreadPool.globalInstance()
        self._tasks: set[BackgroundTask] = set()
        self._busy = False
        # Replaceable in tests: dialogs without a modal event loop.
        self.ask_passphrase: Callable[[str, str], str | None] = self._ask_passphrase
        self.choose_folder: Callable[[str], str | None] = self._choose_folder
        self.choose_file: Callable[[str], str | None] = self._choose_file
        self.confirm: Callable[[str], bool] = self._confirm
        layout = QVBoxLayout(self)
        layout.addWidget(plain_label(t("backup.title")))
        layout.addWidget(plain_label(t("backup.help")))
        layout.addWidget(plain_label(t("backup.warning")))
        actions = QHBoxLayout()
        self.create_button = QPushButton(t("backup.create"))
        self.verify_button = QPushButton(t("backup.verify"))
        self.restore_button = QPushButton(t("backup.restore"))
        self.delete_button = QPushButton(t("backup.delete"))
        self.create_button.clicked.connect(self._create)
        self.verify_button.clicked.connect(self._verify)
        self.restore_button.clicked.connect(self._restore)
        self.delete_button.clicked.connect(self._delete)
        for button in (
            self.create_button,
            self.verify_button,
            self.restore_button,
            self.delete_button,
        ):
            actions.addWidget(button)
        actions.addStretch()
        layout.addLayout(actions)
        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels([t(key) for key in COLUMNS])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setAccessibleName(t("backup.table"))
        layout.addWidget(self.table)
        self.status_label = plain_label("")
        layout.addWidget(self.status_label)
        self.refresh()

    def refresh(self) -> None:
        self._run(self._controller.backups, self._show, working=False)

    def _show(self, result: object) -> None:
        records = result if isinstance(result, list) else []
        self.table.setRowCount(len(records))
        for row, record in enumerate(records):
            for column, value in enumerate(record_values(record)):
                self.table.setItem(row, column, QTableWidgetItem(value))

    # --- dialogs ---------------------------------------------------------------------

    def _ask_passphrase(self, title: str, label: str) -> str | None:
        text, accepted = QInputDialog.getText(self, title, label, QLineEdit.EchoMode.Password)
        return text if accepted else None

    def _choose_folder(self, title: str) -> str | None:
        return QFileDialog.getExistingDirectory(self, title) or None

    def _choose_file(self, title: str) -> str | None:
        name, _ = QFileDialog.getOpenFileName(self, title, "", t("backup.file_filter"))
        return name or None

    def _confirm(self, text: str) -> bool:
        answer = QMessageBox.question(self, t("backup.delete.title"), text)
        return answer == QMessageBox.StandardButton.Yes

    # --- actions ---------------------------------------------------------------------

    def _create(self) -> None:
        folder = self.choose_folder(t("backup.create.folder"))
        if folder is None:
            return
        passphrase = self.ask_passphrase(t("backup.create.title"), t("backup.passphrase"))
        if passphrase is None:
            return
        confirmation = self.ask_passphrase(t("backup.create.title"), t("backup.passphrase.again"))
        if confirmation is None:
            return
        self._run(
            lambda: self._controller.create_backup(Path(folder), passphrase, confirmation),
            self._created,
        )

    def _created(self, result: object) -> None:
        if isinstance(result, BackupRecord):
            self.status_label.setText(
                t("backup.created", file=result.file_name, count=result.file_count)
            )
        self.refresh()

    def _verify(self) -> None:
        source = self.choose_file(t("backup.verify.title"))
        if source is None:
            return
        passphrase = self.ask_passphrase(t("backup.verify.title"), t("backup.passphrase"))
        if passphrase is None:
            return
        self._run(
            lambda: self._controller.verify_backup(Path(source), passphrase),
            lambda result: self._checked(result, "backup.verified"),
        )

    def _restore(self) -> None:
        source = self.choose_file(t("backup.restore.title"))
        if source is None:
            return
        target = self.choose_folder(t("backup.restore.folder"))
        if target is None:
            return
        passphrase = self.ask_passphrase(t("backup.restore.title"), t("backup.passphrase"))
        if passphrase is None:
            return
        self._run(
            lambda: self._controller.restore_backup(Path(source), passphrase, Path(target)),
            lambda result: self._checked(result, "backup.restored", target),
        )

    def _checked(self, result: object, key: str, target: str = "") -> None:
        if isinstance(result, BackupCheck):
            known = t("backup.known" if result.known else "backup.unknown")
            self.status_label.setText(t(key, count=result.file_count, known=known, folder=target))
        self.refresh()

    def _delete(self) -> None:
        source = self.choose_file(t("backup.delete.title"))
        if source is None or not self.confirm(t("backup.delete.confirm")):
            return
        self._run(
            lambda: self._controller.delete_backup(Path(source)),
            self._deleted,
        )

    def _deleted(self, _result: object) -> None:
        self.status_label.setText(t("backup.deleted"))
        self.refresh()

    # --- background ------------------------------------------------------------------

    def _update_buttons(self) -> None:
        for button in (
            self.create_button,
            self.verify_button,
            self.restore_button,
            self.delete_button,
        ):
            button.setEnabled(not self._busy)

    def _run(
        self,
        work: Callable[[], object],
        on_result: Callable[[object], None],
        *,
        working: bool = True,
    ) -> None:
        self._busy = True
        self._update_buttons()
        if working:  # Encryption and checks can take minutes for a large archive.
            self.status_label.setText(t("backup.working"))
        task = BackgroundTask(work, None, on_result)
        self._tasks.add(task)
        queued = Qt.ConnectionType.QueuedConnection
        task.signals.done.connect(self._on_done, queued)
        task.signals.failed.connect(self._on_failed, queued)
        self._pool.start(task)

    def _on_done(self, task: BackgroundTask, result: object) -> None:
        self._tasks.discard(task)
        self._busy = False
        self._update_buttons()
        if task.on_result is not None:
            task.on_result(result)

    def _on_failed(self, task: BackgroundTask, message: str) -> None:
        self._tasks.discard(task)
        self._busy = False
        self.status_label.setText(message)
        self._update_buttons()

    def wait_until_idle(self, timeout_ms: int = 10_000) -> bool:
        return self._pool.waitForDone(timeout_ms)
