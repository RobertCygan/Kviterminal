"""Supplier register: payment accounts and their status (Phase 08a).

Confirming or blocking an account is the only way an account becomes
trusted; the engine never does it. Every change asks for confirmation and is
audited by the service. Supplier names come from invoices and are shown as
plain text only.
"""

import datetime as dt
from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol
from uuid import UUID

from PySide6.QtCore import Qt, QThreadPool
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from invoiceflow.application.reference.model import (
    Dimension,
    ReferenceData,
    SupplierDefaults,
    VatDirection,
)
from invoiceflow.application.validation.model import (
    AccountStatus,
    BankAccountRecord,
    SupplierRecord,
)
from invoiceflow.application.validation.service import SupplierView
from invoiceflow.i18n import t
from invoiceflow.ui.background import BackgroundTask
from invoiceflow.ui.validation_text import format_account
from invoiceflow.ui.widgets import plain_label

COLUMNS = (
    "suppliers.col.name",
    "suppliers.col.id",
    "suppliers.col.account",
    "suppliers.col.kind",
    "suppliers.col.status",
)


class SupplierController(Protocol):
    def suppliers(self) -> list[SupplierView]: ...

    def set_account_status(
        self, account_id: UUID, status: AccountStatus, expected: AccountStatus
    ) -> None: ...

    def reference_data(self) -> ReferenceData: ...

    def supplier_defaults(self, supplier_id: UUID) -> SupplierDefaults | None: ...

    def set_supplier_defaults(
        self,
        supplier_id: UUID,
        account: str | None,
        vat_code: str | None,
        dimensions: dict[Dimension, str],
    ) -> None: ...


@dataclass(frozen=True, slots=True)
class SupplierRow:
    supplier: SupplierRecord
    account: BankAccountRecord | None


def rows_of(views: list[SupplierView]) -> list[SupplierRow]:
    """One row per account; a supplier without accounts gets one empty row."""
    rows: list[SupplierRow] = []
    for view in views:
        if not view.accounts:
            rows.append(SupplierRow(view.supplier, None))
        rows.extend(SupplierRow(view.supplier, account) for account in view.accounts)
    return rows


def row_values(row: SupplierRow) -> tuple[str, ...]:
    supplier, account = row.supplier, row.account
    identity = supplier.org_number or supplier.foreign_vat_id or ""
    if account is None:
        return (supplier.name, identity, "", "", "")
    return (
        supplier.name,
        identity,
        format_account(account.kind, account.account),
        t(f"account.kind.{account.kind}"),
        t(f"account.status.{account.status}"),
    )


class DefaultsDialog(QDialog):
    """Choose the standard posting from the entity's own reference data."""

    def __init__(
        self,
        supplier: SupplierRecord,
        reference: ReferenceData,
        current: SupplierDefaults | None,
        today: dt.date,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(t("defaults.title"))
        layout = QFormLayout(self)
        layout.addRow(plain_label(t("defaults.supplier", supplier=supplier.name)))
        accounts = sorted(
            (entry.account, entry.name)
            for entry in (reference.accounts or {}).values()
            if entry.is_active
        )
        codes = sorted(
            {
                (entry.code, entry.name or "")
                for entry in reference.input_codes_on(today)
                if entry.direction is VatDirection.INPUT
            }
        )
        self.account = self._combo(accounts, None if current is None else current.account)
        self.vat_code = self._combo(codes, None if current is None else current.vat_code)
        layout.addRow(plain_label(t("defaults.account")), self.account)
        layout.addRow(plain_label(t("defaults.vat_code")), self.vat_code)
        self.dimensions: dict[Dimension, QComboBox] = {}
        for dimension in Dimension:
            values = sorted(
                (entry.code, entry.name)
                for (kind, _), entry in (reference.dimensions or {}).items()
                if kind is dimension and entry.is_active
            )
            if values:
                chosen = None if current is None else current.dimensions.get(dimension)
                self.dimensions[dimension] = self._combo(values, chosen)
                layout.addRow(plain_label(t(f"dimension.{dimension}")), self.dimensions[dimension])
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    @staticmethod
    def _combo(values: list[tuple[str, str]], current: str | None) -> QComboBox:
        combo = QComboBox()
        combo.addItem(t("defaults.none"), None)
        for code, name in values:
            combo.addItem(f"{code} - {name}" if name else code, code)  # plain text items
        index = combo.findData(current)
        combo.setCurrentIndex(max(index, 0))
        return combo

    def values(self) -> tuple[str | None, str | None, dict[Dimension, str]]:
        dimensions = {
            dimension: combo.currentData()
            for dimension, combo in self.dimensions.items()
            if combo.currentData() is not None
        }
        return self.account.currentData(), self.vat_code.currentData(), dimensions


class SuppliersPage(QWidget):
    def __init__(self, controller: SupplierController, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._controller = controller
        self._pool = QThreadPool.globalInstance()
        self._tasks: set[BackgroundTask] = set()
        self._rows: list[SupplierRow] = []
        self._busy = False
        # Tests replace this to answer the confirmation without a modal dialog.
        self.confirm: Callable[[str], bool] = self._ask
        layout = QVBoxLayout(self)
        layout.addWidget(plain_label(t("nav.suppliers")))
        buttons = QHBoxLayout()
        self.refresh_button = QPushButton(t("suppliers.refresh"))
        self.verify_button = QPushButton(t("suppliers.verify"))
        self.block_button = QPushButton(t("suppliers.block"))
        self.defaults_button = QPushButton(t("suppliers.defaults"))
        # Tests replace this to fill in the dialog without showing it.
        self.edit_defaults: Callable[[DefaultsDialog], bool] = lambda dialog: (
            dialog.exec() == QDialog.DialogCode.Accepted
        )
        for button in (
            self.refresh_button,
            self.verify_button,
            self.block_button,
            self.defaults_button,
        ):
            buttons.addWidget(button)
        buttons.addStretch()
        layout.addLayout(buttons)
        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels([t(key) for key in COLUMNS])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.setAccessibleName(t("suppliers.table"))
        layout.addWidget(self.table)
        self.status_label = plain_label("")
        layout.addWidget(self.status_label)
        self.refresh_button.clicked.connect(self.refresh)
        self.verify_button.clicked.connect(lambda: self._change(AccountStatus.VERIFIED))
        self.block_button.clicked.connect(lambda: self._change(AccountStatus.BLOCKED))
        self.defaults_button.clicked.connect(self._choose_defaults)
        self.table.itemSelectionChanged.connect(self._update_buttons)
        self.refresh()

    def refresh(self) -> None:
        self._run(self._controller.suppliers, self._show)

    def _show(self, result: object) -> None:
        views = result if isinstance(result, list) else []
        self._rows = rows_of(views)
        self.table.setRowCount(len(self._rows))
        for index, row in enumerate(self._rows):
            for column, value in enumerate(row_values(row)):
                self.table.setItem(index, column, QTableWidgetItem(value))  # plain text
        self.status_label.setText("" if self._rows else t("suppliers.none"))
        self._update_buttons()

    def _selected(self) -> SupplierRow | None:
        model = self.table.selectionModel()
        rows = model.selectedRows() if model else []
        if not rows or rows[0].row() >= len(self._rows):
            return None
        return self._rows[rows[0].row()]

    def _update_buttons(self) -> None:
        self.refresh_button.setEnabled(not self._busy)
        row = self._selected()
        account = None if row is None else row.account
        self.verify_button.setEnabled(
            not self._busy and account is not None and account.status is not AccountStatus.VERIFIED
        )
        self.block_button.setEnabled(
            not self._busy and account is not None and account.status is not AccountStatus.BLOCKED
        )
        self.defaults_button.setEnabled(not self._busy and row is not None)

    def _ask(self, text: str) -> bool:
        box = QMessageBox(self)
        box.setWindowTitle(t("suppliers.confirm.title"))
        box.setTextFormat(Qt.TextFormat.PlainText)
        box.setText(text)
        box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        box.setDefaultButton(QMessageBox.StandardButton.No)
        return box.exec() == QMessageBox.StandardButton.Yes

    def _change(self, status: AccountStatus) -> None:
        row = self._selected()
        if row is None or row.account is None:
            return
        account = row.account
        key = "verify" if status is AccountStatus.VERIFIED else "block"
        text = t(
            f"suppliers.confirm.{key}",
            account=format_account(account.kind, account.account),
            supplier=row.supplier.name,
        )
        if not self.confirm(text):
            return
        self._run(
            lambda: self._controller.set_account_status(account.account_id, status, account.status),
            lambda _: self._changed(),
        )

    def _choose_defaults(self) -> None:
        row = self._selected()
        if row is None:
            return
        supplier = row.supplier
        self._run(
            lambda: (
                self._controller.reference_data(),
                self._controller.supplier_defaults(supplier.supplier_id),
            ),
            lambda result: self._open_defaults(supplier, result),
        )

    def _open_defaults(self, supplier: SupplierRecord, result: object) -> None:
        reference, current = result if isinstance(result, tuple) else (ReferenceData(), None)
        if reference.accounts is None and reference.vat_codes is None:
            self.status_label.setText(t("defaults.no_reference"))
            return
        dialog = DefaultsDialog(supplier, reference, current, dt.date.today(), self)  # noqa: DTZ011
        if not self.edit_defaults(dialog):
            return
        account, vat_code, dimensions = dialog.values()
        self._run(
            lambda: self._controller.set_supplier_defaults(
                supplier.supplier_id, account, vat_code, dimensions
            ),
            lambda _: self.status_label.setText(t("defaults.saved")),
        )

    def _changed(self) -> None:
        self.status_label.setText(t("suppliers.changed"))
        self._run(self._controller.suppliers, self._show_keeping_status)

    def _show_keeping_status(self, result: object) -> None:
        message = self.status_label.text()
        self._show(result)
        self.status_label.setText(message)

    def _run(self, work: Callable[[], object], on_result: Callable[[object], None]) -> None:
        self._busy = True
        self._update_buttons()
        task = BackgroundTask(work, None, on_result)
        self._tasks.add(task)
        queued = Qt.ConnectionType.QueuedConnection
        task.signals.done.connect(self._on_done, queued)
        task.signals.failed.connect(self._on_failed, queued)
        self._pool.start(task)

    def _on_done(self, task: BackgroundTask, result: object) -> None:
        self._tasks.discard(task)
        self._busy = False
        if task.on_result is not None:
            task.on_result(result)
        self._update_buttons()

    def _on_failed(self, task: BackgroundTask, message: str) -> None:
        self._tasks.discard(task)
        self._busy = False
        self.status_label.setText(message)
        self._update_buttons()

    def wait_until_idle(self, timeout_ms: int = 10_000) -> bool:
        return self._pool.waitForDone(timeout_ms)
