"""Shared test fixtures.

Test data must be synthetic. Never add real invoices or real client data.
"""

import functools
import json
import os
import sys
from pathlib import Path
from typing import Any

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent
# Shared helpers (hostile corpus, worker targets). On sys.path, so that a
# spawned worker process can import the hostile targets by name as well.
SUPPORT = Path(__file__).resolve().parent / "support"
if str(SUPPORT) not in sys.path:
    sys.path.insert(0, str(SUPPORT))
EXAMPLE_INVOICE_PATH = REPO_ROOT / "docs" / "examples" / "eksempel_faktura_kanonisk.json"


@pytest.fixture
def example_invoice_json() -> str:
    return EXAMPLE_INVOICE_PATH.read_text(encoding="utf-8")


@pytest.fixture
def example_invoice_data(example_invoice_json: str) -> dict[str, Any]:
    return json.loads(example_invoice_json)


@functools.cache
def tesseract_available() -> bool:
    from invoiceflow.application.processing_model import OcrSettings
    from invoiceflow.processing.tesseract_install import locate

    install = locate()
    return install is not None and install.engine_version(OcrSettings()) is not None


def pytest_runtest_setup(item: pytest.Item) -> None:
    """Tests marked ``tesseract`` need the OCR engine; CI requires it (Phase 05)."""
    if item.get_closest_marker("tesseract") is None or tesseract_available():
        return
    if os.environ.get("INVOICEFLOW_REQUIRE_TESSERACT") == "1":
        pytest.fail("Tesseract with Norwegian language data is required here")
    pytest.skip("Tesseract with Norwegian language data is not installed")
