"""Synthetic Norwegian invoices laid out like real ones (Phase 06).

No real company, person or account: the organisation numbers are invented
(some fail MOD11 on purpose) and the accounts are test numbers. The golden
files hold exactly the values a careful reader would take from each sample.
"""

from dataclasses import dataclass

ENTITY_ORG = "123456785"
ENTITY_NAME = "Syntetisk Kunde AS"

Item = tuple[float, float, str]


@dataclass(frozen=True)
class Sample:
    """A laid-out invoice; its expected values are in ``tests/fixtures/synthetic/extraction``."""

    name: str
    pages: tuple[tuple[Item, ...], ...]


STANDARD = Sample(
    "standard",
    (
        (
            (50, 50, "Syntetisk Leverandør AS"),
            (50, 64, "Storgata 1, 9008 Tromsø"),
            (50, 78, "Org.nr. NO 999 999 999 MVA"),
            (400, 50, "FAKTURA"),
            (50, 130, "Syntetisk Kunde AS"),
            (50, 144, "Kundevegen 2, 8514 Narvik"),
            (350, 130, "Fakturanummer: 2026-0417"),
            (350, 144, "Fakturadato: 24.10.2026"),
            (350, 158, "Forfallsdato: 07.11.2026"),
            (350, 172, "Deres ref.: Kari Nordmann"),
            (50, 230, "Beskrivelse"),
            (300, 230, "Antall"),
            (370, 230, "Pris"),
            (480, 230, "Beløp"),
            (50, 248, "Konsulenttjenester oktober"),
            (300, 248, "12"),
            (370, 248, "950,00"),
            (480, 248, "11 400,00"),
            (50, 266, "Reisekostnader"),
            (300, 266, "1"),
            (370, 266, "1 234,50"),
            (480, 266, "1 234,50"),
            (350, 310, "Sum eks. MVA"),
            (480, 310, "12 634,50"),
            (350, 324, "MVA 25 %"),
            (480, 324, "3 158,63"),
            (350, 338, "Å betale NOK"),
            (480, 338, "15 793,13"),
            (50, 400, "Kontonummer: 1234.56.78903"),
            (50, 414, "KID: 20260417005"),
        ),
    ),
)

COLUMNS = Sample(
    "kolonner",
    (
        (
            (50, 50, "Nordlys Regnskap ASA"),
            (50, 64, "Foretaksregisteret NO 912 345 678 MVA"),
            (420, 50, "Faktura"),
            (50, 120, "Kunde: Syntetisk Kunde AS, org.nr. 123 456 785"),
            (50, 160, "Fakturanr."),
            (160, 160, "Fakturadato"),
            (270, 160, "Forfall"),
            (380, 160, "KID"),
            (50, 174, "88812"),
            (160, 174, "3. oktober 2026"),
            (270, 174, "17.10.26"),
            (380, 174, "0888120004"),
            (50, 240, "Regnskapsførsel september"),
            (480, 240, "8 000,00"),
            (50, 300, "MVA 25 % av 8 000,00"),
            (480, 300, "2 000,00"),
            (50, 314, "Øreavrunding"),
            (480, 314, "0,00"),
            (50, 328, "Totalt å betale kr"),
            (480, 328, "10 000,00"),
            (50, 380, "Betal til konto 9876 54 32109"),
            (50, 394, "IBAN NO93 8601 1117 947  BIC DNBANOKK"),
        ),
    ),
)

CREDIT_NOTE = Sample(
    "kreditnota",
    (
        (
            (50, 50, "Fjord Elektro AS"),
            (50, 64, "Org.nr.: 987 654 321 MVA"),
            (400, 50, "KREDITNOTA"),
            (350, 120, "Kreditnotanr: K-2026-12"),
            (350, 134, "Dato: 2026-10-20"),
            (350, 148, "Gjelder faktura nr. 2026-0100"),
            (50, 200, "Beskrivelse"),
            (300, 200, "Antall"),
            (370, 200, "Pris"),
            (480, 200, "Beløp"),
            (50, 218, "Returnert kabel"),
            (300, 218, "2"),
            (370, 218, "-500,00"),
            (480, 218, "-1 000,00"),
            (350, 260, "Sum eks. MVA"),
            (480, 260, "-1 000,00"),
            (350, 274, "MVA 25 %"),
            (480, 274, "-250,00"),
            (350, 288, "Til betaling NOK"),
            (480, 288, "-1 250,00"),
        ),
    ),
)

TWO_RATES = Sample(
    "to-satser",
    (
        (
            (50, 50, "Kantine Nord SA"),
            (50, 64, "Org nr 911 111 111"),
            (400, 50, "Faktura"),
            (350, 120, "Faktura nr: 5501"),
            (350, 134, "Fakturadato: 01.10.2026"),
            (350, 148, "Forfallsdato: 31.02.2026"),
            (50, 230, "Sum ekskl. mva"),
            (480, 230, "1 300,00"),
            (50, 248, "MVA 15 % av 1 000,00"),
            (480, 248, "150,00"),
            (50, 262, "MVA 25 % av 300,00"),
            (480, 262, "75,00"),
            (50, 276, "Sum mva"),
            (480, 276, "225,00"),
            (50, 290, "Å betale"),
            (480, 290, "1 525,00"),
            (50, 340, "Kontonr. 1111 22 33334"),
        ),
        (
            (50, 50, "Side 2 av 2"),
            (50, 70, "Takk for handelen!"),
        ),
    ),
)

NOT_AN_INVOICE = Sample(
    "avtale",
    (
        (
            (50, 50, "Leieavtale for kontorlokaler"),
            (50, 70, "Partene: Syntetisk Utleie AS og Syntetisk Kunde AS"),
            (50, 90, "Månedlig leie kr 12 000,00"),
        ),
    ),
)

SAMPLES = (STANDARD, COLUMNS, CREDIT_NOTE, TWO_RATES)


def flatten(invoice) -> dict[str, object]:
    """Every value the invoice holds, by path; lines and VAT rows as tuples of values."""
    data = invoice.model_dump(mode="json", exclude_none=True)
    fields: dict[str, object] = {}

    def walk(prefix: str, node: object) -> None:
        if isinstance(node, dict) and "provenance" in node:
            fields[prefix] = node.get("value")
        elif isinstance(node, dict):
            for key, child in node.items():
                walk(f"{prefix}.{key}" if prefix else key, child)

    for key in (
        "invoice_type",
        "invoice_number",
        "invoice_date",
        "due_date",
        "currency",
        "referenced_invoice_number",
        "buyer_reference",
        "supplier",
        "customer",
        "payment",
        "totals",
    ):
        if key in data:
            walk(key, data[key])

    def value(row: dict, key: str) -> object:
        return row[key].get("value") if key in row else None

    return {
        "fields": fields,
        "vat_breakdown": [
            [value(row, "vat_rate"), value(row, "taxable_amount"), value(row, "vat_amount")]
            for row in data.get("vat_breakdown", [])
        ],
        "lines": [
            [
                value(row, "description"),
                value(row, "quantity"),
                value(row, "unit_price"),
                value(row, "net_amount"),
            ]
            for row in data.get("lines", [])
        ],
    }
