"""Build canonical invoices from plain values for rule tests (synthetic only)."""

import copy
from typing import Any
from uuid import UUID

from invoiceflow.domain.invoice import CanonicalInvoice

DOCUMENT_ID = UUID("00000000-0000-4000-8000-000000000001")
_PROVENANCE = {"source": "calculated", "producer": "test"}

# A consistent Norwegian invoice: 2 lines, 25 % VAT, valid check digits.
BASE: dict[str, Any] = {
    "invoice_type": "invoice",
    "invoice_number": "F-1001",
    "invoice_date": "2026-10-01",
    "due_date": "2026-10-15",
    "currency": "NOK",
    "supplier": {
        "name": "Syntetisk Leverandør AS",
        "org_number": "123456785",
        "vat_registered": True,
        "address": {"country_code": "NO"},
    },
    "customer": {"name": "Syntetisk Mottaker AS", "org_number": "314159268"},
    "payment": {"kid": "1234567890128", "bank_account": "12345678903"},
    "lines": [
        {"line_number": 1, "net_amount": "1000.00", "vat_rate": "25"},
        {"line_number": 2, "net_amount": "500.00", "vat_rate": "25"},
    ],
    "vat_breakdown": [{"vat_rate": "25", "taxable_amount": "1500.00", "vat_amount": "375.00"}],
    "totals": {"net_amount": "1500.00", "vat_amount": "375.00", "gross_amount": "1875.00"},
}


def _wrap(data: Any, key: str | None = None) -> Any:
    if isinstance(data, dict):
        return {name: _wrap(value, name) for name, value in data.items() if value is not None}
    if isinstance(data, list):
        return [_wrap(item) for item in data]
    if key == "line_number":
        return data
    return {"value": data, "provenance": dict(_PROVENANCE)}


def plain(**changes: Any) -> dict[str, Any]:
    """BASE with top-level changes; ``None`` removes a field."""
    data = copy.deepcopy(BASE)
    data.update(changes)
    return data


def make(data: dict[str, Any] | None = None, **changes: Any) -> CanonicalInvoice:
    data = copy.deepcopy(data if data is not None else BASE)
    data.update(changes)
    wrapped = _wrap({key: value for key, value in data.items() if value is not None})
    return CanonicalInvoice.model_validate({"document_id": DOCUMENT_ID, **wrapped})
