"""Synthetic scanned invoice pages and a character error rate (Phase 05).

The pages are printed with Helvetica into a PDF, rendered as a greyscale image
and, for the harder variants, rotated slightly, speckled with noise or saved
as JPEG at a lower resolution, as a cheap office scanner would. Never use real
invoices here.
"""

import io
import random

import pypdfium2 as pdfium
from PIL import Image, ImageFilter

from invoiceflow.bootstrap.synthetic_pdf import lines_pdf

# A synthetic Norwegian invoice; no real company, person or account.
REFERENCE_LINES = (
    "Syntetisk Leverandør AS",
    "Org.nr. 999 999 999 MVA",
    "Storgata 1, 9008 Tromsø",
    "FAKTURA",
    "Fakturanummer: 2026-0417",
    "Fakturadato: 24.10.2026",
    "Forfallsdato: 07.11.2026",
    "Kundenummer: 10045",
    "Beskrivelse Antall Pris Beløp",
    "Konsulenttjenester oktober 12 950,00 11 400,00",
    "Reisekostnader 1 1 234,50 1 234,50",
    "Sum eks. MVA 12 634,50",
    "MVA 25 % 3 158,63",
    "Å betale NOK 15 793,13",
    "Kontonummer: 1234.56.78903",
    "KID: 20260417005",
)


def render(lines=REFERENCE_LINES, *, dpi: int = 300, font_size: int = 11) -> Image.Image:
    document = pdfium.PdfDocument(lines_pdf(lines, font_size=font_size))
    try:
        return document[0].render(scale=dpi / 72, grayscale=True).to_pil().convert("L")
    finally:
        document.close()


def degrade(image: Image.Image, *, angle: float, noise: float, seed: int = 7) -> Image.Image:
    """Rotate a little and add salt-and-pepper noise and a slight blur."""
    image = image.rotate(angle, resample=Image.Resampling.BICUBIC, expand=False, fillcolor=255)
    image = image.filter(ImageFilter.GaussianBlur(0.6))
    generator = random.Random(seed)  # noqa: S311 - reproducible test noise, not secrecy
    pixels = image.load()
    width, height = image.size
    for _ in range(int(width * height * noise)):
        x, y = generator.randrange(width), generator.randrange(height)
        pixels[x, y] = 0 if generator.random() < 0.5 else 255
    return image


def encode(image: Image.Image, image_format: str = "PNG", **options) -> bytes:
    buffer = io.BytesIO()
    image.save(buffer, image_format, **options)
    return buffer.getvalue()


def normalised(text: str) -> str:
    return " ".join(text.split())


def character_error_rate(expected: str, actual: str) -> float:
    """Levenshtein distance over the expected length, ignoring layout whitespace."""
    expected, actual = normalised(expected), normalised(actual)
    previous = list(range(len(actual) + 1))
    for row, left in enumerate(expected, start=1):
        current = [row]
        for column, right in enumerate(actual, start=1):
            current.append(
                min(
                    previous[column] + 1,
                    current[column - 1] + 1,
                    previous[column - 1] + (left != right),
                )
            )
        previous = current
    return previous[-1] / max(len(expected), 1)
