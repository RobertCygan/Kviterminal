"""Synthetic reference data for rule and posting tests (not real Norwegian codes)."""

import datetime as dt
from decimal import Decimal
from types import MappingProxyType
from uuid import UUID

from invoiceflow.application.reference.model import (
    AccountEntry,
    Dimension,
    DimensionEntry,
    ReferenceData,
    SupplierDefaults,
    VatCodeEntry,
    VatDirection,
)

SUPPLIER_ID = UUID("00000000-0000-4000-8000-0000000000bb")
START = dt.date(2026, 1, 1)

REFERENCE = ReferenceData(
    accounts=MappingProxyType(
        {
            "6300": AccountEntry("6300", "Leie lokale", "1"),
            "6800": AccountEntry("6800", "Kontorrekvisita", "1"),
            "6900": AccountEntry("6900", "Gammel konto", None, is_active=False),
        }
    ),
    vat_codes=(
        VatCodeEntry("1", Decimal("25"), VatDirection.INPUT, START),
        VatCodeEntry("11", Decimal("15"), VatDirection.INPUT, START),
        VatCodeEntry("13", Decimal("12"), VatDirection.INPUT, START),
        VatCodeEntry("3", Decimal("25"), VatDirection.OUTPUT, START),
        VatCodeEntry(
            "7", Decimal("25"), VatDirection.INPUT, dt.date(2020, 1, 1), dt.date(2025, 12, 31)
        ),
    ),
    dimensions=MappingProxyType(
        {
            (Dimension.DEPARTMENT, "10"): DimensionEntry(Dimension.DEPARTMENT, "10", "Narvik"),
            (Dimension.PROJECT, "P1"): DimensionEntry(Dimension.PROJECT, "P1", "Gammel", False),
        }
    ),
)

DEFAULTS = SupplierDefaults(supplier_id=SUPPLIER_ID, account="6300", vat_code="1")
