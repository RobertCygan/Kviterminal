"""Worker targets that misbehave on purpose; they run in a spawned process.

Importable in the child because the test session puts ``tests/support`` on
``sys.path`` before the process starts (spawn copies ``sys.path``).
"""

import os
import subprocess
import sys
import time
from multiprocessing.connection import Connection

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.processing_model import ProcessingLimits
from invoiceflow.processing.worker import limit_own_resources, serve


def _task(connection: Connection) -> object:
    task = connection.recv()
    limit_own_resources(task.limits.memory_bytes)
    return task


def sleep_forever(connection: Connection) -> None:
    """An endless loop in a parser: only the deadline stops it."""
    _task(connection)
    while True:
        time.sleep(1)


def exit_hard(connection: Connection) -> None:
    """A native crash: the process ends without a report."""
    _task(connection)
    os._exit(3)


def send_garbage(connection: Connection) -> None:
    _task(connection)
    connection.send_bytes(b'{"result_version": 1, "status": "ok", "unexpected": true}')


def send_too_much(connection: Connection) -> None:
    _task(connection)
    connection.send_bytes(b" " * (2 * 1024 * 1024))


def start_child_process(connection: Connection) -> None:
    """Reports whether starting a further process worked (it must not on Windows)."""
    _task(connection)
    try:
        subprocess.run([sys.executable, "-c", "pass"], check=True, timeout=30)
        connection.send_bytes(b"started")
    except (OSError, subprocess.SubprocessError):
        connection.send_bytes(b"refused")


class _AllocatingDocument:
    page_count = 1
    active_content = False

    def pages(self):
        blocks = []
        while True:  # until the memory limit stops it
            blocks.append(bytearray(32 * 1024 * 1024))
        yield  # pragma: no cover

    def close(self) -> None:
        pass


class _AllocatingParser:
    engine = "pypdfium2"
    engine_version = "0"
    formats = frozenset({DocumentFormat.PDF})

    def open(self, data: bytes, document_format: DocumentFormat, limits: ProcessingLimits):
        return _AllocatingDocument()


def allocate_until_limit(connection: Connection) -> None:
    """The real worker loop with a parser that allocates without bound."""
    serve(connection, {DocumentFormat.PDF: _AllocatingParser()})
