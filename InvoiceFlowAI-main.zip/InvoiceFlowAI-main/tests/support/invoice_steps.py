"""Shared steps for service tests: a clean, posted EHF invoice (Phases 08b-10)."""

import datetime as dt

from processing_fakes import InProcessProcessor

from invoiceflow.application.documents import DocumentService
from invoiceflow.application.processing import ProcessingService
from invoiceflow.application.processing_model import ProcessingLimits
from invoiceflow.application.reference.model import ReferenceKind
from invoiceflow.application.reference.service import ReferenceService
from invoiceflow.application.review.service import ReviewService
from invoiceflow.application.services import InvoiceService
from invoiceflow.application.validation.model import AccountStatus
from invoiceflow.application.validation.service import ValidationService
from invoiceflow.bootstrap.synthetic_ehf import build_ehf
from invoiceflow.bootstrap.synthetic_reference import CHART_CSV, VAT_CODES_CSV

TODAY = dt.date(2026, 10, 20)


def validation(setup) -> ValidationService:
    return ValidationService(setup.database.unit_of_work, today=lambda: TODAY)


def references(setup) -> ReferenceService:
    return ReferenceService(setup.database.unit_of_work, validator=validation(setup))


def review(setup) -> ReviewService:
    return ReviewService(setup.database.unit_of_work, validation(setup))


def import_ehf(setup, spec=None, *, name="faktura.xml", scope=None):
    scope = scope or setup.owner
    document_id = setup.add(build_ehf(spec), name, scope=scope)
    ProcessingService(
        setup.database.unit_of_work,
        setup.store,
        setup.derived,
        InProcessProcessor(),
        attachments=DocumentService(setup.database.unit_of_work, setup.store),
        validator=validation(setup),
        poster=references(setup),
        limits=ProcessingLimits(dpi=72),
    ).process(scope, document_id)
    return InvoiceService(setup.database.unit_of_work).summaries(scope)[document_id].invoice_id


def ready_invoice(setup, scope=None) -> object:
    """An invoice with reference data, a verified account and standard posting: no findings."""
    scope = scope or setup.owner
    for kind, text in ((ReferenceKind.CHART, CHART_CSV), (ReferenceKind.VAT_CODES, VAT_CODES_CSV)):
        source = setup.tmp / f"{kind}.csv"
        source.write_text(text, encoding="utf-8")
        references(setup).import_file(scope, kind, source)
    invoice_id = import_ehf(setup, scope=scope)
    (view,) = validation(setup).suppliers(scope)
    (account,) = view.accounts
    validation(setup).set_account_status(
        scope, account.account_id, AccountStatus.VERIFIED, expected=AccountStatus.UNVERIFIED
    )
    references(setup).set_defaults(scope, view.supplier.supplier_id, account="6300", vat_code="1")
    return invoice_id


def status(setup, invoice_id, scope=None) -> str:
    return (
        InvoiceService(setup.database.unit_of_work)
        .get(scope or setup.owner, invoice_id)
        .workflow_status
    )


def events(setup, *types):
    with setup.database.unit_of_work() as uow:
        return [r for r in uow.audit.records() if r.event_type in types]
