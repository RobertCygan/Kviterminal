"""Processors for fast service tests: the real worker code, without a process."""

import json
from collections.abc import Callable
from importlib import metadata
from pathlib import Path

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.ports import WorkerExit, WorkerOutcome, WorkerTask
from invoiceflow.application.processing_model import PAGE_METRICS_VERSION, OcrSettings
from invoiceflow.processing.isolation import IsolatedDocumentProcessor
from invoiceflow.processing.worker import analyse


class InProcessProcessor:
    """Runs :func:`analyse` directly; isolation is tested separately.

    OCR is off unless asked for; with ``ocr`` the installed Tesseract is used.
    """

    def __init__(self, *, ocr: bool = False) -> None:
        self.tasks: list[WorkerTask] = []
        self._isolated = IsolatedDocumentProcessor()
        self._ocr = ocr

    def engine_for(self, document_format: DocumentFormat) -> tuple[str, str]:
        return self._isolated.engine_for(document_format)

    def ocr_engine(self, settings: OcrSettings) -> tuple[str, str] | None:
        return self._isolated.ocr_engine(settings) if self._ocr else None

    def run(self, task: WorkerTask, should_stop: Callable[[], bool]) -> WorkerOutcome:
        self.tasks.append(task)
        ready = self._isolated.prepared(task)
        if ready is None:
            return WorkerOutcome(WorkerExit.CRASHED)
        return WorkerOutcome(WorkerExit.COMPLETED, analyse(ready))


class ScriptedProcessor(InProcessProcessor):
    """Runs the real worker, then lets a test tamper with its report or files."""

    def __init__(self, tamper: Callable[[dict, Path], object], *, ocr: bool = False) -> None:
        super().__init__(ocr=ocr)
        self._tamper = tamper

    def run(self, task: WorkerTask, should_stop: Callable[[], bool]) -> WorkerOutcome:
        outcome = super().run(task, should_stop)
        report = json.loads(outcome.payload or b"{}")
        replaced = self._tamper(report, task.output_dir)
        if isinstance(replaced, WorkerOutcome):
            return replaced
        payload = replaced if isinstance(replaced, bytes) else json.dumps(report).encode()
        return WorkerOutcome(WorkerExit.COMPLETED, payload)


class ExitProcessor(InProcessProcessor):
    """Ends like a killed or crashed worker, without running anything."""

    def __init__(self, exit: WorkerExit, *, ocr: bool = False) -> None:
        super().__init__(ocr=ocr)
        self._exit = exit

    def run(self, task: WorkerTask, should_stop: Callable[[], bool]) -> WorkerOutcome:
        self.tasks.append(task)
        return WorkerOutcome(self._exit)


def pdf_version() -> str:
    """Engine version of the page analysis: the library plus the page metrics (Phase 11a)."""
    return f"{metadata.version('pypdfium2')}+{PAGE_METRICS_VERSION}"
