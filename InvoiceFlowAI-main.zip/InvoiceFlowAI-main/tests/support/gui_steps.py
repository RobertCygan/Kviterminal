"""Shared GUI steps: an archive with reference data and a prepared EHF invoice."""

import time
from collections.abc import Iterator
from contextlib import contextmanager

from PySide6.QtCore import QCoreApplication
from PySide6.QtWidgets import QFileDialog

from invoiceflow.application.reference.model import ReferenceKind
from invoiceflow.application.validation.model import AccountStatus
from invoiceflow.bootstrap.archive import LocalArchiveController
from invoiceflow.bootstrap.persistence import open_archive, open_database
from invoiceflow.bootstrap.synthetic_ehf import CUSTOMER_ORG, Attachment, SyntheticEhf, build_ehf
from invoiceflow.bootstrap.synthetic_pdf import text_pdf
from invoiceflow.bootstrap.synthetic_reference import CHART_CSV, VAT_CODES_CSV
from invoiceflow.config.paths import AppPaths
from invoiceflow.ui.documents_page import DocumentsPage


@contextmanager
def reference_archive(tmp_path) -> Iterator[LocalArchiveController]:
    paths = AppPaths.resolve(tmp_path / "data")
    paths.ensure()
    database, _ = open_database(paths)
    controller = open_archive(database, paths)
    controller.create_entity("Syntetisk Mottaker AS", CUSTOMER_ORG)
    for kind, text in ((ReferenceKind.CHART, CHART_CSV), (ReferenceKind.VAT_CODES, VAT_CODES_CSV)):
        source = tmp_path / f"{kind}.csv"
        source.write_text(text, encoding="utf-8")
        controller.import_reference(kind, source)
    try:
        yield controller
    finally:
        database.close()


def settle(page) -> None:
    """Wait for the page's own work; events are processed explicitly (see test_shell)."""
    deadline = time.monotonic() + 60
    while (page._busy or page._tasks) and time.monotonic() < deadline:
        page.wait_until_idle(100)
        QCoreApplication.processEvents()
    assert not page._busy and not page._tasks


def prepared(qtbot, archive, tmp_path, monkeypatch, *, verify: bool = True) -> None:
    """An EHF invoice with its PDF view analysed; optionally verified and posted."""
    inbox = DocumentsPage(archive)
    qtbot.addWidget(inbox)
    settle(inbox)
    source = tmp_path / "faktura.xml"
    pdf = text_pdf(["Syntetisk faktura EHF-2026-001"])
    source.write_bytes(build_ehf(SyntheticEhf(attachments=(Attachment(pdf),))))
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a, **k: ([str(source)], ""))
    inbox.import_button.click()
    settle(inbox)
    for _ in range(2):  # the EHF, then its PDF attachment
        inbox.process_pending_button.click()
        settle(inbox)
    if verify:
        (view,) = archive.suppliers()
        (account,) = view.accounts
        archive.set_account_status(account.account_id, AccountStatus.VERIFIED, account.status)
        archive.set_supplier_defaults(view.supplier.supplier_id, "6300", "1", {})
