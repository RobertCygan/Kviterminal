"""Continuity guard: the mandatory project documents must exist and be non-empty."""

from pathlib import Path

import pytest

pytestmark = pytest.mark.unit

REPO_ROOT = Path(__file__).resolve().parent.parent

REQUIRED_DOCUMENTS = [
    "README.md",
    "AGENTS.md",
    "docs/MASTER_SPECIFICATION.md",
    "docs/ARCHITECTURE.md",
    "docs/DATA_MODEL.md",
    "docs/SECURITY.md",
    "docs/THREAT_MODEL.md",
    "docs/TEST_STRATEGY.md",
    "docs/DEVELOPMENT_ROADMAP.md",
    "docs/DECISIONS.md",
    "docs/CHANGELOG.md",
    "docs/DEPENDENCIES.md",
    "docs/PHASE_00_AUDIT.md",
    "docs/PHASE_00_DECISION_REGISTER.md",
    "docs/PHASE_00_ACCEPTANCE.md",
    "docs/DOCUMENT_ARCHIVE_SCOPE.md",
    "docs/PHASE_03_REPORT.md",
    "docs/prompts/PHASE_04_ISOLATED_DOCUMENT_PROCESSING.md",
]


@pytest.mark.parametrize("relative_path", REQUIRED_DOCUMENTS)
def test_required_document_exists(relative_path: str) -> None:
    path = REPO_ROOT / relative_path
    assert path.is_file(), f"missing {relative_path}"
    assert path.read_text(encoding="utf-8").strip(), f"{relative_path} is empty"
