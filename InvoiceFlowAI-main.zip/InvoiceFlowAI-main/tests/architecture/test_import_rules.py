"""Architecture guard: enforce module boundaries (docs/ARCHITECTURE.md).

Rules are added here as new packages are introduced.
"""

import ast
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.architecture

PACKAGE_ROOT = Path(__file__).resolve().parents[2] / "src" / "invoiceflow"

# Third-party packages the domain layer may depend on.
DOMAIN_ALLOWED_THIRD_PARTY = {"pydantic"}


def _imported_top_level_modules(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    modules: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            modules.add(node.module)
            # "from invoiceflow import persistence" must count as that module.
            modules.update(f"{node.module}.{alias.name}" for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level > 0:
            modules.add("<relative import>")
    return modules


def _domain_files() -> list[Path]:
    files = sorted((PACKAGE_ROOT / "domain").rglob("*.py"))
    assert files, "domain package not found"
    return files


@pytest.mark.parametrize("path", _domain_files(), ids=lambda p: p.name)
def test_domain_depends_only_on_stdlib_pydantic_and_itself(path: Path) -> None:
    violations = []
    for module in _imported_top_level_modules(path):
        top = module.split(".")[0]
        if top in sys.stdlib_module_names or top in DOMAIN_ALLOWED_THIRD_PARTY:
            continue
        if module == "invoiceflow.domain" or module.startswith("invoiceflow.domain."):
            continue
        violations.append(module)
    assert not violations, f"{path.name} imports outside the domain boundary: {violations}"


@pytest.mark.parametrize("path", sorted(PACKAGE_ROOT.rglob("*.py")), ids=lambda p: str(p))
def test_phase01_boundaries_and_no_network(path: Path) -> None:
    imports = _imported_top_level_modules(path)
    blocked = {"requests", "httpx", "urllib.request", "http.client", "socket"}
    assert not any(
        module == name or module.startswith(name + ".") for module in imports for name in blocked
    )
    package = path.relative_to(PACKAGE_ROOT).parts[0]
    if package in {"application", "config"}:
        assert not any(module.startswith("PySide6") for module in imports)
    if package == "ui":
        assert not any(
            module.startswith(("invoiceflow.persistence", "sqlalchemy")) for module in imports
        )
    if package == "i18n":
        assert all(
            module.split(".")[0] in sys.stdlib_module_names or module.startswith("invoiceflow.i18n")
            for module in imports
        )


PERSISTENCE_LIBRARIES = ("sqlalchemy", "alembic")


def _starts_with(module: str, *prefixes: str) -> bool:
    return any(module == prefix or module.startswith(prefix + ".") for prefix in prefixes)


@pytest.mark.parametrize("path", sorted(PACKAGE_ROOT.rglob("*.py")), ids=lambda p: str(p))
def test_phase02_persistence_boundaries(path: Path) -> None:
    imports = _imported_top_level_modules(path)
    package = path.relative_to(PACKAGE_ROOT).parts[0]
    assert "<relative import>" not in imports
    # SQLAlchemy and Alembic stay inside the persistence adapters.
    if package != "persistence":
        assert not any(_starts_with(m, *PERSISTENCE_LIBRARIES) for m in imports), imports
    # Only the composition root composes concrete adapters.
    if package not in {"persistence", "bootstrap"}:
        assert not any(_starts_with(m, "invoiceflow.persistence") for m in imports), imports
    if package == "persistence":
        assert not any(_starts_with(m, "PySide6", "invoiceflow.ui") for m in imports), imports
        assert not any(_starts_with(m, "invoiceflow.bootstrap") for m in imports), imports
    if package == "application":
        assert not any(_starts_with(m, "invoiceflow.ui", "invoiceflow.bootstrap") for m in imports)


def test_persistence_adapters_are_imported_only_by_bootstrap_persistence() -> None:
    importers = {
        path.relative_to(PACKAGE_ROOT).as_posix()
        for path in PACKAGE_ROOT.rglob("*.py")
        if path.relative_to(PACKAGE_ROOT).parts[0] != "persistence"
        and any(
            _starts_with(m, "invoiceflow.persistence") for m in _imported_top_level_modules(path)
        )
    }
    assert importers == {"bootstrap/persistence.py"}


@pytest.mark.parametrize("path", sorted(PACKAGE_ROOT.rglob("*.py")), ids=lambda p: str(p))
def test_phase03_document_archive_boundaries(path: Path) -> None:
    imports = _imported_top_level_modules(path)
    package = path.relative_to(PACKAGE_ROOT).parts[0]
    # The file-system adapter is composed only by bootstrap.
    if package not in {"documents", "bootstrap"}:
        assert not any(_starts_with(m, "invoiceflow.documents") for m in imports), imports
    if package == "documents":
        forbidden = ("invoiceflow.persistence", "invoiceflow.ui", "invoiceflow.bootstrap")
        assert not any(_starts_with(m, *forbidden, "PySide6", "sqlalchemy") for m in imports)
    if package == "ui":
        assert not any(
            _starts_with(m, "invoiceflow.documents", "hashlib", "shutil") for m in imports
        )


def test_document_adapters_are_imported_only_by_bootstrap_persistence() -> None:
    importers = {
        path.relative_to(PACKAGE_ROOT).as_posix()
        for path in PACKAGE_ROOT.rglob("*.py")
        if path.relative_to(PACKAGE_ROOT).parts[0] != "documents"
        and any(_starts_with(m, "invoiceflow.documents") for m in _imported_top_level_modules(path))
    }
    assert importers == {"bootstrap/persistence.py"}


def _importers(*prefixes: str) -> set[str]:
    return {
        path.relative_to(PACKAGE_ROOT).as_posix()
        for path in PACKAGE_ROOT.rglob("*.py")
        if any(_starts_with(m, *prefixes) for m in _imported_top_level_modules(path))
    }


def test_only_the_adapters_import_a_pdf_or_image_library() -> None:
    """ADR-0023: all PDF access behind DocumentParser, inside the worker."""
    assert _importers("pypdfium2", "fitz", "pymupdf", "pdfminer", "pypdf") == {
        "processing/pdf_pdfium.py"
    }
    assert _importers("PIL") == {"processing/image_pillow.py"}


@pytest.mark.parametrize("path", sorted(PACKAGE_ROOT.rglob("*.py")), ids=lambda p: str(p))
def test_phase04_processing_boundaries(path: Path) -> None:
    imports = _imported_top_level_modules(path)
    package = path.relative_to(PACKAGE_ROOT).parts[0]
    if package == "processing":
        # The worker has no database, no archive adapter, no GUI.
        forbidden = (
            "invoiceflow.persistence",
            "invoiceflow.documents",
            "invoiceflow.ui",
            "invoiceflow.bootstrap",
            "PySide6",
            "sqlalchemy",
            "keyring",
        )
        assert not any(_starts_with(m, *forbidden) for m in imports), imports
    if package in {"application", "domain", "ui", "documents", "persistence"}:
        assert not any(_starts_with(m, "invoiceflow.processing") for m in imports), imports


def test_processing_adapters_are_imported_only_by_bootstrap_persistence() -> None:
    importers = {
        name for name in _importers("invoiceflow.processing") if not name.startswith("processing/")
    }
    assert importers == {"bootstrap/persistence.py"}


def test_only_the_ocr_adapter_starts_programs() -> None:
    """ADR-0040: Tesseract is the only program the application starts."""
    assert _importers("subprocess") == {
        "processing/ocr_tesseract.py",
        "processing/tesseract_install.py",
    }
    assert _importers("shlex", "pty", "pexpect") == set()


def test_only_the_ehf_reader_parses_xml() -> None:
    """ADR-0019: XML only through defusedxml, only inside the worker."""
    assert _importers("defusedxml") == {"processing/ehf.py"}
    assert _importers("xml", "lxml", "xmlschema") == set()


@pytest.mark.parametrize(
    "name",
    [
        "validation/model.py",
        "validation/rules.py",
        "reference/model.py",
        "reference/posting.py",
        "reference/csv_import.py",
        "export/model.py",
        "backup/model.py",
        "scan/model.py",
        "scan/separator.py",
        "extraction/layout.py",
        "extraction/parse.py",
        "extraction/fields.py",
    ],
)
def test_the_validation_rules_are_pure(name: str) -> None:
    """Phases 08a-12: rules, posting, CSV parsing, export table, backup format; no I/O."""
    imports = _imported_top_level_modules(PACKAGE_ROOT / "application" / name)
    allowed_stdlib = {
        "collections.abc",
        "csv",
        "dataclasses",
        "datetime",
        "decimal",
        "enum",
        "hashlib",
        "io",
        "json",
        "re",
        "types",
        "typing",
        "unicodedata",
        "uuid",
    }
    for module in imports:
        assert (
            _starts_with(module, *allowed_stdlib)
            or _starts_with(module, "pydantic", "invoiceflow.domain")
            or _starts_with(module, "invoiceflow.application.validation.model")
            or _starts_with(module, "invoiceflow.application.reference.model")
            or _starts_with(module, "invoiceflow.application.errors")
            or _starts_with(module, "invoiceflow.application.processing_model")
            or _starts_with(module, "invoiceflow.application.extraction")
            or module == "functools"
        ), module


def test_only_the_excel_writer_imports_openpyxl() -> None:
    """Phase 10: the spreadsheet library stays behind the ExportWriter port."""
    assert _importers("openpyxl") == {"export/xlsx_writer.py"}


def test_export_adapters_are_imported_only_by_bootstrap_persistence() -> None:
    importers = {
        name for name in _importers("invoiceflow.export") if not name.startswith("export/")
    }
    assert importers == {"bootstrap/persistence.py"}
    for path in sorted((PACKAGE_ROOT / "export").rglob("*.py")):
        imports = _imported_top_level_modules(path)
        forbidden = ("invoiceflow.persistence", "invoiceflow.ui", "invoiceflow.bootstrap")
        assert not any(_starts_with(m, *forbidden, "PySide6", "sqlalchemy") for m in imports)


def test_only_the_backup_stream_imports_the_cipher_library() -> None:
    """Phase 12: AES-GCM stays behind the backup adapters."""
    assert _importers("cryptography") == {"backup/crypto.py"}
    assert _importers("tarfile") == {"backup/archive.py"}


def test_backup_adapters_are_imported_only_by_bootstrap_persistence() -> None:
    importers = {
        name for name in _importers("invoiceflow.backup") if not name.startswith("backup/")
    }
    assert importers == {"bootstrap/persistence.py"}
    for path in sorted((PACKAGE_ROOT / "backup").rglob("*.py")):
        imports = _imported_top_level_modules(path)
        forbidden = ("invoiceflow.persistence", "invoiceflow.ui", "invoiceflow.bootstrap")
        assert not any(_starts_with(m, *forbidden, "PySide6", "sqlalchemy") for m in imports)
