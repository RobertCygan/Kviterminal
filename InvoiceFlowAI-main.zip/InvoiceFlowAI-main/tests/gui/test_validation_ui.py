"""Validation in the inbox and the supplier page (Phase 08a, offscreen Qt)."""

import ast
import time
from pathlib import Path
from uuid import uuid4

import pytest
from PySide6.QtCore import QCoreApplication
from PySide6.QtWidgets import QFileDialog

from invoiceflow.application.reference.model import ReferenceKind
from invoiceflow.application.validation import rules
from invoiceflow.application.validation.model import (
    AccountKind,
    RuleId,
    Severity,
    ValidationFinding,
    ValidationSummary,
)
from invoiceflow.bootstrap.persistence import open_archive, open_database
from invoiceflow.bootstrap.synthetic_ehf import CUSTOMER_ORG, build_ehf
from invoiceflow.bootstrap.synthetic_reference import CHART_CSV, VAT_CODES_CSV
from invoiceflow.config.paths import AppPaths
from invoiceflow.i18n import t
from invoiceflow.i18n.catalog_nb_no import CATALOG
from invoiceflow.ui.documents_page import COLUMNS, DocumentsPage, validation_details
from invoiceflow.ui.suppliers_page import SuppliersPage, row_values, rows_of
from invoiceflow.ui.validation_text import finding_text, format_account, status_text

VALIDATION_COLUMN = COLUMNS.index("documents.col.validation")
NBSP = "\N{NO-BREAK SPACE}"
PREFIX = "validation."  # message keys are built, not spelled out (gitleaks)


@pytest.fixture
def archive(tmp_path):
    paths = AppPaths.resolve(tmp_path / "data")
    paths.ensure()
    database, _ = open_database(paths)
    controller = open_archive(database, paths)
    controller.create_entity("Syntetisk Mottaker AS", CUSTOMER_ORG)
    # Synthetic chart of accounts and VAT codes (Phase 08b).
    for kind, text in ((ReferenceKind.CHART, CHART_CSV), (ReferenceKind.VAT_CODES, VAT_CODES_CSV)):
        source = tmp_path / f"{kind}.csv"
        source.write_text(text, encoding="utf-8")
        controller.import_reference(kind, source)
    yield controller
    database.close()


def settle(qtbot, page) -> None:
    """Wait for this page's own background work and deliver its results.

    Events are processed explicitly: after a test has quit the application
    (tests/gui/test_shell.py), nested Qt event loops return at once.
    """
    deadline = time.monotonic() + 60
    while (page._busy or page._tasks) and time.monotonic() < deadline:
        page.wait_until_idle(100)
        QCoreApplication.processEvents()
    assert not page._busy and not page._tasks


def inbox_with_ehf(qtbot, controller, monkeypatch, tmp_path: Path) -> DocumentsPage:
    page = DocumentsPage(controller)
    qtbot.addWidget(page)
    settle(qtbot, page)
    source = tmp_path / "faktura.xml"
    source.write_bytes(build_ehf())
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a, **k: ([str(source)], ""))
    page.import_button.click()
    settle(qtbot, page)
    page.process_pending_button.click()
    settle(qtbot, page)
    return page


def test_the_inbox_shows_the_validation_and_its_findings(qtbot, archive, monkeypatch, tmp_path):
    page = inbox_with_ehf(qtbot, archive, monkeypatch, tmp_path)
    assert page.table.horizontalHeaderItem(VALIDATION_COLUMN).text() == t(
        "documents.col.validation"
    )
    # BANK-001 and ACC-002 (no standard posting for the new supplier yet).
    assert page.table.item(0, VALIDATION_COLUMN).text() == "2 feil"
    page.table.selectRow(0)
    assert page.show_validation_button.isEnabled()
    page.show_validation_button.click()
    settle(qtbot, page)
    dialog = page.validation_dialog
    assert dialog is not None and dialog.windowTitle() == t("validation.dialog.title")
    texts = [label.text() for label in dialog.findChildren(type(page.status_label))]
    assert any(t("validation.bank_001_unverified") in text for text in texts)
    assert any(text.startswith("Feil (BANK-001): ") for text in texts)
    dialog.close()


def test_confirming_the_account_clears_the_finding(qtbot, archive, monkeypatch, tmp_path):
    inbox = inbox_with_ehf(qtbot, archive, monkeypatch, tmp_path)
    page = SuppliersPage(archive)
    qtbot.addWidget(page)
    settle(qtbot, page)
    assert [page.table.item(0, column).text() for column in range(5)] == [
        "Syntetisk Leverandør AS",
        "123456785",
        "1234.56.78903",
        t("account.kind.bban"),
        t("account.status.unverified"),
    ]
    assert not page.verify_button.isEnabled()  # nothing selected
    page.table.selectRow(0)
    asked: list[str] = []
    page.confirm = lambda text: asked.append(text) or False
    page.verify_button.click()
    settle(qtbot, page)
    assert page.table.item(0, 4).text() == t("account.status.unverified")
    assert "1234.56.78903" in asked[0] and "Syntetisk Leverandør AS" in asked[0]

    page.confirm = lambda text: True
    page.table.selectRow(0)
    page.verify_button.click()
    settle(qtbot, page)
    assert page.table.item(0, 4).text() == t("account.status.verified")
    assert page.status_label.text() == t("suppliers.changed")
    inbox.refresh()
    settle(qtbot, inbox)
    assert inbox.table.item(0, VALIDATION_COLUMN).text() == "1 feil"

    # The standard posting gives the invoice an account; then nothing is left.
    def choose(dialog) -> bool:
        dialog.account.setCurrentIndex(dialog.account.findData("6300"))
        dialog.vat_code.setCurrentIndex(dialog.vat_code.findData("1"))
        return True

    page.edit_defaults = choose
    page.table.selectRow(0)
    page.defaults_button.click()
    settle(qtbot, page)
    assert page.status_label.text() == t("defaults.saved")
    inbox.refresh()
    settle(qtbot, inbox)
    assert inbox.table.item(0, VALIDATION_COLUMN).text() == t("validation.status.ok")

    page.table.selectRow(0)
    assert not page.verify_button.isEnabled() and page.block_button.isEnabled()
    page.block_button.click()
    settle(qtbot, page)
    assert page.table.item(0, 4).text() == t("account.status.blocked")


def test_revalidating_reports_the_count(qtbot, archive, monkeypatch, tmp_path):
    page = inbox_with_ehf(qtbot, archive, monkeypatch, tmp_path)
    assert page.revalidate_button.isEnabled()
    page.revalidate_button.click()
    settle(qtbot, page)
    assert page.status_label.text() == t("validation.summary", count=1)


def test_the_supplier_page_without_suppliers(qtbot, archive):
    page = SuppliersPage(archive)
    qtbot.addWidget(page)
    settle(qtbot, page)
    assert page.table.rowCount() == 0
    assert page.status_label.text() == t("suppliers.none")


def test_supplier_rows_and_names_are_plain_text():
    from invoiceflow.application.validation.model import SupplierRecord
    from invoiceflow.application.validation.service import SupplierView

    supplier = SupplierRecord(uuid4(), uuid4(), "<b>AS</b>", None, "DE123456789", None)
    rows = rows_of([SupplierView(supplier, ())])
    assert row_values(rows[0]) == ("<b>AS</b>", "DE123456789", "", "", "")


@pytest.mark.parametrize(
    ("summary", "text"),
    [
        (None, "Ikke kontrollert"),
        (ValidationSummary(0, 0, 0), "OK"),
        (ValidationSummary(0, 0, 2), "OK"),
        (ValidationSummary(2, 1, 0), "2 feil, 1 advarsel"),
        (ValidationSummary(0, 3, 0), "3 advarsler"),
    ],
)
def test_status_text(summary, text):
    assert status_text(summary) == text


def test_finding_text_formats_amounts_rates_and_fields():
    finding = ValidationFinding(
        rule_id=RuleId.MVA_001,
        severity=Severity.ERROR,
        field_path="vat_breakdown.1.vat_amount",
        message_key=PREFIX + "mva_001",
        params={"rate": "12.5", "expected": "1250.00", "actual": "1249.97"},
    )
    assert finding_text(finding) == (
        f"Feil (MVA-001): MVA med sats 12,5{NBSP}% skal være 1{NBSP}250,00, men er 1{NBSP}249,97."
    )
    required = ValidationFinding(
        rule_id=RuleId.REQ_001,
        severity=Severity.ERROR,
        field_path="totals.gross_amount",
        message_key=PREFIX + "req_001",
    )
    assert finding_text(required) == "Feil (REQ-001): Obligatorisk felt mangler: beløp å betale."
    assert validation_details(None) == t("validation.dialog.not_run")


def test_every_message_of_the_rules_has_a_norwegian_text():
    tree = ast.parse(Path(rules.__file__).read_text(encoding="utf-8"))
    keys = {
        node.args[2].value
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and getattr(node.func, "id", None) == "_finding"
        and isinstance(node.args[2], ast.Constant)
    }
    keys |= set(rules._BANK_MESSAGES.values())
    assert len(keys) >= 20
    for key in keys:
        assert f"validation.{key}" in CATALOG, key
    for severity in Severity:
        assert f"validation.severity.{severity}" in CATALOG


def test_accounts_are_grouped_for_reading():
    assert format_account(AccountKind.BBAN, "12345678903") == "1234.56.78903"
    assert format_account(AccountKind.IBAN, "NO9386011117947") == "NO93 8601 1117 947"
