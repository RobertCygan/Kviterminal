"""Database startup through the real composition root and CLI."""

import json
import sqlite3
from pathlib import Path

import pytest

from invoiceflow.__main__ import main
from invoiceflow.i18n import t
from invoiceflow.persistence.migrator import initialize_database


def log_rows(data_dir: Path) -> list[dict[str, object]]:
    text = (data_dir / "logs/invoiceflow.log").read_text(encoding="utf-8")
    return [json.loads(line) for line in text.splitlines()]


def raw_rows(path: Path, sql: str) -> list[tuple[object, ...]]:
    connection = sqlite3.connect(path)
    try:
        return connection.execute(sql).fetchall()
    finally:
        connection.close()


@pytest.mark.security
def test_self_test_leaves_the_application_database_untouched(tmp_path, qapp) -> None:
    data = tmp_path / "data"
    assert main(["--self-test", "--data-dir", str(data)]) == 0
    assert main(["--self-test", "--data-dir", str(data)]) == 0
    assert not list(data.glob(".selftest-*"))
    path = data / "database" / "invoiceflow.sqlite3"
    assert raw_rows(path, "SELECT event_type FROM audit_events") == [("database.created",)]
    for table in ("accounting_entities", "invoices", "invoice_revisions"):
        assert raw_rows(path, f"SELECT COUNT(*) FROM {table}") == [(0,)]  # noqa: S608
    assert not list((data / "backups").rglob("*.sqlite3"))


@pytest.mark.security
def test_self_test_cleans_up_after_a_failure(tmp_path, monkeypatch, qapp) -> None:
    import invoiceflow.bootstrap.persistence as persistence

    def broken(*args, **kwargs):
        raise RuntimeError("synthetic private failure")

    monkeypatch.setattr(persistence, "content_sha256", broken)
    assert main(["--self-test", "--data-dir", str(tmp_path)]) == 1
    assert not list(tmp_path.glob(".selftest-*"))
    assert "synthetic private failure" not in (tmp_path / "logs/invoiceflow.log").read_text(
        encoding="utf-8"
    )


@pytest.mark.security
@pytest.mark.parametrize(
    ("content", "code", "key"),
    [
        (
            b"Dette er ikke en database. " * 100,
            "DATABASE_UNRECOGNIZED",
            "error.database_unrecognized",
        ),
        (None, "DATABASE_NEWER_SCHEMA", "error.database_newer"),
    ],
    ids=["foreign", "newer"],
)
def test_unusable_database_stops_startup_with_a_norwegian_message(
    tmp_path, qapp, capsys, content: bytes | None, code: str, key: str
) -> None:
    path = tmp_path / "database" / "invoiceflow.sqlite3"
    path.parent.mkdir(parents=True)
    if content is None:
        initialize_database(path, tmp_path / "backups")
        connection = sqlite3.connect(path)
        connection.execute("UPDATE alembic_version SET version_num = '9999_future'")
        connection.commit()
        connection.close()
    else:
        path.write_bytes(content)
    before = path.read_bytes()

    assert main(["--data-dir", str(tmp_path)]) == 2

    assert capsys.readouterr().err.strip() == t("error.cli", message=t(key), code=code)
    assert path.read_bytes() == before
    rows = log_rows(tmp_path)
    assert [row["event"] for row in rows] == ["database.error", "app.stopped"]
    assert rows[0]["code"] == code
    assert main(["--self-test", "--data-dir", str(tmp_path)]) == 1
    assert t("self_test.failed", code=code) in capsys.readouterr().out
