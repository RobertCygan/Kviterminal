"""Real Qt navigation, literal text, dialogs and offline lifecycle."""

import json
import socket

import pytest
from PySide6.QtCore import QLockFile, Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import QLabel

from invoiceflow import __version__
from invoiceflow.__main__ import main
from invoiceflow.i18n import t
from invoiceflow.i18n.catalog_nb_no import CATALOG, NAVIGATION
from invoiceflow.ui.dialogs import about_dialog, error_dialog
from invoiceflow.ui.main_window import MainWindow
from invoiceflow.ui.widgets import plain_label


def test_window_navigation_and_catalog(qtbot):
    window = MainWindow(__version__, "synthetic-data")
    qtbot.addWidget(window)
    window.show()
    assert window.windowTitle() == t("app.title")
    assert [window.navigation.item(i).text() for i in range(len(NAVIGATION))] == [
        t(key) for key in NAVIGATION
    ]
    for index in range(len(NAVIGATION)):
        rect = window.navigation.visualItemRect(window.navigation.item(index))
        qtbot.mouseClick(window.navigation.viewport(), Qt.MouseButton.LeftButton, pos=rect.center())
        assert window.pages.currentIndex() == index
    window.navigation.setCurrentRow(0)
    qtbot.keyClick(window.navigation, Qt.Key.Key_Down)
    assert window.pages.currentIndex() == 1
    for label in window.findChildren(QLabel):
        assert label.text() in CATALOG.values()
    for action in window.findChildren(QAction):
        if action.text():
            assert action.text() in CATALOG.values()
    assert window.statusBar().currentMessage() == t("status.local")


def test_literal_labels_and_dialogs(qtbot):
    label = plain_label("<b>x</b>")
    qtbot.addWidget(label)
    assert label.textFormat() == Qt.TextFormat.PlainText
    assert label.text() == "<b>x</b>"
    about = about_dialog(__version__, "synthetic-data")
    qtbot.addWidget(about)
    assert __version__ in about.findChild(QLabel).text()
    error = error_dialog("UNEXPECTED", "synthetic-correlation-id")
    qtbot.addWidget(error)
    text = error.findChild(QLabel).text()
    assert "UNEXPECTED" in text and "synthetic-correlation-id" in text
    assert "Traceback" not in text


@pytest.mark.security
def test_self_test_is_offline_and_releases_lock(tmp_path, monkeypatch, qapp):
    def blocked(*args, **kwargs):
        pytest.fail("Unexpected network access")

    monkeypatch.setattr(socket.socket, "connect", blocked)
    monkeypatch.setattr(socket, "create_connection", blocked)
    assert main(["--self-test", "--data-dir", str(tmp_path)]) == 0
    rows = [
        json.loads(line)
        for line in (tmp_path / "logs/invoiceflow.log").read_text(encoding="utf-8").splitlines()
    ]
    assert [row["event"] for row in rows] == ["database.created", "app.started", "app.stopped"]
    lock = QLockFile(str(tmp_path / "instance.lock"))
    assert lock.tryLock(0)
    try:
        assert main(["--data-dir", str(tmp_path)]) == 3
    finally:
        lock.unlock()
    assert main(["--self-test", "--data-dir", str(tmp_path)]) == 0


def test_invalid_config_not_overwritten_by_self_test(tmp_path, qapp):
    config = tmp_path / "config"
    config.mkdir()
    path = config / "config.json"
    raw = '{"api_key":"synthetic-not-a-secret"}'
    path.write_text(raw, encoding="utf-8")
    assert main(["--self-test", "--data-dir", str(tmp_path)]) == 1
    assert path.read_text(encoding="utf-8") == raw


def test_synced_directory_warning_and_shutdown(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("OneDrive", str(tmp_path))
    assert main(["--self-test", "--data-dir", str(tmp_path / "data")]) == 0
    log = (tmp_path / "data/logs/invoiceflow.log").read_text(encoding="utf-8")
    assert "DATA_DIR_SYNCED" in log
    assert str(tmp_path) not in log


def test_self_test_failure_still_releases_lock(tmp_path, monkeypatch, qapp):
    import invoiceflow.bootstrap.self_test as self_test

    def fail(*args):
        raise RuntimeError("private synthetic content")

    monkeypatch.setattr(self_test, "run_self_test", fail)
    assert main(["--self-test", "--data-dir", str(tmp_path)]) == 1
    lock = QLockFile(str(tmp_path / "instance.lock"))
    assert lock.tryLock(0)
    lock.unlock()
    log = (tmp_path / "logs/invoiceflow.log").read_text(encoding="utf-8")
    assert "private synthetic content" not in log
    assert "app.stopped" in log


def test_self_test_detects_broken_shell(qapp):
    from invoiceflow.bootstrap.self_test import run_self_test

    window = MainWindow(__version__, "synthetic")
    window.setWindowTitle("broken")
    with pytest.raises(RuntimeError, match="Invalid shell"):
        run_self_test(qapp, window)
    window.close()


def test_interactive_shutdown_writes_stop(tmp_path, qapp):
    from PySide6.QtCore import QTimer

    QTimer.singleShot(50, qapp.quit)
    assert main(["--data-dir", str(tmp_path)]) == 0
    log = (tmp_path / "logs/invoiceflow.log").read_text(encoding="utf-8")
    assert "app.started" in log and "app.stopped" in log


def test_callback_exception_is_safe_and_fails_self_test(tmp_path, monkeypatch, qapp, capsys):
    import sys

    import invoiceflow.bootstrap.self_test as self_test

    previous_hook = sys.excepthook

    def callback_error(*args):
        sys.excepthook(ValueError, ValueError("synthetic private callback contents"), None)

    monkeypatch.setattr(self_test, "run_self_test", callback_error)
    assert main(["--self-test", "--data-dir", str(tmp_path)]) == 1
    assert "Selvtest feilet" in capsys.readouterr().out
    assert sys.excepthook is previous_hook
    log = (tmp_path / "logs/invoiceflow.log").read_text(encoding="utf-8")
    assert "synthetic private callback contents" not in log
    rows = [json.loads(line) for line in log.splitlines()]
    error = next(row for row in rows if row["event"] == "app.error")
    assert error["exception_type"] == "ValueError"
    assert error["correlation_id"]


def test_lock_permission_failure(tmp_path, monkeypatch, qapp):
    from PySide6 import QtCore

    real_lock = QtCore.QLockFile

    class UnavailableLock:
        LockError = real_lock.LockError

        def __init__(self, *args):
            pass

        def setStaleLockTime(self, *args):  # noqa: N802 - Qt interface
            pass

        def tryLock(self, *args):  # noqa: N802 - Qt interface
            return False

        def error(self):
            return real_lock.LockError.PermissionError

    monkeypatch.setattr(QtCore, "QLockFile", UnavailableLock)
    assert main(["--data-dir", str(tmp_path)]) == 2


def test_self_test_detects_disconnected_navigation(qapp):
    from invoiceflow.bootstrap.self_test import run_self_test

    window = MainWindow(__version__, "synthetic")
    window.navigation.currentRowChanged.disconnect()
    with pytest.raises(RuntimeError, match="Navigation failed"):
        run_self_test(qapp, window)
    window.close()


def test_error_log_level_keeps_lifecycle_events(tmp_path, qapp):
    config = tmp_path / "config"
    config.mkdir()
    (config / "config.json").write_text('{"log_level":"ERROR"}', encoding="utf-8")
    assert main(["--self-test", "--data-dir", str(tmp_path)]) == 0
    rows = [
        json.loads(line)
        for line in (tmp_path / "logs/invoiceflow.log").read_text(encoding="utf-8").splitlines()
    ]
    assert [row["event"] for row in rows] == ["database.created", "app.started", "app.stopped"]
