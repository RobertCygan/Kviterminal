"""The document inbox page with a real archive behind it (offscreen Qt)."""

import datetime as dt
import hashlib
import json
from pathlib import Path
from uuid import uuid4

import hostile_corpus
import pytest
from ocr_samples import encode, render
from PySide6.QtWidgets import QDialog, QFileDialog, QInputDialog, QPlainTextEdit

from invoiceflow.__main__ import main
from invoiceflow.application.document_model import DocumentType, ImportOutcome, ImportResult
from invoiceflow.application.errors import StorageError
from invoiceflow.application.processing_model import (
    JobRecord,
    JobStatus,
    PageText,
    ProcessingErrorCode,
    ProcessingStep,
    TextSource,
)
from invoiceflow.bootstrap.persistence import open_archive, open_database
from invoiceflow.bootstrap.synthetic_pdf import text_pdf
from invoiceflow.config.paths import AppPaths
from invoiceflow.i18n import t
from invoiceflow.ui import documents_page
from invoiceflow.ui.documents_page import (
    COLUMNS,
    DocumentsPage,
    EntityDialog,
    EntityState,
    format_size,
    ocr_text,
    page_texts_text,
    processing_text,
    summarize,
)

PDF = b"%PDF-1.4\n% syntetisk\n%%EOF\n"


@pytest.fixture
def archive(tmp_path):
    paths = AppPaths.resolve(tmp_path / "data")
    paths.ensure()
    database, _ = open_database(paths)
    yield open_archive(database, paths), paths
    database.close()


def make_page(qtbot, controller) -> DocumentsPage:
    page = DocumentsPage(controller)
    qtbot.addWidget(page)
    assert page.wait_until_idle()
    qtbot.waitUntil(lambda: not page._busy)
    return page


def settle(qtbot, page: DocumentsPage) -> None:
    assert page.wait_until_idle()
    qtbot.waitUntil(lambda: not page._busy and page.wait_until_idle(100))


def create_entity(qtbot, page, monkeypatch, name="Syntetisk AS", org="123456785") -> None:
    def fake_exec(dialog):
        dialog.name.setText(name)
        dialog.org_number.setText(org)
        return QDialog.DialogCode.Accepted

    monkeypatch.setattr(EntityDialog, "exec", fake_exec)
    page.create_entity_button.click()
    settle(qtbot, page)


def test_without_an_entity_only_creation_is_possible(qtbot, archive) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)
    assert page.entity_label.text() == t("entity.none")
    assert page.create_entity_button.isVisibleTo(page)
    assert not page.import_button.isEnabled() and not page.inbox_button.isEnabled()


def test_first_entity_then_import_and_classify(qtbot, archive, monkeypatch, tmp_path) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    assert page.entity_label.text() == t("entity.active", name="Syntetisk AS")
    assert not page.create_entity_button.isVisibleTo(page)
    assert page.import_button.isEnabled()

    source = tmp_path / "Faktura &amp; Co.pdf"
    source.write_bytes(PDF)
    monkeypatch.setattr(
        QFileDialog, "getOpenFileNames", lambda *args, **kwargs: ([str(source)], "")
    )
    page.import_button.click()
    settle(qtbot, page)
    assert page.table.rowCount() == 1
    assert page.table.item(0, 0).text() == "Faktura &amp; Co.pdf"  # shown literally
    assert page.table.item(0, 1).text() == t("document.type.unclassified")
    assert page.table.item(0, 2).text() == "PDF"
    assert page.table.item(0, 5).text() == t("document.status.stored")
    assert page.status_label.text() == summarize([ImportResult(ImportOutcome.IMPORTED)])
    assert source.exists()

    page.table.selectRow(0)
    assert page.type_button.isEnabled()
    monkeypatch.setattr(
        QInputDialog,
        "getItem",
        lambda *args, **kwargs: (t("document.type.receipt"), True),
    )
    page.type_button.click()
    settle(qtbot, page)
    assert page.table.item(0, 1).text() == t("document.type.receipt")
    assert controller.list_documents()[0].document_type is DocumentType.RECEIPT


def test_inbox_import_reports_every_outcome(qtbot, archive, monkeypatch) -> None:
    controller, paths = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    (paths.inbox / "a.pdf").write_bytes(PDF)
    (paths.inbox / "b.pdf").write_bytes(b"MZ syntetisk")
    (paths.inbox / "c.pdf").write_bytes(b"")
    page.inbox_button.click()
    settle(qtbot, page)
    assert page.status_label.text() == t(
        "documents.summary", imported=1, duplicate=0, quarantined=1, rejected=1, failed=0
    )
    assert sorted(page.table.item(row, 5).text() for row in range(page.table.rowCount())) == [
        t("document.status.quarantined"),
        t("document.status.stored"),
    ]
    assert sorted(p.name for p in paths.inbox.iterdir()) == ["a.pdf", "b.pdf", "c.pdf"]


def test_invalid_entity_input_shows_a_norwegian_message(qtbot, archive, monkeypatch) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch, name="   ", org="")
    assert page.status_label.text() == t("error.invalid_input")
    assert page.entity_label.text() == t("entity.none")


def test_second_entity_is_refused_and_several_disable_import(qtbot, archive, monkeypatch) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    with pytest.raises(Exception, match="ENTITY_EXISTS"):
        controller.create_entity("Annen AS", None)
    controller._entities.create(name="Annen AS")  # e.g. created by a later version
    page.refresh()
    settle(qtbot, page)
    assert page.entity_label.text() == t("entity.multiple")
    assert not page.import_button.isEnabled()
    assert controller.list_documents() == []
    with pytest.raises(Exception, match="ENTITY_REQUIRED"):
        controller.import_inbox()


def test_unexpected_errors_show_no_details(qtbot, archive, monkeypatch) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)

    def broken():
        raise RuntimeError("C:/Users/x/hemmelig faktura.pdf")

    monkeypatch.setattr(controller, "import_inbox", broken)
    page._run(controller.import_inbox, summarize)
    settle(qtbot, page)
    assert page.status_label.text() == t("error.unexpected")


def test_cancelled_dialogs_change_nothing(qtbot, archive, monkeypatch) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)
    monkeypatch.setattr(EntityDialog, "exec", lambda self: QDialog.DialogCode.Rejected)
    page.create_entity_button.click()
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a, **k: ([], ""))
    page._choose_files()
    page._change_type()  # nothing selected
    assert controller.entity_state().count == 0


@pytest.mark.parametrize(
    ("size", "expected"),
    [(512, "512 B"), (1536, "2 kB"), (1024 * 1024, "1,0 MB"), (52428800, "50,0 MB")],
)
def test_size_is_formatted_without_floats(size, expected) -> None:
    assert format_size(size) == expected


def test_page_keeps_working_after_a_controller_exception(qtbot, monkeypatch) -> None:
    class Failing:
        def entity_state(self):
            raise RuntimeError("synthetic")

        def list_documents(self):
            return []

    page = make_page(qtbot, Failing())
    assert page.status_label.text() == t("error.unexpected")
    assert documents_page.COLUMNS


def test_self_test_with_archive_and_recovery_log(tmp_path, qapp) -> None:
    data = tmp_path / "data"
    assert main(["--self-test", "--data-dir", str(data)]) == 0
    staging = data / "documents" / ("0" * 32) / "staging"
    staging.mkdir(parents=True)
    (staging / "x.part").write_bytes(b"rest")
    # No entity owns this directory, so recovery leaves it alone and logs nothing.
    assert main(["--self-test", "--data-dir", str(data)]) == 0
    events = [
        json.loads(line)["event"]
        for line in (data / "logs/invoiceflow.log").read_text(encoding="utf-8").splitlines()
    ]
    assert "documents.recovered" not in events
    assert (staging / "x.part").exists()


def test_startup_recovery_is_logged_without_names(tmp_path, qapp, monkeypatch) -> None:
    paths = AppPaths.resolve(tmp_path / "data")
    paths.ensure()
    database, _ = open_database(paths)
    controller = open_archive(database, paths)
    controller.create_entity("Syntetisk AS", None)
    entity = controller._entities.list()[0].entity_id
    staging = paths.documents / entity.hex / "staging"
    staging.mkdir(parents=True)
    (staging / "krasj.part").write_bytes(b"rest")
    database.close()

    assert main(["--self-test", "--data-dir", str(paths.data)]) == 0

    rows = [
        json.loads(line)
        for line in (paths.logs / "invoiceflow.log").read_text(encoding="utf-8").splitlines()
    ]
    recovered = [row for row in rows if row["event"] == "documents.recovered"]
    assert recovered == [{**recovered[0], "code": "staging_1_orphans_0_missing_0_failed_0"}]
    assert "krasj" not in json.dumps(rows)
    assert not (staging / "krasj.part").exists()


def test_tasks_run_off_the_gui_thread(qtbot, archive) -> None:
    import threading

    controller, _ = archive
    threads = []

    class Recording:
        def entity_state(self):
            threads.append(threading.current_thread())
            return controller.entity_state()

        def list_documents(self):
            return controller.list_documents()

        def latest_jobs(self):
            return controller.latest_jobs()

        def invoice_summaries(self):
            return controller.invoice_summaries()

        def latest_ocr_jobs(self):
            return controller.latest_ocr_jobs()

        def ocr_available(self):
            return controller.ocr_available()

    make_page(qtbot, Recording())
    assert threads and threads[0] is not threading.main_thread()


def test_entity_dialog_values_strip_the_mask(qtbot) -> None:
    dialog = EntityDialog()
    qtbot.addWidget(dialog)
    dialog.name.setText("  Syntetisk AS ")
    assert dialog.values() == ("Syntetisk AS", None)
    dialog.org_number.setText("123456785")
    assert dialog.values() == ("Syntetisk AS", "123456785")


def test_main_window_uses_the_documents_page(qtbot, archive) -> None:
    from invoiceflow import __version__
    from invoiceflow.ui.main_window import MainWindow

    controller, _ = archive
    window = MainWindow(__version__, "synthetic", archive=controller)
    qtbot.addWidget(window)
    assert window.documents_page is not None
    assert window.pages.widget(1) is window.documents_page
    window.documents_page.wait_until_idle()
    window.close()


def test_documents_path_properties(tmp_path) -> None:
    paths = AppPaths.resolve(tmp_path)
    assert (paths.documents, paths.inbox) == (tmp_path / "documents", tmp_path / "inbox")
    assert isinstance(paths.documents, Path)


def test_results_are_handled_on_the_gui_thread(qtbot, archive, monkeypatch) -> None:
    import threading

    controller, _ = archive
    page = make_page(qtbot, controller)
    seen = []
    original = DocumentsPage._show

    def recording_show(self, *shown):
        seen.append(threading.current_thread())
        original(self, *shown)

    monkeypatch.setattr(DocumentsPage, "_show", recording_show)
    page.refresh()
    settle(qtbot, page)
    assert seen and all(thread is threading.main_thread() for thread in seen)


def test_summary_counts_failed_imports() -> None:
    results = [ImportResult(ImportOutcome.IMPORTED), ImportResult(ImportOutcome.FAILED)]
    assert summarize(results) == t(
        "documents.summary", imported=1, duplicate=0, quarantined=0, rejected=0, failed=1
    )


def test_a_failed_file_in_a_selection_does_not_stop_the_rest(
    qtbot, archive, monkeypatch, tmp_path
) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    sources = []
    for index in range(3):
        path = tmp_path / f"{index}.pdf"
        path.write_bytes(PDF + str(index).encode())
        sources.append(path)
    real_publish = controller._documents._store.publish

    def publish(staged, entity_id, sha256, extension):
        if staged.sha256 == hashlib.sha256(sources[1].read_bytes()).hexdigest():
            raise StorageError("synthetic locked archive folder")
        return real_publish(staged, entity_id, sha256, extension)

    monkeypatch.setattr(controller._documents._store, "publish", publish)
    monkeypatch.setattr(
        QFileDialog, "getOpenFileNames", lambda *a, **k: ([str(p) for p in sources], "")
    )
    page.import_button.click()
    settle(qtbot, page)
    assert page.status_label.text() == t(
        "documents.summary", imported=2, duplicate=0, quarantined=0, rejected=0, failed=1
    )
    assert page.table.rowCount() == 2


def test_a_stop_request_keeps_new_imports_from_starting(qtbot, archive, monkeypatch) -> None:
    controller, paths = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    (paths.inbox / "a.pdf").write_bytes(PDF)
    controller.request_stop()
    assert controller.import_inbox() == []
    assert controller.list_documents() == []
    assert (paths.inbox / "a.pdf").exists()


def test_shutdown_asks_the_controller_to_stop_and_waits(qtbot) -> None:
    class Stoppable:
        stopped = False

        def entity_state(self):
            return EntityState(None, 0)

        def list_documents(self):
            return []

        def latest_jobs(self):
            return {}

        def invoice_summaries(self):
            return {}

        def latest_ocr_jobs(self):
            return {}

        def ocr_available(self):
            return True

        def request_stop(self):
            self.stopped = True

    controller = Stoppable()
    page = make_page(qtbot, controller)
    assert page.shutdown() is True
    assert controller.stopped


def test_a_slow_shutdown_is_logged_without_details(tmp_path, qapp, monkeypatch) -> None:
    monkeypatch.setattr(DocumentsPage, "shutdown", lambda self, timeout_ms=10_000: False)
    data = tmp_path / "data"
    assert main(["--self-test", "--data-dir", str(data)]) == 0
    events = [
        json.loads(line)["event"]
        for line in (data / "logs/invoiceflow.log").read_text(encoding="utf-8").splitlines()
    ]
    assert "documents.shutdown_timeout" in events


def test_a_stop_request_during_a_file_finishes_that_file_only(qtbot, archive, monkeypatch) -> None:
    controller, paths = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    for index in range(3):
        (paths.inbox / f"{index}.pdf").write_bytes(PDF + str(index).encode())
    store = controller._documents._store
    real_publish = store.publish

    def publish_then_ask_to_stop(*args):
        stored = real_publish(*args)
        controller.request_stop()  # arrives while the first file is being stored
        return stored

    monkeypatch.setattr(store, "publish", publish_then_ask_to_stop)
    results = controller.import_inbox()
    assert [r.outcome for r in results] == [ImportOutcome.IMPORTED]
    documents = controller.list_documents()
    assert len(documents) == 1  # the file in progress was completed, not cut in half
    assert not list(paths.documents.rglob("*.part"))


# -- Phase 04: isolated page analysis -------------------------------------------


def import_pdfs(qtbot, page, monkeypatch, tmp_path, files: dict[str, bytes]) -> None:
    sources = []
    for name, data in files.items():
        source = tmp_path / name
        source.write_bytes(data)
        sources.append(str(source))
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a, **k: (sources, ""))
    page.import_button.click()
    settle(qtbot, page)


def row_of(page, name: str) -> int:
    return next(
        row for row in range(page.table.rowCount()) if page.table.item(row, 0).text() == name
    )


def test_processing_shows_pages_and_norwegian_status(qtbot, archive, monkeypatch, tmp_path) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    import_pdfs(
        qtbot,
        page,
        monkeypatch,
        tmp_path,
        {"god.pdf": text_pdf(["en", "to"]), "laast.pdf": hostile_corpus.pdf_encrypted()},
    )
    good, locked = row_of(page, "god.pdf"), row_of(page, "laast.pdf")
    assert page.table.item(good, 6).text() == ""
    assert page.table.item(good, 7).text() == t("processing.status.none")
    assert page.process_pending_button.isEnabled()

    page.process_pending_button.click()
    settle(qtbot, page)
    assert page.status_label.text() == t(
        "processing.summary", succeeded=1, failed=1, timed_out=0, cancelled=0
    )
    good, locked = row_of(page, "god.pdf"), row_of(page, "laast.pdf")
    assert page.table.item(good, 6).text() == "2"
    assert page.table.item(good, 7).text() == t("processing.status.succeeded")
    assert page.table.item(locked, 7).text() == t(
        "processing.status.rejected", reason=t("processing.error.encrypted")
    )

    page.table.selectRow(locked)
    assert page.process_selected_button.isEnabled()
    page.process_selected_button.click()
    settle(qtbot, page)
    assert page.status_label.text() == t(
        "processing.summary", succeeded=0, failed=1, timed_out=0, cancelled=0
    )


def test_quarantined_documents_cannot_be_processed(qtbot, archive, monkeypatch, tmp_path) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    import_pdfs(qtbot, page, monkeypatch, tmp_path, {"forkledd.pdf": b"MZ syntetisk"})
    assert page.table.item(0, 7).text() == ""
    page.table.selectRow(0)
    assert not page.process_selected_button.isEnabled()


@pytest.mark.parametrize(
    ("job", "expected"),
    [
        (None, t("processing.status.none")),
        (
            {"status": JobStatus.SUCCEEDED, "page_count": 1, "active_content": True},
            t("processing.status.succeeded_active"),
        ),
        (
            {"status": JobStatus.FAILED, "error_code": ProcessingErrorCode.WORKER_CRASHED},
            t("processing.status.failed", reason=t("processing.error.worker_crashed")),
        ),
        (
            {"status": JobStatus.TIMED_OUT, "error_code": ProcessingErrorCode.TIMED_OUT},
            t("processing.status.timed_out"),
        ),
        (
            {"status": JobStatus.CANCELLED, "error_code": ProcessingErrorCode.CANCELLED},
            t("processing.status.cancelled"),
        ),
        ({"status": JobStatus.RUNNING}, t("processing.status.running")),
    ],
)
def test_processing_text_for_every_state(job, expected) -> None:
    record = None
    if job is not None:
        record = JobRecord(
            uuid4(),
            uuid4(),
            uuid4(),
            ProcessingStep.PAGE_ANALYSIS,
            "a" * 64,
            1,
            engine="pypdfium2",
            engine_version="5.13.0",
            settings_hash="b" * 64,
            queued_at=dt.datetime(2026, 10, 23, tzinfo=dt.UTC),
            **job,
        )
    assert processing_text(record) == expected


def test_every_error_code_has_a_norwegian_reason() -> None:
    for code in ProcessingErrorCode:
        assert t(f"processing.error.{code}") != f"processing.error.{code}"


def test_ehf_rows_show_invoice_and_findings(qtbot, archive, monkeypatch, tmp_path) -> None:
    from invoiceflow.bootstrap.synthetic_ehf import SyntheticEhf, build_ehf

    controller, _ = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    import_pdfs(
        qtbot,
        page,
        monkeypatch,
        tmp_path,
        {"ehf.xml": build_ehf(SyntheticEhf(payable_override="99.00"))},
    )
    assert page.table.item(0, 2).text() == t("documents.format.ehf")
    page.process_pending_button.click()
    settle(qtbot, page)
    assert page.table.item(0, 7).text() == t("processing.status.succeeded")
    invoice = documents_page.COLUMNS.index("documents.col.invoice")
    findings = documents_page.COLUMNS.index("documents.col.findings")
    assert page.table.item(0, invoice).text() == (
        "Syntetisk Leverandør AS · EHF-2026-001 · 99,00 NOK"
    )
    # The entity has organisation number 123456785; the invoice is to another.
    assert page.table.item(0, findings).text() == "; ".join(
        t(f"finding.{code}") for code in ("payable_mismatch", "wrong_recipient")
    )


# -- Phase 05: OCR -----------------------------------------------------------------

TEXT_COLUMN = COLUMNS.index("documents.col.text")


def ocr_job(status: JobStatus, **fields) -> JobRecord:
    return JobRecord(
        uuid4(),
        uuid4(),
        uuid4(),
        ProcessingStep.OCR,
        "a" * 64,
        1,
        status,
        engine="tesseract",
        engine_version="5.3.4+ocr1+0451eb4f",
        settings_hash="b" * 64,
        queued_at=dt.datetime(2026, 10, 24, tzinfo=dt.UTC),
        **fields,
    )


def test_the_text_column_names_the_ocr_outcome() -> None:
    assert ocr_text(None) == ""
    assert ocr_text(ocr_job(JobStatus.SUCCEEDED, page_count=2)) == t("documents.text.ocr", count=2)
    failed = ocr_job(JobStatus.FAILED, error_code=ProcessingErrorCode.OCR_FAILED)
    assert ocr_text(failed) == t(
        "documents.text.ocr_failed", reason=t("processing.error.ocr_failed")
    )
    timed_out = ocr_job(JobStatus.TIMED_OUT, error_code=ProcessingErrorCode.TIMED_OUT)
    assert t("processing.status.timed_out") in ocr_text(timed_out)


def test_page_texts_say_where_each_text_comes_from() -> None:
    text = page_texts_text(
        [
            PageText(1, TextSource.TEXT_LAYER, "Faktura 1"),
            PageText(2, TextSource.OCR, "Å betale", 93),
            PageText(3, TextSource.NONE, ""),
            PageText(4, TextSource.OCR, None, 70),
        ]
    )
    assert text.split("\n\n") == [
        t("text.page.text_layer", page=1) + "\nFaktura 1",
        t("text.page.ocr", page=2, confidence=93) + "\nÅ betale",
        t("text.page.none", page=3),
        t("text.page.ocr", page=4, confidence=70) + "\n" + t("text.page.unreadable"),
    ]
    assert page_texts_text([]) == t("text.dialog.none")


def test_without_tesseract_the_page_says_so(qtbot, archive, monkeypatch) -> None:
    controller, _ = archive
    monkeypatch.setattr(controller, "ocr_available", lambda: False)
    page = make_page(qtbot, controller)
    assert page.ocr_label.isVisibleTo(page)
    assert page.ocr_label.text() == t("documents.ocr_missing")


@pytest.mark.tesseract
def test_a_scanned_page_is_recognised_and_its_text_shown(
    qtbot,
    archive,
    monkeypatch,
    tmp_path,
) -> None:
    controller, _ = archive
    page = make_page(qtbot, controller)
    create_entity(qtbot, page, monkeypatch)
    assert not page.ocr_label.isVisibleTo(page)
    scan = encode(render(("Faktura 2026-0417", "Å betale NOK 1 234,50"), font_size=14))
    import_pdfs(qtbot, page, monkeypatch, tmp_path, {"skann.png": scan})
    assert not page.show_text_button.isEnabled()  # not analysed yet

    page.process_pending_button.click()
    settle(qtbot, page)

    assert page.table.item(0, TEXT_COLUMN).text() == t("documents.text.ocr", count=1)
    page.table.selectRow(0)
    assert page.show_text_button.isEnabled()
    page.show_text_button.click()
    settle(qtbot, page)
    assert page.text_dialog is not None
    shown = page.text_dialog.findChild(QPlainTextEdit).toPlainText()
    heading = t("text.page.ocr", page=1, confidence=0).split(",")[0]
    assert shown.splitlines()[0].startswith(heading)
    assert "Faktura 2026-0417\nÅ betale NOK 1 234,50" in shown
    page.text_dialog.close()
