"""Reference data page, posting suggestion in the inbox (Phase 08b, offscreen Qt)."""

import time
from uuid import uuid4

import pytest
from PySide6.QtCore import QCoreApplication
from PySide6.QtWidgets import QFileDialog

from invoiceflow.application.reference.model import (
    ImportRecord,
    ReferenceData,
    ReferenceKind,
)
from invoiceflow.bootstrap.persistence import open_archive, open_database
from invoiceflow.bootstrap.synthetic_ehf import CUSTOMER_ORG, build_ehf
from invoiceflow.bootstrap.synthetic_reference import CHART_CSV, DIMENSIONS_CSV, VAT_CODES_CSV
from invoiceflow.config.paths import AppPaths
from invoiceflow.i18n import t
from invoiceflow.ui.documents_page import DocumentsPage, posting_details
from invoiceflow.ui.reference_page import ReferencePage, status_values
from invoiceflow.ui.suppliers_page import DefaultsDialog, SuppliersPage

NBSP = "\N{NO-BREAK SPACE}"


@pytest.fixture
def archive(tmp_path):
    paths = AppPaths.resolve(tmp_path / "data")
    paths.ensure()
    database, _ = open_database(paths)
    controller = open_archive(database, paths)
    controller.create_entity("Syntetisk Mottaker AS", CUSTOMER_ORG)
    yield controller
    database.close()


def settle(page) -> None:
    """Wait for the page's own work; events are processed explicitly (see test_shell)."""
    deadline = time.monotonic() + 60
    while (page._busy or page._tasks) and time.monotonic() < deadline:
        page.wait_until_idle(100)
        QCoreApplication.processEvents()
    assert not page._busy and not page._tasks


def test_reference_files_are_imported_and_listed(qtbot, archive, tmp_path, monkeypatch) -> None:
    page = ReferencePage(archive)
    qtbot.addWidget(page)
    settle(page)
    assert [page.table.item(row, 2).text() for row in range(3)] == [t("reference.none")] * 3
    source = tmp_path / "kontoplan.csv"
    source.write_text(CHART_CSV, encoding="utf-8")
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(source), ""))
    page.import_buttons[ReferenceKind.CHART].click()
    settle(page)
    assert page.status_label.text() == t(
        "reference.imported", kind=t("reference.kind.chart"), count=5
    )
    assert page.table.item(0, 1).text() == "5"

    broken = tmp_path / "mva.csv"
    broken.write_text("kode;sats;retning;gyldig_fra\n1;25;inngående;31.02.2026\n", "utf-8")
    page.import_file(ReferenceKind.VAT_CODES, broken)
    settle(page)
    assert page.status_label.text() == t(
        "reference.error.invalid_date", line=2, column="gyldig_fra"
    )
    assert page.table.item(1, 2).text() == t("reference.none")


def test_cancelled_file_choice_imports_nothing(qtbot, archive, monkeypatch) -> None:
    page = ReferencePage(archive)
    qtbot.addWidget(page)
    settle(page)
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: ("", ""))
    page.import_buttons[ReferenceKind.DIMENSIONS].click()
    settle(page)
    assert archive.reference_status() == {}


def import_all(archive, tmp_path) -> None:
    for kind, text in (
        (ReferenceKind.CHART, CHART_CSV),
        (ReferenceKind.VAT_CODES, VAT_CODES_CSV),
        (ReferenceKind.DIMENSIONS, DIMENSIONS_CSV),
    ):
        source = tmp_path / f"{kind}.csv"
        source.write_text(text, encoding="utf-8")
        archive.import_reference(kind, source)


def test_posting_is_shown_and_suggested_again(qtbot, archive, tmp_path, monkeypatch) -> None:
    import_all(archive, tmp_path)
    inbox = DocumentsPage(archive)
    qtbot.addWidget(inbox)
    settle(inbox)
    source = tmp_path / "faktura.xml"
    source.write_bytes(build_ehf())
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a, **k: ([str(source)], ""))
    inbox.import_button.click()
    settle(inbox)
    inbox.process_pending_button.click()
    settle(inbox)
    inbox.table.selectRow(0)
    inbox.show_validation_button.click()
    settle(inbox)
    texts = [
        label.text() for label in inbox.validation_dialog.findChildren(type(inbox.status_label))
    ]
    assert any(f"Linje 1: konto mangler · MVA-kode 1 · 10{NBSP}500,00" in text for text in texts)
    inbox.validation_dialog.close()

    suppliers = SuppliersPage(archive)
    qtbot.addWidget(suppliers)
    settle(suppliers)
    suppliers.table.selectRow(0)

    def choose(dialog: DefaultsDialog) -> bool:
        assert dialog.dimensions  # the imported dimensions are offered
        dialog.account.setCurrentIndex(dialog.account.findData("6800"))
        department = dialog.dimensions[next(iter(dialog.dimensions))]
        department.setCurrentIndex(1)
        return True

    suppliers.edit_defaults = choose
    suppliers.defaults_button.click()
    settle(suppliers)
    assert suppliers.status_label.text() == t("defaults.saved")
    (line,) = archive.posting(
        archive.invoice_summaries()[archive.list_documents()[0].document_id].invoice_id
    )
    assert (line.account.value, line.vat_code.value) == ("6800", "1")

    inbox.refresh()
    settle(inbox)
    inbox.table.selectRow(0)
    assert inbox.resuggest_button.isEnabled()
    inbox.resuggest_button.click()
    settle(inbox)
    assert inbox.status_label.text() == t("posting.resuggested")


def test_defaults_need_reference_data(qtbot, archive, tmp_path, monkeypatch) -> None:
    inbox = DocumentsPage(archive)
    qtbot.addWidget(inbox)
    settle(inbox)
    source = tmp_path / "faktura.xml"
    source.write_bytes(build_ehf())
    monkeypatch.setattr(QFileDialog, "getOpenFileNames", lambda *a, **k: ([str(source)], ""))
    inbox.import_button.click()
    settle(inbox)
    inbox.process_pending_button.click()
    settle(inbox)
    suppliers = SuppliersPage(archive)
    qtbot.addWidget(suppliers)
    settle(suppliers)
    suppliers.table.selectRow(0)
    suppliers.edit_defaults = lambda dialog: pytest.fail("no dialog without reference data")
    suppliers.defaults_button.click()
    settle(suppliers)
    assert suppliers.status_label.text() == t("defaults.no_reference")


def test_status_values_and_empty_posting() -> None:
    import datetime as dt

    record = ImportRecord(
        uuid4(),
        ReferenceKind.CHART,
        "0" * 64,
        7,
        dt.datetime(2026, 10, 1, 10, tzinfo=dt.UTC),
        "user/local",
    )
    assert status_values(ReferenceKind.CHART, record) == ("Kontoplan", "7", "01.10.2026")
    assert posting_details(()) == t("posting.none")
    assert ReferenceData().accounts is None
