"""The review page with a real archive behind it (Phase 09, offscreen Qt)."""

import pytest
from gui_steps import prepared, reference_archive, settle

from invoiceflow.i18n import t
from invoiceflow.ui.review_page import ReviewPage, field_rows, value_text

STATUS_COLUMN = 3


@pytest.fixture
def archive(tmp_path):
    with reference_archive(tmp_path) as controller:
        yield controller


def open_page(qtbot, archive) -> ReviewPage:
    page = ReviewPage(archive)
    qtbot.addWidget(page)
    settle(page)
    page.invoice_table.selectRow(0)
    settle(page)
    return page


def field_row(page: ReviewPage, path: str) -> int:
    return next(i for i, row in enumerate(page._rows) if row.path == path)


def test_details_preview_and_approval(qtbot, archive, tmp_path, monkeypatch) -> None:
    prepared(qtbot, archive, tmp_path, monkeypatch)
    page = open_page(qtbot, archive)
    assert page.invoice_table.item(0, 0).text() == "Syntetisk Leverandør AS"
    assert page.invoice_table.item(0, STATUS_COLUMN).text() == t("review.status.draft")
    number = field_row(page, "invoice_number")
    assert page.field_table.item(number, 1).text() == "EHF-2026-001"
    assert page.field_table.item(number, 2).text() == t("review.source.extracted")
    posting = field_row(page, "accounting_lines.1.account")
    assert page.field_table.item(posting, 1).text() == "6300"
    assert page.preview_label.pixmap() is not None and not page.preview_label.pixmap().isNull()
    assert page.finding_table.rowCount() == 0
    assert all("&" in b.text() for b in (page.approve_button, page.reject_button, page.edit_button))

    page.approve_button.click()
    settle(page)
    assert page.status_label.text() == t("review.approved")
    settle(page)
    assert page.invoice_table.item(0, STATUS_COLUMN).text() == t("review.status.approved")
    assert not page.approve_button.isEnabled() and page.revoke_button.isEnabled()
    assert t("review.history.approved", date="", revision="").split(" ")[0] in (
        page.history_label.text()
    )

    page.revoke_button.click()
    settle(page)
    settle(page)
    assert page.invoice_table.item(0, STATUS_COLUMN).text() == t("review.status.draft")


def test_an_edit_creates_a_revision_and_is_shown_as_manual(qtbot, archive, tmp_path, monkeypatch):
    prepared(qtbot, archive, tmp_path, monkeypatch)
    page = open_page(qtbot, archive)
    page.field_table.selectRow(field_row(page, "due_date"))
    assert page.edit_button.isEnabled()
    page.ask_text = lambda title, label, initial: "01.09.2026"
    page.edit_button.click()
    settle(page)
    settle(page)
    assert page.status_label.text() == t("review.edited")
    row = field_row(page, "due_date")
    assert page.field_table.item(row, 1).text() == "01.09.2026"
    assert page.field_table.item(row, 2).text().startswith(t("review.source.manual"))
    texts = [page.finding_table.item(i, 0).text() for i in range(page.finding_table.rowCount())]
    assert any("DAT-001" in text for text in texts)

    # The new error blocks approval until it is overridden with a reason.
    page.approve_button.click()
    settle(page)
    assert page.status_label.text() == t("review.error.open_errors", count=1)
    page.finding_table.selectRow(0)
    assert page.override_button.isEnabled()
    page.ask_text = lambda title, label, initial: "Avtalt kortere frist med leverandøren"
    page.override_button.click()
    settle(page)
    settle(page)
    assert page.finding_table.item(0, 1).text() == t("review.finding.overridden")
    page.approve_button.click()
    settle(page)
    settle(page)
    assert page.invoice_table.item(0, STATUS_COLUMN).text() == t("review.status.approved")


def test_a_bank_finding_blocks_and_cannot_be_overridden(qtbot, archive, tmp_path, monkeypatch):
    prepared(qtbot, archive, tmp_path, monkeypatch, verify=False)
    page = open_page(qtbot, archive)
    texts = [page.finding_table.item(i, 0).text() for i in range(page.finding_table.rowCount())]
    bank = next(i for i, text in enumerate(texts) if "BANK-001" in text)
    page.finding_table.selectRow(bank)
    assert page.finding_table.item(bank, 1).text() == t("review.finding.blocking")
    assert not page.override_button.isEnabled()
    page.approve_button.click()
    settle(page)
    assert page.status_label.text() == t("review.error.blocked", rule="BANK-001")


def test_rejecting_needs_a_comment_and_cancel_does_nothing(qtbot, archive, tmp_path, monkeypatch):
    prepared(qtbot, archive, tmp_path, monkeypatch)
    page = open_page(qtbot, archive)
    page.ask_text = lambda title, label, initial: None
    page.reject_button.click()
    settle(page)
    assert page.invoice_table.item(0, STATUS_COLUMN).text() == t("review.status.draft")
    page.ask_text = lambda title, label, initial: "Ikke bestilt"
    page.reject_button.click()
    settle(page)
    settle(page)
    assert page.invoice_table.item(0, STATUS_COLUMN).text() == t("review.status.rejected")


def test_a_source_box_is_marked_on_the_preview(qtbot, archive, tmp_path, monkeypatch) -> None:
    prepared(qtbot, archive, tmp_path, monkeypatch)
    page = open_page(qtbot, archive)
    before = page.preview_label.pixmap().toImage()
    page._draw_preview((0.1, 0.1, 0.5, 0.2))
    after = page.preview_label.pixmap().toImage()
    assert before != after
    page._draw_preview(None)
    assert page.preview_label.pixmap().toImage() == before


def test_without_invoices_or_preview(qtbot, archive) -> None:
    page = ReviewPage(archive)
    qtbot.addWidget(page)
    settle(page)
    assert page.status_label.text() == t("review.none")
    assert not page.approve_button.isEnabled()
    page._preview = None
    page._draw_preview(None)
    assert page.preview_label.text() == t("review.no_preview")


def test_values_are_plain_text_and_formatted() -> None:
    import datetime as dt
    from decimal import Decimal

    from plain_invoice import make

    assert value_text(Decimal("10500.00")) == "10\N{NO-BREAK SPACE}500,00"
    assert value_text(dt.date(2026, 10, 1)) == "01.10.2026"
    assert value_text(True) == t("review.yes") and value_text(None) == ""
    rows = {row.path: row for row in field_rows(make())}
    assert rows["supplier.name"].value == "Syntetisk Leverandør AS"
    assert rows["payment.iban"].value == ""
