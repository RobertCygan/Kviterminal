"""The backup page with a real archive behind it (Phase 12, offscreen Qt)."""

import pytest
from gui_steps import reference_archive, settle

from invoiceflow.i18n import t
from invoiceflow.ui.backup_page import BackupPage

PASSPHRASE = "Syntetisk passordfrase 42"  # noqa: S105 - synthetic test value
STATUS_COLUMN = 4


@pytest.fixture
def archive(tmp_path):
    with reference_archive(tmp_path) as controller:
        controller._backups._scrypt_n = 2**10  # fast key derivation in tests
        yield controller


def open_page(qtbot, archive) -> BackupPage:
    page = BackupPage(archive)
    qtbot.addWidget(page)
    settle(page)
    return page


def answers(*values):
    remaining = list(values)
    return lambda *_: remaining.pop(0)


def test_create_verify_restore_and_delete(qtbot, archive, tmp_path_factory) -> None:
    page = open_page(qtbot, archive)
    assert page.table.rowCount() == 0
    assert all("&" in b.text() for b in (page.create_button, page.restore_button))
    disk = tmp_path_factory.mktemp("disk")

    page.choose_folder = answers(str(disk))
    page.ask_passphrase = answers(PASSPHRASE, "Annen passordfrase 42")
    page.create_button.click()
    settle(page)
    assert page.status_label.text() == t("backup.error.mismatch")

    page.choose_folder = answers(str(disk))
    page.ask_passphrase = answers(PASSPHRASE, PASSPHRASE)
    page.create_button.click()
    settle(page)
    settle(page)
    (backup,) = disk.iterdir()
    assert page.status_label.text().startswith(t("backup.created", file=backup.name, count=0)[:30])
    assert page.table.rowCount() == 1
    assert page.table.item(0, STATUS_COLUMN).text() == t("backup.status.made")

    page.choose_file = answers(str(backup))
    page.ask_passphrase = answers(PASSPHRASE)
    page.verify_button.click()
    settle(page)
    settle(page)
    assert t("backup.known") in page.status_label.text()

    target = tmp_path_factory.mktemp("ny") / "data"
    page.choose_file = answers(str(backup))
    page.choose_folder = answers(str(target))
    page.ask_passphrase = answers(PASSPHRASE)
    page.restore_button.click()
    settle(page)
    settle(page)
    assert str(target) in page.status_label.text()
    assert (target / "database" / "invoiceflow.sqlite3").exists()

    page.choose_file = answers(str(backup))
    page.confirm = lambda text: False
    page.delete_button.click()
    settle(page)
    assert backup.exists()
    page.choose_file = answers(str(backup))
    page.confirm = lambda text: True
    page.delete_button.click()
    settle(page)
    settle(page)
    assert not backup.exists()
    assert page.status_label.text() == t("backup.deleted")
    assert page.table.item(0, STATUS_COLUMN).text().startswith("Slettet")


def test_cancelled_dialogs_do_nothing(qtbot, archive) -> None:
    page = open_page(qtbot, archive)
    page.choose_folder = answers(None)
    page.choose_file = answers(None, None, None)
    for button in (page.create_button, page.verify_button, page.restore_button):
        button.click()
    page.choose_file = answers("x.ifbak")
    page.ask_passphrase = answers(None)
    page.verify_button.click()
    settle(page)
    assert page.status_label.text() == ""
    assert page.table.rowCount() == 0
