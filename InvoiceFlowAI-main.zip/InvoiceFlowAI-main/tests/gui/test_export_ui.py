"""The export page with a real archive and export folder behind it (Phase 10, offscreen Qt)."""

import pytest
from gui_steps import prepared, reference_archive, settle
from PySide6.QtCore import Qt

from invoiceflow.application.export.model import (
    STANDARD_FIELDS,
    STANDARD_MAPPING,
    ExportColumn,
    ExportField,
    ExportTarget,
)
from invoiceflow.i18n import t
from invoiceflow.ui.export_page import ColumnsDialog, ExportPage, column_text
from invoiceflow.ui.main_window import MainWindow

REASON = "Filen ble slettet før import i regnskapet"
STATUS_COLUMN, KIND_COLUMN = 4, 5


@pytest.fixture
def archive(tmp_path):
    with reference_archive(tmp_path) as controller:
        yield controller


def approved(qtbot, archive, tmp_path, monkeypatch) -> None:
    prepared(qtbot, archive, tmp_path, monkeypatch)
    (summary,) = archive.invoice_summaries().values()
    revision = archive.review_view(summary.invoice_id).record.revision
    archive.approve(summary.invoice_id, revision, None)


def open_page(qtbot, archive) -> ExportPage:
    page = ExportPage(archive)
    qtbot.addWidget(page)
    settle(page)
    return page


def test_export_copy_and_reexport(qtbot, archive, tmp_path, monkeypatch) -> None:
    approved(qtbot, archive, tmp_path, monkeypatch)
    page = open_page(qtbot, archive)
    assert page.ready_label.text() == t("export.ready", count=1)
    assert page.ready_table.item(0, 0).text() == "Syntetisk Leverandør AS"
    assert page.export_button.isEnabled() and not page.copy_button.isEnabled()
    assert all("&" in b.text() for b in (page.export_button, page.copy_button))

    page.format_combo.setCurrentIndex(page.format_combo.findData(ExportTarget.CSV))
    page.export_button.click()
    settle(page)
    settle(page)
    assert page.status_label.text().startswith(t("export.done", count=1, file="")[:12])
    assert page.ready_label.text() == t("export.ready", count=0)
    assert not page.export_button.isEnabled()
    assert page.batch_table.rowCount() == 1
    assert page.batch_table.item(0, STATUS_COLUMN).text() == t("export.status.written")

    page.batch_table.selectRow(0)
    assert page.copy_button.isEnabled() and page.reexport_button.isEnabled()
    target = tmp_path / "kopi.csv"
    page.choose_file = lambda name, file_filter: str(target)
    page.copy_button.click()
    settle(page)
    assert page.status_label.text() == t("export.copied")
    assert target.read_bytes().startswith(b"\xef\xbb\xbf")

    page.ask_text = lambda title, label, initial: None
    page.reexport_button.click()
    settle(page)
    assert page.batch_table.rowCount() == 1
    page.ask_text = lambda title, label, initial: "kort"
    page.reexport_button.click()
    settle(page)
    settle(page)
    assert page.status_label.text() == t("export.error.reason")
    page.batch_table.selectRow(0)
    page.ask_text = lambda title, label, initial: REASON
    page.reexport_button.click()
    settle(page)
    settle(page)
    assert page.batch_table.rowCount() == 2
    assert page.batch_table.item(0, KIND_COLUMN).text() == t("export.kind.reexport")


def test_columns_are_saved_as_a_new_version(qtbot, archive) -> None:
    page = open_page(qtbot, archive)
    assert not page.export_button.isEnabled() and page.columns_button.isEnabled()
    page.edit_columns = lambda mapping: [ExportColumn(ExportField.INVOICE_NUMBER, "Bilag")]
    page.columns_button.click()
    settle(page)
    settle(page)
    assert page.status_label.text() == t("export.mapping.saved", version=1)
    assert archive.export_mapping().columns == (ExportColumn(ExportField.INVOICE_NUMBER, "Bilag"),)
    page.edit_columns = lambda mapping: None
    page.columns_button.click()
    settle(page)
    assert archive.export_mapping().version == 1


def test_the_columns_dialog_orders_renames_and_unchecks(qtbot) -> None:
    answers = iter(["Leverandørnavn", ""])
    dialog = ColumnsDialog(STANDARD_MAPPING, lambda title, label, initial: next(answers))
    qtbot.addWidget(dialog)
    assert [c.field for c in dialog.columns()] == list(STANDARD_FIELDS)
    assert dialog.list.count() == len(ExportField)
    dialog.list.setCurrentRow(1)
    dialog.up_button.click()
    dialog.list.setCurrentRow(0)
    dialog.rename_button.click()
    dialog.list.item(2).setCheckState(Qt.CheckState.Unchecked)
    columns = dialog.columns()
    assert columns[0] == ExportColumn(ExportField.SUPPLIER_ORG_NUMBER, "Leverandørnavn")
    assert columns[1] == ExportColumn(ExportField.SUPPLIER_NAME)
    assert ExportField.INVOICE_TYPE not in [c.field for c in columns]
    assert dialog.list.item(0).text() == column_text(columns[0])
    dialog.rename_button.click()  # an empty answer restores the standard header
    assert dialog.columns()[0] == ExportColumn(ExportField.SUPPLIER_ORG_NUMBER)
    dialog.list.setCurrentRow(0)
    dialog.up_button.click()  # already first: nothing moves
    dialog.reset_button.click()
    assert [c.field for c in dialog.columns()] == list(STANDARD_FIELDS)


def test_the_main_window_shows_the_export_page(qtbot, archive) -> None:
    window = MainWindow("0", "data", False, archive, archive, archive, archive, archive)
    qtbot.addWidget(window)
    assert window.export_page is not None
    settle(window.export_page)
    if window.review_page is not None:
        settle(window.review_page)
    for page in (window.documents_page, window.suppliers_page, window.reference_page):
        if page is not None:
            page.wait_until_idle(5000)


def test_shortcuts_are_unique(qtbot, archive) -> None:
    page = open_page(qtbot, archive)
    texts = [
        t("export.format"),
        *(
            b.text()
            for b in (
                page.export_button,
                page.columns_button,
                page.copy_button,
                page.reexport_button,
                page.refresh_button,
            )
        ),
    ]
    keys = [text[text.index("&") + 1].lower() for text in texts]
    assert len(set(keys)) == len(keys), keys
