"""The scan page with a real archive behind it (Phase 11a, offscreen Qt)."""

from pathlib import Path

import pytest
from gui_steps import reference_archive, settle
from PySide6.QtGui import QGuiApplication

from invoiceflow.bootstrap.synthetic_pdf import batch_pdf
from invoiceflow.i18n import t
from invoiceflow.ui.scan_page import PAGE_COLUMNS, POLL_MILLISECONDS, ScanPage, thresholds_text

PARTS_COLUMN, BLANK_COLUMN, SEPARATOR_COLUMN, NEAR_COLUMN = 2, 3, 4, 5


@pytest.fixture
def archive(tmp_path):
    with reference_archive(tmp_path) as controller:
        controller._scanning._folder._min_age = 0
        yield controller


def open_page(qtbot, archive) -> ScanPage:
    page = ScanPage(archive)
    qtbot.addWidget(page)
    settle(page)
    return page


def test_watching_imports_and_shows_the_parts(qtbot, archive) -> None:
    page = open_page(qtbot, archive)
    inbox = Path(archive.scan_folder())
    assert str(inbox) in page.folder_label.text()
    assert page.timer.interval() == POLL_MILLISECONDS and not page.timer.isActive()
    (inbox / "bunke.pdf").write_bytes(batch_pdf(["Faktura 1", "blank", "separator", "Faktura 2"]))

    page.watch_box.setChecked(True)
    settle(page)
    assert page.timer.isActive()
    page.poll_button.click()  # the second look finds the file unchanged
    settle(page)
    settle(page)

    assert t("scan.polled", imported=1, duplicates=0, refused=0, failed=0, processed=1) == (
        page.status_label.text()
    )
    assert page.table.rowCount() == 1
    assert page.table.item(0, PARTS_COLUMN).text() == t("scan.parts", count=2, ranges="1, 4")
    assert page.table.item(0, BLANK_COLUMN).text() == "2"
    assert page.table.item(0, SEPARATOR_COLUMN).text() == "3"
    assert page.table.item(0, NEAR_COLUMN).text() == ""
    page.watch_box.setChecked(False)
    assert not page.timer.isActive() and page.status_label.text() == t("scan.stopped")


def test_the_measurements_of_the_selected_document_are_listed(qtbot, archive) -> None:
    page = open_page(qtbot, archive)
    inbox = Path(archive.scan_folder())
    (inbox / "bunke.pdf").write_bytes(batch_pdf(["Faktura 1", "blank", "separator"]))
    page.poll()
    settle(page)
    page.poll()
    settle(page)
    settle(page)
    assert page.pages_table.rowCount() == 0  # nothing selected yet
    assert page.pages_table.columnCount() == len(PAGE_COLUMNS)

    page.table.selectRow(0)

    rows = [
        [page.pages_table.item(row, column).text() for column in range(len(PAGE_COLUMNS))]
        for row in range(page.pages_table.rowCount())
    ]
    assert [row[:2] for row in rows] == [
        ["1", t("scan.kind.content")],
        ["2", t("scan.kind.blank")],
        ["3", t("scan.kind.separator")],
    ]
    assert rows[1][2:5] == ["0", "0", "0"] and int(rows[2][3]) >= 850
    assert all(row[5] == "" for row in rows)
    assert "850" in thresholds_text() and "150" in thresholds_text()

    (inbox / "ny.pdf").write_bytes(batch_pdf(["Faktura 2", "Faktura 2 side 2"]))
    page.poll()
    settle(page)
    page.poll()
    settle(page)
    settle(page)
    assert page.table.rowCount() == 2
    assert page.table.item(page.table.currentRow(), 0).text() == "bunke.pdf"
    assert page.pages_table.rowCount() == 3  # still the selected document


def test_the_folder_path_is_copied(qtbot, archive) -> None:
    page = open_page(qtbot, archive)
    page.copy_button.click()
    assert QGuiApplication.clipboard().text() == archive.scan_folder()
    assert page.status_label.text() == t("scan.copied")


def test_the_separator_sheet_is_saved_and_cancel_does_nothing(qtbot, archive, tmp_path) -> None:
    page = open_page(qtbot, archive)
    page.choose_file = lambda: None
    page.separator_button.click()
    settle(page)
    assert page.status_label.text() == ""
    target = tmp_path / "skilleark.pdf"
    page.choose_file = lambda: str(target)
    page.separator_button.click()
    settle(page)
    assert page.status_label.text() == t("scan.separator.saved")
    assert target.read_bytes().startswith(b"%PDF")
    keys = [
        text[text.index("&") + 1].lower()
        for text in (
            page.watch_box.text(),
            page.poll_button.text(),
            page.separator_button.text(),
            page.refresh_button.text(),
            page.copy_button.text(),
        )
    ]
    assert len(set(keys)) == len(keys)
