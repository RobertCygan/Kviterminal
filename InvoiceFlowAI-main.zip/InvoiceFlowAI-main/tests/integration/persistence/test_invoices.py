"""Entity-scoped invoice storage, immutable revisions and the unit of work."""

import copy
import datetime as dt
import json
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

import pytest
from sqlalchemy.exc import IntegrityError

from invoiceflow.application.audit import AuditDraft, AuditEventType
from invoiceflow.application.errors import (
    ConflictError,
    DataIntegrityError,
    InvoiceFlowError,
    NotFoundError,
)
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import EntityService, InvoiceService
from invoiceflow.domain import CanonicalInvoice
from invoiceflow.domain.canonical import content_sha256, invoice_canonical_json, sha256_hex
from invoiceflow.persistence.database import Database
from invoiceflow.persistence.repositories import SqlAuditLog

from .conftest import add_document

pytestmark = pytest.mark.integration

Scopes = tuple[EntityScope, EntityScope]
NOW = dt.datetime(2026, 10, 20, 10, 0, tzinfo=dt.UTC)


def variant(data: dict[str, Any], gross: str) -> CanonicalInvoice:
    changed = copy.deepcopy(data)
    changed["totals"]["gross_amount"]["value"] = gross
    return CanonicalInvoice.model_validate(changed)


def audit_types(database: Database) -> list[str]:
    with database.unit_of_work() as uow:
        return [record.event_type for record in uow.audit.records()]


def raw(database: Database, sql: str, *params: object) -> list[tuple[object, ...]]:
    with database.engine.connect() as connection, connection.begin():
        return [tuple(row) for row in connection.exec_driver_sql(sql, params)]


# --- round trip and revisions -------------------------------------------------


def test_invoice_round_trip_is_lossless(
    invoices: InvoiceService, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    owner, _ = scopes
    record = invoices.register(owner, example_invoice)
    stored = invoices.get(owner, record.invoice_id)
    assert stored.invoice == example_invoice
    assert invoice_canonical_json(stored.invoice) == invoice_canonical_json(example_invoice)
    assert stored.content_sha256 == content_sha256(example_invoice) == record.content_sha256
    assert (stored.revision, stored.workflow_status, stored.entity_id) == (
        1,
        "draft",
        owner.entity_id,
    )


def test_projection_columns_are_exact_text(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    record = invoices.register(scopes[0], example_invoice)
    rows = raw(
        database,
        "SELECT gross_amount, typeof(gross_amount), net_amount, vat_amount, invoice_date"
        " FROM invoices WHERE id = ?",
        record.invoice_id.hex,
    )
    totals = example_invoice.totals
    assert rows == [
        (
            format(totals.gross_amount.value, "f"),
            "text",
            format(totals.net_amount.value, "f"),
            format(totals.vat_amount.value, "f"),
            example_invoice.invoice_date.value.isoformat(),
        )
    ]
    assert isinstance(totals.gross_amount.value, Decimal)


def test_revision_keeps_earlier_versions_unchanged(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_data: dict[str, Any]
) -> None:
    owner, _ = scopes
    first = CanonicalInvoice.model_validate(example_data)
    second = variant(example_data, "9999.99")
    record = invoices.register(owner, first)

    revised = invoices.revise(owner, record.invoice_id, second, expected_revision=1)

    assert revised.revision == 2
    assert invoices.get(owner, record.invoice_id).invoice == second
    assert invoices.get_revision(owner, record.invoice_id, 1).invoice == first
    assert invoices.get_revision(owner, record.invoice_id, 2).invoice == second
    assert raw(database, "SELECT gross_amount FROM invoices") == [("9999.99",)]
    assert audit_types(database)[-2:] == [
        AuditEventType.INVOICE_CREATED,
        AuditEventType.INVOICE_REVISED,
    ]
    with database.unit_of_work() as uow:
        last = list(uow.audit.records())[-1]
    assert dict(last.details) == {
        "revision": 2,
        "previous_revision": 1,
        "content_sha256": content_sha256(second),
        "previous_content_sha256": content_sha256(first),
        "schema_version": "1.0",
    }


def test_identical_revision_is_idempotent(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    owner, _ = scopes
    record = invoices.register(owner, example_invoice)
    events = len(audit_types(database))
    again = invoices.revise(owner, record.invoice_id, example_invoice, expected_revision=1)
    assert again.revision == 1
    assert len(audit_types(database)) == events
    assert raw(database, "SELECT COUNT(*) FROM invoice_revisions") == [(1,)]


def test_stale_revision_is_a_conflict(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_data: dict[str, Any]
) -> None:
    owner, _ = scopes
    record = invoices.register(owner, CanonicalInvoice.model_validate(example_data))
    invoices.revise(owner, record.invoice_id, variant(example_data, "1.00"), expected_revision=1)
    with pytest.raises(ConflictError):
        invoices.revise(
            owner, record.invoice_id, variant(example_data, "2.00"), expected_revision=1
        )
    assert invoices.get(owner, record.invoice_id).revision == 2


def test_concurrent_writer_with_the_same_expected_revision_conflicts(
    database: Database, scopes: Scopes, example_data: dict[str, Any]
) -> None:
    """Optimistic check inside the repository, independent of the service."""
    owner, _ = scopes
    record = InvoiceService(database.unit_of_work).register(
        owner, CanonicalInvoice.model_validate(example_data)
    )
    with database.unit_of_work() as uow:
        uow.invoices(owner).replace(
            invoice_id=record.invoice_id,
            invoice=variant(example_data, "1.00"),
            expected_revision=1,
            recorded_at=NOW,
            actor="system",
        )
        uow.commit()
    with database.unit_of_work() as uow, pytest.raises(ConflictError):
        uow.invoices(owner).replace(
            invoice_id=record.invoice_id,
            invoice=variant(example_data, "2.00"),
            expected_revision=1,
            recorded_at=NOW,
            actor="system",
        )


def test_revision_cannot_move_the_document(
    invoices: InvoiceService, scopes: Scopes, example_data: dict[str, Any]
) -> None:
    owner, _ = scopes
    record = invoices.register(owner, CanonicalInvoice.model_validate(example_data))
    moved = copy.deepcopy(example_data)
    moved["document_id"] = str(uuid4())
    with pytest.raises(InvoiceFlowError) as error:
        invoices.revise(
            owner, record.invoice_id, CanonicalInvoice.model_validate(moved), expected_revision=1
        )
    assert error.value.code == "INVALID_INPUT"


def test_missing_revision_is_not_found(
    invoices: InvoiceService, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    record = invoices.register(scopes[0], example_invoice)
    with pytest.raises(NotFoundError):
        invoices.get_revision(scopes[0], record.invoice_id, 2)


def test_register_requires_an_existing_entity(
    database: Database, invoices: InvoiceService, example_invoice: CanonicalInvoice
) -> None:
    with pytest.raises(NotFoundError):
        invoices.register(EntityScope(uuid4()), example_invoice)
    assert raw(database, "SELECT COUNT(*) FROM invoices") == [(0,)]


# --- entity isolation ----------------------------------------------------------


@pytest.mark.security
def test_other_entity_cannot_read_or_revise(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_data: dict[str, Any]
) -> None:
    owner, other = scopes
    record = invoices.register(owner, CanonicalInvoice.model_validate(example_data))
    missing = uuid4()
    # Another entity's invoice is indistinguishable from a missing one.
    for scope, invoice_id in [(other, record.invoice_id), (owner, missing)]:
        with pytest.raises(NotFoundError) as error:
            invoices.get(scope, invoice_id)
        assert (error.value.code, error.value.message_key) == ("NOT_FOUND", "error.not_found")
    with pytest.raises(NotFoundError):
        invoices.get_revision(other, record.invoice_id, 1)
    with pytest.raises(NotFoundError):
        invoices.revise(
            other, record.invoice_id, variant(example_data, "1.00"), expected_revision=1
        )
    assert invoices.get(owner, record.invoice_id).revision == 1


@pytest.mark.security
def test_listing_is_scoped_to_one_entity(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_data: dict[str, Any]
) -> None:
    owner, other = scopes
    mine = invoices.register(owner, CanonicalInvoice.model_validate(example_data))
    other_data = copy.deepcopy(example_data)
    other_data["document_id"] = str(add_document(database, other))
    theirs = invoices.register(other, variant(other_data, "1.00"))
    with database.unit_of_work() as uow:
        assert uow.invoices(owner).list_ids() == [mine.invoice_id]
        assert uow.invoices(other).list_ids() == [theirs.invoice_id]


@pytest.mark.security
@pytest.mark.parametrize("scope", [None, "11111111111141118111111111111111", uuid4()])
def test_repository_requires_an_entity_scope(database: Database, scope: object) -> None:
    with database.unit_of_work() as uow, pytest.raises(TypeError):
        uow.invoices(scope)  # type: ignore[arg-type]


@pytest.mark.security
def test_database_rejects_a_revision_owned_by_another_entity(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_data: dict[str, Any]
) -> None:
    """Raw SQL cannot attach a revision of entity A's invoice to entity B."""
    owner, other = scopes
    record = invoices.register(owner, CanonicalInvoice.model_validate(example_data))
    with database.engine.connect() as connection:
        transaction = connection.begin()
        connection.exec_driver_sql(
            "INSERT INTO invoice_revisions SELECT invoice_id, 2, ?, schema_version,"
            " canonical_json, content_sha256, 'revised', recorded_at, recorded_by"
            " FROM invoice_revisions WHERE invoice_id = ?",
            (other.entity_id.hex, record.invoice_id.hex),
        )
        with pytest.raises(IntegrityError, match="FOREIGN KEY"):
            transaction.commit()


@pytest.mark.security
@pytest.mark.parametrize(
    ("sql", "message"),
    [
        ("UPDATE invoices SET entity_id = ?", "ownership is immutable"),
        ("UPDATE invoice_revisions SET entity_id = ?", "append-only"),
    ],
)
def test_database_rejects_moving_an_invoice_to_another_entity(
    database: Database,
    invoices: InvoiceService,
    scopes: Scopes,
    example_invoice: CanonicalInvoice,
    sql: str,
    message: str,
) -> None:
    owner, other = scopes
    invoices.register(owner, example_invoice)
    with (
        database.engine.connect() as connection,
        connection.begin(),
        pytest.raises(IntegrityError, match=message),
    ):
        connection.exec_driver_sql(sql, (other.entity_id.hex,))


@pytest.mark.security
@pytest.mark.parametrize(
    ("sql", "message"),
    [
        ("UPDATE invoice_revisions SET canonical_json = '{}'", "append-only"),
        ("DELETE FROM invoice_revisions", "append-only"),
        ("DELETE FROM invoices", "cannot be deleted"),
        ("UPDATE invoices SET content_sha256 = '" + "e" * 64 + "'", "stored revision"),
        ("UPDATE invoices SET current_revision = 2", "stored revision"),
        ("UPDATE invoices SET document_id = '" + "f" * 32 + "'", "immutable"),
        ("DELETE FROM accounting_entities", "FOREIGN KEY"),
        ("UPDATE accounting_entities SET id = '" + "f" * 32 + "'", "immutable"),
    ],
)
def test_database_triggers_protect_stored_invoices(
    database: Database,
    invoices: InvoiceService,
    scopes: Scopes,
    example_invoice: CanonicalInvoice,
    sql: str,
    message: str,
) -> None:
    invoices.register(scopes[0], example_invoice)
    with (
        database.engine.connect() as connection,
        connection.begin(),
        pytest.raises(IntegrityError, match=message),
    ):
        connection.exec_driver_sql(sql)


@pytest.mark.security
def test_revision_numbers_must_be_consecutive(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    record = invoices.register(scopes[0], example_invoice)
    with (
        database.engine.connect() as connection,
        connection.begin(),
        pytest.raises(IntegrityError, match="consecutive"),
    ):
        connection.exec_driver_sql(
            "INSERT INTO invoice_revisions SELECT invoice_id, 3, entity_id, schema_version,"
            " canonical_json, content_sha256, 'revised', recorded_at, recorded_by"
            " FROM invoice_revisions WHERE invoice_id = ?",
            (record.invoice_id.hex,),
        )


# --- tamper detection ------------------------------------------------------------


def tamper(database: Database, sql: str, *params: object) -> None:
    """Simulate an attacker with file access who first removes the triggers."""
    with database.engine.connect() as connection, connection.begin():
        connection.exec_driver_sql("DROP TRIGGER invoice_revisions_no_update")
        connection.exec_driver_sql(sql, params)


@pytest.mark.security
def test_modified_snapshot_is_detected(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    owner, _ = scopes
    record = invoices.register(owner, example_invoice)
    tamper(
        database,
        "UPDATE invoice_revisions SET canonical_json = replace(canonical_json, '5671.25', '1.00')",
    )
    with pytest.raises(DataIntegrityError):
        invoices.get(owner, record.invoice_id)


@pytest.mark.security
def test_snapshot_with_recomputed_hash_but_invalid_content_is_detected(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    owner, _ = scopes
    record = invoices.register(owner, example_invoice)
    forged = '{"schema_version":"1.0"}'
    tamper(
        database,
        "UPDATE invoice_revisions SET canonical_json = ?, content_sha256 = ?",
        forged,
        sha256_hex(forged.encode()),
    )
    with pytest.raises(DataIntegrityError):
        invoices.get_revision(owner, record.invoice_id, 1)


@pytest.mark.security
def test_non_canonical_snapshot_is_detected(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    """Valid JSON with a matching hash, but not the canonical serialisation."""
    owner, _ = scopes
    record = invoices.register(owner, example_invoice)
    pretty = json.dumps(json.loads(invoice_canonical_json(example_invoice)), indent=1)
    tamper(
        database,
        "UPDATE invoice_revisions SET canonical_json = ?, content_sha256 = ?",
        pretty,
        sha256_hex(pretty.encode()),
    )
    with pytest.raises(DataIntegrityError):
        invoices.get(owner, record.invoice_id)


# --- unit of work ----------------------------------------------------------------


def test_unit_of_work_without_commit_rolls_back(database: Database, scopes: Scopes) -> None:
    owner, _ = scopes
    with database.unit_of_work() as uow:
        uow.audit.append(
            AuditDraft(
                event_type=AuditEventType.ENTITY_CREATED,
                actor="system",
                entity_id=owner.entity_id,
                subject_id=str(owner.entity_id),
            ),
            occurred_at=NOW,
        )
    assert len(audit_types(database)) == 3  # database.created + two entity.created


def test_exception_rolls_back_business_change_and_audit_event(
    database: Database, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    owner, _ = scopes
    events = audit_types(database)

    class BoomError(Exception):
        pass

    with pytest.raises(BoomError), database.unit_of_work() as uow:
        uow.invoices(owner).add(
            invoice_id=uuid4(),
            invoice=example_invoice,
            recorded_at=NOW,
            actor="system",
        )
        raise BoomError
    assert raw(database, "SELECT COUNT(*) FROM invoices") == [(0,)]
    assert raw(database, "SELECT COUNT(*) FROM invoice_revisions") == [(0,)]
    assert audit_types(database) == events


def test_audit_failure_rolls_back_the_business_change(
    database: Database, scopes: Scopes, example_invoice: CanonicalInvoice, monkeypatch
) -> None:
    """Atomicity: an invoice is never stored without its audit event."""
    owner, _ = scopes

    def failing_append(self: object, draft: object, *, occurred_at: object) -> None:
        raise RuntimeError("audit write failed")

    monkeypatch.setattr(SqlAuditLog, "append", failing_append)
    with pytest.raises(RuntimeError):
        InvoiceService(database.unit_of_work).register(owner, example_invoice)
    assert raw(database, "SELECT COUNT(*) FROM invoices") == [(0,)]
    assert raw(database, "SELECT COUNT(*) FROM invoice_revisions") == [(0,)]


def test_entity_and_its_audit_event_are_written_together(database: Database) -> None:
    service = EntityService(database.unit_of_work)
    record = service.create(name="Syntetisk enhet C AS")
    assert service.get(record.entity_id) == record
    with database.unit_of_work() as uow:
        last = list(uow.audit.records())[-1]
    assert (last.event_type, last.entity_id, last.subject_id) == (
        AuditEventType.ENTITY_CREATED,
        record.entity_id,
        str(record.entity_id),
    )
    assert dict(last.details) == {}


@pytest.mark.parametrize(
    "values",
    [{"name": " "}, {"name": "X", "org_number": "123"}, {"name": "X", "default_currency": "nok"}],
)
def test_invalid_entity_input_is_rejected(database: Database, values: dict[str, str]) -> None:
    with pytest.raises(InvoiceFlowError) as error:
        EntityService(database.unit_of_work).create(**values)
    assert error.value.code == "INVALID_INPUT"


def test_duplicate_org_number_is_a_conflict(database: Database, scopes: Scopes) -> None:
    with pytest.raises(ConflictError):
        EntityService(database.unit_of_work).create(name="Kopi AS", org_number="123456785")


def test_unknown_entity_is_not_found(database: Database) -> None:
    with pytest.raises(NotFoundError):
        EntityService(database.unit_of_work).get(UUID(int=7))


def test_unit_of_work_cannot_be_reused_or_committed_twice(database: Database) -> None:
    uow = database.unit_of_work()
    with uow:
        uow.commit()
        with pytest.raises(RuntimeError):
            uow.commit()
        with pytest.raises(RuntimeError):
            uow.invoices(EntityScope(uuid4()))
    with pytest.raises(RuntimeError), uow:
        pass


@pytest.mark.security
def test_modified_projection_is_detected_on_read(
    database: Database, invoices: InvoiceService, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    record = invoices.register(scopes[0], example_invoice)
    with database.engine.connect() as connection, connection.begin():
        connection.exec_driver_sql(
            "UPDATE invoices SET invoice_number = ? WHERE id = ?",
            ("FORGED", record.invoice_id.hex),
        )
    with pytest.raises(DataIntegrityError):
        invoices.get(scopes[0], record.invoice_id)
