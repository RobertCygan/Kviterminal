"""Exact column types, SQLite settings and connection lifecycle on real files."""

import datetime as dt
import sqlite3
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import Column, Integer, MetaData, Table, insert, select
from sqlalchemy.exc import IntegrityError, StatementError

from invoiceflow.persistence.database import Database
from invoiceflow.persistence.engine import EXPECTED_SETTINGS, create_sqlite_engine, read_settings
from invoiceflow.persistence.types import DecimalText, UtcDateTime

pytestmark = pytest.mark.integration


RAW_QUERIES = {
    "amount": "SELECT amount, typeof(amount) FROM probe",
    "price": "SELECT price, typeof(price) FROM probe",
}


@pytest.fixture
def probe(tmp_path: Path):
    engine = create_sqlite_engine(tmp_path / "types.sqlite3")
    metadata = MetaData()
    table = Table(
        "probe",
        metadata,
        Column("id", Integer, primary_key=True),
        Column("amount", DecimalText(2)),
        Column("price", DecimalText(2)),
        Column("at", UtcDateTime()),
    )
    metadata.create_all(engine)
    yield engine, table
    engine.dispose()


@pytest.mark.parametrize(
    ("value", "stored", "column"),
    [
        (Decimal("1234.5"), "1234.50", "amount"),
        (Decimal("-0.00"), "0.00", "amount"),
        (Decimal("1E+2"), "100.00", "amount"),
        (Decimal("9999999999999.99"), "9999999999999.99", "amount"),
        (Decimal("0.1") + Decimal("0.2"), "0.30", "amount"),
        (7, "7.00", "amount"),
        (Decimal("0.012500"), "0.0125", "price"),
    ],
)
def test_decimal_text_round_trip_is_exact(probe, value, stored, column) -> None:
    engine, table = probe
    with engine.connect() as connection, connection.begin():
        connection.execute(insert(table).values({column: value}))
        raw = connection.exec_driver_sql(RAW_QUERIES[column]).one()
        read = connection.execute(select(table.c[column])).scalar_one()
    assert raw == (stored, "text")
    assert read == Decimal(value)
    assert str(read) == stored


@pytest.mark.security
@pytest.mark.parametrize(
    "value", [0.1, 1.0, True, "12.50", Decimal("NaN"), Decimal("Infinity"), Decimal("-sNaN")]
)
def test_decimal_text_rejects_inexact_values(probe, value) -> None:
    engine, table = probe
    with (
        engine.connect() as connection,
        connection.begin(),
        pytest.raises(StatementError) as error,
    ):
        connection.execute(insert(table).values(amount=value))
    assert isinstance(error.value.orig, TypeError | ValueError)


@pytest.mark.parametrize("stored", ["1e2", "12,50", " 1.00", "0x10"])
def test_non_canonical_stored_decimal_is_rejected_on_read(probe, stored) -> None:
    engine, table = probe
    with engine.connect() as connection, connection.begin():
        connection.exec_driver_sql("INSERT INTO probe (amount) VALUES (?)", (stored,))
        with pytest.raises(ValueError):
            connection.execute(select(table.c.amount)).scalar_one()


def test_utc_datetime_round_trip(probe) -> None:
    engine, table = probe
    oslo = dt.datetime(2026, 10, 20, 12, 30, 15, 123456, tzinfo=dt.timezone(dt.timedelta(hours=2)))
    with engine.connect() as connection, connection.begin():
        connection.execute(insert(table).values(at=oslo))
        raw = connection.exec_driver_sql("SELECT at FROM probe").scalar_one()
        read = connection.execute(select(table.c.at)).scalar_one()
    assert raw == "2026-10-20T10:30:15.123456Z"
    assert read == oslo
    assert read.tzinfo is dt.UTC


@pytest.mark.security
def test_utc_datetime_rejects_naive(probe) -> None:
    engine, table = probe
    with (
        engine.connect() as connection,
        connection.begin(),
        pytest.raises(StatementError) as error,
    ):
        connection.execute(insert(table).values(at=dt.datetime(2026, 1, 1)))  # noqa: DTZ001
    assert isinstance(error.value.orig, ValueError)


def test_connection_settings_are_applied_to_every_new_connection(tmp_path: Path) -> None:
    engine = create_sqlite_engine(tmp_path / "settings.sqlite3")
    try:
        connections = [engine.connect() for _ in range(3)]
        for connection in connections:
            with connection.begin():
                assert read_settings(connection) == EXPECTED_SETTINGS
        for connection in connections:
            connection.close()
    finally:
        engine.dispose()


def test_wal_is_persistent_and_other_settings_are_per_connection(database: Database) -> None:
    database.close()
    raw = sqlite3.connect(database.path)
    try:
        assert raw.execute("PRAGMA journal_mode").fetchone() == ("wal",)
        # A connection that did not set them gets SQLite's defaults.
        assert raw.execute("PRAGMA foreign_keys").fetchone() == (0,)
        assert raw.execute("PRAGMA trusted_schema").fetchone() == (1,)
    finally:
        raw.close()


def test_transactions_take_the_write_lock_immediately(database: Database) -> None:
    with database.engine.connect() as first, first.begin():
        first.exec_driver_sql("SELECT 1")
        blocked = sqlite3.connect(database.path, timeout=0.1, isolation_level=None)
        try:
            with pytest.raises(sqlite3.OperationalError, match="locked"):
                blocked.execute("BEGIN IMMEDIATE")
        finally:
            blocked.close()


def test_closing_the_database_releases_all_files(database: Database, db_path: Path) -> None:
    with database.unit_of_work() as uow:
        uow.audit.verify()
    database.close()
    moved = db_path.with_name("moved.sqlite3")
    db_path.rename(moved)  # fails on Windows while any handle is open
    assert not db_path.with_name(db_path.name + "-wal").exists()
    moved.unlink()


def test_no_monetary_column_uses_real_or_numeric(database: Database) -> None:
    with database.engine.connect() as connection, connection.begin():
        tables = connection.exec_driver_sql(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).scalars()
        for table in list(tables):
            for column in connection.exec_driver_sql(f"PRAGMA table_info({table})"):
                declared = column[2].upper()
                assert not any(kind in declared for kind in ("REAL", "FLOA", "DOUB", "NUMERIC"))


T0 = "2026-01-01T00:00:00.000000Z"


@pytest.mark.security
@pytest.mark.parametrize("value", ["1e2", "12,50", "1.2.3", "-", ".5", "5.", "1-2", "", " 1.00"])
def test_database_rejects_non_canonical_amounts(database: Database, value) -> None:
    """Defence in depth: raw SQL that bypasses DecimalText still cannot store them.

    Floats are rejected at bind time by DecimalText (see
    test_decimal_text_rejects_inexact_values); a REAL bound through raw SQL
    becomes text by column affinity, so the CHECK only guards the text form.
    """
    with database.engine.connect() as connection:
        transaction = connection.begin()
        connection.exec_driver_sql(
            "INSERT INTO accounting_entities VALUES (?, 'X', NULL, 'NOK', 1, ?, ?)",
            ("a" * 32, T0, T0),
        )
        # A matching document and revision first, so that only the CHECK can fail.
        connection.exec_driver_sql(
            "INSERT INTO documents (id, entity_id, document_type, sha256, size_bytes,"
            " detected_format, display_name, storage_path, source, status, imported_at,"
            " imported_by) VALUES (?, ?, 'invoice', ?, 1, 'pdf', 'x.pdf', ?, 'file_import',"
            " 'stored', ?, 'system')",
            ("c" * 32, "a" * 32, "e" * 64, "a" * 32 + "/originals/x.pdf", T0),
        )
        connection.exec_driver_sql(
            "INSERT INTO invoice_revisions VALUES"
            " (?, 1, ?, '1.0', '{}', ?, 'created', ?, 'system')",
            ("b" * 32, "a" * 32, "d" * 64, T0),
        )
        with pytest.raises(IntegrityError, match="CHECK"):
            connection.exec_driver_sql(
                "INSERT INTO invoices (id, entity_id, document_id, schema_version,"
                " current_revision, content_sha256, workflow_status, gross_amount, row_version,"
                " created_at, updated_at) VALUES (?, ?, ?, '1.0', 1, ?, 'draft', ?, 1, ?, ?)",
                ("b" * 32, "a" * 32, "c" * 32, "d" * 64, value, T0, T0),
            )
        transaction.rollback()


@pytest.mark.security
def test_orphan_revision_is_rejected_at_commit(database: Database) -> None:
    """The revision -> invoice foreign key is deferred, but still enforced."""
    with database.engine.connect() as connection:
        transaction = connection.begin()
        connection.exec_driver_sql(
            "INSERT INTO accounting_entities VALUES (?, 'X', NULL, 'NOK', 1, ?, ?)",
            ("a" * 32, T0, T0),
        )
        connection.exec_driver_sql(
            "INSERT INTO invoice_revisions VALUES"
            " (?, 1, ?, '1.0', '{}', ?, 'created', ?, 'system')",
            ("b" * 32, "a" * 32, "d" * 64, T0),
        )
        with pytest.raises(IntegrityError, match="FOREIGN KEY"):
            transaction.commit()


def test_null_values_pass_through_both_types(probe) -> None:
    engine, table = probe
    with engine.connect() as connection, connection.begin():
        connection.execute(insert(table).values(amount=None, at=None))
        row = connection.execute(select(table.c.amount, table.c.at)).one()
    assert tuple(row) == (None, None)


def test_changed_connection_settings_are_detected(database: Database) -> None:
    from invoiceflow.persistence.engine import SettingsError, verify_settings

    with database.engine.connect() as connection, connection.begin():
        verify_settings(connection)
        connection.exec_driver_sql("PRAGMA secure_delete = OFF")
        with pytest.raises(SettingsError):
            verify_settings(connection)


def test_connection_without_wal_is_refused() -> None:
    """An in-memory database cannot use WAL; the engine refuses to hand it out."""
    from invoiceflow.persistence.engine import SettingsError

    engine = create_sqlite_engine(Path(":memory:"))
    try:
        with pytest.raises(SettingsError):
            engine.connect()
    finally:
        engine.dispose()


def test_decimal_storage_remains_exact_beyond_default_context(probe) -> None:
    engine, table = probe
    value = Decimal("0.123456789012345678901234567891")
    with engine.connect() as connection, connection.begin():
        connection.execute(insert(table).values(price=value))
        assert connection.execute(select(table.c.price)).scalar_one() == value


@pytest.mark.parametrize("value", [Decimal("1E+100000"), Decimal("1E-100000")])
def test_decimal_storage_bounds_exponent_expansion(probe, value) -> None:
    engine, table = probe
    with engine.connect() as connection, connection.begin(), pytest.raises(StatementError):
        connection.execute(insert(table).values(amount=value))
