"""The persistence self-test detects deviations and always cleans up."""

import dataclasses
from pathlib import Path

import pytest

import invoiceflow.bootstrap.persistence as persistence
from invoiceflow.application.audit import ChainVerification
from invoiceflow.application.services import InvoiceService
from invoiceflow.bootstrap.persistence import (
    EXTRACTION_SELF_TEST_EVENTS,
    OCR_SELF_TEST_EVENTS,
    SELF_TEST_EVENTS,
)
from invoiceflow.config.paths import AppPaths
from invoiceflow.persistence.repositories import SqlAuditLog

BASE_EVENTS = SELF_TEST_EVENTS + EXTRACTION_SELF_TEST_EVENTS

pytestmark = pytest.mark.integration


@pytest.fixture
def paths(tmp_path: Path) -> AppPaths:
    resolved = AppPaths.resolve(tmp_path)
    resolved.ensure()
    return resolved


class LeakyInvoices(InvoiceService):
    """Ignores the scope on reads: the self-test must notice."""

    def get(self, scope, invoice_id):
        with self._uow_factory() as uow:
            return uow.invoices(self.owner).get(invoice_id)

    def register(self, scope, invoice, **kwargs):
        self.owner = scope
        return super().register(scope, invoice, **kwargs)


class ForgetfulInvoices(InvoiceService):
    """Returns the current revision for every revision number."""

    def get_revision(self, scope, invoice_id, revision):
        return self.get(scope, invoice_id)


def not_created(path, backup_dir):
    result = persistence_initialize(path, backup_dir)
    return dataclasses.replace(result, created=False)


persistence_initialize = persistence.initialize_database


@pytest.mark.parametrize(
    ("target", "replacement", "message"),
    [
        ("initialize_database", not_created, "initialisation"),
        ("EXPECTED_SETTINGS", {}, "settings"),
        ("content_sha256", lambda invoice: "0" * 64, "round trip"),
        ("InvoiceService", LeakyInvoices, "entity isolation"),
        ("InvoiceService", ForgetfulInvoices, "revisions"),
    ],
)
def test_self_test_reports_each_deviation(
    paths: AppPaths, monkeypatch, target: str, replacement: object, message: str
) -> None:
    monkeypatch.setattr(persistence, target, replacement)
    with pytest.raises(RuntimeError, match=message):
        persistence.run_persistence_self_test(paths)
    assert not list(paths.data.glob(".selftest-*"))


def test_self_test_reports_an_invalid_chain(paths: AppPaths, monkeypatch) -> None:
    real_verify = SqlAuditLog.verify

    def verify_then_fail(self: SqlAuditLog) -> ChainVerification:
        # Inject failure only once the synthetic business events exist, so
        # additional startup checks cannot move the failure into initialization.
        result = real_verify(self)
        return (
            ChainVerification(False, 0, 1, "hash")
            if result.events_checked in (BASE_EVENTS, BASE_EVENTS + OCR_SELF_TEST_EVENTS)
            else result
        )

    monkeypatch.setattr(SqlAuditLog, "verify", verify_then_fail)
    with pytest.raises(RuntimeError, match="audit chain"):
        persistence.run_persistence_self_test(paths)
    assert not list(paths.data.glob(".selftest-*"))


def test_self_test_passes_and_leaves_nothing_behind(paths: AppPaths) -> None:
    before = sorted(p.name for p in paths.data.iterdir())
    persistence.run_persistence_self_test(paths)
    assert sorted(p.name for p in paths.data.iterdir()) == before


def test_without_tesseract_the_self_test_skips_ocr(paths: AppPaths, monkeypatch) -> None:
    from invoiceflow.processing.isolation import IsolatedDocumentProcessor

    monkeypatch.setattr(IsolatedDocumentProcessor, "ocr_engine", lambda self, settings: None)
    checked = []
    real_verify = SqlAuditLog.verify

    def recording(self: SqlAuditLog) -> ChainVerification:
        result = real_verify(self)
        checked.append(result.events_checked)
        return result

    monkeypatch.setattr(SqlAuditLog, "verify", recording)
    persistence.run_persistence_self_test(paths)
    assert checked[-1] == BASE_EVENTS


@pytest.mark.tesseract
def test_the_self_test_reads_a_scanned_page(paths: AppPaths, monkeypatch) -> None:
    from invoiceflow.application.processing import ProcessingService

    monkeypatch.setattr(ProcessingService, "recognise", lambda self, *args, **kwargs: None)
    with pytest.raises(RuntimeError, match="ocr"):
        persistence.run_persistence_self_test(paths)
    assert not list(paths.data.glob(".selftest-*"))


def test_the_self_test_reads_a_laid_out_invoice(paths: AppPaths, monkeypatch) -> None:
    from invoiceflow.application.processing import ProcessingService

    monkeypatch.setattr(ProcessingService, "extract", lambda self, *args, **kwargs: [])
    with pytest.raises(RuntimeError, match="extraction"):
        persistence.run_persistence_self_test(paths)
    assert not list(paths.data.glob(".selftest-*"))
