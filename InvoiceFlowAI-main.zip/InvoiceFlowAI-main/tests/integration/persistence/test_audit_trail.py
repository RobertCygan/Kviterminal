"""The append-only audit chain as stored in SQLite."""

import itertools
import json
import sqlite3
import threading
from pathlib import Path

import pytest
from sqlalchemy.exc import IntegrityError

from invoiceflow.application.audit import GENESIS_HASH, AuditEventType
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import EntityService, InvoiceService
from invoiceflow.domain import CanonicalInvoice
from invoiceflow.persistence.database import Database

pytestmark = [pytest.mark.integration, pytest.mark.security]

Scopes = tuple[EntityScope, EntityScope]

COPY_LAST = (
    "INSERT INTO audit_events SELECT {sequence}, '{event_id}', occurred_at, actor, event_type,"
    " entity_id, subject_type, subject_id, details_json, hash_version, {prev_hash},"
    " '{event_hash}' FROM audit_events ORDER BY sequence DESC LIMIT 1"
)


def verify(database: Database):
    with database.unit_of_work() as uow:
        return uow.audit.verify()


def execute(database: Database, sql: str, *params: object) -> None:
    with database.engine.connect() as connection, connection.begin():
        connection.exec_driver_sql(sql, params)


@pytest.mark.parametrize(
    "sql",
    [
        "UPDATE audit_events SET actor = 'system/x' WHERE sequence = 1",
        "UPDATE audit_events SET details_json = '{}'",
        "DELETE FROM audit_events WHERE sequence = (SELECT MAX(sequence) FROM audit_events)",
        "DELETE FROM audit_events",
    ],
)
def test_audit_events_cannot_be_changed_or_deleted(database: Database, sql: str) -> None:
    with pytest.raises(IntegrityError, match="append-only"):
        execute(database, sql)
    assert verify(database).valid


@pytest.mark.parametrize(
    ("sequence", "prev_hash"),
    [
        ("sequence + 1", "event_hash"),  # duplicates the link of the existing end
        ("sequence + 2", "event_hash"),  # gap
        ("sequence", "event_hash"),  # reuses a sequence number
        ("sequence + 1", f"'{GENESIS_HASH}'"),  # second genesis: a fork
        ("sequence + 1", f"'{'b' * 64}'"),  # links to nothing
    ],
    ids=["duplicate", "gap", "reuse", "fork", "dangling"],
)
def test_inserts_must_extend_the_end_of_the_chain(
    database: Database, scopes: Scopes, sequence: str, prev_hash: str
) -> None:
    sql = COPY_LAST.format(
        sequence=sequence, event_id="e" * 32, prev_hash=prev_hash, event_hash="f" * 64
    )
    if sequence == "sequence + 1" and prev_hash == "event_hash":
        # Correct position and link but a forged hash: the trigger allows it,
        # verification catches it.
        execute(database, sql)
        result = verify(database)
        assert not result.valid and result.reason == "hash"
        return
    with pytest.raises(IntegrityError):
        execute(database, sql)
    assert verify(database).valid


def test_stored_details_are_canonical_and_contain_no_invoice_content(
    database: Database, scopes: Scopes, example_invoice: CanonicalInvoice
) -> None:
    InvoiceService(database.unit_of_work).register(scopes[0], example_invoice)
    with database.engine.connect() as connection, connection.begin():
        rows = connection.exec_driver_sql(
            "SELECT event_type, details_json FROM audit_events ORDER BY sequence"
        ).all()
    texts = " ".join(details for _, details in rows)
    for secret in ["5671.25", "Fjordkontor", "Nordlys", "123456785", "Syntetisk"]:
        assert secret not in texts
    for _, details in rows:
        assert details == json.dumps(
            json.loads(details), sort_keys=True, separators=(",", ":"), ensure_ascii=False
        )


def test_chain_links_from_genesis(database: Database, scopes: Scopes) -> None:
    with database.unit_of_work() as uow:
        records = list(uow.audit.records())
    assert [r.sequence for r in records] == [1, 2, 3]
    assert records[0].prev_hash == GENESIS_HASH
    assert all(b.prev_hash == a.event_hash for a, b in itertools.pairwise(records))
    assert [r.event_type for r in records] == [
        AuditEventType.DATABASE_CREATED,
        AuditEventType.ENTITY_CREATED,
        AuditEventType.ENTITY_CREATED,
    ]


@pytest.mark.parametrize(
    ("sql", "reason"),
    [
        ("UPDATE audit_events SET actor = 'system/forged' WHERE sequence = 2", "hash"),
        ("UPDATE audit_events SET details_json = '{\"revision\":1}' WHERE sequence = 1", "payload"),
        ("UPDATE audit_events SET occurred_at = 'not a time' WHERE sequence = 2", "unreadable"),
        ("DELETE FROM audit_events WHERE sequence = 2", "sequence"),
        ("UPDATE audit_events SET hash_version = 2 WHERE sequence = 3", "hash_version"),
    ],
    ids=["field", "details", "unreadable", "removed", "version"],
)
def test_tampering_after_dropping_triggers_is_detected(
    db_path: Path, database: Database, scopes: Scopes, sql: str, reason: str
) -> None:
    database.close()
    connection = sqlite3.connect(db_path)
    try:
        # CHECK constraints are enforced by SQLite itself; an attacker with
        # write access to the file can disable them as well.
        connection.execute("PRAGMA ignore_check_constraints = ON")
        for trigger in ("audit_events_no_update", "audit_events_no_delete"):
            connection.execute(f"DROP TRIGGER {trigger}")
        connection.execute(sql)
        connection.commit()
    finally:
        connection.close()
    result = verify(database)
    assert not result.valid
    assert result.reason == reason


def test_concurrent_writers_produce_one_linear_chain(db_path: Path, database: Database) -> None:
    """Separate engines (as separate processes would) serialise via BEGIN IMMEDIATE."""
    database.close()
    writers, per_writer = 4, 5
    errors: list[BaseException] = []
    barrier = threading.Barrier(writers)

    def work(number: int) -> None:
        handle = Database(db_path)
        try:
            service = EntityService(handle.unit_of_work)
            barrier.wait()
            for index in range(per_writer):
                service.create(name=f"Parallell enhet {number}-{index}")
        except BaseException as exc:  # pragma: no cover - reported below
            errors.append(exc)
        finally:
            handle.close()

    threads = [threading.Thread(target=work, args=(n,)) for n in range(writers)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=60)
    assert errors == []
    result = verify(database)
    assert result.valid
    assert result.events_checked == 1 + writers * per_writer
