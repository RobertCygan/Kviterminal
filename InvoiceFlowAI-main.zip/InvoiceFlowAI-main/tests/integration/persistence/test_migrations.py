"""Database creation, migration, safety copies and refusal of unknown files."""

import contextlib
import datetime as dt
import shutil
import sqlite3
from contextlib import closing
from pathlib import Path
from uuid import UUID, uuid4

import pytest
import sqlalchemy as sa
from alembic.autogenerate import compare_metadata
from alembic.migration import MigrationContext

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.errors import DatabaseError
from invoiceflow.persistence import migrator
from invoiceflow.persistence.database import Database
from invoiceflow.persistence.migrator import (
    MIGRATIONS_DIR,
    create_safety_copy,
    initialize_database,
    known_revisions,
)
from invoiceflow.persistence.schema import metadata

pytestmark = pytest.mark.integration

NOW = dt.datetime(2026, 10, 20, 10, 0, tzinfo=dt.UTC)
HEAD = known_revisions()[0]

MIGRATION_0002 = '''"""Synthetic second revision used only by tests."""

from alembic import op

revision = "9999_test"
down_revision = "{head}"
branch_labels = None
depends_on = None


def upgrade() -> None:
{body}


def downgrade() -> None:
    raise NotImplementedError
'''


def _clock() -> dt.datetime:
    return NOW


def scripts_with_0002(tmp_path: Path, body: str) -> Path:
    """Copy of the real migrations plus a synthetic revision after the head."""
    location = tmp_path / "migrations"
    shutil.copytree(MIGRATIONS_DIR, location, ignore=shutil.ignore_patterns("__pycache__"))
    (location / "versions" / "9999_test.py").write_text(
        MIGRATION_0002.format(body=body, head=HEAD), encoding="utf-8"
    )
    return location


def raw_rows(path: Path, sql: str) -> list[tuple[object, ...]]:
    connection = sqlite3.connect(path)
    try:
        return connection.execute(sql).fetchall()
    finally:
        connection.close()


def audit_types(path: Path) -> list[str]:
    return [row[0] for row in raw_rows(path, "SELECT event_type FROM audit_events ORDER BY 1")]


def test_empty_directory_is_migrated_to_head(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    result = initialize_database(path, tmp_path / "backups", clock=_clock)
    head, _ = known_revisions()
    assert result.created and result.revision == head == HEAD
    assert result.backup_path is None and result.migrated_from is None
    assert result.audit.valid and result.audit.events_checked == 1
    assert raw_rows(path, "SELECT version_num FROM alembic_version") == [(head,)]
    assert audit_types(path) == [AuditEventType.DATABASE_CREATED]
    assert not (tmp_path / "backups").exists()


def test_repeated_initialisation_is_a_no_op(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    again = initialize_database(path, tmp_path / "backups", clock=_clock)
    assert not again.created and again.backup_path is None
    assert audit_types(path) == [AuditEventType.DATABASE_CREATED]
    assert not (tmp_path / "backups").exists()


def test_existing_empty_file_is_initialised(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    path.touch()
    assert initialize_database(path, tmp_path / "backups").created


def test_schema_matches_table_metadata(database: Database) -> None:
    """The literal migration DDL and the Core metadata describe the same schema."""
    with database.engine.connect() as connection, connection.begin():
        context = MigrationContext.configure(connection, opts={"compare_type": True})
        assert compare_metadata(context, metadata) == []
        # The check is not vacuous: a changed copy of the metadata is reported.
        changed = sa.MetaData()
        for table in metadata.sorted_tables:
            table.to_metadata(changed)
        changed.tables["invoices"].append_column(sa.Column("extra", sa.String(5)))
        assert [diff[0] for diff in compare_metadata(context, changed)] == ["add_column"]


def test_foreign_keys_match_table_metadata(database: Database) -> None:
    with database.engine.connect() as connection, connection.begin():
        for table in metadata.sorted_tables:
            stored = {
                (row[2], row[3], row[4])
                for row in connection.exec_driver_sql(f"PRAGMA foreign_key_list({table.name})")
            }
            declared = {
                (fk.column.table.name, fk.parent.name, fk.column.name)
                for constraint in table.foreign_key_constraints
                for fk in constraint.elements
            }
            assert stored == declared, table.name


@pytest.mark.security
def test_migration_of_existing_database_takes_a_verified_safety_copy(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    scripts = scripts_with_0002(tmp_path, "    op.execute('CREATE TABLE phase_test (id INTEGER)')")

    result = initialize_database(path, tmp_path / "backups", clock=_clock, script_location=scripts)

    assert result.revision == "9999_test" and result.migrated_from == HEAD
    assert not result.created
    assert result.backup_path is not None
    assert result.backup_path.parent == tmp_path / "backups"
    assert result.backup_path.name == f"invoiceflow-{HEAD}-20261020T100000000000Z.sqlite3"
    # The copy is a complete, consistent database at the old revision.
    assert raw_rows(result.backup_path, "PRAGMA integrity_check") == [("ok",)]
    assert raw_rows(result.backup_path, "SELECT version_num FROM alembic_version") == [(HEAD,)]
    assert audit_types(result.backup_path) == [AuditEventType.DATABASE_CREATED]
    assert not list((tmp_path / "backups").glob("*.partial"))
    # The migrated database carries the new revision and an audit event for it.
    assert raw_rows(path, "SELECT version_num FROM alembic_version") == [("9999_test",)]
    assert audit_types(path) == [AuditEventType.DATABASE_CREATED, AuditEventType.DATABASE_MIGRATED]
    details = raw_rows(path, "SELECT details_json FROM audit_events WHERE sequence = 2")
    assert details == [
        (f'{{"backup_created":true,"from_revision":"{HEAD}","to_revision":"9999_test"}}',)
    ]
    assert result.audit.valid and result.audit.events_checked == 2


@pytest.mark.security
def test_failed_migration_rolls_back_and_keeps_original_and_copy(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    before = raw_rows(path, "SELECT sql FROM sqlite_master ORDER BY name")
    scripts = scripts_with_0002(
        tmp_path,
        "    op.execute('CREATE TABLE phase_test (id INTEGER)')\n"
        "    op.execute('DROP TABLE audit_events')\n"
        "    op.execute('THIS IS NOT SQL')",
    )

    with pytest.raises(DatabaseError) as error:
        initialize_database(path, tmp_path / "backups", clock=_clock, script_location=scripts)

    assert error.value.code == "DATABASE_MIGRATION_FAILED"
    # Every statement of the failed migration was rolled back.
    assert raw_rows(path, "SELECT sql FROM sqlite_master ORDER BY name") == before
    assert raw_rows(path, "SELECT version_num FROM alembic_version") == [(HEAD,)]
    assert audit_types(path) == [AuditEventType.DATABASE_CREATED]
    copies = list((tmp_path / "backups").glob("*.sqlite3"))
    assert len(copies) == 1
    assert raw_rows(copies[0], "PRAGMA integrity_check") == [("ok",)]
    # The original still opens normally with the program's own migrations.
    assert initialize_database(path, tmp_path / "backups").audit.valid


@pytest.mark.security
def test_backup_failure_stops_the_migration(tmp_path: Path, monkeypatch) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    scripts = scripts_with_0002(tmp_path, "    op.execute('CREATE TABLE phase_test (id INTEGER)')")

    def failing_replace(source: object, target: object) -> None:
        raise OSError("disk full")

    monkeypatch.setattr(migrator.os, "replace", failing_replace)
    with pytest.raises(DatabaseError) as error:
        initialize_database(path, tmp_path / "backups", clock=_clock, script_location=scripts)

    assert error.value.code == "DATABASE_BACKUP_FAILED"
    assert raw_rows(path, "SELECT version_num FROM alembic_version") == [(HEAD,)]
    assert list((tmp_path / "backups").iterdir()) == []


def test_safety_copy_never_overwrites_an_existing_copy(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    first = create_safety_copy(path, tmp_path / "backups", HEAD, NOW)
    with pytest.raises(DatabaseError) as error:
        create_safety_copy(path, tmp_path / "backups", HEAD, NOW)
    assert error.value.code == "DATABASE_BACKUP_FAILED"
    assert first.exists()


def test_safety_copy_is_verified_against_the_expected_revision(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    with pytest.raises(DatabaseError) as error:
        create_safety_copy(path, tmp_path / "backups", "0099_other", NOW)
    assert error.value.code == "DATABASE_BACKUP_FAILED"
    assert list((tmp_path / "backups").iterdir()) == []


def test_safety_copy_is_consistent_while_another_connection_writes(tmp_path: Path) -> None:
    """The backup API copies a committed snapshot, never a half-written file."""
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    writer = sqlite3.connect(path, isolation_level=None)
    try:
        writer.execute("BEGIN IMMEDIATE")
        writer.execute("CREATE TABLE uncommitted (id INTEGER)")
        copy = create_safety_copy(path, tmp_path / "backups", HEAD, NOW)
        writer.execute("ROLLBACK")
    finally:
        writer.close()
    tables = raw_rows(copy, "SELECT name FROM sqlite_master WHERE name = 'uncommitted'")
    assert tables == []
    assert raw_rows(copy, "PRAGMA integrity_check") == [("ok",)]


@pytest.mark.security
def test_newer_schema_is_refused_without_changes(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    scripts = scripts_with_0002(tmp_path, "    op.execute('CREATE TABLE phase_test (id INTEGER)')")
    initialize_database(path, tmp_path / "backups", clock=_clock, script_location=scripts)
    content = path.read_bytes()

    with pytest.raises(DatabaseError) as error:
        initialize_database(path, tmp_path / "backups", clock=_clock)

    assert error.value.code == "DATABASE_NEWER_SCHEMA"
    assert path.read_bytes() == content
    assert not list((tmp_path / "backups").glob("*.sqlite3"))


@pytest.mark.security
@pytest.mark.parametrize(
    "setup",
    [
        "CREATE TABLE customers (id INTEGER PRIMARY KEY, name TEXT)",
        "CREATE TABLE alembic_version (version_num VARCHAR(32) NOT NULL)",
        "CREATE TABLE alembic_version (version_num VARCHAR(32));"
        " INSERT INTO alembic_version VALUES ('a'), ('b')",
    ],
    ids=["foreign_tables", "no_version_row", "two_version_rows"],
)
def test_foreign_sqlite_database_is_refused_unchanged(tmp_path: Path, setup: str) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    connection = sqlite3.connect(path)
    connection.executescript(setup)
    connection.close()
    content = path.read_bytes()

    with pytest.raises(DatabaseError) as error:
        initialize_database(path, tmp_path / "backups")

    assert error.value.code == "DATABASE_UNRECOGNIZED"
    assert path.read_bytes() == content
    assert sorted(item.name for item in tmp_path.iterdir()) == ["invoiceflow.sqlite3"]


@pytest.mark.security
def test_file_that_is_not_a_database_is_refused_unchanged(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    content = b"Dette er ikke en database. " * 200
    path.write_bytes(content)
    with pytest.raises(DatabaseError) as error:
        initialize_database(path, tmp_path / "backups")
    assert error.value.code == "DATABASE_UNRECOGNIZED"
    assert path.read_bytes() == content


@pytest.mark.security
def test_corrupt_database_is_refused_unchanged(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    connection = sqlite3.connect(path)
    connection.execute("PRAGMA journal_mode=DELETE")
    connection.close()
    data = bytearray(path.read_bytes())
    page_size = int.from_bytes(data[16:18], "big")
    # Overwrite the second page (the first table's b-tree) with garbage.
    data[page_size : 2 * page_size] = b"\xff" * page_size
    path.write_bytes(bytes(data))

    with pytest.raises(DatabaseError) as error:
        initialize_database(path, tmp_path / "backups")

    assert error.value.code in {"DATABASE_INTEGRITY_FAILED", "DATABASE_UNRECOGNIZED"}
    assert path.read_bytes() == bytes(data)
    assert not (tmp_path / "backups").exists()


@pytest.mark.security
def test_symlinked_database_is_refused(tmp_path: Path) -> None:
    target = tmp_path / "elsewhere.sqlite3"
    target.touch()
    link = tmp_path / "invoiceflow.sqlite3"
    try:
        link.symlink_to(target)
    except OSError:
        pytest.skip("symbolic links are not available")
    with pytest.raises(DatabaseError) as error:
        initialize_database(link, tmp_path / "backups")
    assert error.value.code == "DATABASE_UNAVAILABLE"


def test_broken_script_directory_is_reported_as_migration_failure(tmp_path: Path) -> None:
    with pytest.raises(DatabaseError) as error:
        initialize_database(
            tmp_path / "x.sqlite3", tmp_path / "backups", script_location=tmp_path / "missing"
        )
    assert error.value.code == "DATABASE_MIGRATION_FAILED"
    assert not (tmp_path / "x.sqlite3").exists()


@pytest.mark.security
def test_startup_refuses_a_database_with_a_broken_audit_chain(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    connection = sqlite3.connect(path)
    connection.execute("DROP TRIGGER audit_events_no_update")
    connection.execute("UPDATE audit_events SET actor = 'system/forged'")
    connection.commit()
    connection.close()
    with pytest.raises(DatabaseError) as error:
        initialize_database(path, tmp_path / "backups")
    assert error.value.code == "AUDIT_CHAIN_INVALID"


def test_safety_copy_is_a_single_self_contained_file(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    copy = create_safety_copy(path, tmp_path / "backups", HEAD, NOW)
    assert [item.name for item in (tmp_path / "backups").iterdir()] == [copy.name]
    assert raw_rows(copy, "PRAGMA journal_mode") == [("delete",)]


@pytest.mark.security
def test_valid_sql_migration_with_damaged_chain_rolls_back(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(path, tmp_path / "backups", clock=_clock)
    before = raw_rows(path, "SELECT sql FROM sqlite_master ORDER BY name")
    scripts = scripts_with_0002(
        tmp_path,
        "    op.execute('DROP TRIGGER audit_events_no_update')\n"
        "    op.execute(\"UPDATE audit_events SET actor = 'system/forged'\")",
    )
    with pytest.raises(DatabaseError, match="DATABASE_MIGRATION_FAILED"):
        initialize_database(path, tmp_path / "backups", clock=_clock, script_location=scripts)
    assert raw_rows(path, "SELECT sql FROM sqlite_master ORDER BY name") == before
    assert raw_rows(path, "SELECT version_num FROM alembic_version") == [(HEAD,)]
    assert raw_rows(path, "SELECT actor FROM audit_events") == [("system",)]
    assert initialize_database(path, tmp_path / "backups").audit.valid
    assert len(list((tmp_path / "backups").glob("*.sqlite3"))) == 1


@pytest.mark.security
def test_foreign_database_with_known_revision_is_refused_without_writes(tmp_path: Path) -> None:
    path = tmp_path / "invoiceflow.sqlite3"
    with closing(sqlite3.connect(path)) as connection:
        connection.executescript(
            "CREATE TABLE customers (id INTEGER);"
            "CREATE TABLE alembic_version (version_num VARCHAR(32));"
            "INSERT INTO alembic_version VALUES ('0001_initial');"
        )
    before = path.read_bytes()
    with pytest.raises(DatabaseError, match="DATABASE_UNRECOGNIZED"):
        initialize_database(path, tmp_path / "backups")
    assert path.read_bytes() == before
    assert sorted(item.name for item in tmp_path.iterdir()) == ["invoiceflow.sqlite3"]


def scripts_at_0001(tmp_path: Path) -> Path:
    """The migrations as shipped in Phase 02 (only 0001_initial)."""
    location = tmp_path / "migrations-0001"
    shutil.copytree(MIGRATIONS_DIR, location, ignore=shutil.ignore_patterns("__pycache__"))
    for script in (location / "versions").glob("*.py"):
        if not script.name.startswith("0001_"):
            script.unlink()
    return location


def phase02_database(tmp_path: Path) -> Path:
    from invoiceflow.application.services import EntityService

    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_at_0001(tmp_path)
    )
    database = Database(path)
    try:
        EntityService(database.unit_of_work).create(name="Syntetisk enhet AS")
    finally:
        database.close()
    return path


def test_phase02_database_is_migrated_to_0002_with_its_audit_chain(tmp_path: Path) -> None:
    path = phase02_database(tmp_path)
    before = raw_rows(path, "SELECT * FROM audit_events ORDER BY sequence")

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    # One safety copy, then every later migration (0002, 0003, ...) in one transaction.
    assert (result.migrated_from, result.revision) == ("0001_initial", HEAD)
    assert result.backup_path is not None and result.backup_path.exists()
    after = raw_rows(path, "SELECT * FROM audit_events ORDER BY sequence")
    assert after[: len(before)] == before  # every stored event copied unchanged
    assert [row[4] for row in after] == ["database.created", "entity.created", "database.migrated"]
    assert result.audit.valid and result.audit.events_checked == 3
    tables = {row[0] for row in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"documents", "document_links"} <= tables
    triggers = {
        row[0] for row in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='trigger'")
    }
    assert {
        "audit_events_no_update",
        "audit_events_no_delete",
        "audit_events_extend_chain",
        "documents_no_delete",
        "documents_immutable",
        "invoices_reference_document",
    } <= triggers


@pytest.mark.security
def test_migration_0002_refuses_existing_invoices_and_keeps_the_original(tmp_path: Path) -> None:
    from invoiceflow.application.scope import EntityScope
    from invoiceflow.application.services import EntityService
    from invoiceflow.bootstrap.persistence import synthetic_invoice

    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_at_0001(tmp_path)
    )
    database = Database(path)
    try:
        entity = EntityService(database.unit_of_work).create(name="Syntetisk enhet AS")
        # A Phase 02 invoice, written as Phase 02 did (no documents table yet).
        with database.unit_of_work() as uow:
            uow.invoices(EntityScope(entity.entity_id)).add(
                invoice_id=uuid4(), invoice=synthetic_invoice(), recorded_at=NOW, actor="system"
            )
            uow.commit()
    finally:
        database.close()
    before = raw_rows(path, "SELECT sql FROM sqlite_master ORDER BY name")

    with pytest.raises(DatabaseError) as error:
        initialize_database(path, tmp_path / "backups", clock=_clock)

    assert error.value.code == "DATABASE_MIGRATION_FAILED"
    assert raw_rows(path, "SELECT sql FROM sqlite_master ORDER BY name") == before
    assert raw_rows(path, "SELECT version_num FROM alembic_version") == [("0001_initial",)]
    assert len(list((tmp_path / "backups").glob("*.sqlite3"))) == 1


def test_audit_events_accept_document_subjects_after_0002(database: Database) -> None:
    with database.engine.connect() as connection, connection.begin():
        sql = connection.exec_driver_sql(
            "SELECT sql FROM sqlite_master WHERE name = 'audit_events'"
        ).scalar_one()
    assert "'document'" in sql


def scripts_up_to(tmp_path: Path, last: str) -> Path:
    """The migrations as shipped up to and including revision ``last``."""
    location = tmp_path / f"migrations-{last}"
    shutil.copytree(MIGRATIONS_DIR, location, ignore=shutil.ignore_patterns("__pycache__"))
    for script in (location / "versions").glob("*.py"):
        if script.name.split("_", 1)[0] > last:
            script.unlink()
    return location


def test_phase03_database_is_migrated_to_the_head_unchanged(tmp_path: Path) -> None:
    from invoiceflow.application.documents import DocumentService
    from invoiceflow.application.scope import EntityScope
    from invoiceflow.application.services import EntityService
    from invoiceflow.bootstrap.synthetic_pdf import text_pdf
    from invoiceflow.documents.store import FileDocumentStore

    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_up_to(tmp_path, "0002")
    )
    database = Database(path)
    try:
        entity = EntityService(database.unit_of_work).create(name="Syntetisk enhet AS")
        source = tmp_path / "faktura.pdf"
        source.write_bytes(text_pdf(["F03"]))
        DocumentService(
            database.unit_of_work, FileDocumentStore(tmp_path / "documents")
        ).import_file(EntityScope(entity.entity_id), source)
    finally:
        database.close()
    documents_before = raw_rows(path, "SELECT * FROM documents")
    events_before = raw_rows(path, "SELECT * FROM audit_events ORDER BY sequence")

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    assert (result.migrated_from, result.revision) == ("0002_documents", HEAD)
    assert result.audit.valid and result.backup_path is not None
    assert raw_rows(path, "SELECT * FROM documents") == documents_before
    assert raw_rows(path, "SELECT * FROM audit_events ORDER BY sequence")[:-1] == events_before
    tables = {row[0] for row in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"processing_jobs", "document_pages", "derived_files"} <= tables


@contextlib.contextmanager
def _pages_without_metrics():
    """Current code on an older schema: page metrics exist only from 0010."""
    import dataclasses
    from unittest.mock import patch

    from invoiceflow.persistence.repositories import SqlProcessingRepository

    original = SqlProcessingRepository.add_pages

    def add_pages(self, pages):
        stripped = [
            dataclasses.replace(page, dark_permille=None, center_dark_permille=None)
            for page in pages
        ]
        return original(self, stripped)

    with patch.object(SqlProcessingRepository, "add_pages", add_pages):
        yield


def _phase04_database(tmp_path: Path) -> Path:
    """A database at 0003 with a document, a finished job, pages and files."""
    import sys

    from invoiceflow.application.documents import DocumentService
    from invoiceflow.application.processing import ProcessingService
    from invoiceflow.application.scope import EntityScope
    from invoiceflow.application.services import EntityService
    from invoiceflow.bootstrap.synthetic_pdf import text_pdf
    from invoiceflow.documents.derived import FileDerivedStore
    from invoiceflow.documents.store import FileDocumentStore

    support = str(Path(__file__).resolve().parents[2] / "support")
    if support not in sys.path:
        sys.path.insert(0, support)
    from processing_fakes import InProcessProcessor

    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_up_to(tmp_path, "0003")
    )
    database = Database(path)
    try:
        scope = EntityScope(EntityService(database.unit_of_work).create(name="F04 AS").entity_id)
        store = FileDocumentStore(tmp_path / "documents")
        source = tmp_path / "f04.pdf"
        source.write_bytes(text_pdf(["F04", "side to"]))
        document_id = (
            DocumentService(database.unit_of_work, store).import_file(scope, source).document_id
        )
        with _pages_without_metrics():
            ProcessingService(
                database.unit_of_work,
                store,
                FileDerivedStore(tmp_path / "documents"),
                InProcessProcessor(),
            ).process(scope, document_id)
    finally:
        database.close()
    return path


QUERIES_0004 = {
    "documents": "SELECT * FROM documents ORDER BY 1",
    "processing_jobs": "SELECT * FROM processing_jobs ORDER BY 1",
    # The columns of 0003; 0010 adds page metrics (NULL for these rows).
    "document_pages": "SELECT entity_id, document_id, job_id, page_number, width_px, height_px,"
    " rotation_degrees, has_text_layer, text_layer_chars FROM document_pages ORDER BY 1, 2, 3, 4",
    "derived_files": "SELECT * FROM derived_files ORDER BY 1",
    "audit_events": "SELECT * FROM audit_events ORDER BY 1",
}


def test_phase04_database_is_migrated_to_the_head_unchanged(tmp_path: Path) -> None:
    path = _phase04_database(tmp_path)
    before = {table: raw_rows(path, query) for table, query in QUERIES_0004.items()}
    assert len(before["document_pages"]) == 2 and len(before["derived_files"]) == 4

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    assert (result.migrated_from, result.revision) == ("0003_processing", HEAD)
    assert result.audit.valid and result.backup_path is not None
    for table, query in QUERIES_0004.items():
        after = raw_rows(path, query)
        expected = before[table]
        assert (after[: len(expected)] if table == "audit_events" else after) == expected, table
    assert raw_rows(path, "PRAGMA foreign_key_check") == []
    assert raw_rows(path, "PRAGMA integrity_check") == [("ok",)]
    triggers = {r[0] for r in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='trigger'")}
    assert {
        "documents_no_delete",
        "documents_immutable",
        "processing_jobs_stored_document",
        "processing_jobs_no_delete",
        "processing_jobs_transition",
        "document_pages_running_job",
        "invoice_findings_no_update",
        "invoice_findings_no_delete",
    } <= triggers
    # Foreign keys are on again for every new connection and still enforced.
    database = Database(path)
    try:
        assert database.settings()["foreign_keys"] == 1
        with (
            database.engine.connect() as connection,
            connection.begin(),
            pytest.raises(sa.exc.IntegrityError),
        ):
            connection.exec_driver_sql(
                "INSERT INTO document_links VALUES (?, ?, ?, 'related', ?, 'system')",
                ("a" * 32, "b" * 32, "c" * 32, "2026-10-23T00:00:00.000000Z"),
            )
    finally:
        database.close()


@pytest.mark.security
def test_a_dangling_reference_stops_migration_0004_and_keeps_the_original(tmp_path: Path) -> None:
    path = _phase04_database(tmp_path)
    connection = sqlite3.connect(path)
    try:
        # Damage written without foreign keys: a link to a document that does not exist.
        connection.execute("PRAGMA foreign_keys = OFF")
        entity = connection.execute("SELECT entity_id FROM documents").fetchone()[0]
        document = connection.execute("SELECT id FROM documents").fetchone()[0]
        connection.execute(
            "INSERT INTO document_links VALUES (?, ?, ?, 'related', ?, 'system')",
            (entity, document, "f" * 32, "2026-10-23T00:00:00.000000Z"),
        )
        connection.commit()
    finally:
        connection.close()
    before = raw_rows(path, "SELECT sql FROM sqlite_master ORDER BY name")

    with pytest.raises(DatabaseError) as error:
        initialize_database(path, tmp_path / "backups", clock=_clock)

    assert error.value.code == "DATABASE_MIGRATION_FAILED"
    assert raw_rows(path, "SELECT sql FROM sqlite_master ORDER BY name") == before
    assert raw_rows(path, "SELECT version_num FROM alembic_version") == [("0003_processing",)]


def _phase15_database(tmp_path: Path) -> Path:
    """A database at 0004 with an EHF invoice, its findings and an attachment."""
    import sys

    from invoiceflow.application.documents import DocumentService
    from invoiceflow.application.processing import ProcessingService
    from invoiceflow.application.scope import EntityScope
    from invoiceflow.application.services import EntityService
    from invoiceflow.bootstrap.synthetic_ehf import Attachment, SyntheticEhf, build_ehf
    from invoiceflow.bootstrap.synthetic_pdf import text_pdf
    from invoiceflow.documents.derived import FileDerivedStore
    from invoiceflow.documents.store import FileDocumentStore

    support = str(Path(__file__).resolve().parents[2] / "support")
    if support not in sys.path:
        sys.path.insert(0, support)
    from processing_fakes import InProcessProcessor

    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_up_to(tmp_path, "0004")
    )
    database = Database(path)
    try:
        entities = EntityService(database.unit_of_work)
        scope = EntityScope(entities.create(name="F15 AS", org_number="987654325").entity_id)
        store = FileDocumentStore(tmp_path / "documents")
        documents = DocumentService(database.unit_of_work, store)
        source = tmp_path / "faktura.xml"
        source.write_bytes(build_ehf(SyntheticEhf(attachments=(Attachment(text_pdf(["V"])),))))
        document_id = documents.import_file(scope, source).document_id
        with _pages_without_metrics():
            ProcessingService(
                database.unit_of_work,
                store,
                FileDerivedStore(tmp_path / "documents"),
                InProcessProcessor(),
                attachments=documents,
            ).process(scope, document_id)
    finally:
        database.close()
    return path


QUERIES_0005 = {
    "documents": "SELECT * FROM documents ORDER BY 1",
    "document_links": "SELECT * FROM document_links ORDER BY 1, 2, 3",
    "invoices": "SELECT * FROM invoices ORDER BY 1",
    "invoice_revisions": "SELECT * FROM invoice_revisions ORDER BY 1, 2",
    "invoice_findings": "SELECT * FROM invoice_findings ORDER BY 1, 2, 3",
    "audit_events": "SELECT * FROM audit_events ORDER BY 1",
}


def test_phase15_database_is_migrated_to_0005_unchanged(tmp_path: Path) -> None:
    path = _phase15_database(tmp_path)
    before = {table: raw_rows(path, query) for table, query in QUERIES_0005.items()}
    assert len(before["invoices"]) == 1 and before["invoice_findings"]

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    assert (result.migrated_from, result.revision) == ("0004_ehf", HEAD)
    assert result.audit.valid and result.backup_path is not None
    for table, query in QUERIES_0005.items():
        after = raw_rows(path, query)
        expected = before[table]
        assert (after[: len(expected)] if table == "audit_events" else after) == expected, table
    assert raw_rows(path, "PRAGMA foreign_key_check") == []
    assert raw_rows(path, "PRAGMA integrity_check") == [("ok",)]
    triggers = {r[0] for r in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='trigger'")}
    assert {
        "audit_events_no_update",
        "audit_events_no_delete",
        "audit_events_extend_chain",
        "suppliers_no_update",
        "supplier_bank_accounts_status_only",
        "validation_runs_no_delete",
        "validation_results_no_update",
    } <= triggers
    sql = raw_rows(path, "SELECT sql FROM sqlite_master WHERE name = 'audit_events'")[0][0]
    assert "'supplier'" in sql


def _phase08a_database(tmp_path: Path) -> Path:
    """A database at 0005 with an EHF invoice, a supplier, an account and a validation run."""
    import sys
    from unittest.mock import patch

    from invoiceflow.application.documents import DocumentService
    from invoiceflow.application.processing import ProcessingService
    from invoiceflow.application.reference.model import EMPTY_REFERENCE
    from invoiceflow.application.scope import EntityScope
    from invoiceflow.application.services import EntityService
    from invoiceflow.application.validation.service import ValidationService
    from invoiceflow.bootstrap.synthetic_ehf import build_ehf
    from invoiceflow.documents.derived import FileDerivedStore
    from invoiceflow.documents.store import FileDocumentStore
    from invoiceflow.persistence.repositories import SqlReferenceRepository

    support = str(Path(__file__).resolve().parents[2] / "support")
    if support not in sys.path:
        sys.path.insert(0, support)
    from processing_fakes import InProcessProcessor

    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_up_to(tmp_path, "0005")
    )
    database = Database(path)
    try:
        scope = EntityScope(EntityService(database.unit_of_work).create(name="F08 AS").entity_id)
        store = FileDocumentStore(tmp_path / "documents")
        documents = DocumentService(database.unit_of_work, store)
        source = tmp_path / "faktura.xml"
        source.write_bytes(build_ehf())
        document_id = documents.import_file(scope, source).document_id
        # The 0005 schema has no reference tables yet: validate as Phase 08a did.
        with (
            patch.object(SqlReferenceRepository, "current", lambda self: EMPTY_REFERENCE),
            _pages_without_metrics(),
        ):
            ProcessingService(
                database.unit_of_work,
                store,
                FileDerivedStore(tmp_path / "documents"),
                InProcessProcessor(),
                attachments=documents,
                validator=ValidationService(database.unit_of_work),
            ).process(scope, document_id)
    finally:
        database.close()
    return path


QUERIES_0006 = {
    "invoices": "SELECT * FROM invoices ORDER BY 1",
    "invoice_revisions": "SELECT * FROM invoice_revisions ORDER BY 1, 2",
    "suppliers": "SELECT * FROM suppliers ORDER BY 1",
    "supplier_bank_accounts": "SELECT * FROM supplier_bank_accounts ORDER BY 1",
    "validation_runs": "SELECT * FROM validation_runs ORDER BY 1",
    "validation_results": "SELECT * FROM validation_results ORDER BY 1, 2, 3",
    "audit_events": "SELECT * FROM audit_events ORDER BY 1",
}


def test_phase08a_database_is_migrated_to_0006_unchanged(tmp_path: Path) -> None:
    path = _phase08a_database(tmp_path)
    before = {table: raw_rows(path, query) for table, query in QUERIES_0006.items()}
    assert before["validation_runs"] and before["supplier_bank_accounts"]

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    assert (result.migrated_from, result.revision) == ("0005_validation", HEAD)
    assert result.audit.valid and result.backup_path is not None
    for table, query in QUERIES_0006.items():
        after = raw_rows(path, query)
        expected = before[table]
        assert (after[: len(expected)] if table == "audit_events" else after) == expected, table
    assert raw_rows(path, "PRAGMA foreign_key_check") == []
    triggers = {r[0] for r in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='trigger'")}
    assert {
        "reference_imports_no_update",
        "chart_of_accounts_import_kind",
        "vat_codes_import_kind",
        "dimension_values_import_kind",
        "supplier_defaults_no_delete",
    } <= triggers


def _phase08b_database(tmp_path: Path) -> Path:
    """A database at 0006 with reference data, standard posting and a posted invoice."""
    import sys

    from invoiceflow.application.documents import DocumentService
    from invoiceflow.application.processing import ProcessingService
    from invoiceflow.application.reference.model import ReferenceKind
    from invoiceflow.application.reference.service import ReferenceService
    from invoiceflow.application.scope import EntityScope
    from invoiceflow.application.services import EntityService
    from invoiceflow.application.validation.service import ValidationService
    from invoiceflow.bootstrap.synthetic_ehf import build_ehf
    from invoiceflow.bootstrap.synthetic_reference import CHART_CSV, VAT_CODES_CSV
    from invoiceflow.documents.derived import FileDerivedStore
    from invoiceflow.documents.store import FileDocumentStore

    support = str(Path(__file__).resolve().parents[2] / "support")
    if support not in sys.path:
        sys.path.insert(0, support)
    from processing_fakes import InProcessProcessor

    path = tmp_path / "invoiceflow.sqlite3"
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_up_to(tmp_path, "0006")
    )
    database = Database(path)
    try:
        scope = EntityScope(EntityService(database.unit_of_work).create(name="F08b AS").entity_id)
        validation = ValidationService(database.unit_of_work)
        references = ReferenceService(database.unit_of_work, validator=validation)
        for kind, text in (
            (ReferenceKind.CHART, CHART_CSV),
            (ReferenceKind.VAT_CODES, VAT_CODES_CSV),
        ):
            source = tmp_path / f"{kind}.csv"
            source.write_text(text, encoding="utf-8")
            references.import_file(scope, kind, source)
        store = FileDocumentStore(tmp_path / "documents")
        documents = DocumentService(database.unit_of_work, store)
        source = tmp_path / "faktura.xml"
        source.write_bytes(build_ehf())
        document_id = documents.import_file(scope, source).document_id
        with _pages_without_metrics():
            ProcessingService(
                database.unit_of_work,
                store,
                FileDerivedStore(tmp_path / "documents"),
                InProcessProcessor(),
                attachments=documents,
                validator=validation,
                poster=references,
            ).process(scope, document_id)
        (view,) = validation.suppliers(scope)
        references.set_defaults(scope, view.supplier.supplier_id, account="6300", vat_code="1")
    finally:
        database.close()
    return path


QUERIES_0007 = {
    "invoices": "SELECT * FROM invoices ORDER BY 1",
    "invoice_revisions": "SELECT * FROM invoice_revisions ORDER BY 1, 2",
    "reference_imports": "SELECT * FROM reference_imports ORDER BY 1",
    "chart_of_accounts": "SELECT * FROM chart_of_accounts ORDER BY 1, 2, 3",
    "vat_codes": "SELECT * FROM vat_codes ORDER BY 1, 2, 3, 4",
    "supplier_defaults": "SELECT * FROM supplier_defaults ORDER BY 1",
    "validation_runs": "SELECT * FROM validation_runs ORDER BY 1",
    "audit_events": "SELECT * FROM audit_events ORDER BY 1",
}


def test_phase08b_database_is_migrated_to_0007_unchanged(tmp_path: Path) -> None:
    path = _phase08b_database(tmp_path)
    before = {table: raw_rows(path, query) for table, query in QUERIES_0007.items()}
    assert before["supplier_defaults"] and len(before["invoice_revisions"]) == 2

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    assert (result.migrated_from, result.revision) == ("0006_reference", HEAD)
    assert result.audit.valid and result.backup_path is not None
    for table, query in QUERIES_0007.items():
        after = raw_rows(path, query)
        expected = before[table]
        assert (after[: len(expected)] if table == "audit_events" else after) == expected, table
    assert raw_rows(path, "PRAGMA foreign_key_check") == []
    triggers = {r[0] for r in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='trigger'")}
    assert {
        "approvals_current_content",
        "approvals_next_in_sequence",
        "finding_overrides_no_delete",
        "invoices_approved_needs_approval",
        "invoices_approved_content_frozen",
    } <= triggers


QUERIES_0008 = {
    **QUERIES_0007,
    "approvals": "SELECT * FROM approvals ORDER BY 1",
    "finding_overrides": "SELECT * FROM finding_overrides ORDER BY 1",
}


def test_phase09_database_is_migrated_to_0008_and_can_export(tmp_path: Path) -> None:
    from invoiceflow.application.export.model import ExportTarget
    from invoiceflow.application.export.service import ExportService
    from invoiceflow.application.review.service import ReviewService
    from invoiceflow.application.scope import EntityScope
    from invoiceflow.application.services import InvoiceService
    from invoiceflow.application.validation.model import AccountStatus
    from invoiceflow.application.validation.service import ValidationService
    from invoiceflow.export.csv_writer import CsvWriter
    from invoiceflow.export.files import FileExportStore
    from invoiceflow.i18n import t

    path = _phase08b_database(tmp_path)
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_up_to(tmp_path, "0007")
    )
    (scope_id,) = {row[0] for row in raw_rows(path, "SELECT entity_id FROM invoices")}
    scope = EntityScope(UUID(hex=scope_id))
    database = Database(path)
    try:
        (summary,) = InvoiceService(database.unit_of_work).summaries(scope).values()
        validation = ValidationService(database.unit_of_work)
        ((account,),) = [view.accounts for view in validation.suppliers(scope)]
        validation.set_account_status(
            scope, account.account_id, AccountStatus.VERIFIED, expected=AccountStatus.UNVERIFIED
        )
        ReviewService(database.unit_of_work, validation).approve(
            scope, summary.invoice_id, expected_revision=2
        )
    finally:
        database.close()
    before = {table: raw_rows(path, query) for table, query in QUERIES_0008.items()}
    assert before["approvals"]

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    assert (result.migrated_from, result.revision) == ("0007_review", HEAD)
    assert result.audit.valid and result.backup_path is not None
    for table, query in QUERIES_0008.items():
        after = raw_rows(path, query)
        expected = before[table]
        assert (after[: len(expected)] if table == "audit_events" else after) == expected, table
    assert raw_rows(path, "PRAGMA foreign_key_check") == []
    triggers = {r[0] for r in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='trigger'")}
    assert {
        "export_items_approved_content",
        "export_items_start_pending",
        "export_batches_finish_once",
        "invoices_exported_needs_export",
        "invoices_exported_frozen",
        "invoices_pending_export_frozen",
        "approvals_closed_by_export",
    } <= triggers
    database = Database(path)
    try:
        batch = ExportService(
            database.unit_of_work,
            {ExportTarget.CSV: CsvWriter()},
            FileExportStore(tmp_path / "exports"),
            t,
        ).export(scope, ExportTarget.CSV)
    finally:
        database.close()
    assert batch.item_count == 1


def test_phase10_database_is_migrated_to_0009_unchanged(tmp_path: Path) -> None:
    path = _phase08b_database(tmp_path)
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_up_to(tmp_path, "0008")
    )
    queries = {
        **QUERIES_0008,
        "export_batches": "SELECT * FROM export_batches ORDER BY 1",
        "export_mappings": "SELECT * FROM export_mappings ORDER BY 1",
    }
    before = {table: raw_rows(path, query) for table, query in queries.items()}

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    assert (result.migrated_from, result.revision) == ("0008_export", HEAD)
    assert result.audit.valid and result.backup_path is not None
    for table, query in queries.items():
        after = raw_rows(path, query)
        expected = before[table]
        assert (after[: len(expected)] if table == "audit_events" else after) == expected, table
    triggers = {r[0] for r in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='trigger'")}
    assert {"backups_delete_once", "backups_no_delete"} <= triggers
    assert raw_rows(path, "SELECT COUNT(*) FROM backups") == [(0,)]


def test_phase04_pages_get_empty_metrics_in_0010(tmp_path: Path) -> None:
    path = _phase04_database(tmp_path)
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_up_to(tmp_path, "0009")
    )
    before = raw_rows(path, QUERIES_0004["document_pages"])

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    assert (result.migrated_from, result.revision) == ("0009_backup", HEAD)
    assert raw_rows(path, QUERIES_0004["document_pages"]) == before
    assert raw_rows(
        path, "SELECT DISTINCT dark_permille, center_dark_permille FROM document_pages"
    ) == [(None, None)]
    with closing(sqlite3.connect(path)) as connection, pytest.raises(sqlite3.IntegrityError):
        connection.execute("UPDATE document_pages SET dark_permille = 1001")


def test_jobs_survive_the_rebuild_for_ocr_in_0011(tmp_path: Path) -> None:
    path = _phase04_database(tmp_path)
    initialize_database(
        path, tmp_path / "backups", clock=_clock, script_location=scripts_up_to(tmp_path, "0010")
    )
    before = {table: raw_rows(path, query) for table, query in QUERIES_0004.items()}

    result = initialize_database(path, tmp_path / "backups", clock=_clock)

    assert (result.migrated_from, result.revision) == ("0010_page_metrics", HEAD)
    after = {table: raw_rows(path, query) for table, query in QUERIES_0004.items()}
    audit_before, audit_after = before.pop("audit_events"), after.pop("audit_events")
    assert after == before
    assert audit_after[: len(audit_before)] == audit_before  # plus database.migrated
    triggers = {r[0] for r in raw_rows(path, "SELECT name FROM sqlite_master WHERE type='trigger'")}
    assert {
        "processing_jobs_transition",
        "processing_jobs_no_delete",
        "processing_jobs_stored_document",
        "ocr_pages_running_job",
        "ocr_pages_no_update",
        "ocr_pages_no_delete",
        "document_pages_running_job",
    } <= triggers
    assert raw_rows(path, "PRAGMA foreign_key_check") == []
    with closing(sqlite3.connect(path)) as connection, pytest.raises(sqlite3.IntegrityError):
        connection.execute("UPDATE processing_jobs SET step = 'translation'")
