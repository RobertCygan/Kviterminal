"""Document import end to end: real SQLite, real files, audit and crash recovery."""

import hashlib
import json
import os
import threading
from pathlib import Path
from uuid import uuid4

import pytest
from sqlalchemy.exc import IntegrityError

from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentStatus,
    DocumentType,
    ImportOutcome,
    ImportSource,
    IntegrityStatus,
    QuarantineReason,
    RejectReason,
)
from invoiceflow.application.documents import DocumentService
from invoiceflow.application.errors import NotFoundError, StorageError
from invoiceflow.application.ports import StoreRecovery
from invoiceflow.application.scope import EntityScope
from invoiceflow.documents.store import FileDocumentStore
from invoiceflow.persistence.database import Database
from invoiceflow.persistence.repositories import SqlAuditLog, SqlDocumentRepository

pytestmark = pytest.mark.integration

Scopes = tuple[EntityScope, EntityScope]

SAMPLES = {
    "faktura.pdf": (b"%PDF-1.4\n% syntetisk faktura\n%%EOF\n", DocumentFormat.PDF),
    "kvittering.png": (b"\x89PNG\r\n\x1a\n syntetisk", DocumentFormat.PNG),
    "skann.jpg": (b"\xff\xd8\xff\xe0 syntetisk", DocumentFormat.JPEG),
    "skann.tif": (b"II*\x00 syntetisk", DocumentFormat.TIFF),
}


@pytest.fixture
def scopes(entities) -> Scopes:
    """Two entities without any documents (overrides the invoice fixture)."""
    first = entities.create(name="Syntetisk enhet A AS")
    second = entities.create(name="Syntetisk enhet B AS")
    return EntityScope(first.entity_id), EntityScope(second.entity_id)


@pytest.fixture
def store(tmp_path: Path) -> FileDocumentStore:
    root = tmp_path / "documents"
    root.mkdir()
    return FileDocumentStore(root, sleep=lambda _: None)


@pytest.fixture
def service(database: Database, store: FileDocumentStore) -> DocumentService:
    return DocumentService(database.unit_of_work, store, max_bytes=4096)


@pytest.fixture
def source_dir(tmp_path: Path) -> Path:
    directory = tmp_path / "kilde"
    directory.mkdir()
    return directory


def write(directory: Path, name: str, content: bytes) -> Path:
    path = directory / name
    path.write_bytes(content)
    return path


def audit_rows(database: Database) -> list[tuple[str, str, str]]:
    with database.engine.connect() as connection, connection.begin():
        return [
            tuple(row)
            for row in connection.exec_driver_sql(
                "SELECT event_type, subject_type, details_json FROM audit_events ORDER BY sequence"
            )
        ]


def chain_valid(database: Database) -> bool:
    with database.unit_of_work() as uow:
        return uow.audit.verify().valid


@pytest.mark.parametrize("name", sorted(SAMPLES))
def test_supported_formats_are_imported_unchanged(
    service, store, scopes: Scopes, source_dir, name
) -> None:
    owner, _ = scopes
    content, document_format = SAMPLES[name]
    source = write(source_dir, name, content)

    result = service.import_file(owner, source)

    assert result.outcome is ImportOutcome.IMPORTED
    record = service.get(owner, result.document_id)
    assert record.detected_format is document_format
    assert record.document_type is DocumentType.UNCLASSIFIED
    assert record.status is DocumentStatus.STORED
    assert record.sha256 == hashlib.sha256(content).hexdigest()
    assert record.display_name == name
    assert store.resolve(record.storage_path).read_bytes() == content
    assert name not in record.storage_path
    assert source.read_bytes() == content  # the source is always kept


def test_duplicates_are_per_entity(service, scopes: Scopes, source_dir, database) -> None:
    owner, other = scopes
    source = write(source_dir, "faktura.pdf", SAMPLES["faktura.pdf"][0])
    first = service.import_file(owner, source)
    again = service.import_file(owner, source)
    elsewhere = service.import_file(other, source)
    assert again.outcome is ImportOutcome.DUPLICATE and again.document_id == first.document_id
    assert elsewhere.outcome is ImportOutcome.IMPORTED
    assert elsewhere.document_id != first.document_id
    assert len(service.list_documents(owner)) == 1
    assert [row[0] for row in audit_rows(database)][-3:] == [
        "document.imported",
        "document.duplicate_rejected",
        "document.imported",
    ]


@pytest.mark.security
@pytest.mark.parametrize(
    ("name", "content", "reason"),
    [
        ("faktura.pdf", b"MZ\x90\x00 syntetisk program", QuarantineReason.UNKNOWN_FORMAT),
        ("faktura.pdf", b"\x89PNG\r\n\x1a\n forkledd", QuarantineReason.EXTENSION_MISMATCH),
        ("faktura.pdf.exe", b"%PDF-1.4 forkledd", QuarantineReason.EXTENSION_MISMATCH),
        ("faktura", b"%PDF-1.4 uten endelse", QuarantineReason.EXTENSION_MISMATCH),
    ],
    ids=["unknown", "disguised", "double_extension", "no_extension"],
)
def test_suspicious_files_are_quarantined(
    service, store, scopes: Scopes, source_dir, name, content, reason
) -> None:
    owner, _ = scopes
    result = service.import_file(owner, write(source_dir, name, content))
    assert (result.outcome, result.reason) == (ImportOutcome.QUARANTINED, reason)
    record = service.get(owner, result.document_id)
    assert record.status is DocumentStatus.QUARANTINED
    assert record.detected_format is None
    assert record.storage_path == f"{owner.entity_id.hex}/quarantine/{record.document_id.hex}.bin"
    assert store.resolve(record.storage_path).read_bytes() == content


@pytest.mark.security
def test_rejected_files_are_not_stored_but_audited(
    service, scopes: Scopes, source_dir, database, tmp_path
) -> None:
    owner, _ = scopes
    empty = service.import_file(owner, write(source_dir, "tom.pdf", b""))
    large = service.import_file(owner, write(source_dir, "stor.pdf", b"%PDF-" + b"x" * 5000))
    folder = service.import_file(owner, tmp_path)
    assert [(r.outcome, r.reason) for r in (empty, large, folder)] == [
        (ImportOutcome.REJECTED, RejectReason.EMPTY),
        (ImportOutcome.REJECTED, RejectReason.TOO_LARGE),
        (ImportOutcome.REJECTED, RejectReason.NOT_A_FILE),
    ]
    assert service.list_documents(owner) == []
    rejected = [json.loads(row[2]) for row in audit_rows(database) if row[0] == "document.rejected"]
    assert [row["reject_reason"] for row in rejected] == [
        "empty",
        "too_large",
        "not_a_regular_file",
    ]


@pytest.mark.security
def test_audit_contains_no_file_names_or_paths(
    service, scopes: Scopes, source_dir, database
) -> None:
    owner, _ = scopes
    name = "Nordlys Regnskap AS - faktura 2026-10045.pdf"
    service.import_file(owner, write(source_dir, name, SAMPLES["faktura.pdf"][0]))
    service.import_file(owner, write(source_dir, "Hemmelig.pdf", b"MZ syntetisk"))
    text = json.dumps(audit_rows(database))
    for fragment in ("Nordlys", "faktura", "Hemmelig", str(source_dir), "originals", ".pdf"):
        assert fragment not in text
    assert chain_valid(database)


@pytest.mark.security
def test_hostile_file_name_is_only_a_label(service, store, scopes: Scopes, source_dir) -> None:
    owner, _ = scopes
    name = "..‮fdp.exe"  # leading dots and a right-to-left override
    record = service.get(
        owner, service.import_file(owner, write(source_dir, name, b"MZ x")).document_id
    )
    assert record.display_name == "fdp.exe"
    assert store.resolve(record.storage_path).is_relative_to(store.root)


@pytest.mark.security
def test_another_entity_cannot_see_or_change_a_document(
    service, scopes: Scopes, source_dir
) -> None:
    owner, other = scopes
    result = service.import_file(owner, write(source_dir, "a.pdf", SAMPLES["faktura.pdf"][0]))
    for action in (
        lambda: service.get(other, result.document_id),
        lambda: service.set_type(other, result.document_id, DocumentType.INVOICE),
        lambda: service.get(owner, uuid4()),
    ):
        with pytest.raises(NotFoundError):
            action()
    assert service.list_documents(other) == []


def test_unknown_entity_cannot_import(service, source_dir) -> None:
    with pytest.raises(NotFoundError):
        service.import_file(EntityScope(uuid4()), write(source_dir, "a.pdf", b"%PDF-1.4"))


def test_type_change_is_audited_and_idempotent(
    service, scopes: Scopes, source_dir, database
) -> None:
    owner, _ = scopes
    result = service.import_file(owner, write(source_dir, "a.pdf", SAMPLES["faktura.pdf"][0]))
    updated = service.set_type(owner, result.document_id, DocumentType.RECEIPT)
    same = service.set_type(owner, result.document_id, DocumentType.RECEIPT)
    assert updated.document_type is same.document_type is DocumentType.RECEIPT
    changes = [json.loads(r[2]) for r in audit_rows(database) if r[0] == "document.type_changed"]
    assert changes == [{"document_type": "receipt", "previous_document_type": "unclassified"}]
    with pytest.raises(ValueError):
        service.set_type(owner, result.document_id, "faktura")  # type: ignore[arg-type]


def test_inbox_import_is_flat_and_keeps_sources(service, scopes: Scopes, tmp_path) -> None:
    owner, _ = scopes
    inbox = tmp_path / "innboks"
    (inbox / "undermappe").mkdir(parents=True)
    write(inbox, "faktura.pdf", SAMPLES["faktura.pdf"][0])
    write(inbox, "kvittering.png", SAMPLES["kvittering.png"][0])
    write(inbox / "undermappe", "skjult.pdf", b"%PDF-1.4 skjult")
    results = service.import_inbox(owner, inbox)
    assert [r.outcome for r in results] == [ImportOutcome.IMPORTED] * 2
    assert {d.source for d in service.list_documents(owner)} == {ImportSource.INBOX}
    assert sorted(p.name for p in inbox.iterdir()) == [
        "faktura.pdf",
        "kvittering.png",
        "undermappe",
    ]


@pytest.mark.security
def test_a_storage_failure_does_not_stop_the_rest_of_a_batch(
    service, store, scopes: Scopes, tmp_path, monkeypatch
) -> None:
    owner, _ = scopes
    inbox = tmp_path / "innboks"
    inbox.mkdir()
    write(inbox, "a.pdf", SAMPLES["faktura.pdf"][0])
    write(inbox, "b.png", SAMPLES["kvittering.png"][0])
    write(inbox, "c.jpg", SAMPLES["skann.jpg"][0])
    real_publish = store.publish

    def publish(staged, entity_id, sha256, extension):
        if extension == "png":
            raise StorageError("synthetic locked archive folder")
        return real_publish(staged, entity_id, sha256, extension)

    monkeypatch.setattr(store, "publish", publish)
    results = service.import_inbox(owner, inbox)
    assert [r.outcome for r in results] == [
        ImportOutcome.IMPORTED,
        ImportOutcome.FAILED,
        ImportOutcome.IMPORTED,
    ]
    assert len(service.list_documents(owner)) == 2
    assert not list(store.root.rglob("*.part"))  # the failed private copy was discarded
    monkeypatch.undo()
    # Nothing was stored for the failed file, so it can simply be imported again.
    assert service.import_file(owner, inbox / "b.png").outcome is ImportOutcome.IMPORTED


def test_a_batch_stops_between_files_when_asked(service, scopes: Scopes, tmp_path) -> None:
    owner, _ = scopes
    inbox = tmp_path / "innboks"
    inbox.mkdir()
    write(inbox, "a.pdf", SAMPLES["faktura.pdf"][0])
    write(inbox, "b.png", SAMPLES["kvittering.png"][0])
    write(inbox, "c.jpg", SAMPLES["skann.jpg"][0])
    asked = []

    def should_stop() -> bool:
        asked.append(True)
        return len(asked) > 1  # allowed before the first file, refused before the second

    results = service.import_inbox(owner, inbox, should_stop=should_stop)
    assert [r.outcome for r in results] == [ImportOutcome.IMPORTED]
    assert len(service.list_documents(owner)) == 1
    assert sorted(p.name for p in inbox.iterdir()) == ["a.pdf", "b.png", "c.jpg"]  # sources kept
    # Nothing is half done: the next run imports the rest.
    rest = service.import_inbox(owner, inbox)
    assert [r.outcome for r in rest] == [
        ImportOutcome.DUPLICATE,
        ImportOutcome.IMPORTED,
        ImportOutcome.IMPORTED,
    ]


def test_reconcile_reports_files_it_could_not_handle(
    service, store, scopes: Scopes, monkeypatch
) -> None:
    owner, _ = scopes
    monkeypatch.setattr(
        store,
        "recover",
        lambda entity_id, known: StoreRecovery(0, 0, frozenset(), failed=3),
    )
    assert service.reconcile(owner).failed == 3


# --- crash points ------------------------------------------------------------------


@pytest.mark.security
def test_crash_before_commit_leaves_an_orphan_that_is_recovered(
    service, store, scopes: Scopes, source_dir, database, monkeypatch
) -> None:
    owner, _ = scopes
    source = write(source_dir, "faktura.pdf", SAMPLES["faktura.pdf"][0])

    def crash(self, draft, *, occurred_at):
        raise RuntimeError("synthetic crash after publishing")

    monkeypatch.setattr(SqlAuditLog, "append", crash)
    with pytest.raises(RuntimeError):
        service.import_file(owner, source)
    monkeypatch.undo()

    # Published original, no row and no audit event.
    assert service.list_documents(owner) == []
    originals = list((store.root / owner.entity_id.hex / "originals").rglob("*.pdf"))
    assert len(originals) == 1
    report = service.reconcile(owner)
    assert (report.staging_removed, report.orphans_moved, report.missing) == (0, 1, ())
    assert not list((store.root / owner.entity_id.hex / "originals").rglob("*.pdf"))
    # The same file can be imported normally afterwards.
    assert service.import_file(owner, source).outcome is ImportOutcome.IMPORTED
    assert chain_valid(database)


@pytest.mark.security
def test_crash_after_staging_is_cleaned_up(
    service, store, scopes: Scopes, source_dir, monkeypatch
) -> None:
    owner, _ = scopes
    source = write(source_dir, "faktura.pdf", SAMPLES["faktura.pdf"][0])
    store.stage(source, owner.entity_id, 4096)  # the process dies here
    assert service.reconcile(owner).staging_removed == 1
    assert not list(store.root.rglob("*.part"))


@pytest.mark.security
def test_crash_while_publishing_stores_nothing(
    service, store, scopes: Scopes, source_dir, database, monkeypatch
) -> None:
    owner, _ = scopes
    events = len(audit_rows(database))

    def full_disk(*args):
        raise OSError(28, "No space left on device")

    monkeypatch.setattr("invoiceflow.documents.store.os.replace", full_disk)
    with pytest.raises(StorageError) as error:
        service.import_file(owner, write(source_dir, "a.pdf", SAMPLES["faktura.pdf"][0]))
    assert error.value.code == "STORAGE_UNAVAILABLE"
    assert service.list_documents(owner) == []
    assert len(audit_rows(database)) == events
    assert not list(store.root.rglob("*.part"))  # discarded in finally


@pytest.mark.security
def test_missing_and_tampered_originals_are_detected(
    service, store, scopes: Scopes, source_dir
) -> None:
    owner, _ = scopes
    first = service.import_file(owner, write(source_dir, "a.pdf", SAMPLES["faktura.pdf"][0]))
    second = service.import_file(owner, write(source_dir, "b.png", SAMPLES["kvittering.png"][0]))
    first_path = store.resolve(service.get(owner, first.document_id).storage_path)
    os.chmod(first_path, 0o600)
    first_path.write_bytes(b"%PDF- manipulert")
    second_path = store.resolve(service.get(owner, second.document_id).storage_path)
    os.chmod(second_path, 0o600)
    second_path.unlink()

    statuses = service.verify_integrity(owner)
    assert statuses == {
        first.document_id: IntegrityStatus.MISMATCH,
        second.document_id: IntegrityStatus.MISSING,
    }
    assert service.reconcile(owner).missing == (second.document_id,)
    record = service.get(owner, first.document_id)
    assert record.integrity_status is IntegrityStatus.MISMATCH
    assert record.integrity_checked_at is not None


def test_concurrent_import_of_the_same_file_stores_one_document(
    database, store, scopes: Scopes, source_dir
) -> None:
    owner, _ = scopes
    source = write(source_dir, "a.pdf", SAMPLES["faktura.pdf"][0])
    barrier = threading.Barrier(4)
    results = []

    def work() -> None:
        handle = Database(database.path)
        try:
            service = DocumentService(handle.unit_of_work, store)
            barrier.wait()
            results.append(service.import_file(owner, source).outcome)
        finally:
            handle.close()

    threads = [threading.Thread(target=work) for _ in range(4)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=60)
    assert sorted(results) == sorted([ImportOutcome.IMPORTED] + [ImportOutcome.DUPLICATE] * 3)
    assert chain_valid(database)


def test_lost_race_at_insert_is_reported_as_duplicate(
    service, scopes: Scopes, source_dir, monkeypatch
) -> None:
    """The duplicate check passes, but another import commits before ours."""
    owner, _ = scopes
    source = write(source_dir, "a.pdf", SAMPLES["faktura.pdf"][0])
    winner = service.import_file(owner, source)
    calls = []
    real = SqlDocumentRepository.find_by_sha256

    def first_none(self, sha256):
        calls.append(sha256)
        return None if len(calls) == 1 else real(self, sha256)

    monkeypatch.setattr(SqlDocumentRepository, "find_by_sha256", first_none)
    result = service.import_file(owner, source)
    assert (result.outcome, result.document_id) == (ImportOutcome.DUPLICATE, winner.document_id)


# --- database-level protection --------------------------------------------------------


def raw(database: Database, sql: str, *params: object) -> None:
    with database.engine.connect() as connection, connection.begin():
        connection.exec_driver_sql(sql, params)


@pytest.fixture
def stored(service, scopes: Scopes, source_dir):
    owner, other = scopes
    first = service.import_file(owner, write(source_dir, "a.pdf", SAMPLES["faktura.pdf"][0]))
    second = service.import_file(owner, write(source_dir, "b.png", SAMPLES["kvittering.png"][0]))
    foreign = service.import_file(other, write(source_dir, "c.jpg", SAMPLES["skann.jpg"][0]))
    quarantined = service.import_file(owner, write(source_dir, "d.pdf", b"MZ x"))
    return first.document_id, second.document_id, foreign.document_id, quarantined.document_id


@pytest.mark.security
@pytest.mark.parametrize(
    ("sql", "message"),
    [
        ("DELETE FROM documents", "cannot be deleted"),
        ("UPDATE documents SET sha256 = '" + "f" * 64 + "'", "immutable"),
        ("UPDATE documents SET entity_id = '" + "f" * 32 + "'", "immutable"),
        ("UPDATE documents SET storage_path = 'x/y'", "immutable"),
        ("UPDATE documents SET status = 'stored', detected_format = 'pdf'", "immutable"),
        ("UPDATE documents SET display_name = 'nytt navn'", "immutable"),
        ("UPDATE documents SET document_type = 'faktura'", "CHECK"),
        ("UPDATE documents SET storage_path = '../x'", "immutable"),
    ],
)
def test_documents_are_protected_in_the_database(database, stored, sql, message) -> None:
    with pytest.raises(IntegrityError, match=message):
        raw(database, sql)


def test_document_type_and_integrity_may_change(database, stored) -> None:
    raw(database, "UPDATE documents SET document_type = 'receipt', integrity_status = 'ok'")


@pytest.mark.security
def test_links_stay_inside_one_entity(database, scopes: Scopes, stored) -> None:
    owner, _ = scopes
    first, second, foreign, _ = stored
    link = "INSERT INTO document_links VALUES (?, ?, ?, ?, '2026-10-22T10:00:00.000000Z', 'system')"
    raw(database, link, owner.entity_id.hex, first.hex, second.hex, "attachment")
    for params, message in [
        ((owner.entity_id.hex, first.hex, foreign.hex, "related"), "FOREIGN KEY"),
        ((owner.entity_id.hex, first.hex, first.hex, "related"), "CHECK"),
        ((owner.entity_id.hex, first.hex, second.hex, "other"), "CHECK"),
        ((owner.entity_id.hex, first.hex, second.hex, "attachment"), "UNIQUE"),
    ]:
        with pytest.raises(IntegrityError, match=message):
            raw(database, link, *params)
    for sql in ("UPDATE document_links SET link_type = 'related'", "DELETE FROM document_links"):
        with pytest.raises(IntegrityError, match="append-only"):
            raw(database, sql)


@pytest.mark.security
def test_invoices_must_reference_a_stored_document_of_their_entity(
    database, scopes: Scopes, stored, example_data
) -> None:
    from invoiceflow.application.services import InvoiceService
    from invoiceflow.domain import CanonicalInvoice

    owner, _ = scopes
    first, _, foreign, quarantined = stored
    invoices = InvoiceService(database.unit_of_work)
    for document_id in (foreign, quarantined, uuid4()):
        data = {**example_data, "document_id": str(document_id)}
        with pytest.raises(NotFoundError):
            invoices.register(owner, CanonicalInvoice.model_validate(data))
    data = {**example_data, "document_id": str(first)}
    assert invoices.register(owner, CanonicalInvoice.model_validate(data)).revision == 1


# --- repository guards -------------------------------------------------------------


@pytest.mark.security
def test_repository_guards(database, scopes: Scopes, stored) -> None:
    import dataclasses
    import datetime as dt

    owner, other = scopes
    first = stored[0]
    with database.unit_of_work() as uow:
        repository = uow.documents(owner)
        record = repository.get(first)
        with pytest.raises(NotFoundError):  # a record of another entity
            uow.documents(other).add(record)
        with pytest.raises(Exception, match="REVISION_CONFLICT"):  # stale expected type
            repository.set_type(first, DocumentType.RECEIPT, expected=DocumentType.CONTRACT)
        with pytest.raises(NotFoundError):
            repository.set_type(uuid4(), DocumentType.RECEIPT, expected=DocumentType.OTHER)
        with pytest.raises(NotFoundError):
            uow.documents(other).set_integrity(
                first, IntegrityStatus.OK, checked_at=dt.datetime.now(dt.UTC)
            )
        with pytest.raises(Exception, match="REVISION_CONFLICT"):  # same hash, same entity
            repository.add(dataclasses.replace(record, document_id=uuid4()))
        with pytest.raises(TypeError):
            uow.documents(None)  # type: ignore[arg-type]
