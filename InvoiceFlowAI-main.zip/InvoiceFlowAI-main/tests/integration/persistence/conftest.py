"""Fixtures for tests against real, file-backed SQLite databases."""

import datetime as dt
import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any
from uuid import UUID, uuid4

import pytest

from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentRecord,
    DocumentStatus,
    DocumentType,
    ImportSource,
)
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import EntityService, InvoiceService
from invoiceflow.domain import CanonicalInvoice
from invoiceflow.persistence.database import Database
from invoiceflow.persistence.migrator import initialize_database

EXAMPLE = (
    Path(__file__).resolve().parents[3] / "docs" / "examples" / "eksempel_faktura_kanonisk.json"
)


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "database" / "invoiceflow.sqlite3"


@pytest.fixture
def database(tmp_path: Path, db_path: Path) -> Iterator[Database]:
    db_path.parent.mkdir()
    initialize_database(db_path, tmp_path / "backups")
    handle = Database(db_path)
    yield handle
    handle.close()


@pytest.fixture
def entities(database: Database) -> EntityService:
    return EntityService(database.unit_of_work)


@pytest.fixture
def invoices(database: Database) -> InvoiceService:
    return InvoiceService(database.unit_of_work)


def add_document(database: Database, scope: EntityScope, document_id: UUID | None = None) -> UUID:
    """Store a document row without a file or audit event (metadata only)."""
    document_id = document_id or uuid4()
    sha = document_id.hex * 2
    with database.unit_of_work() as uow:
        uow.documents(scope).add(
            DocumentRecord(
                document_id=document_id,
                entity_id=scope.entity_id,
                document_type=DocumentType.INVOICE,
                sha256=sha,
                size_bytes=1,
                detected_format=DocumentFormat.PDF,
                display_name="syntetisk.pdf",
                storage_path=f"{scope.entity_id.hex}/originals/{sha[:2]}/{sha[2:4]}/{sha}.pdf",
                source=ImportSource.FILE_IMPORT,
                status=DocumentStatus.STORED,
                imported_at=dt.datetime(2026, 10, 22, tzinfo=dt.UTC),
                imported_by="system",
            )
        )
        uow.commit()
    return document_id


@pytest.fixture
def scopes(
    database: Database, entities: EntityService, example_data: dict[str, Any]
) -> tuple[EntityScope, EntityScope]:
    """Two entities; the example invoice's document belongs to the first."""
    first = entities.create(name="Syntetisk enhet A AS", org_number="123456785")
    second = entities.create(name="Syntetisk enhet B AS", org_number="314159268")
    owner = EntityScope(first.entity_id)
    add_document(database, owner, UUID(example_data["document_id"]))
    return owner, EntityScope(second.entity_id)


@pytest.fixture
def example_data() -> dict[str, Any]:
    return json.loads(EXAMPLE.read_text(encoding="utf-8"))


@pytest.fixture
def example_invoice(example_data: dict[str, Any]) -> CanonicalInvoice:
    return CanonicalInvoice.model_validate(example_data)
