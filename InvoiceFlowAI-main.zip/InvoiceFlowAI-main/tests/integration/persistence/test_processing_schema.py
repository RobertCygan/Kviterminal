"""Migration 0003: the database itself refuses half or foreign processing state."""

import datetime as dt
import sqlite3
from dataclasses import replace
from uuid import uuid4

import pytest

from invoiceflow.application.errors import ConflictError, NotFoundError
from invoiceflow.application.processing_model import (
    DerivedFileRecord,
    DerivedKind,
    JobRecord,
    JobStatus,
    OcrPageRecord,
    PageRecord,
    ProcessingErrorCode,
    ProcessingStep,
)
from invoiceflow.application.scope import EntityScope
from invoiceflow.persistence.database import Database

from .conftest import add_document

pytestmark = [pytest.mark.integration, pytest.mark.security]

NOW = dt.datetime(2026, 10, 23, 12, 0, tzinfo=dt.UTC)


def job_for(scope: EntityScope, document_id, *, key="a" * 64, attempt=1, status=JobStatus.RUNNING):
    return JobRecord(
        job_id=uuid4(),
        entity_id=scope.entity_id,
        document_id=document_id,
        step=ProcessingStep.PAGE_ANALYSIS,
        idempotency_key=key,
        attempt=attempt,
        status=status,
        engine="pypdfium2",
        engine_version="5.13.0",
        settings_hash="b" * 64,
        queued_at=NOW,
        started_at=None if status is JobStatus.QUEUED else NOW,
    )


def page(job: JobRecord, number=1) -> PageRecord:
    return PageRecord(job.job_id, job.document_id, number, 10, 20, 0, 5)


def derived(scope: EntityScope, job: JobRecord, number=1) -> DerivedFileRecord:
    return DerivedFileRecord(
        uuid4(),
        job.job_id,
        job.document_id,
        number,
        DerivedKind.PAGE_RENDER,
        f"{scope.entity_id.hex}/derived/{job.document_id.hex}/{job.job_id.hex}/page-0001.png",
        "c" * 64,
        10,
        "pypdfium2/5.13.0",
        NOW,
    )


@pytest.fixture
def owner(database: Database, entities) -> EntityScope:
    return EntityScope(entities.create(name="Syntetisk AS").entity_id)


@pytest.fixture
def other(database: Database, entities) -> EntityScope:
    return EntityScope(entities.create(name="Annen AS").entity_id)


def add_job(database, scope, job):
    with database.unit_of_work() as uow:
        uow.processing(scope).add_job(job)
        uow.commit()
    return job


def raw(database: Database, sql: str, *params) -> None:
    connection = sqlite3.connect(database.path)
    try:
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute(sql, params)
        connection.commit()
    finally:
        connection.close()


def test_pages_and_files_need_a_running_job(database, owner) -> None:
    job = add_job(database, owner, job_for(owner, add_document(database, owner)))
    with database.unit_of_work() as uow:
        repository = uow.processing(owner)
        repository.add_pages([page(job)])
        repository.add_derived_files([derived(owner, job)])
        repository.finish_job(
            job.job_id,
            status=JobStatus.SUCCEEDED,
            finished_at=NOW,
            page_count=1,
            active_content=False,
        )
        uow.commit()
    with database.unit_of_work() as uow, pytest.raises(ConflictError):
        uow.processing(owner).add_pages([page(job, 2)])


def test_a_finished_job_is_final(database, owner) -> None:
    job = add_job(database, owner, job_for(owner, add_document(database, owner)))
    with database.unit_of_work() as uow:
        uow.processing(owner).finish_job(
            job.job_id,
            status=JobStatus.FAILED,
            finished_at=NOW,
            error_code=ProcessingErrorCode.CORRUPT,
        )
        uow.commit()
    with database.unit_of_work() as uow, pytest.raises(ConflictError):
        uow.processing(owner).finish_job(
            job.job_id,
            status=JobStatus.SUCCEEDED,
            finished_at=NOW,
            page_count=1,
            active_content=False,
        )
    for sql in (
        "UPDATE processing_jobs SET status = 'succeeded', error_code = NULL, page_count = 1, "
        "active_content = 0",
        "UPDATE processing_jobs SET engine_version = '9.9.9'",
        "DELETE FROM processing_jobs",
    ):
        with pytest.raises(sqlite3.DatabaseError):
            raw(database, sql)


def test_states_must_be_consistent(database, owner) -> None:
    job = add_job(database, owner, job_for(owner, add_document(database, owner)))
    with database.unit_of_work() as uow, pytest.raises(ConflictError):
        # Succeeded without a page count or the active-content flag.
        uow.processing(owner).finish_job(job.job_id, status=JobStatus.SUCCEEDED, finished_at=NOW)
    with database.unit_of_work() as uow, pytest.raises(ValueError):
        uow.processing(owner).finish_job(job.job_id, status=JobStatus.RUNNING, finished_at=NOW)


def test_one_unfinished_and_one_successful_job_per_key(database, owner) -> None:
    document_id = add_document(database, owner)
    add_job(database, owner, job_for(owner, document_id))
    with pytest.raises(ConflictError):
        add_job(database, owner, job_for(owner, document_id, attempt=2))


def test_jobs_only_for_stored_documents_of_the_same_entity(database, owner, other) -> None:
    document_id = add_document(database, owner)
    with pytest.raises(ConflictError):
        add_job(database, other, job_for(other, document_id))
    raw(database, "UPDATE documents SET document_type = 'invoice'")  # allowed column
    with pytest.raises(sqlite3.DatabaseError):
        raw(database, "UPDATE documents SET status = 'quarantined', detected_format = NULL")


def test_pages_cannot_point_at_another_document_or_entity(database, owner, other) -> None:
    job = add_job(database, owner, job_for(owner, add_document(database, owner)))
    foreign = PageRecord(job.job_id, add_document(database, owner), 1, 10, 20, 0, 5)
    with database.unit_of_work() as uow, pytest.raises(ConflictError):
        uow.processing(owner).add_pages([foreign])
    with database.unit_of_work() as uow, pytest.raises(ConflictError):
        uow.processing(other).add_pages([page(job)])
    with database.unit_of_work() as uow, pytest.raises(NotFoundError):
        uow.processing(other).finish_job(
            job.job_id,
            status=JobStatus.FAILED,
            finished_at=NOW,
            error_code=ProcessingErrorCode.CORRUPT,
        )


def test_derived_paths_stay_in_the_derived_folder(database, owner) -> None:
    job = add_job(database, owner, job_for(owner, add_document(database, owner)))
    escaping = replace(
        derived(owner, job), storage_path=f"{owner.entity_id.hex}/originals/../x.png"
    )
    with database.unit_of_work() as uow:
        repository = uow.processing(owner)
        repository.add_pages([page(job)])
        with pytest.raises(ConflictError):
            repository.add_derived_files([escaping])


def test_page_rows_are_append_only(database, owner) -> None:
    job = add_job(database, owner, job_for(owner, add_document(database, owner)))
    with database.unit_of_work() as uow:
        uow.processing(owner).add_pages([page(job)])
        uow.commit()
    for sql in ("UPDATE document_pages SET width_px = 1", "DELETE FROM document_pages"):
        with pytest.raises(sqlite3.DatabaseError):
            raw(database, sql)


def test_text_flag_matches_character_count(database, owner) -> None:
    job = add_job(database, owner, job_for(owner, add_document(database, owner)))
    with pytest.raises(sqlite3.DatabaseError):
        raw(
            database,
            "INSERT INTO document_pages VALUES (?, ?, ?, 1, 10, 10, 0, 1, 0)",
            owner.entity_id.hex,
            job.document_id.hex,
            job.job_id.hex,
        )


def test_invoice_findings_are_append_only_and_entity_bound(database, owner, other) -> None:
    from invoiceflow.bootstrap.persistence import synthetic_invoice

    document_id = add_document(database, owner)
    with database.unit_of_work() as uow:
        repository = uow.invoices(owner)
        invoice_id = uuid4()
        repository.add(
            invoice_id=invoice_id,
            invoice=synthetic_invoice(document_id=document_id),
            recorded_at=NOW,
            actor="system",
        )
        repository.add_findings(invoice_id, 1, ["possible_duplicate"], NOW)
        uow.commit()
    with database.unit_of_work() as uow:
        assert uow.invoices(owner).findings(invoice_id) == [(1, "possible_duplicate")]
        assert uow.invoices(other).findings(invoice_id) == []
        with pytest.raises(NotFoundError):
            uow.invoices(other).add_findings(invoice_id, 1, ["wrong_recipient"], NOW)
    with database.unit_of_work() as uow, pytest.raises(ConflictError):
        uow.invoices(owner).add_findings(invoice_id, 9, ["wrong_recipient"], NOW)  # no revision 9
    for sql in ("UPDATE invoice_findings SET code = 'x'", "DELETE FROM invoice_findings"):
        with pytest.raises(sqlite3.DatabaseError):
            raw(database, sql)
    with pytest.raises(sqlite3.DatabaseError):
        raw(
            database,
            "INSERT INTO invoice_findings VALUES (?, ?, 1, 'Fritekst fra fakturaen', ?)",
            owner.entity_id.hex,
            invoice_id.hex,
            "2026-10-23T12:00:00.000000Z",
        )


# -- Phase 05: OCR (migration 0011) ---------------------------------------------------


def ocr_job(scope: EntityScope, document_id, *, key="d" * 64):
    return replace(
        job_for(scope, document_id, key=key),
        step=ProcessingStep.OCR,
        engine="tesseract",
        engine_version="5.3.4+ocr1+0451eb4f",
    )


def ocr_page(scope: EntityScope, job: JobRecord, source: JobRecord, number=1, **changes):
    record = OcrPageRecord(
        job_id=job.job_id,
        document_id=job.document_id,
        source_job_id=source.job_id,
        page_number=number,
        word_count=3,
        line_count=2,
        char_count=14,
        mean_confidence=91,
        low_confidence_words=0,
        storage_path=f"{scope.entity_id.hex}/derived/{job.document_id.hex}/{job.job_id.hex}/"
        f"ocr-{number:04d}.json",
        sha256="e" * 64,
        size_bytes=100,
        producer="tesseract/5.3.4+ocr1+0451eb4f",
        created_at=NOW,
    )
    return replace(record, **changes)


def analysed(database, scope, document_id):
    job = add_job(database, scope, job_for(scope, document_id, key=document_id.hex * 2))
    with database.unit_of_work() as uow:
        repository = uow.processing(scope)
        repository.add_pages([page(job)])
        repository.finish_job(
            job.job_id,
            status=JobStatus.SUCCEEDED,
            finished_at=NOW,
            page_count=1,
            active_content=False,
        )
        uow.commit()
    return job


def test_ocr_pages_need_a_running_ocr_job_of_the_same_document(database, owner) -> None:
    document_id = add_document(database, owner)
    source = analysed(database, owner, document_id)
    other_document = add_document(database, owner)
    foreign_source = analysed(database, owner, other_document)
    job = add_job(database, owner, ocr_job(owner, document_id))

    for record in (
        ocr_page(owner, job, foreign_source),  # another document's page image
        ocr_page(owner, job, source, 2),  # no such page
        ocr_page(owner, job, job),  # an OCR job is not a page analysis
        ocr_page(owner, job, source, low_confidence_words=4),
        ocr_page(owner, job, source, line_count=4),
        ocr_page(owner, job, source, storage_path="../ocr-0001.json"),
    ):
        with database.unit_of_work() as uow, pytest.raises(ConflictError):
            uow.processing(owner).add_ocr_pages([record])
    with database.unit_of_work() as uow:
        repository = uow.processing(owner)
        repository.add_ocr_pages([ocr_page(owner, job, source)])
        finished = repository.finish_job(
            job.job_id,
            status=JobStatus.SUCCEEDED,
            finished_at=NOW,
            page_count=1,
            active_content=False,
        )
        uow.commit()
    assert finished.step is ProcessingStep.OCR
    with database.unit_of_work() as uow:
        repository = uow.processing(owner)
        [stored] = repository.ocr_pages(job.job_id)
        assert stored == ocr_page(owner, job, source)
        assert repository.latest_jobs()[document_id].job_id == source.job_id
        assert repository.latest_jobs(ocr=True)[document_id].job_id == job.job_id
        with pytest.raises(ConflictError):
            repository.add_ocr_pages([ocr_page(owner, job, source, 1)])
    for sql in ("UPDATE ocr_pages SET word_count = 4", "DELETE FROM ocr_pages"):
        with pytest.raises(sqlite3.IntegrityError, match="append-only"):
            raw(database, sql)


def test_ocr_pages_are_entity_bound(database, owner, other) -> None:
    document_id = add_document(database, owner)
    source = analysed(database, owner, document_id)
    job = add_job(database, owner, ocr_job(owner, document_id))
    with database.unit_of_work() as uow:
        uow.processing(owner).add_ocr_pages([ocr_page(owner, job, source)])
        uow.commit()
    with database.unit_of_work() as uow:
        assert uow.processing(other).ocr_pages(job.job_id) == []
        assert uow.processing(other).latest_jobs(ocr=True) == {}


def test_a_successful_ocr_job_names_its_page_count(database, owner) -> None:
    job = add_job(database, owner, ocr_job(owner, add_document(database, owner)))
    with database.unit_of_work() as uow, pytest.raises(ConflictError):
        uow.processing(owner).finish_job(
            job.job_id, status=JobStatus.SUCCEEDED, finished_at=NOW, active_content=False
        )
    with database.unit_of_work() as uow:
        failed = uow.processing(owner).finish_job(
            job.job_id,
            status=JobStatus.FAILED,
            finished_at=NOW,
            error_code=ProcessingErrorCode.OCR_FAILED,
        )
        uow.commit()
    assert failed.error_code is ProcessingErrorCode.OCR_FAILED
