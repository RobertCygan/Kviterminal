"""The content-addressed file store on a real file system."""

import contextlib
import hashlib
import os
import stat
from pathlib import Path
from uuid import UUID, uuid4

import pytest

from invoiceflow.application.document_model import IntegrityStatus, RejectReason
from invoiceflow.application.ports import StagingError, StorageError
from invoiceflow.documents import store as store_module
from invoiceflow.documents.store import FileDocumentStore

pytestmark = pytest.mark.integration

ENTITY = UUID("11111111-1111-4111-8111-111111111111")
PDF = b"%PDF-1.4\n% syntetisk\n%%EOF\n"


@pytest.fixture
def store(tmp_path: Path) -> FileDocumentStore:
    root = tmp_path / "documents"
    root.mkdir()
    return FileDocumentStore(root, sleep=lambda _: None)


@pytest.fixture
def source(tmp_path: Path) -> Path:
    path = tmp_path / "kilde" / "faktura.pdf"
    path.parent.mkdir()
    path.write_bytes(PDF)
    return path


class StatOverride:
    """A real stat result with selected fields replaced (keeps Windows attributes)."""

    def __init__(self, info: os.stat_result, **overrides: int) -> None:
        self._info = info
        self._overrides = overrides

    def __getattr__(self, name: str) -> object:
        if name in self._overrides:
            return self._overrides[name]
        return getattr(self._info, name)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def symlink_or_skip(link: Path, target: Path) -> None:
    try:
        link.symlink_to(target)
    except OSError:
        pytest.skip("symbolic links are not available")


def test_stage_copies_hashes_and_keeps_the_source(store, source) -> None:
    staged = store.stage(source, ENTITY, 1024)
    assert (staged.sha256, staged.size_bytes, staged.header) == (sha(PDF), len(PDF), PDF[:16])
    assert store.resolve(staged.token).read_bytes() == PDF
    assert staged.token.startswith(f"{ENTITY.hex}/staging/")
    assert source.read_bytes() == PDF


def test_publish_is_content_addressed_read_only_and_idempotent(store, source) -> None:
    staged = store.stage(source, ENTITY, 1024)
    digest = sha(PDF)
    path = store.publish(staged, ENTITY, digest, "pdf")
    assert path == f"{ENTITY.hex}/originals/{digest[:2]}/{digest[2:4]}/{digest}.pdf"
    final = store.resolve(path)
    assert final.read_bytes() == PDF
    assert not os.stat(final).st_mode & stat.S_IWUSR
    assert not store.resolve(staged.token).exists()
    # The same content again (e.g. after a crash) reuses the existing original.
    again = store.stage(source, ENTITY, 1024)
    assert store.publish(again, ENTITY, digest, "pdf") == path
    assert not store.resolve(again.token).exists()
    assert store.verify(path, digest) is IntegrityStatus.OK


@pytest.mark.security
def test_publish_refuses_a_corrupted_existing_original(store, source) -> None:
    digest = sha(PDF)
    staged = store.stage(source, ENTITY, 1024)
    path = store.publish(staged, ENTITY, digest, "pdf")
    final = store.resolve(path)
    os.chmod(final, stat.S_IWUSR | stat.S_IRUSR)
    final.write_bytes(b"%PDF- manipulert")
    with pytest.raises(StorageError):
        store.publish(store.stage(source, ENTITY, 1024), ENTITY, digest, "pdf")
    assert store.verify(path, digest) is IntegrityStatus.MISMATCH


@pytest.mark.security
def test_publish_refuses_a_staged_copy_changed_after_hashing(store, source) -> None:
    staged = store.stage(source, ENTITY, 1024)
    store.resolve(staged.token).write_bytes(b"%PDF- endret i staging")
    with pytest.raises(StorageError):
        store.publish(staged, ENTITY, staged.sha256, "pdf")


@pytest.mark.parametrize("extension", ["../x", "pdf/..", "p d f", ""])
def test_publish_rejects_unsafe_extensions(store, source, extension) -> None:
    staged = store.stage(source, ENTITY, 1024)
    with pytest.raises(StorageError):
        store.publish(staged, ENTITY, staged.sha256, extension)


def test_quarantine_is_read_only_and_named_by_id(store, source) -> None:
    staged = store.stage(source, ENTITY, 1024)
    quarantine_id = uuid4()
    path = store.quarantine(staged, ENTITY, quarantine_id)
    assert path == f"{ENTITY.hex}/quarantine/{quarantine_id.hex}.bin"
    assert not os.stat(store.resolve(path)).st_mode & stat.S_IWUSR


@pytest.mark.security
@pytest.mark.parametrize(
    ("content", "max_bytes", "reason"),
    [
        (b"", 1024, RejectReason.EMPTY),
        (b"x" * 1025, 1024, RejectReason.TOO_LARGE),
    ],
    ids=["empty", "too_large"],
)
def test_stage_rejects_empty_and_oversized_files(store, tmp_path, content, max_bytes, reason):
    path = tmp_path / "fil.pdf"
    path.write_bytes(content)
    with pytest.raises(StagingError) as error:
        store.stage(path, ENTITY, max_bytes)
    assert error.value.reason is reason
    assert not list((store.root).rglob("*.part"))


def test_size_limit_is_inclusive(store, tmp_path) -> None:
    path = tmp_path / "fil.pdf"
    path.write_bytes(b"x" * 1024)
    assert store.stage(path, ENTITY, 1024).size_bytes == 1024


@pytest.mark.security
def test_file_growing_beyond_the_limit_while_read_is_rejected(store, tmp_path, monkeypatch):
    """lstat sees a small file, but more bytes arrive while copying."""
    path = tmp_path / "fil.pdf"
    path.write_bytes(b"x" * 2048)
    real_lstat = os.lstat

    def small_lstat(target, *args, **kwargs):
        info = real_lstat(target, *args, **kwargs)
        if Path(target) == path:
            return StatOverride(info, st_size=10)
        return info

    monkeypatch.setattr(store_module.os, "lstat", small_lstat)
    with pytest.raises(StagingError) as error:
        store.stage(path, ENTITY, 1024)
    assert error.value.reason is RejectReason.TOO_LARGE
    monkeypatch.undo()
    assert not list(store.root.rglob("*.part"))


@pytest.mark.security
def test_file_changed_during_read_is_rejected(store, source, monkeypatch) -> None:
    real_stat = os.stat

    def changed_stat(target, *args, **kwargs):
        info = real_stat(target, *args, **kwargs)
        if Path(target) == source:
            return StatOverride(info, st_mtime_ns=info.st_mtime_ns + 5)
        return info

    monkeypatch.setattr(store_module.os, "stat", changed_stat)
    with pytest.raises(StagingError) as error:
        store.stage(source, ENTITY, 1024)
    assert error.value.reason is RejectReason.CHANGED
    monkeypatch.undo()
    assert not list(store.root.rglob("*.part"))


@pytest.mark.security
def test_links_and_directories_are_not_files(store, source, tmp_path) -> None:
    link = tmp_path / "lenke.pdf"
    symlink_or_skip(link, source)
    for path, reason in [
        (link, RejectReason.NOT_A_FILE),
        (tmp_path, RejectReason.NOT_A_FILE),
        (tmp_path / "finnes-ikke.pdf", RejectReason.UNREADABLE),
    ]:
        with pytest.raises(StagingError) as error:
            store.stage(path, ENTITY, 1024)
        assert error.value.reason is reason


def test_unreadable_source_is_rejected(store, source, monkeypatch) -> None:
    def failing_open(self, *args, **kwargs):
        if self == source:
            raise PermissionError("synthetic")
        return original_open(self, *args, **kwargs)

    original_open = Path.open
    monkeypatch.setattr(Path, "open", failing_open)
    with pytest.raises(StagingError) as error:
        store.stage(source, ENTITY, 1024)
    assert error.value.reason is RejectReason.UNREADABLE


def test_disk_failure_while_publishing_is_a_storage_error(store, source, monkeypatch) -> None:
    staged = store.stage(source, ENTITY, 1024)

    def full_disk(*args):
        raise OSError(28, "No space left on device")

    monkeypatch.setattr(store_module.os, "replace", full_disk)
    with pytest.raises(StorageError):
        store.publish(staged, ENTITY, staged.sha256, "pdf")
    with pytest.raises(StorageError):
        store.quarantine(staged, ENTITY, uuid4())


@pytest.mark.security
@pytest.mark.parametrize("path", ["../utenfor.pdf", f"{ENTITY.hex}/../../utenfor.pdf"])
def test_resolve_rejects_paths_outside_the_archive(store, path) -> None:
    with pytest.raises(StorageError):
        store.resolve(path)


@pytest.mark.security
def test_linked_archive_directory_is_refused(store, source, tmp_path) -> None:
    elsewhere = tmp_path / "annet"
    elsewhere.mkdir()
    symlink_or_skip(store.root / ENTITY.hex, elsewhere)
    with pytest.raises(StorageError):
        store.stage(source, ENTITY, 1024)


def test_verify_reports_missing_and_changed_files(store, source) -> None:
    staged = store.stage(source, ENTITY, 1024)
    path = store.publish(staged, ENTITY, staged.sha256, "pdf")
    assert store.verify(path, "0" * 64) is IntegrityStatus.MISMATCH
    assert store.verify(f"{ENTITY.hex}/originals/aa/bb/missing.pdf", "0" * 64) is (
        IntegrityStatus.MISSING
    )
    assert store.verify("../escape", "0" * 64) is IntegrityStatus.MISMATCH


def test_list_candidates_is_flat_and_skips_links(store, tmp_path, source) -> None:
    inbox = tmp_path / "innboks"
    (inbox / "undermappe").mkdir(parents=True)
    (inbox / "undermappe" / "skjult.pdf").write_bytes(PDF)
    (inbox / "b.pdf").write_bytes(PDF)
    (inbox / "a.png").write_bytes(b"x")
    with contextlib.suppress(OSError):  # links need privileges on Windows
        (inbox / "lenke.pdf").symlink_to(source)
    assert [path.name for path in store.list_candidates(inbox)] == ["a.png", "b.pdf"]
    with pytest.raises(StorageError):
        store.list_candidates(tmp_path / "finnes-ikke")


def test_recover_cleans_staging_moves_orphans_and_reports_missing(store, source) -> None:
    kept = store.publish(staged := store.stage(source, ENTITY, 1024), ENTITY, staged.sha256, "pdf")
    other = source.with_name("annen.pdf")
    other.write_bytes(PDF + b"annen")
    orphan_staged = store.stage(other, ENTITY, 1024)
    orphan = store.publish(orphan_staged, ENTITY, orphan_staged.sha256, "pdf")
    leftover = store.stage(source, ENTITY, 1024)  # a crash right after staging
    missing = f"{ENTITY.hex}/originals/aa/bb/{'a' * 64}.pdf"

    report = store.recover(ENTITY, frozenset({kept, missing}))

    assert (report.staging_removed, report.orphans_moved) == (1, 1)
    assert report.missing_paths == frozenset({missing})
    assert not store.resolve(leftover.token).exists()
    assert store.resolve(kept).exists()
    assert not store.resolve(orphan).exists()
    moved = list((store.root / ENTITY.hex / "orphans").iterdir())
    assert len(moved) == 1 and moved[0].read_bytes() == PDF + b"annen"


def test_recover_on_an_empty_entity_is_a_no_op(store) -> None:
    report = store.recover(ENTITY, frozenset())
    assert (report.staging_removed, report.orphans_moved, report.missing_paths) == (
        0,
        0,
        frozenset(),
    )


@pytest.mark.security
def test_publish_accepts_an_identical_original_that_appeared_meanwhile(
    store, source, monkeypatch
) -> None:
    """Windows refuses to replace a read-only file another writer just published."""
    first = store.stage(source, ENTITY, 1024)
    second = store.stage(source, ENTITY, 1024)
    real_replace = os.replace
    competing = []

    def windows_replace(src, dst):
        if not competing and str(dst).endswith(".pdf"):
            competing.append(True)
            real_replace(store.resolve(first.token), dst)  # the other writer wins
            os.chmod(dst, stat.S_IRUSR)
        if os.path.exists(dst) and not os.stat(dst).st_mode & stat.S_IWUSR:
            raise PermissionError(5, "Access is denied")  # Windows: read-only target
        return real_replace(src, dst)

    monkeypatch.setattr(store_module.os, "replace", windows_replace)
    path = store.publish(second, ENTITY, second.sha256, "pdf")
    assert store.verify(path, second.sha256) is IntegrityStatus.OK
    assert not store.resolve(second.token).exists()


@pytest.mark.security
def test_publishing_is_serialized(store, source, monkeypatch) -> None:
    """A file being replaced cannot be opened on Windows; publishers take turns."""
    staged = store.stage(source, ENTITY, 1024)
    real_replace = os.replace
    held = []

    def recording_replace(src, dst):
        held.append(store_module._PUBLISH_LOCK.locked())
        return real_replace(src, dst)

    monkeypatch.setattr(store_module.os, "replace", recording_replace)
    store.publish(staged, ENTITY, staged.sha256, "pdf")
    assert held == [True]
    assert not store_module._PUBLISH_LOCK.locked()


def locked(times: int, real=os.replace):
    """os.replace that fails like Windows while another program holds the file."""
    calls = []

    def replace(src, dst):
        calls.append(dst)
        if len(calls) <= times:
            raise PermissionError(32, "The process cannot access the file")
        return real(src, dst)

    return replace, calls


@pytest.mark.security
@pytest.mark.parametrize("operation", ["publish", "quarantine"])
def test_a_briefly_locked_file_is_moved_after_retrying(
    tmp_path, source, monkeypatch, operation
) -> None:
    root = tmp_path / "documents"
    root.mkdir()
    pauses = []
    store = FileDocumentStore(root, sleep=pauses.append)
    staged = store.stage(source, ENTITY, 1024)
    replace, calls = locked(2)
    monkeypatch.setattr(store_module.os, "replace", replace)
    if operation == "publish":
        path = store.publish(staged, ENTITY, staged.sha256, "pdf")
    else:
        path = store.quarantine(staged, ENTITY, uuid4())
    assert store.verify(path, staged.sha256) is IntegrityStatus.OK
    assert (len(calls), pauses) == (3, [0.05, 0.1])


@pytest.mark.security
def test_a_file_that_stays_locked_is_a_storage_error(tmp_path, source, monkeypatch) -> None:
    root = tmp_path / "documents"
    root.mkdir()
    pauses = []
    store = FileDocumentStore(root, sleep=pauses.append)
    staged = store.stage(source, ENTITY, 1024)
    replace, calls = locked(100)
    monkeypatch.setattr(store_module.os, "replace", replace)
    with pytest.raises(StorageError):
        store.publish(staged, ENTITY, staged.sha256, "pdf")
    assert len(calls) == 6
    assert pauses == [0.05, 0.1, 0.2, 0.4, 0.8]  # about 1.5 s in total, then give up
    assert store.resolve(staged.token).exists()  # the private copy is still there


@pytest.mark.security
def test_recovery_skips_locked_files_and_keeps_going(store, source, monkeypatch) -> None:
    """A file held by another program must not stop the application from starting."""
    base = store.root / ENTITY.hex
    first = store.stage(source, ENTITY, 1024)
    second = store.stage(source, ENTITY, 1024)
    orphan = store.publish(store.stage(source, ENTITY, 1024), ENTITY, first.sha256, "pdf")
    held = {store.resolve(first.token), store.resolve(orphan)}
    real_unlink = Path.unlink
    real_replace = os.replace

    def unlink(self, missing_ok=False):
        if self in held:
            raise PermissionError(32, "The process cannot access the file")
        return real_unlink(self, missing_ok=missing_ok)

    def replace(src, dst):
        if Path(src) in held:
            raise PermissionError(32, "The process cannot access the file")
        return real_replace(src, dst)

    monkeypatch.setattr(Path, "unlink", unlink)
    monkeypatch.setattr(store_module.os, "replace", replace)
    report = store.recover(ENTITY, frozenset())
    assert (report.staging_removed, report.orphans_moved, report.failed) == (1, 0, 2)
    assert store.resolve(first.token).exists() and store.resolve(orphan).exists()
    assert not store.resolve(second.token).exists()
    assert not (base / "orphans").exists() or not list((base / "orphans").iterdir())


def plant_link(target: Path, link: Path) -> None:
    try:
        os.symlink(target, link)
    except (OSError, NotImplementedError):  # Windows without the symlink privilege
        pytest.skip("symbolic links are not available")


@pytest.mark.security
@pytest.mark.parametrize("where", ["inside", "outside", "different", "dangling"])
def test_verify_rejects_an_original_replaced_by_a_link(store, source, tmp_path, where) -> None:
    staged = store.stage(source, ENTITY, 1024)
    path = store.publish(staged, ENTITY, staged.sha256, "pdf")
    original = store.resolve(path)
    target = {
        "inside": store.root / "kopi.bin",
        "outside": tmp_path / "utenfor.bin",
        "different": store.root / "annet.bin",
        "dangling": store.root / "finnes-ikke.bin",
    }[where]
    if where in ("inside", "outside"):
        target.write_bytes(PDF)  # identical content: the hash alone cannot tell
    elif where == "different":
        target.write_bytes(b"annet innhold")
    os.chmod(original, stat.S_IWUSR | stat.S_IRUSR)
    original.unlink()
    plant_link(target, original)
    assert store.verify(path, staged.sha256) is IntegrityStatus.MISMATCH


@pytest.mark.security
def test_verify_rejects_an_original_below_a_linked_directory(store, source, tmp_path) -> None:
    staged = store.stage(source, ENTITY, 1024)
    path = store.publish(staged, ENTITY, staged.sha256, "pdf")
    folder = store.resolve(path).parent
    moved = store.root / "flyttet"
    folder.rename(moved)
    plant_link(moved, folder)
    assert store.verify(path, staged.sha256) is IntegrityStatus.MISMATCH


def test_verify_still_accepts_a_plain_original_and_reports_missing(store, source) -> None:
    staged = store.stage(source, ENTITY, 1024)
    path = store.publish(staged, ENTITY, staged.sha256, "pdf")
    assert store.verify(path, staged.sha256) is IntegrityStatus.OK
    assert store.verify(path.replace(".pdf", ".png"), staged.sha256) is IntegrityStatus.MISSING
