"""Derived file store: only named, regular files of a work folder are published."""

import os
import stat
from uuid import uuid4

import pytest

from invoiceflow.application.errors import StorageError
from invoiceflow.application.ports import WorkOutputError
from invoiceflow.application.processing_model import ProcessingErrorCode
from invoiceflow.documents.derived import FileDerivedStore

pytestmark = [pytest.mark.integration, pytest.mark.security]


@pytest.fixture
def store(tmp_path) -> FileDerivedStore:
    return FileDerivedStore(tmp_path / "documents")


def test_publish_moves_files_read_only_and_checks_hashes(store) -> None:
    entity, document, job = uuid4(), uuid4(), uuid4()
    work = store.create_work_dir(entity, job)
    (work / "page-0001.png").write_bytes(b"png")
    files = store.inspect(work, ["page-0001.png"], 100)
    assert files["page-0001.png"].size_bytes == 3
    published = store.publish(entity, document, job, work, files)
    path = store.root / published["page-0001.png"]
    assert path.read_bytes() == b"png" and not path.stat().st_mode & stat.S_IWUSR
    expected = f"{entity.hex}/derived/{document.hex}/{job.hex}/page-0001.png"
    assert published["page-0001.png"] == expected
    store.discard_work(work)
    assert not work.exists() and path.exists()


def test_inspect_refuses_other_names_missing_and_large_files(store) -> None:
    work = store.create_work_dir(uuid4(), uuid4())
    (work / "page-0001.png").write_bytes(b"x" * 10)
    for names, code in (
        (["../page-0001.png"], ProcessingErrorCode.INVALID_RESULT),
        (["notes.txt"], ProcessingErrorCode.INVALID_RESULT),
        (["page-0002.png"], ProcessingErrorCode.INVALID_RESULT),
        (["page-0001.png"], ProcessingErrorCode.OUTPUT_TOO_LARGE),
    ):
        with pytest.raises(WorkOutputError) as error:
            store.inspect(work, names, 5)
        assert error.value.code is code
    with pytest.raises(WorkOutputError):
        store.read(work, "page-0001.png", 5)


def test_a_file_changed_after_inspection_is_not_published(store) -> None:
    entity, job = uuid4(), uuid4()
    work = store.create_work_dir(entity, job)
    (work / "page-0001.png").write_bytes(b"one")
    files = store.inspect(work, ["page-0001.png"], 100)
    (work / "page-0001.png").write_bytes(b"two")
    with pytest.raises(WorkOutputError):
        store.publish(entity, uuid4(), job, work, files)


def test_only_work_folders_of_this_store_are_accepted(store, tmp_path) -> None:
    elsewhere = tmp_path / "elsewhere"
    elsewhere.mkdir()
    (elsewhere / "page-0001.png").write_bytes(b"x")
    with pytest.raises(StorageError):
        store.inspect(elsewhere, ["page-0001.png"], 100)
    store.discard_work(elsewhere)  # never removes a folder outside the store
    assert elsewhere.exists()


def test_a_job_folder_is_published_only_once(store) -> None:
    entity, document, job = uuid4(), uuid4(), uuid4()
    for _ in range(2):
        work = store.root / entity.hex / "work" / job.hex
        work.mkdir(parents=True, exist_ok=True)
        (work / "page-0001.png").write_bytes(b"x")
    files = store.inspect(work, ["page-0001.png"], 9)
    store.publish(entity, document, job, work, files)
    with pytest.raises(StorageError):
        store.publish(entity, document, job, work, files)
    with pytest.raises(StorageError):
        store.create_work_dir(entity, job)


def test_recover_removes_work_and_moves_unreferenced_jobs(store) -> None:
    entity, document, kept, lost = uuid4(), uuid4(), uuid4(), uuid4()
    for job in (kept, lost):
        folder = store.root / entity.hex / "derived" / document.hex / job.hex
        folder.mkdir(parents=True)
        (folder / "page-0001.png").write_bytes(b"x")
        os.chmod(folder / "page-0001.png", stat.S_IRUSR)
    work = store.create_work_dir(entity, uuid4())
    (work / "page-0001.png").write_bytes(b"x")
    os.chmod(work / "page-0001.png", stat.S_IRUSR)
    recovery = store.recover(entity, frozenset({kept}))
    assert (recovery.work_removed, recovery.derived_moved, recovery.failed) == (1, 1, 0)
    assert (store.root / entity.hex / "derived" / document.hex / kept.hex).is_dir()
    (moved,) = (store.root / entity.hex / "orphans").iterdir()
    assert moved.name.startswith(f"derived-{lost.hex}-") and (moved / "page-0001.png").exists()
    assert store.recover(uuid4(), frozenset()).work_removed == 0


def test_a_linked_work_folder_is_refused(store, tmp_path) -> None:
    entity, job = uuid4(), uuid4()
    target = tmp_path / "elsewhere"
    target.mkdir()
    (store.root / entity.hex / "work").mkdir(parents=True)
    link = store.root / entity.hex / "work" / job.hex
    try:
        link.symlink_to(target, target_is_directory=True)
    except OSError:
        pytest.skip("symbolic links are not permitted for this user")
    with pytest.raises(StorageError):
        store.inspect(link, ["page-0001.png"], 10)


def test_ocr_inputs_are_only_given_never_replaced_and_ocr_files_publish(store) -> None:
    entity, document, job = uuid4(), uuid4(), uuid4()
    work = store.create_work_dir(entity, job)
    store.put_work_file(work, "input-0001.png", b"png")
    assert (work / "input-0001.png").read_bytes() == b"png"
    for name in ("input-0001.png", "ocr-0001.json", "../input-0002.png", "input-1.png"):
        with pytest.raises(StorageError):
            store.put_work_file(work, name, b"x")
    with pytest.raises(StorageError):
        store.put_work_file(store.root, "input-0002.png", b"x")
    (work / "ocr-0001.json").write_bytes(b"{}")
    files = store.inspect(work, ["ocr-0001.json"], 100)
    published = store.publish(entity, document, job, work, files)
    assert published["ocr-0001.json"].endswith(f"{job.hex}/ocr-0001.json")
    store.discard_work(work)
    assert not (store.root / published["ocr-0001.json"]).with_name("input-0001.png").exists()
