"""The OCR step of ProcessingService against a real database, archive and Tesseract (Phase 05)."""

import json
import os
import stat

import pytest
from ocr_samples import encode, render
from processing_fakes import ExitProcessor, InProcessProcessor, ScriptedProcessor

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.errors import NotFoundError
from invoiceflow.application.ports import WorkerExit
from invoiceflow.application.processing_model import (
    OCR_ENGINE,
    JobStatus,
    OcrLayer,
    PageText,
    ProcessingErrorCode,
    ProcessingStep,
    TextSource,
)
from invoiceflow.bootstrap.synthetic_pdf import batch_pdf, text_pdf

pytestmark = [pytest.mark.integration, pytest.mark.tesseract]

LINES = ("Faktura 2026-0417", "Syntetisk Leverandør AS", "Å betale NOK 1 234,50")
SCAN = encode(render(LINES, font_size=14))


def ocr_events(setup):
    with setup.database.unit_of_work() as uow:
        records = list(uow.audit.records())
    return [
        record.details
        for record in records
        if record.event_type == AuditEventType.PROCESSING_FINISHED
        and record.details["step"] == "ocr"
    ]


def layer(setup, page) -> OcrLayer:
    data = setup.derived.read_published(page.storage_path, page.sha256, 10_000_000)
    assert data is not None
    return OcrLayer.model_validate_json(data)


def test_a_scanned_page_is_recognised_after_its_analysis(setup) -> None:
    document_id = setup.add(SCAN, "skann.png")
    service = setup.make(InProcessProcessor(ocr=True))

    jobs = service.process_pending(setup.owner)

    assert [job.step for job in jobs] == [ProcessingStep.PAGE_ANALYSIS, ProcessingStep.OCR]
    analysis, ocr = jobs
    assert ocr.status is JobStatus.SUCCEEDED and ocr.page_count == 1
    assert ocr.engine == OCR_ENGINE and ocr.engine_version.split("+")[1] == "ocr1"
    [page] = service.ocr_pages(setup.owner, ocr.job_id)
    assert (page.source_job_id, page.page_number) == (analysis.job_id, 1)
    assert page.line_count == 3 and page.mean_confidence >= 80
    recognised = layer(setup, page)
    assert recognised.text().splitlines() == list(LINES)
    assert page.word_count == len(recognised.words) and page.char_count == len(recognised.text())
    path = setup.store.root / page.storage_path
    assert not os.stat(path).st_mode & stat.S_IWUSR  # published read-only
    # The audit chain counts words; it never holds the text.
    [details] = ocr_events(setup)
    assert details["word_count"] == page.word_count and "Faktura" not in json.dumps(details)
    assert service.latest_jobs(setup.owner)[document_id].job_id == analysis.job_id
    assert service.latest_ocr_jobs(setup.owner)[document_id].job_id == ocr.job_id
    # Nothing is left to do, and an explicit run returns the earlier success.
    assert service.process_pending(setup.owner) == []
    assert service.recognise(setup.owner, document_id) == ocr


def test_text_layers_blank_pages_and_separators_are_not_recognised(setup) -> None:
    setup.add(text_pdf(["Faktura med tekstlag"]), "digital.pdf")
    setup.add(batch_pdf(["blank", "separator"]), "tom.pdf")
    service = setup.make(InProcessProcessor(ocr=True))

    jobs = service.process_pending(setup.owner)

    assert {job.step for job in jobs} == {ProcessingStep.PAGE_ANALYSIS}
    assert service.latest_ocr_jobs(setup.owner) == {}


def test_without_tesseract_nothing_is_recognised(setup) -> None:
    document_id = setup.add(SCAN, "skann.png")
    service = setup.make(InProcessProcessor())

    assert [job.step for job in service.process_pending(setup.owner)] == [
        ProcessingStep.PAGE_ANALYSIS
    ]
    assert service.recognise(setup.owner, document_id) is None
    assert not service.ocr_available()


def test_a_changed_page_image_is_never_read(setup) -> None:
    document_id = setup.add(SCAN, "skann.png")
    analysis = setup.make().process(setup.owner, document_id)
    [render_file] = [
        record
        for record in setup.make().derived_files(setup.owner, analysis.job_id)
        if record.kind == "page_render"
    ]
    path = setup.store.root / render_file.storage_path
    os.chmod(path, stat.S_IWUSR | stat.S_IRUSR)
    path.write_bytes(encode(render(("Annen tekst",), font_size=14)))

    job = setup.make(InProcessProcessor(ocr=True)).recognise(setup.owner, document_id)

    assert job is not None and job.status is JobStatus.FAILED
    assert job.error_code is ProcessingErrorCode.SOURCE_CHANGED


@pytest.mark.parametrize(
    "tamper",
    [
        lambda report, folder: report["pages"][0].update(word_count=1),
        lambda report, folder: report["pages"][0].update(page_number=2, file="ocr-0002.json"),
        lambda report, folder: report.update(engine_version="9.9.9+ocr1+00000000"),
        lambda report, folder: report.update(status="error", error_code="corrupt", pages=[]),
        lambda report, folder: (folder / "ocr-0001.json").write_text('{"words": []}'),
    ],
    ids=["count", "page", "engine", "foreign_code", "file"],
)
def test_a_report_that_does_not_match_its_files_is_refused(setup, tamper) -> None:
    document_id = setup.add(SCAN, "skann.png")
    setup.make().process(setup.owner, document_id)

    def change(report, folder):
        if "pages" in report and report.get("engine") == OCR_ENGINE:
            if (folder / "ocr-0001.json").exists():
                os.chmod(folder / "ocr-0001.json", stat.S_IWUSR | stat.S_IRUSR)
            tamper(report, folder)

    job = setup.make(ScriptedProcessor(change, ocr=True)).recognise(setup.owner, document_id)

    assert job is not None and job.status is JobStatus.FAILED
    assert job.error_code is ProcessingErrorCode.INVALID_RESULT
    assert setup.make().ocr_pages(setup.owner, job.job_id) == []


def test_a_timed_out_ocr_run_is_recorded_and_retried(setup) -> None:
    document_id = setup.add(SCAN, "skann.png")
    setup.make().process(setup.owner, document_id)

    stopped = setup.make(ExitProcessor(WorkerExit.TIMED_OUT, ocr=True)).recognise(
        setup.owner, document_id
    )
    assert stopped is not None and stopped.status is JobStatus.TIMED_OUT
    # Failed runs are not retried by the queue, only explicitly.
    service = setup.make(InProcessProcessor(ocr=True))
    assert service.recognise_pending(setup.owner) == []
    again = service.recognise(setup.owner, document_id)
    assert again is not None and again.status is JobStatus.SUCCEEDED and again.attempt == 2


def test_ocr_belongs_to_the_entity_of_the_document(setup) -> None:
    document_id = setup.add(SCAN, "skann.png", scope=setup.other)
    service = setup.make(InProcessProcessor(ocr=True))
    service.process_pending(setup.other)

    assert service.latest_ocr_jobs(setup.owner) == {}
    assert len(service.latest_ocr_jobs(setup.other)) == 1
    with pytest.raises(NotFoundError):
        service.recognise(setup.owner, document_id)


def test_an_interrupted_ocr_job_is_closed_at_startup(setup) -> None:
    document_id = setup.add(SCAN, "skann.png")
    setup.make().process(setup.owner, document_id)

    def crash(report, folder):
        if report.get("engine") == OCR_ENGINE:
            raise KeyboardInterrupt  # the application dies mid-run

    with pytest.raises(KeyboardInterrupt):
        setup.make(ScriptedProcessor(crash, ocr=True)).recognise(setup.owner, document_id)
    service = setup.make(InProcessProcessor(ocr=True))
    recovery = service.reconcile(setup.owner)

    assert recovery.interrupted == 1
    job = service.latest_ocr_jobs(setup.owner)[document_id]
    assert job.status is JobStatus.FAILED and job.error_code is ProcessingErrorCode.INTERRUPTED


def test_page_texts_come_from_the_text_layer_or_ocr(setup) -> None:
    digital = setup.add(text_pdf(["Faktura med tekstlag"]), "digital.pdf")
    scanned = setup.add(SCAN, "skann.png")
    service = setup.make(InProcessProcessor(ocr=True))
    service.process_pending(setup.owner)

    [layer_page] = service.page_texts(setup.owner, digital)
    assert (layer_page.source, layer_page.text) == (TextSource.TEXT_LAYER, "Faktura med tekstlag")
    [ocr_page] = service.page_texts(setup.owner, scanned)
    assert ocr_page.source is TextSource.OCR and ocr_page.text == "\n".join(LINES)
    assert ocr_page.mean_confidence is not None and ocr_page.mean_confidence >= 80

    # A changed OCR file is never shown.
    ocr_job = service.latest_ocr_jobs(setup.owner)[scanned]
    [record] = service.ocr_pages(setup.owner, ocr_job.job_id)
    path = setup.store.root / record.storage_path
    os.chmod(path, stat.S_IWUSR | stat.S_IRUSR)
    path.write_text('{"forfalsket": true}', encoding="utf-8")
    [changed] = service.page_texts(setup.owner, scanned)
    assert changed.source is TextSource.OCR and changed.text is None
    assert service.page_texts(setup.other, scanned) == []


def test_blank_pages_have_no_text(setup) -> None:
    document_id = setup.add(batch_pdf(["blank"]), "tom.pdf")
    service = setup.make(InProcessProcessor(ocr=True))
    service.process_pending(setup.owner)
    assert service.page_texts(setup.owner, document_id) == [PageText(1, TextSource.NONE, "")]
