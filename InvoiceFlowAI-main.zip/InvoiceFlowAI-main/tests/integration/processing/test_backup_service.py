"""Encrypted backup and restore with a real database and archive (Phase 12)."""

import sqlite3
from contextlib import closing
from pathlib import Path

import pytest
from invoice_steps import events, ready_invoice, review

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.backup.model import BackupError
from invoiceflow.application.backup.service import BackupService
from invoiceflow.application.services import InvoiceService
from invoiceflow.backup.archive import FileBackupArchive
from invoiceflow.config.paths import AppPaths
from invoiceflow.persistence.backup import SqliteSnapshotter
from invoiceflow.persistence.database import Database
from invoiceflow.persistence.migrator import verify_database

pytestmark = pytest.mark.integration

PASSPHRASE = "Syntetisk passordfrase 42"  # noqa: S105 - synthetic test value


def service(setup) -> BackupService:
    return BackupService(
        setup.database.unit_of_work,
        SqliteSnapshotter(setup.database.path),
        FileBackupArchive(AppPaths(setup.tmp)),
        scrypt_n=2**10,
    )


@pytest.fixture
def outside(tmp_path_factory) -> Path:
    """Folders outside the data directory (an external disk, a new data folder)."""
    return tmp_path_factory.mktemp("ekstern")


def backed_up(setup, outside: Path):
    invoice_id = ready_invoice(setup)
    revision = review(setup).view(setup.owner, invoice_id).record.revision
    review(setup).approve(setup.owner, invoice_id, expected_revision=revision)
    folder = outside / "disk"
    folder.mkdir()
    record = service(setup).create(folder, PASSPHRASE, PASSPHRASE)
    return invoice_id, record, folder / record.file_name


def test_a_backup_restores_into_a_working_data_directory(setup, outside) -> None:
    invoice_id, record, path = backed_up(setup, outside)
    assert path.exists() and record.byte_count == path.stat().st_size
    assert PASSPHRASE.encode() not in path.read_bytes()
    assert service(setup).backups() == [record]
    (created,) = events(setup, AuditEventType.BACKUP_CREATED)
    assert created.entity_id is None and created.subject_id == "backup"
    assert created.details["audit_anchor"] == record.audit_anchor
    assert created.details["file_count"] == record.file_count
    assert not list((setup.tmp / "backups" / "work").iterdir())  # no plain copy left

    target = outside / "ny-datamappe"
    check = service(setup).restore(path, PASSPHRASE, target)

    assert check.known and check.file_count == record.file_count
    assert verify_database(target / "database" / "invoiceflow.sqlite3").valid
    restored = Database(target / "database" / "invoiceflow.sqlite3")
    try:
        original = InvoiceService(setup.database.unit_of_work).get(setup.owner, invoice_id)
        copy = InvoiceService(restored.unit_of_work).get(setup.owner, invoice_id)
        assert copy == original and copy.workflow_status == "approved"
    finally:
        restored.close()
    originals = sorted(p.name for p in (target / "documents").rglob("*") if p.is_file())
    assert originals == sorted(
        p.name
        for p in (setup.tmp / "documents").rglob("*")
        if p.is_file() and "staging" not in p.parts and "work" not in p.parts
    )
    (restored_event,) = events(setup, AuditEventType.BACKUP_RESTORED)
    assert restored_event.details == {"backup_id": str(record.backup_id), "valid": True}


def test_a_verification_keeps_nothing(setup, outside) -> None:
    _, record, path = backed_up(setup, outside)
    check = service(setup).verify(path, PASSPHRASE)
    assert check.known and check.backup_id == record.backup_id
    assert not list((setup.tmp / "backups" / "work").iterdir())
    (verified,) = events(setup, AuditEventType.BACKUP_VERIFIED)
    assert verified.details["valid"] is True


def test_a_wrong_passphrase_or_a_changed_byte_is_refused(setup, outside) -> None:
    _, _, path = backed_up(setup, outside)
    with pytest.raises(BackupError) as caught:
        service(setup).verify(path, "Feil passordfrase 1234")
    assert caught.value.reason == "passphrase_or_damaged"
    data = bytearray(path.read_bytes())
    for position in (len(data) // 2, len(data) - 1, 20):
        changed = bytearray(data)
        changed[position] ^= 0x40
        broken = outside / f"endret-{position}.ifbak"
        broken.write_bytes(bytes(changed))
        with pytest.raises(BackupError):
            service(setup).verify(broken, PASSPHRASE)
    cut = outside / "avkortet.ifbak"
    cut.write_bytes(bytes(data[: len(data) - 10]))
    with pytest.raises(BackupError):
        service(setup).verify(cut, PASSPHRASE)
    failed = [e.details["valid"] for e in events(setup, AuditEventType.BACKUP_VERIFIED)]
    assert failed and not any(failed)


def test_a_failed_restore_leaves_the_folder_empty(setup, outside) -> None:
    _, _, path = backed_up(setup, outside)
    target = outside / "mål"
    with pytest.raises(BackupError):
        service(setup).restore(path, "Feil passordfrase 1234", target)
    assert target.is_dir() and list(target.iterdir()) == []
    (failed,) = events(setup, AuditEventType.BACKUP_RESTORED)
    assert failed.details["valid"] is False
    (target / "noe.txt").write_text("x", encoding="utf-8")
    with pytest.raises(BackupError) as caught:
        service(setup).restore(path, PASSPHRASE, target)
    assert caught.value.reason == "not_empty"
    with pytest.raises(BackupError) as caught:
        service(setup).restore(path, PASSPHRASE, setup.tmp / "gjenopprett")
    assert caught.value.reason == "target_inside_data"


def test_a_backup_is_refused_when_the_chain_or_the_archive_is_broken(setup, outside) -> None:
    ready_invoice(setup)
    folder = outside / "disk"
    folder.mkdir()
    original = next((setup.tmp / "documents").rglob("originals/*/*/*"))
    original.chmod(0o600)
    content = original.read_bytes()
    original.unlink()
    with pytest.raises(BackupError) as caught:
        service(setup).create(folder, PASSPHRASE, PASSPHRASE)
    assert caught.value.reason == "source_incomplete"
    assert list(folder.iterdir()) == []
    original.write_bytes(content)
    with pytest.raises(BackupError) as caught:
        service(setup).create(folder, PASSPHRASE, "Annen passordfrase 42")
    assert caught.value.reason == "mismatch"
    with closing(sqlite3.connect(setup.database.path)) as connection:
        connection.execute("DROP TRIGGER audit_events_no_update")
        connection.execute("UPDATE audit_events SET actor = 'user/endret' WHERE sequence = 2")
        connection.commit()
    with pytest.raises(BackupError) as caught:
        service(setup).create(folder, PASSPHRASE, PASSPHRASE)
    assert caught.value.reason == "chain"
    assert service(setup).backups() == []


def test_a_restored_database_with_a_broken_chain_is_refused(setup, outside) -> None:
    ready_invoice(setup)
    folder = outside / "disk"
    folder.mkdir()
    backups = service(setup)

    class Tampering(SqliteSnapshotter):
        def snapshot(self, target):
            copy = super().snapshot(target)
            with closing(sqlite3.connect(target)) as connection:
                connection.execute("DROP TRIGGER audit_events_no_update")
                connection.execute(
                    "UPDATE audit_events SET actor = 'user/endret' WHERE sequence = 2"
                )
                connection.commit()
            return copy

    tampering = BackupService(
        setup.database.unit_of_work,
        Tampering(setup.database.path),
        FileBackupArchive(AppPaths(setup.tmp)),
        scrypt_n=2**10,
    )
    record = tampering.create(folder, PASSPHRASE, PASSPHRASE)
    with pytest.raises(BackupError) as caught:
        backups.verify(folder / record.file_name, PASSPHRASE)
    assert caught.value.reason == "chain"


def test_only_a_registered_backup_is_deleted_and_the_deletion_is_recorded(setup, outside):
    _, record, path = backed_up(setup, outside)
    stranger = outside / "fremmed.ifbak"
    stranger.write_bytes(b"not ours")
    with pytest.raises(BackupError) as caught:
        service(setup).delete(stranger)
    assert caught.value.reason == "unknown_backup" and stranger.exists()

    service(setup).delete(path)

    assert not path.exists()
    (listed,) = service(setup).backups()
    assert listed.deleted_at is not None and listed.deleted_by == "user/local"
    (deleted,) = events(setup, AuditEventType.BACKUP_DELETED)
    assert deleted.details == {
        "backup_id": str(record.backup_id),
        "file_sha256": record.file_sha256,
    }
    with closing(sqlite3.connect(setup.database.path)) as connection:
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute("DELETE FROM backups")
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute("UPDATE backups SET deleted_at = NULL, deleted_by = NULL")


def test_leftover_work_folders_are_removed_at_startup(setup) -> None:
    leftover = setup.tmp / "backups" / "work" / "avbrutt"
    leftover.mkdir(parents=True)
    (leftover / "invoiceflow.sqlite3").write_bytes(b"plain copy")
    assert service(setup).recover() == 1 and not leftover.exists()
