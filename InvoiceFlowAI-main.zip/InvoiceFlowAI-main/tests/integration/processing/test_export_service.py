"""Crash-safe export of approved invoices with a real database and folder (Phase 10)."""

import io
import os
import sqlite3
import stat
import zipfile
from contextlib import closing
from decimal import Decimal
from pathlib import Path

import openpyxl
import pytest
from invoice_steps import (
    events,
    import_ehf,
    ready_invoice,
    references,
    review,
    status,
)

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.errors import ConflictError, NotFoundError
from invoiceflow.application.export.model import (
    STANDARD_FIELDS,
    BatchStatus,
    ExportColumn,
    ExportError,
    ExportField,
    ExportTarget,
    ItemStatus,
)
from invoiceflow.application.export.service import ExportService
from invoiceflow.application.review.model import WorkflowStatus
from invoiceflow.application.review.service import ReviewError
from invoiceflow.bootstrap.synthetic_ehf import SyntheticEhf
from invoiceflow.export.csv_writer import CsvWriter
from invoiceflow.export.files import FileExportStore
from invoiceflow.export.xlsx_writer import XlsxWriter
from invoiceflow.i18n import t

pytestmark = pytest.mark.integration

HOSTILE = '=HYPERLINK("http://x.invalid";"klikk")'
REASON = "Filen ble slettet før import i regnskapet"


class Crash(BaseException):
    """Stands in for a power cut: no handler in the service catches it."""


class CrashingStore(FileExportStore):
    def __init__(self, root: Path, *, after_write: bool) -> None:
        super().__init__(root)
        self.after_write = after_write

    def write(self, entity_id, name, data):  # type: ignore[no-untyped-def]
        if self.after_write:
            super().write(entity_id, name, data)
        else:
            directory = self.root / entity_id.hex
            directory.mkdir(parents=True, exist_ok=True)
            (directory / f".{'a' * 32}.part").write_bytes(data[:10])
        raise Crash


class BrokenWriter:
    def render(self, sheet):  # type: ignore[no-untyped-def]
        raise ValueError("writer failed")


def exports(setup, *, store=None, writers=None) -> ExportService:
    return ExportService(
        setup.database.unit_of_work,
        writers or {ExportTarget.EXCEL: XlsxWriter(), ExportTarget.CSV: CsvWriter()},
        store or FileExportStore(setup.tmp / "exports"),
        t,
    )


def approve(setup, invoice_id, scope=None) -> None:
    scope = scope or setup.owner
    revision = review(setup).view(scope, invoice_id).record.revision
    review(setup).approve(scope, invoice_id, expected_revision=revision)


def approved_invoice(setup, scope=None):
    invoice_id = ready_invoice(setup, scope)
    approve(setup, invoice_id, scope)
    return invoice_id


def second_invoice(setup, spec: SyntheticEhf, name: str = "b.xml"):
    """Another invoice of the verified supplier: posted by its standard, no findings."""
    invoice_id = import_ehf(setup, spec, name=name)
    approve(setup, invoice_id)
    return invoice_id


def exported_file(setup, batch, scope=None) -> Path:
    return setup.tmp / "exports" / (scope or setup.owner).entity_id.hex / batch.file_name


def rows(path: Path, sheet: int = 0) -> list[tuple]:
    workbook = openpyxl.load_workbook(path)
    return list(workbook.worksheets[sheet].iter_rows(values_only=True))


def raw(setup, sql: str, *params) -> list[tuple]:
    with closing(sqlite3.connect(setup.database.path)) as connection:
        return connection.execute(sql, params).fetchall()


def test_an_approved_invoice_is_exported_to_excel_once(setup) -> None:
    invoice_id = approved_invoice(setup)
    service = exports(setup)
    assert [c.invoice_id for c in service.ready(setup.owner)] == [invoice_id]

    batch = service.export(setup.owner, ExportTarget.EXCEL)

    assert (batch.status, batch.item_count, batch.sequence) == (BatchStatus.WRITTEN, 1, 1)
    assert batch.file_name.startswith("fakturaeksport-00001-") and batch.file_name.endswith(".xlsx")
    path = exported_file(setup, batch)
    assert not os.stat(path).st_mode & stat.S_IWUSR  # read-only
    import hashlib

    assert hashlib.sha256(path.read_bytes()).hexdigest() == batch.file_sha256
    assert status(setup, invoice_id) == WorkflowStatus.EXPORTED
    assert service.ready(setup.owner) == []

    header, *data = rows(path)
    assert header == tuple(t(f"export.column.{field}") for field in STANDARD_FIELDS)
    assert len(data) == 1  # one accounting line (one VAT rate)
    values = dict(zip(STANDARD_FIELDS, data[0], strict=True))
    assert values[ExportField.SUPPLIER_NAME] == "Syntetisk Leverandør AS"
    assert values[ExportField.INVOICE_TYPE] == "Faktura"
    assert values[ExportField.GROSS_TOTAL] == 13125
    assert values[ExportField.ACCOUNT] == "6300"
    assert values[ExportField.INVOICE_ID] == str(invoice_id)
    assert values[ExportField.INVOICE_DATE].date().isoformat() == "2026-10-01"

    summary = dict(rows(path, 1))
    assert summary[t("export.summary.gross", currency="NOK")] == 13125
    assert summary[t("export.summary.posted", currency="NOK")] == 10500
    assert summary[t("export.summary.invoices")] == 1
    (completed,) = events(setup, AuditEventType.EXPORT_COMPLETED)
    assert summary[t("export.summary.anchor")] == batch.audit_anchor
    assert dict(completed.details) == {
        "batch_id": str(batch.batch_id),
        "target": "excel",
        "item_count": 1,
        "file_sha256": batch.file_sha256,
        "audit_anchor": batch.audit_anchor,
        "mapping_version": 0,
        "is_reexport": False,
        "recovered": False,
    }
    (exported,) = events(setup, AuditEventType.INVOICE_EXPORTED)
    assert exported.subject_id == str(invoice_id) and exported.details["revision"] == 2

    with pytest.raises(ExportError) as caught:
        service.export(setup.owner, ExportTarget.CSV)
    assert caught.value.reason == "nothing_to_export"


def test_only_approved_invoices_are_exported(setup) -> None:
    draft = ready_invoice(setup)
    with pytest.raises(ExportError):
        exports(setup).export(setup.owner, ExportTarget.EXCEL)
    approved = second_invoice(setup, SyntheticEhf(number="EHF-2026-002"))
    batch = exports(setup).export(setup.owner, ExportTarget.CSV)
    assert batch.item_count == 1
    assert status(setup, draft) == WorkflowStatus.DRAFT
    assert status(setup, approved) == WorkflowStatus.EXPORTED


def test_exported_sum_equals_the_sum_of_approved_invoices(setup) -> None:
    first = approved_invoice(setup)
    second = second_invoice(setup, SyntheticEhf(number="EHF-2026-002"))
    credit = second_invoice(setup, SyntheticEhf(number="K-2026-001", credit_note=True), "k.xml")
    batch = exports(setup).export(setup.owner, ExportTarget.EXCEL)
    path = exported_file(setup, batch)
    header, *data = rows(path)
    gross = header.index(t("export.column.gross_total"))
    line = header.index(t("export.column.line_net_amount"))
    kind = header.index(t("export.column.invoice_type"))
    ident = header.index(t("export.column.invoice_id"))
    per_invoice = {row[ident]: Decimal(str(row[gross])) for row in data}
    # Credit notes are exported with negative amounts (ADR-0020).
    assert per_invoice == {
        str(first): Decimal(13125),
        str(second): Decimal(13125),
        str(credit): Decimal(-13125),
    }
    summary = dict(rows(path, 1))
    assert (
        Decimal(str(summary[t("export.summary.gross", currency="NOK")]))
        == sum(per_invoice.values())
        == Decimal(13125)
    )
    assert Decimal(str(summary[t("export.summary.posted", currency="NOK")])) == sum(
        Decimal(str(row[line])) for row in data
    )
    assert {row[kind] for row in data} == {"Faktura", "Kreditnota"}


def test_csv_uses_bom_semicolon_decimal_comma_and_neutralizes_formulas(setup) -> None:
    approved_invoice(setup)
    second_invoice(
        setup,
        SyntheticEhf(number="-2+3", supplier_name=HOSTILE, buyer_reference="@SUM(A1)"),
    )
    batch = exports(setup).export(setup.owner, ExportTarget.CSV)
    data = exported_file(setup, batch).read_bytes()
    assert data.startswith(b"\xef\xbb\xbf")
    text = data.decode("utf-8-sig")
    lines = text.split("\r\n")
    assert lines[0].split(";")[0] == t("export.column.supplier_name")
    assert "13125,00" in text and "10500,00" in text and "01.10.2026" in text
    assert "'=HYPERLINK" in text and "'-2+3" in text
    import csv

    cells = [cell for row in csv.reader(io.StringIO(text), delimiter=";") for cell in row]
    assert not any(cell.startswith(("=", "+", "-", "@")) for cell in cells)


def test_excel_writes_hostile_text_as_text_never_as_a_formula(setup) -> None:
    approved_invoice(setup)
    second_invoice(setup, SyntheticEhf(number="+1", supplier_name=HOSTILE))
    batch = exports(setup).export(setup.owner, ExportTarget.EXCEL)
    path = exported_file(setup, batch)
    with zipfile.ZipFile(path) as archive:
        for name in archive.namelist():
            if name.startswith("xl/worksheets/"):
                assert b"<f>" not in archive.read(name) and b"<f " not in archive.read(name)
    sheet = openpyxl.load_workbook(path).worksheets[0]
    hostile = [cell for row in sheet.iter_rows() for cell in row if cell.value == HOSTILE]
    assert hostile and all(c.data_type == "s" and c.quotePrefix for c in hostile)


def test_an_exported_invoice_is_frozen(setup) -> None:
    invoice_id = approved_invoice(setup)
    exports(setup).export(setup.owner, ExportTarget.EXCEL)
    revision = review(setup).view(setup.owner, invoice_id).record.revision
    for action in (
        lambda: review(setup).edit(
            setup.owner, invoice_id, "buyer_reference", "Ny", expected_revision=revision
        ),
        lambda: review(setup).revoke(setup.owner, invoice_id, expected_revision=revision),
        lambda: review(setup).reject(
            setup.owner, invoice_id, expected_revision=revision, comment="Nei"
        ),
    ):
        with pytest.raises(ReviewError) as caught:
            action()
        assert caught.value.reason == "exported"
    assert references(setup).suggest(setup.owner, invoice_id) is None
    with closing(sqlite3.connect(setup.database.path)) as connection:
        for sql in (
            "UPDATE invoices SET workflow_status = 'draft'",
            "UPDATE invoices SET content_sha256 = ?",
        ):
            with pytest.raises(sqlite3.IntegrityError):
                connection.execute(sql, *(() if "?" not in sql else (("0" * 64,),)))
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute("DELETE FROM export_items")
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute("UPDATE export_items SET status = 'pending'")


def test_the_database_refuses_a_second_active_export(setup) -> None:
    invoice_id = approved_invoice(setup)
    batch = exports(setup).export(setup.owner, ExportTarget.EXCEL)
    (item,) = raw(setup, "SELECT approval_id, revision, content_sha256 FROM export_items")
    entity = setup.owner.entity_id.hex
    with closing(sqlite3.connect(setup.database.path)) as connection:
        connection.execute(
            "INSERT INTO export_batches VALUES (?, ?, 2, 'excel', 0, '[]', 'created',"
            " 'fakturaeksport-00002-20261024-100000.xlsx', NULL, 1, 0, NULL, ?,"
            " '2026-10-24T10:00:00.000000Z', 'user/local', NULL)",
            ("b" * 32, entity, "0" * 64),
        )
        for target in ("excel", "csv"):
            with pytest.raises(sqlite3.IntegrityError):
                connection.execute(
                    "INSERT INTO export_items (entity_id, batch_id, invoice_id, approval_id,"
                    " revision, content_sha256, target, status, created_at, updated_at)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)",
                    (
                        entity,
                        "b" * 32,
                        invoice_id.hex,
                        *item,
                        target,
                        "2026-10-24T10:00:00.000000Z",
                        "2026-10-24T10:00:00.000000Z",
                    ),
                )
    assert batch.item_count == 1


def test_a_failed_write_stores_a_failed_batch_and_keeps_the_invoice_approved(setup) -> None:
    invoice_id = approved_invoice(setup)
    broken = exports(setup, writers={ExportTarget.EXCEL: BrokenWriter()})
    with pytest.raises(ExportError) as caught:
        broken.export(setup.owner, ExportTarget.EXCEL)
    assert caught.value.reason == "write_failed"
    (failed,) = broken.batches(setup.owner)
    assert failed.status is BatchStatus.FAILED and failed.file_sha256 is None
    assert status(setup, invoice_id) == WorkflowStatus.APPROVED
    (event,) = events(setup, AuditEventType.EXPORT_FAILED)
    assert event.details["export_error"] == "write_failed"
    assert not (setup.tmp / "exports" / setup.owner.entity_id.hex / failed.file_name).exists()

    batch = exports(setup).export(setup.owner, ExportTarget.EXCEL)
    assert (batch.sequence, batch.status) == (2, BatchStatus.WRITTEN)
    assert status(setup, invoice_id) == WorkflowStatus.EXPORTED


def test_a_crash_after_the_file_was_renamed_is_completed_at_startup(setup) -> None:
    invoice_id = approved_invoice(setup)
    crashing = exports(setup, store=CrashingStore(setup.tmp / "exports", after_write=True))
    with pytest.raises(Crash):
        crashing.export(setup.owner, ExportTarget.CSV)
    (open_batch,) = exports(setup).batches(setup.owner)
    assert open_batch.status is BatchStatus.CREATED
    assert status(setup, invoice_id) == WorkflowStatus.APPROVED

    report = exports(setup).recover(setup.owner)

    assert (report.completed, report.failed) == (1, 0)
    (batch,) = exports(setup).batches(setup.owner)
    assert batch.status is BatchStatus.WRITTEN
    assert status(setup, invoice_id) == WorkflowStatus.EXPORTED
    (completed,) = events(setup, AuditEventType.EXPORT_COMPLETED)
    assert completed.details["recovered"] is True and completed.actor == "system"


def test_a_crash_before_the_file_existed_fails_the_batch_at_startup(setup) -> None:
    invoice_id = approved_invoice(setup)
    crashing = exports(setup, store=CrashingStore(setup.tmp / "exports", after_write=False))
    with pytest.raises(Crash):
        crashing.export(setup.owner, ExportTarget.EXCEL)

    # While the export is open the invoice cannot change or be decided again.
    revision = review(setup).view(setup.owner, invoice_id).record.revision
    with pytest.raises(ConflictError):
        review(setup).revoke(setup.owner, invoice_id, expected_revision=revision)
    with pytest.raises(ConflictError):
        review(setup).edit(
            setup.owner, invoice_id, "buyer_reference", "Ny", expected_revision=revision
        )

    report = exports(setup).recover(setup.owner)

    assert (report.completed, report.failed, report.temporary_removed) == (0, 1, 1)
    (batch,) = exports(setup).batches(setup.owner)
    assert batch.status is BatchStatus.FAILED
    assert status(setup, invoice_id) == WorkflowStatus.APPROVED
    (failed,) = events(setup, AuditEventType.EXPORT_FAILED)
    assert failed.details["export_error"] == "interrupted"
    # Recovery also runs before the next export, which now succeeds.
    assert exports(setup).export(setup.owner, ExportTarget.EXCEL).sequence == 2


def test_a_reexport_needs_a_reason_and_supersedes_the_earlier_export(setup) -> None:
    invoice_id = approved_invoice(setup)
    service = exports(setup)
    first = service.export(setup.owner, ExportTarget.EXCEL)
    with pytest.raises(ExportError) as caught:
        service.reexport(setup.owner, first.batch_id, "kort")
    assert caught.value.reason == "reason"

    again = service.reexport(setup.owner, first.batch_id, REASON, target=ExportTarget.CSV)

    assert (again.is_reexport, again.reexport_reason, again.target) == (
        True,
        REASON,
        ExportTarget.CSV,
    )
    assert raw(setup, "SELECT status FROM export_items ORDER BY id") == [
        (ItemStatus.SUPERSEDED,),
        (ItemStatus.EXPORTED,),
    ]
    assert status(setup, invoice_id) == WorkflowStatus.EXPORTED
    reexported = events(setup, AuditEventType.INVOICE_EXPORTED)[-1]
    assert reexported.details["is_reexport"] is True
    assert REASON not in str(events(setup, AuditEventType.EXPORT_COMPLETED)[-1].details)
    # The first batch no longer holds the latest export of the invoice.
    with pytest.raises(ExportError):
        service.reexport(setup.owner, first.batch_id, REASON)


def test_a_custom_mapping_is_versioned_and_used(setup) -> None:
    approved_invoice(setup)
    service = exports(setup)
    columns = [
        ExportColumn(ExportField.INVOICE_NUMBER, "Bilagsnr"),
        ExportColumn(ExportField.GROSS_TOTAL),
    ]
    mapping = service.set_mapping(setup.owner, columns, expected_version=0)
    assert mapping.version == 1
    with pytest.raises(ConflictError):
        service.set_mapping(setup.owner, columns, expected_version=0)
    for wrong, reason in (
        ([ExportColumn(ExportField.KID, "=1+1")], "header"),
        ([ExportColumn(ExportField.KID, "a‮b")], "header"),
        ([], "columns"),
        ([ExportColumn(ExportField.KID), ExportColumn(ExportField.KID)], "columns"),
        (
            [ExportColumn(ExportField.KID), ExportColumn(ExportField.IBAN, "KID")],
            "duplicate_header",
        ),
    ):
        with pytest.raises(ExportError) as caught:
            service.set_mapping(setup.owner, wrong, expected_version=1)
        assert caught.value.reason == reason

    batch = service.export(setup.owner, ExportTarget.EXCEL)

    assert batch.mapping_version == 1
    assert rows(exported_file(setup, batch)) == [
        ("Bilagsnr", t("export.column.gross_total")),
        ("EHF-2026-001", 13125),
    ]
    (event,) = events(setup, AuditEventType.EXPORT_MAPPING_SET)
    assert dict(event.details) == {"mapping_version": 1, "column_count": 2}


def test_a_copy_is_checked_against_the_stored_hash(setup, tmp_path) -> None:
    approved_invoice(setup)
    service = exports(setup)
    batch = service.export(setup.owner, ExportTarget.CSV)
    target = tmp_path / "kopi" / "eksport.csv"
    target.parent.mkdir()
    service.save_copy(setup.owner, batch.batch_id, target)
    assert target.read_bytes() == exported_file(setup, batch).read_bytes()

    path = exported_file(setup, batch)
    os.chmod(path, stat.S_IWUSR | stat.S_IRUSR)
    path.write_bytes(path.read_bytes() + b"x")
    with pytest.raises(ExportError) as caught:
        service.save_copy(setup.owner, batch.batch_id, target)
    assert caught.value.reason == "file_changed"
    path.unlink()
    with pytest.raises(ExportError) as caught:
        service.save_copy(setup.owner, batch.batch_id, target)
    assert caught.value.reason == "file_missing"


def test_exports_are_separated_by_entity(setup) -> None:
    approved_invoice(setup)
    service = exports(setup)
    batch = service.export(setup.owner, ExportTarget.EXCEL)
    assert service.ready(setup.other) == [] and service.batches(setup.other) == []
    with pytest.raises(NotFoundError):
        service.save_copy(setup.other, batch.batch_id, setup.tmp / "x.xlsx")
    with pytest.raises(NotFoundError):
        service.reexport(setup.other, batch.batch_id, REASON)
    with pytest.raises(ExportError):
        service.export(setup.other, ExportTarget.EXCEL)


def test_reexport_reasons_and_failed_batches(setup) -> None:
    invoice_id = approved_invoice(setup)
    broken = exports(setup, writers={ExportTarget.EXCEL: BrokenWriter()})
    with pytest.raises(ExportError):
        broken.export(setup.owner, ExportTarget.EXCEL)
    (failed,) = broken.batches(setup.owner)
    with pytest.raises(ExportError) as caught:
        broken.save_copy(setup.owner, failed.batch_id, setup.tmp / "x.xlsx")
    assert caught.value.reason == "not_written"
    # A failed first export is repeated by a normal export, not a re-export.
    with pytest.raises(ExportError) as caught:
        exports(setup).reexport(setup.owner, failed.batch_id, REASON)
    assert caught.value.reason == "nothing_to_export"
    for reason in ("kort", " " * 20, "Grunn med\u202e skjult tegn", "x" * 501):
        with pytest.raises(ExportError) as caught:
            exports(setup).reexport(setup.owner, failed.batch_id, reason)
        assert caught.value.reason == "reason"
    batch = exports(setup).export(setup.owner, ExportTarget.EXCEL)
    with pytest.raises(ExportError) as caught:
        exports(setup).save_copy(setup.owner, batch.batch_id, setup.tmp / "mangler" / "x.xlsx")
    assert caught.value.reason == "copy_failed"
    # A failed re-export can itself be exported again.
    crashing = exports(setup, writers={ExportTarget.EXCEL: BrokenWriter()})
    with pytest.raises(ExportError):
        crashing.reexport(setup.owner, batch.batch_id, REASON)
    failed_again = crashing.batches(setup.owner)[0]
    assert failed_again.status is BatchStatus.FAILED and failed_again.is_reexport
    again = exports(setup).reexport(setup.owner, failed_again.batch_id, REASON)
    assert again.status is BatchStatus.WRITTEN
    assert status(setup, invoice_id) == WorkflowStatus.EXPORTED
    assert raw(setup, "SELECT status FROM export_items ORDER BY id") == [
        (ItemStatus.FAILED,),
        (ItemStatus.SUPERSEDED,),
        (ItemStatus.SUPERSEDED,),
        (ItemStatus.EXPORTED,),
    ]
