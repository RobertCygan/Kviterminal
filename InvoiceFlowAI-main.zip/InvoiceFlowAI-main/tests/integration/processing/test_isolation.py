"""The real isolated worker: limits are enforced, not just configured (ADR-0010).

Every test here starts real ``spawn`` processes. The time and memory limits
are scaled down; the tests prove that the parent kills or outlives the
worker and that the worker process is gone afterwards.
"""

import ctypes
import hashlib
import os
import sys
import time
from pathlib import Path

import hostile_corpus as corpus
import hostile_workers
import pytest

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.ports import OcrTask, WorkerExit, WorkerTask
from invoiceflow.application.processing_model import (
    JobStatus,
    OcrSettings,
    ProcessingErrorCode,
    ProcessingLimits,
    WorkerResult,
)
from invoiceflow.bootstrap.synthetic_pdf import text_pdf
from invoiceflow.processing.isolation import IsolatedDocumentProcessor
from invoiceflow.processing.worker import child_main

pytestmark = [pytest.mark.integration, pytest.mark.security]

MEMORY = 512 * 1024 * 1024


def process_alive(pid: int) -> bool:
    if sys.platform == "win32":
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.restype = ctypes.c_void_p
        handle = kernel32.OpenProcess(0x00100000 | 0x1000, False, pid)  # SYNCHRONIZE | QUERY
        if not handle:
            return False
        try:
            return kernel32.WaitForSingleObject(ctypes.c_void_p(handle), 0) == 0x102  # TIMEOUT
        finally:
            kernel32.CloseHandle(ctypes.c_void_p(handle))
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    return True


def task_for(tmp_path: Path, data: bytes, fmt=DocumentFormat.PDF, **limits) -> WorkerTask:
    source = tmp_path / "original.bin"
    source.write_bytes(data)
    output = tmp_path / "out"
    output.mkdir()
    return WorkerTask(
        source,
        hashlib.sha256(data).hexdigest(),
        fmt,
        output,
        ProcessingLimits(**({"dpi": 72, "memory_bytes": MEMORY} | limits)),
    )


def run(target, task: WorkerTask, should_stop=lambda: False):
    processor = IsolatedDocumentProcessor(target=target)
    started = time.monotonic()
    outcome = processor.run(task, should_stop)
    elapsed = time.monotonic() - started
    assert processor.last_pid is not None
    assert not process_alive(processor.last_pid), "the worker must be gone"
    return outcome, elapsed


def test_a_real_worker_analyses_a_pdf(tmp_path) -> None:
    outcome, _ = run(child_main, task_for(tmp_path, text_pdf(["hei"])))
    assert outcome.exit is WorkerExit.COMPLETED
    result = WorkerResult.model_validate_json(outcome.payload)
    assert (result.status, result.page_count) == ("ok", 1)


def test_endless_work_is_killed_at_the_deadline(tmp_path) -> None:
    outcome, elapsed = run(
        hostile_workers.sleep_forever, task_for(tmp_path, b"%PDF-", timeout_seconds=3)
    )
    assert outcome.exit is WorkerExit.TIMED_OUT
    assert 3 <= elapsed < 30


def test_a_stop_request_kills_the_worker(tmp_path) -> None:
    deadline = time.monotonic() + 1
    outcome, elapsed = run(
        hostile_workers.sleep_forever,
        task_for(tmp_path, b"%PDF-", timeout_seconds=600),
        should_stop=lambda: time.monotonic() > deadline,
    )
    assert outcome.exit is WorkerExit.CANCELLED and elapsed < 60


def test_a_crash_without_report_is_a_crash(tmp_path) -> None:
    outcome, _ = run(hostile_workers.exit_hard, task_for(tmp_path, b"%PDF-"))
    assert outcome.exit is WorkerExit.CRASHED


def test_an_oversized_report_is_never_read(tmp_path) -> None:
    outcome, _ = run(hostile_workers.send_too_much, task_for(tmp_path, b"%PDF-"))
    assert outcome.exit is WorkerExit.INVALID_RESULT and outcome.payload is None


def test_unexpected_report_fields_arrive_as_bytes_only(tmp_path) -> None:
    outcome, _ = run(hostile_workers.send_garbage, task_for(tmp_path, b"%PDF-"))
    assert outcome.exit is WorkerExit.COMPLETED and isinstance(outcome.payload, bytes)


def test_the_memory_limit_stops_unbounded_allocation(tmp_path) -> None:
    outcome, _ = run(hostile_workers.allocate_until_limit, task_for(tmp_path, b"%PDF-1.4"))
    if outcome.exit is WorkerExit.COMPLETED:
        result = WorkerResult.model_validate_json(outcome.payload)
        assert result.error_code is ProcessingErrorCode.MEMORY_LIMIT
    else:
        assert outcome.exit in {WorkerExit.MEMORY_LIMIT, WorkerExit.CRASHED}


@pytest.mark.windows_only
@pytest.mark.skipif(sys.platform != "win32", reason="Windows Job Object")
def test_the_worker_cannot_start_further_processes(tmp_path) -> None:
    outcome, _ = run(hostile_workers.start_child_process, task_for(tmp_path, b"%PDF-"))
    assert outcome.payload == b"refused"


HOSTILE = {
    "pdf-image-bomb": (corpus.pdf_image_bomb(), DocumentFormat.PDF),
    "png-bomb": (corpus.png_bomb(), DocumentFormat.PNG),
    "many-pages": (corpus.pdf_many_pages(101), DocumentFormat.PDF),
    "deep-nesting": (corpus.pdf_deep_nesting(), DocumentFormat.PDF),
    "cyclic-pages": (corpus.pdf_cyclic_page_tree(), DocumentFormat.PDF),
    "damaged-xref": (corpus.pdf_damaged_xref(), DocumentFormat.PDF),
    "truncated": (corpus.pdf_truncated(), DocumentFormat.PDF),
    "zero-pages": (corpus.pdf_zero_pages(), DocumentFormat.PDF),
    "encrypted": (corpus.pdf_encrypted(), DocumentFormat.PDF),
    "javascript": (corpus.pdf_with_javascript(), DocumentFormat.PDF),
    "launch": (corpus.pdf_with_launch(), DocumentFormat.PDF),
    "embedded-file": (corpus.pdf_with_embedded_file(), DocumentFormat.PDF),
    "polyglot": (corpus.pdf_polyglot(), DocumentFormat.PDF),
    "huge-page": (corpus.pdf_huge_page(), DocumentFormat.PDF),
    "corrupt-jpeg": (corpus.corrupt_jpeg(), DocumentFormat.JPEG),
    "tiff-pages": (corpus.tiff_pages(101), DocumentFormat.TIFF),
}
EXPECTED = {
    "pdf-image-bomb": None,  # succeeds or hits the memory limit; never hangs
    "png-bomb": ProcessingErrorCode.PAGE_TOO_LARGE,
    "many-pages": ProcessingErrorCode.TOO_MANY_PAGES,
    "deep-nesting": None,
    "cyclic-pages": ProcessingErrorCode.CORRUPT,
    "damaged-xref": None,  # PDFium may repair the cross-reference table
    "truncated": None,
    "zero-pages": None,
    "encrypted": ProcessingErrorCode.ENCRYPTED,
    "javascript": "active",
    "launch": "active",
    "embedded-file": "active",
    "polyglot": "ok",
    "huge-page": ProcessingErrorCode.PAGE_TOO_LARGE,
    "corrupt-jpeg": ProcessingErrorCode.CORRUPT,
    "tiff-pages": ProcessingErrorCode.TOO_MANY_PAGES,
}


@pytest.mark.parametrize("name", list(HOSTILE))
def test_hostile_corpus_through_the_isolated_worker(setup, name) -> None:
    data, fmt = HOSTILE[name]
    extension = {
        DocumentFormat.PDF: "pdf",
        DocumentFormat.PNG: "png",
        DocumentFormat.JPEG: "jpg",
        DocumentFormat.TIFF: "tif",
    }[fmt]
    document_id = setup.add(data, f"fiendtlig.{extension}")
    processor = IsolatedDocumentProcessor()
    service = setup.make(processor, timeout_seconds=60, memory_bytes=1024 * 1024 * 1024)
    job = service.process(setup.owner, document_id)

    assert not process_alive(processor.last_pid)
    expected = EXPECTED[name]
    if expected == "active":
        assert (job.status, job.active_content) == (JobStatus.SUCCEEDED, True)
    elif expected == "ok":
        assert (job.status, job.active_content) == (JobStatus.SUCCEEDED, False)
    elif expected is None:
        assert job.status in {JobStatus.SUCCEEDED, JobStatus.FAILED}
        assert job.status is JobStatus.SUCCEEDED or job.error_code in {
            ProcessingErrorCode.CORRUPT,
            ProcessingErrorCode.NO_PAGES,
            ProcessingErrorCode.MEMORY_LIMIT,
            ProcessingErrorCode.WORKER_CRASHED,
        }
    else:
        assert (job.status, job.error_code) == (JobStatus.FAILED, expected)
    # The main process kept working and nothing escaped the job folders.
    assert setup.documents.verify_integrity(setup.owner) == {document_id: "ok"}
    assert not any((setup.store.root / setup.owner.entity_id.hex / "work").iterdir())


EHF_CASES = {
    "valid": (None, JobStatus.SUCCEEDED),
    "xxe": (ProcessingErrorCode.INVALID_XML, JobStatus.FAILED),
    "billion-laughs": (ProcessingErrorCode.INVALID_XML, JobStatus.FAILED),
    "deep-nesting": (ProcessingErrorCode.INVALID_XML, JobStatus.FAILED),
    "ehf-2": (ProcessingErrorCode.UNSUPPORTED_VERSION, JobStatus.FAILED),
}


@pytest.mark.parametrize("name", list(EHF_CASES))
def test_ehf_through_the_isolated_worker(setup, name) -> None:
    import hostile_xml

    from invoiceflow.bootstrap.synthetic_ehf import build_ehf

    data = {
        "valid": build_ehf,
        "xxe": hostile_xml.external_entity,
        "billion-laughs": hostile_xml.billion_laughs,
        "deep-nesting": hostile_xml.deep_nesting,
        "ehf-2": hostile_xml.ehf_2,
    }[name]()
    document_id = setup.add(data, "faktura.xml")
    processor = IsolatedDocumentProcessor()
    job = setup.make(processor, timeout_seconds=60).process(setup.owner, document_id)
    assert not process_alive(processor.last_pid)
    code, status = EHF_CASES[name]
    assert (job.status, job.error_code) == (status, code)


def test_an_ocr_task_without_tesseract_never_starts_a_worker(tmp_path) -> None:
    calls = []

    def nothing():
        calls.append(1)

    processor = IsolatedDocumentProcessor(locate_tesseract=nothing)
    assert processor.ocr_engine(OcrSettings()) is None
    task = WorkerTask(
        tmp_path / "x",
        "0" * 64,
        DocumentFormat.PNG,
        tmp_path,
        ProcessingLimits(),
        OcrTask(OcrSettings(), (), 1.0),
    )
    assert processor.run(task, lambda: False).exit is WorkerExit.CRASHED
    assert processor.last_pid is None
    assert calls == [1]  # looked for once per run of the application
