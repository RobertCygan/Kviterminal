"""Review, correction and hash-bound approval with a real database (Phase 09)."""

import sqlite3
from contextlib import closing
from decimal import Decimal

import pytest
from invoice_steps import (
    events,
    import_ehf,
    ready_invoice,
    review,
    status,
    validation,
)

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.errors import ConflictError, NotFoundError
from invoiceflow.application.review.editing import EditError
from invoiceflow.application.review.model import Decision, WorkflowStatus
from invoiceflow.application.review.service import ReviewError, ReviewService
from invoiceflow.application.validation.model import RuleId

pytestmark = pytest.mark.integration

REASON = "Avtalt med leverandør på telefon"


def test_a_clean_invoice_is_approved_bound_to_its_content(setup) -> None:
    invoice_id = ready_invoice(setup)
    view = review(setup).view(setup.owner, invoice_id)
    assert view.run is not None and view.run.findings == ()
    decision = review(setup).approve(
        setup.owner, invoice_id, expected_revision=view.record.revision, comment="Ok"
    )
    assert (decision.decision, decision.revision, decision.content_sha256) == (
        Decision.APPROVED,
        view.record.revision,
        view.record.content_sha256,
    )
    assert status(setup, invoice_id) == WorkflowStatus.APPROVED
    (approved,) = events(setup, AuditEventType.INVOICE_APPROVED)
    assert dict(approved.details) == {
        "approval_id": str(decision.approval_id),
        "revision": view.record.revision,
        "content_sha256": view.record.content_sha256,
        "run_id": str(decision.run_id),
        "override_count": 0,
    }
    with pytest.raises(ReviewError) as caught:
        review(setup).approve(setup.owner, invoice_id, expected_revision=view.record.revision)
    assert caught.value.reason == "already_approved"


def test_an_edit_after_approval_revokes_it(setup) -> None:
    invoice_id = ready_invoice(setup)
    revision = review(setup).view(setup.owner, invoice_id).record.revision
    review(setup).approve(setup.owner, invoice_id, expected_revision=revision)
    edited = review(setup).edit(
        setup.owner, invoice_id, "buyer_reference", "Ny ref", expected_revision=revision
    )
    assert edited.revision == revision + 1
    assert status(setup, invoice_id) == WorkflowStatus.DRAFT
    view = review(setup).view(setup.owner, invoice_id)
    assert [d.decision for d in view.decisions] == [Decision.APPROVED, Decision.REVOKED]
    assert view.decisions[-1].revision == revision
    assert view.run is not None and view.run.revision == revision + 1
    assert len(events(setup, AuditEventType.INVOICE_APPROVAL_REVOKED)) == 1
    # The new content can be approved again.
    review(setup).approve(setup.owner, invoice_id, expected_revision=revision + 1)
    assert status(setup, invoice_id) == WorkflowStatus.APPROVED


def test_bank_and_duplicate_findings_block_and_cannot_be_overridden(setup) -> None:
    invoice_id = import_ehf(setup)
    service = review(setup)
    view = service.view(setup.owner, invoice_id)
    with pytest.raises(ReviewError) as caught:
        service.approve(setup.owner, invoice_id, expected_revision=view.record.revision)
    assert (caught.value.reason, caught.value.params) == ("blocked", {"rule": "BANK-001"})
    bank = next(f for f in view.run.findings if f.rule_id is RuleId.BANK_001)
    with pytest.raises(ReviewError) as caught:
        service.override(
            setup.owner, invoice_id, bank, REASON, expected_revision=view.record.revision
        )
    assert caught.value.reason == "not_overridable"
    assert status(setup, invoice_id) == WorkflowStatus.DRAFT
    assert events(setup, AuditEventType.INVOICE_APPROVED) == []


def test_other_errors_can_be_overridden_with_a_reason(setup) -> None:
    invoice_id = ready_invoice(setup)
    service = review(setup)
    revision = service.view(setup.owner, invoice_id).record.revision
    # A wrong due date gives DAT-001; it can be accepted with a reason.
    service.edit(setup.owner, invoice_id, "due_date", "01.09.2026", expected_revision=revision)
    view = service.view(setup.owner, invoice_id)
    (finding,) = view.run.findings
    assert finding.rule_id is RuleId.DAT_001
    with pytest.raises(ReviewError) as caught:
        service.approve(setup.owner, invoice_id, expected_revision=view.record.revision)
    assert (caught.value.reason, caught.value.params) == ("open_errors", {"count": 1})
    for short in ("", "for kort", "x" * 501, "Grunn‮ med skjult tegn"):
        with pytest.raises(ReviewError) as caught:
            service.override(
                setup.owner, invoice_id, finding, short, expected_revision=view.record.revision
            )
        assert caught.value.reason == "reason"
    service.override(
        setup.owner, invoice_id, finding, REASON, expected_revision=view.record.revision
    )
    assert service.view(setup.owner, invoice_id).is_overridden(finding)
    decision = service.approve(setup.owner, invoice_id, expected_revision=view.record.revision)
    (approved,) = events(setup, AuditEventType.INVOICE_APPROVED)
    assert approved.details["override_count"] == 1
    (overridden,) = events(setup, AuditEventType.FINDING_OVERRIDDEN)
    assert dict(overridden.details) == {"revision": view.record.revision, "rule_id": "DAT-001"}
    assert REASON not in str(overridden.details)
    assert decision.decision is Decision.APPROVED


def test_an_override_does_not_carry_over_to_new_content(setup) -> None:
    invoice_id = ready_invoice(setup)
    service = review(setup)
    revision = service.view(setup.owner, invoice_id).record.revision
    service.edit(setup.owner, invoice_id, "due_date", "01.09.2026", expected_revision=revision)
    view = service.view(setup.owner, invoice_id)
    service.override(
        setup.owner,
        invoice_id,
        view.run.findings[0],
        REASON,
        expected_revision=view.record.revision,
    )
    service.edit(
        setup.owner, invoice_id, "due_date", "02.09.2026", expected_revision=view.record.revision
    )
    newer = service.view(setup.owner, invoice_id)
    assert not newer.is_overridden(newer.run.findings[0])
    with pytest.raises(ReviewError):
        service.approve(setup.owner, invoice_id, expected_revision=newer.record.revision)


def test_stale_revisions_are_conflicts(setup) -> None:
    invoice_id = ready_invoice(setup)
    service = review(setup)
    revision = service.view(setup.owner, invoice_id).record.revision
    service.edit(setup.owner, invoice_id, "buyer_reference", "A", expected_revision=revision)
    for action in (
        lambda: service.approve(setup.owner, invoice_id, expected_revision=revision),
        lambda: service.edit(
            setup.owner, invoice_id, "buyer_reference", "B", expected_revision=revision
        ),
        lambda: service.reject(setup.owner, invoice_id, expected_revision=revision, comment="Nei"),
    ):
        with pytest.raises(ConflictError):
            action()


def test_reject_and_revoke(setup) -> None:
    invoice_id = ready_invoice(setup)
    service = review(setup)
    revision = service.view(setup.owner, invoice_id).record.revision
    with pytest.raises(ReviewError) as caught:
        service.reject(setup.owner, invoice_id, expected_revision=revision, comment=" ")
    assert caught.value.reason == "comment"
    with pytest.raises(ReviewError) as caught:
        service.revoke(setup.owner, invoice_id, expected_revision=revision)
    assert caught.value.reason == "not_approved"
    service.reject(setup.owner, invoice_id, expected_revision=revision, comment="Ikke bestilt")
    assert status(setup, invoice_id) == WorkflowStatus.REJECTED
    # A rejected invoice can still be approved later (e.g. after clarification).
    service.approve(setup.owner, invoice_id, expected_revision=revision)
    service.revoke(setup.owner, invoice_id, expected_revision=revision)
    assert status(setup, invoice_id) == WorkflowStatus.DRAFT
    decisions = [d.decision for d in service.view(setup.owner, invoice_id).decisions]
    assert decisions == [Decision.REJECTED, Decision.APPROVED, Decision.REVOKED]
    assert service.view(setup.owner, invoice_id).decisions[0].comment == "Ikke bestilt"


def test_an_invalid_edit_changes_nothing(setup) -> None:
    invoice_id = ready_invoice(setup)
    service = review(setup)
    before = service.view(setup.owner, invoice_id).record
    with pytest.raises(EditError):
        service.edit(
            setup.owner, invoice_id, "totals.gross_amount", "mye", expected_revision=before.revision
        )
    assert service.view(setup.owner, invoice_id).record == before


def test_edited_totals_are_validated_again(setup) -> None:
    invoice_id = ready_invoice(setup)
    service = review(setup)
    revision = service.view(setup.owner, invoice_id).record.revision
    service.edit(
        setup.owner, invoice_id, "totals.gross_amount", "13 000,00", expected_revision=revision
    )
    view = service.view(setup.owner, invoice_id)
    assert view.record.invoice.totals.gross_amount.value == Decimal("13000.00")
    assert "SUM-002" in {f.rule_id.value for f in view.run.findings}
    assert [r.revision for r in view.revisions] == list(range(1, view.record.revision + 1))


def test_another_entity_sees_nothing(setup) -> None:
    invoice_id = ready_invoice(setup)
    service = review(setup)
    with pytest.raises(NotFoundError):
        service.view(setup.other, invoice_id)
    with pytest.raises(NotFoundError):
        service.approve(setup.other, invoice_id, expected_revision=2)


def test_a_crash_before_commit_approves_nothing(setup, monkeypatch) -> None:
    from invoiceflow.persistence.repositories import SqlAuditLog

    invoice_id = ready_invoice(setup)
    revision = review(setup).view(setup.owner, invoice_id).record.revision
    original = SqlAuditLog.append

    def failing(self, draft, *, occurred_at):
        if draft.event_type == AuditEventType.INVOICE_APPROVED:
            raise RuntimeError("simulated crash")
        return original(self, draft, occurred_at=occurred_at)

    monkeypatch.setattr(SqlAuditLog, "append", failing)
    with pytest.raises(RuntimeError):
        review(setup).approve(setup.owner, invoice_id, expected_revision=revision)
    monkeypatch.undo()
    assert status(setup, invoice_id) == WorkflowStatus.DRAFT
    assert review(setup).view(setup.owner, invoice_id).decisions == ()


@pytest.mark.security
def test_the_approval_gate_resists_tampering(setup) -> None:
    invoice_id = ready_invoice(setup)
    revision = review(setup).view(setup.owner, invoice_id).record.revision
    with closing(sqlite3.connect(setup.database.path)) as connection:
        # Status approved without an approval of this content.
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute("UPDATE invoices SET workflow_status = 'approved'")
        connection.rollback()
    review(setup).approve(setup.owner, invoice_id, expected_revision=revision)
    with closing(sqlite3.connect(setup.database.path)) as connection:
        for statement in [
            "UPDATE approvals SET decision = 'rejected'",
            "DELETE FROM approvals",
            "UPDATE invoices SET content_sha256 = (SELECT content_sha256 FROM invoice_revisions"
            " WHERE revision = 1)",
        ]:
            with pytest.raises(sqlite3.IntegrityError):
                connection.execute(statement)
        entity, invoice = connection.execute("SELECT entity_id, id FROM invoices").fetchone()
        # BANK-001 and DUP-001 cannot be overridden even directly in the database.
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute(
                "INSERT INTO finding_overrides VALUES (?, ?, ?, ?, 'BANK-001', NULL,"
                " 'validation.bank_001_unverified', 'Ingen grunn i det hele tatt',"
                " '2026-10-20T10:00:00.000000Z', 'user/local')",
                ("f" * 32, entity, invoice, revision),
            )
        connection.rollback()


def test_the_preview_is_the_first_page_of_the_analysed_pdf_view(setup) -> None:
    from invoiceflow.bootstrap.synthetic_ehf import Attachment, SyntheticEhf
    from invoiceflow.bootstrap.synthetic_pdf import text_pdf

    pdf = text_pdf(["Syntetisk visning"])
    invoice_id = import_ehf(setup, SyntheticEhf(attachments=(Attachment(pdf),)))
    service = ReviewService(setup.database.unit_of_work, validation(setup), derived=setup.derived)
    assert service.preview(setup.owner, invoice_id) is None  # the PDF is not analysed yet
    assert review(setup).preview(setup.owner, invoice_id) is None  # no derived store
    setup.make().process_pending(setup.owner)
    image = service.preview(setup.owner, invoice_id)
    assert image is not None and image.startswith(b"\x89PNG")
    # A changed file on disk is never shown.
    with closing(sqlite3.connect(setup.database.path)) as connection:
        (storage_path,) = connection.execute(
            "SELECT storage_path FROM derived_files WHERE kind = 'page_render'"
        ).fetchone()
    target = setup.derived.root / storage_path
    target.chmod(0o644)
    target.write_bytes(b"\x89PNG endret")
    assert service.preview(setup.owner, invoice_id) is None
    assert setup.derived.read_published("../x/derived/a/b", "0" * 64, 10) is None
