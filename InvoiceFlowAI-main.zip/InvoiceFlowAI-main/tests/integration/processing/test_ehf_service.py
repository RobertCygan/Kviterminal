"""EHF import end to end: database, archive, worker code (in-process) and checks."""

import json
from decimal import Decimal

import hostile_corpus
import hostile_xml
import pytest
from processing_fakes import InProcessProcessor, ScriptedProcessor

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.document_model import DocumentStatus, ImportSource
from invoiceflow.application.errors import NotFoundError
from invoiceflow.application.processing_model import (
    JobStatus,
    ProcessingErrorCode,
    ProcessingStep,
)
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import EntityService, InvoiceService
from invoiceflow.bootstrap.synthetic_ehf import (
    CUSTOMER_ORG,
    Attachment,
    Line,
    SyntheticEhf,
    build_ehf,
)
from invoiceflow.bootstrap.synthetic_pdf import text_pdf

pytestmark = pytest.mark.integration


def ehf_document(setup, spec: SyntheticEhf | None = None, *, name="faktura.xml", scope=None):
    return setup.add(build_ehf(spec), name, scope=scope)


def summary(setup, document_id, scope=None):
    return (
        InvoiceService(setup.database.unit_of_work).summaries(scope or setup.owner).get(document_id)
    )


def events(setup, *types):
    with setup.database.unit_of_work() as uow:
        return [r for r in uow.audit.records() if not types or r.event_type in types]


def test_an_ehf_invoice_becomes_a_draft_invoice(setup) -> None:
    document_id = ehf_document(setup)
    job = setup.make().process(setup.owner, document_id)
    assert (job.status, job.step, job.engine, job.page_count) == (
        JobStatus.SUCCEEDED,
        ProcessingStep.EHF_EXTRACTION,
        "ehf",
        None,
    )
    found = summary(setup, document_id)
    assert (found.supplier_name, found.invoice_number, found.gross_amount, found.currency) == (
        "Syntetisk Leverandør AS",
        "EHF-2026-001",
        Decimal("13125.00"),
        "NOK",
    )
    assert found.findings == ()
    record = InvoiceService(setup.database.unit_of_work).get(setup.owner, found.invoice_id)
    assert record.workflow_status == "draft" and record.invoice.document_id == document_id
    assert len(events(setup, AuditEventType.INVOICE_CREATED)) == 1
    (finished,) = events(setup, AuditEventType.PROCESSING_FINISHED)
    assert dict(finished.details) == {
        "job_id": str(job.job_id),
        "step": "ehf_extraction",
        "job_status": "succeeded",
        "active_content": False,
        "line_count": 2,
        "attachment_count": 0,
        "finding_count": 0,
    }
    text = json.dumps([dict(event.details) for event in events(setup)])
    assert "Syntetisk" not in text and "13125" not in text and "EHF-2026" not in text


def test_processing_is_idempotent_and_never_registers_twice(setup) -> None:
    document_id = ehf_document(setup)
    service = setup.make()
    first = service.process(setup.owner, document_id)
    assert service.process(setup.owner, document_id) == first
    assert service.process_pending(setup.owner) == []

    # A new parser version is a new job, but the document keeps one invoice.
    class NewerParser(InProcessProcessor):
        def engine_for(self, document_format):
            engine, version = super().engine_for(document_format)
            return engine, version + ".1"

        def run(self, task, should_stop):
            outcome = super().run(task, should_stop)
            report = json.loads(outcome.payload)
            report["engine_version"] += ".1"
            return type(outcome)(outcome.exit, json.dumps(report).encode())

    second = setup.make(NewerParser()).process(setup.owner, document_id)
    assert second.job_id != first.job_id and second.status is JobStatus.SUCCEEDED
    with setup.database.unit_of_work() as uow:
        assert len(uow.invoices(setup.owner).ids_for_document(document_id)) == 1


@pytest.mark.parametrize(
    ("spec", "codes"),
    [
        (SyntheticEhf(payable_override="99.00"), ("payable_mismatch",)),
        (SyntheticEhf(tax_override="1.00"), ("gross_mismatch", "vat_mismatch")),
        (SyntheticEhf(currency="EUR"), ()),
    ],
    ids=["payable", "vat", "foreign-currency"],
)
def test_arithmetic_deviations_are_flagged(setup, spec, codes) -> None:
    document_id = ehf_document(setup, spec)
    job = setup.make().process(setup.owner, document_id)
    assert job.status is JobStatus.SUCCEEDED
    assert summary(setup, document_id).findings == codes


def test_recipient_is_compared_with_the_entity(setup) -> None:
    entities = EntityService(setup.database.unit_of_work)
    udi = EntityScope(entities.create(name="Mottaker AS", org_number=CUSTOMER_ORG).entity_id)
    right = ehf_document(setup, scope=udi)
    wrong = ehf_document(setup, SyntheticEhf(number="2", customer_org="999999999"), scope=udi)
    missing = ehf_document(setup, SyntheticEhf(number="3", customer_org=None), scope=udi)
    service = setup.make()
    for document_id in (right, wrong, missing):
        assert service.process(udi, document_id).status is JobStatus.SUCCEEDED
    assert summary(setup, right, udi).findings == ()
    assert summary(setup, wrong, udi).findings == ("wrong_recipient",)
    assert summary(setup, missing, udi).findings == ("missing_recipient",)


def test_same_number_from_the_same_supplier_is_a_possible_duplicate(setup) -> None:
    first = ehf_document(setup)
    second = ehf_document(setup, SyntheticEhf(buyer_reference="annen fil"), name="kopi.xml")
    service = setup.make()
    service.process(setup.owner, first)
    service.process(setup.owner, second)
    assert summary(setup, first).findings == ()
    assert summary(setup, second).findings == ("possible_duplicate",)


def test_identical_file_is_a_duplicate_already_at_import(setup) -> None:
    ehf_document(setup)
    source = setup.tmp / "kilde" / "faktura.xml"
    assert setup.documents.import_file(setup.owner, source).outcome == "duplicate"


def test_attachments_are_imported_and_linked(setup) -> None:
    pdf = text_pdf(["Visning av fakturaen"])
    spec = SyntheticEhf(
        attachments=(
            Attachment(pdf),
            Attachment(b"MZ ikke en PDF", "forkledd.pdf"),
            Attachment(hostile_corpus.png_page(), "", "image/png"),
        )
    )
    document_id = ehf_document(setup, spec)
    job = setup.make().process(setup.owner, document_id)
    assert job.status is JobStatus.SUCCEEDED
    with setup.database.unit_of_work() as uow:
        repository = uow.documents(setup.owner)
        links = repository.links(document_id)
        linked = [repository.get(target) for _, target, _ in links]
    assert [link[2] for link in links] == ["attachment"] * 3
    assert {(doc.display_name, doc.status, doc.source) for doc in linked} == {
        ("faktura.pdf", DocumentStatus.STORED, ImportSource.EHF_ATTACHMENT),
        ("forkledd.pdf", DocumentStatus.QUARANTINED, ImportSource.EHF_ATTACHMENT),
        ("vedlegg-03.png", DocumentStatus.STORED, ImportSource.EHF_ATTACHMENT),
    }
    assert summary(setup, document_id).findings == ("attachment_refused",)
    # The PDF view can now be analysed like any other PDF (F04).
    pending = setup.make().process_pending(setup.owner)
    assert {job.step for job in pending} == {ProcessingStep.PAGE_ANALYSIS}
    assert len(pending) == 2


def test_an_attachment_already_in_the_archive_is_linked_not_copied(setup) -> None:
    pdf = text_pdf(["Felles vedlegg"])
    existing = setup.add(pdf, "vedlegg.pdf")
    document_id = ehf_document(setup, SyntheticEhf(attachments=(Attachment(pdf),)))
    setup.make().process(setup.owner, document_id)
    with setup.database.unit_of_work() as uow:
        assert [link[1] for link in uow.documents(setup.owner).links(document_id)] == [existing]


@pytest.mark.security
@pytest.mark.parametrize(
    ("data", "code"),
    [
        (hostile_xml.external_entity(), ProcessingErrorCode.INVALID_XML),
        (hostile_xml.billion_laughs(), ProcessingErrorCode.INVALID_XML),
        (hostile_xml.ehf_2(), ProcessingErrorCode.UNSUPPORTED_VERSION),
        (hostile_xml.wrong_root(), ProcessingErrorCode.UNSUPPORTED_FORMAT),
    ],
    ids=["xxe", "billion-laughs", "ehf-2", "wrong-root"],
)
def test_refused_files_register_nothing(setup, data, code) -> None:
    document_id = setup.add(data, "fiendtlig.xml")
    job = setup.make().process(setup.owner, document_id)
    assert (job.status, job.error_code) == (JobStatus.FAILED, code)
    assert summary(setup, document_id) is None
    assert not events(setup, AuditEventType.INVOICE_CREATED)


def test_unreadable_and_missing_values_are_flagged(setup) -> None:
    unreadable = setup.add(hostile_xml.bad_numbers(), "tall.xml")
    missing = setup.add(hostile_xml.missing_required(), "mangler.xml")
    external = setup.add(hostile_xml.external_attachment(), "ekstern.xml")
    service = setup.make()
    for document_id in (unreadable, missing, external):
        assert service.process(setup.owner, document_id).status is JobStatus.SUCCEEDED
    # A present but unreadable amount is unreadable, not missing.
    assert summary(setup, unreadable).findings == ("unreadable_value",)
    assert summary(setup, missing).findings == ("missing_required",)
    # Same supplier and number as the first file, so also a possible duplicate.
    assert summary(setup, external).findings == ("external_attachment", "possible_duplicate")


TAMPERING = {
    "engine": lambda r, o: r.update(engine="pypdfium2"),
    "version": lambda r, o: r.update(engine_version="9.9"),
    "hash": lambda r, o: r.update(sha256="0" * 64),
    "foreign-code": lambda r, o: r.update(
        status="error", error_code="encrypted", invoice=None, monetary=None
    ),
    "extra": lambda r, o: r.update(extra=1),
    "invoice": lambda r, o: r["invoice"].update(lines="nei"),
    "attachment-size": lambda r, o: r["attachments"][0].update(size_bytes=1),
    "attachment-missing": lambda r, o: (o / "attachment-01.bin").unlink(),
    "attachment-name": lambda r, o: r["attachments"][0].update(file="../x.bin"),
}


@pytest.mark.security
@pytest.mark.parametrize("tamper", list(TAMPERING.values()), ids=list(TAMPERING))
def test_untrustworthy_ehf_reports_register_nothing(setup, tamper) -> None:
    spec = SyntheticEhf(attachments=(Attachment(text_pdf(["v"])),))
    document_id = ehf_document(setup, spec)
    job = setup.make(ScriptedProcessor(tamper)).process(setup.owner, document_id)
    assert (job.status, job.error_code) == (JobStatus.FAILED, ProcessingErrorCode.INVALID_RESULT)
    assert summary(setup, document_id) is None
    assert len(setup.documents.list_documents(setup.owner)) == 1  # no attachment imported


def test_other_entities_see_nothing(setup) -> None:
    document_id = ehf_document(setup)
    setup.make().process(setup.owner, document_id)
    with pytest.raises(NotFoundError):
        setup.make().process(setup.other, document_id)
    assert summary(setup, document_id, setup.other) is None
    other_document = ehf_document(setup, scope=setup.other)
    setup.make().process(setup.other, other_document)
    # The same file in another entity is its own invoice, not a duplicate.
    assert summary(setup, other_document, setup.other).findings == ()


def test_a_crash_before_the_final_commit_registers_nothing(setup, monkeypatch) -> None:
    document_id = ehf_document(setup)
    service = setup.make()

    def lost(*args, **kwargs):
        raise RuntimeError("simulated crash")

    monkeypatch.setattr(service, "_finish_ehf", lost)
    with pytest.raises(RuntimeError):
        service.process(setup.owner, document_id)
    (job,) = service.latest_jobs(setup.owner).values()
    assert job.error_code is ProcessingErrorCode.STORAGE_FAILED
    assert summary(setup, document_id) is None
    monkeypatch.undo()
    assert service.process(setup.owner, document_id).status is JobStatus.SUCCEEDED
    assert summary(setup, document_id).gross_amount == Decimal("13125.00")


def test_many_lines_are_registered_exactly(setup) -> None:
    lines = tuple(Line(f"Vare {number}", "1", "0.10") for number in range(1, 201))
    document_id = ehf_document(setup, SyntheticEhf(lines=lines))
    setup.make().process(setup.owner, document_id)
    found = summary(setup, document_id)
    assert found.gross_amount == Decimal("25.00") and found.findings == ()
