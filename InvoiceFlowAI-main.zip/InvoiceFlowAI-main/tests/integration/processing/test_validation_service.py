"""Validation runs and the supplier register against a real database (Phase 08a)."""

import datetime as dt
import sqlite3
from contextlib import closing

import pytest
from processing_fakes import InProcessProcessor

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.documents import DocumentService
from invoiceflow.application.errors import ConflictError, InvoiceFlowError, NotFoundError
from invoiceflow.application.processing import ProcessingService
from invoiceflow.application.processing_model import ProcessingLimits
from invoiceflow.application.services import InvoiceService
from invoiceflow.application.validation.model import AccountKind, AccountStatus, Severity
from invoiceflow.application.validation.service import USER_ACTOR, ValidationService
from invoiceflow.bootstrap.synthetic_ehf import SyntheticEhf, build_ehf
from invoiceflow.domain.provenance import FieldValue

pytestmark = pytest.mark.integration

TODAY = dt.date(2026, 10, 20)


def service(setup) -> ValidationService:
    return ValidationService(setup.database.unit_of_work, today=lambda: TODAY)


def processing(setup) -> ProcessingService:
    return ProcessingService(
        setup.database.unit_of_work,
        setup.store,
        setup.derived,
        InProcessProcessor(),
        attachments=DocumentService(setup.database.unit_of_work, setup.store),
        validator=service(setup),
        limits=ProcessingLimits(dpi=72),
    )


def import_ehf(setup, spec: SyntheticEhf | None = None, *, scope=None, name="faktura.xml"):
    """Import and process one EHF file; return the registered invoice id."""
    scope = scope or setup.owner
    document_id = setup.add(build_ehf(spec), name, scope=scope)
    processing(setup).process(scope, document_id)
    summary = InvoiceService(setup.database.unit_of_work).summaries(scope)[document_id]
    return summary.invoice_id


# Phase 08b rules (posting and reference data) are tested in test_reference_service.py.
F08B_RULES = ("MVA-002", "ACC-")


def f08a(findings) -> list:
    return [f for f in findings if not f.rule_id.value.startswith(F08B_RULES)]


def codes(run) -> list[tuple[str, str]]:
    return [
        (f.rule_id.value, f.message_key.removeprefix("validation.")) for f in f08a(run.findings)
    ]


def events(setup, *types):
    with setup.database.unit_of_work() as uow:
        return [r for r in uow.audit.records() if r.event_type in types]


def only_account(setup, scope=None):
    (view,) = service(setup).suppliers(scope or setup.owner)
    (account,) = view.accounts
    return view, account


def test_an_ehf_invoice_is_validated_when_it_is_registered(setup) -> None:
    invoice_id = import_ehf(setup)
    run = service(setup).latest(setup.owner, invoice_id)
    assert run is not None and (run.run_number, run.revision) == (1, 1)
    assert codes(run) == [("BANK-001", "bank_001_unverified")]
    # BANK-001 here; ACC-001 (no posting without a poster) and the MVA-002 info: F08b.
    assert (run.summary.errors, run.summary.warnings, run.summary.infos) == (2, 0, 1)
    view, account = only_account(setup)
    assert (view.supplier.org_number, view.supplier.name) == (
        "123456785",
        "Syntetisk Leverandør AS",
    )
    assert (account.kind, account.account, account.status) == (
        AccountKind.BBAN,
        "12345678903",
        AccountStatus.UNVERIFIED,
    )
    assert account.first_seen_invoice_id == invoice_id
    (validated,) = events(setup, AuditEventType.INVOICE_VALIDATED)
    assert dict(validated.details) == {
        "run_id": str(run.run_id),
        "revision": 1,
        "ruleset_version": "1.1",
        "error_count": 2,
        "warning_count": 0,
        "info_count": 1,
    }
    assert len(events(setup, AuditEventType.SUPPLIER_CREATED)) == 1
    (added,) = events(setup, AuditEventType.SUPPLIER_ACCOUNT_ADDED)
    assert dict(added.details) == {"account_id": str(account.account_id), "account_kind": "bban"}


def test_verifying_the_account_validates_the_invoices_again(setup) -> None:
    invoice_id = import_ehf(setup)
    _, account = only_account(setup)
    updated = service(setup).set_account_status(
        setup.owner, account.account_id, AccountStatus.VERIFIED, expected=AccountStatus.UNVERIFIED
    )
    assert (updated.status, updated.status_changed_by) == (AccountStatus.VERIFIED, USER_ACTOR)
    run = service(setup).latest(setup.owner, invoice_id)
    assert run is not None and run.run_number == 2 and f08a(run.findings) == []
    (changed,) = events(setup, AuditEventType.SUPPLIER_ACCOUNT_STATUS_CHANGED)
    assert dict(changed.details) == {
        "account_id": str(account.account_id),
        "account_status": "verified",
        "previous_account_status": "unverified",
    }
    assert changed.actor == USER_ACTOR
    # A second invoice with the same account is clean at once.
    second = import_ehf(
        setup, SyntheticEhf(number="EHF-2026-002", issue_date="2026-10-02"), name="andre.xml"
    )
    assert f08a(service(setup).latest(setup.owner, second).findings) == []


def test_a_blocked_account_is_an_error(setup) -> None:
    invoice_id = import_ehf(setup)
    _, account = only_account(setup)
    service(setup).set_account_status(
        setup.owner, account.account_id, AccountStatus.BLOCKED, expected=AccountStatus.UNVERIFIED
    )
    assert codes(service(setup).latest(setup.owner, invoice_id)) == [
        ("BANK-001", "bank_001_blocked")
    ]


def test_account_status_changes_are_deliberate_and_compare_and_set(setup) -> None:
    import_ehf(setup)
    _, account = only_account(setup)
    validation = service(setup)
    with pytest.raises(ConflictError):
        validation.set_account_status(
            setup.owner, account.account_id, AccountStatus.VERIFIED, expected=AccountStatus.BLOCKED
        )
    for status, expected in [
        (AccountStatus.UNVERIFIED, AccountStatus.VERIFIED),
        (AccountStatus.VERIFIED, AccountStatus.VERIFIED),
    ]:
        with pytest.raises(InvoiceFlowError):
            validation.set_account_status(
                setup.owner, account.account_id, status, expected=expected
            )
    with pytest.raises(NotFoundError):
        validation.set_account_status(
            setup.other,
            account.account_id,
            AccountStatus.VERIFIED,
            expected=AccountStatus.UNVERIFIED,
        )
    assert only_account(setup)[1].status is AccountStatus.UNVERIFIED


def test_duplicates_are_found_within_the_entity_only(setup) -> None:
    first = import_ehf(setup)
    second = import_ehf(setup, SyntheticEhf(buyer_reference="Annen"), name="kopi.xml")
    assert ("DUP-001", "dup_001") in codes(service(setup).latest(setup.owner, second))
    # The first invoice learns about the duplicate when it is validated again.
    assert ("DUP-001", "dup_001") not in codes(service(setup).latest(setup.owner, first))
    runs = service(setup).validate_all(setup.owner)
    assert all(("DUP-001", "dup_001") in codes(run) for run in runs)
    elsewhere = import_ehf(setup, scope=setup.other)
    assert codes(service(setup).latest(setup.other, elsewhere)) == [
        ("BANK-001", "bank_001_unverified")
    ]
    # Separate supplier registers: the other entity has its own unverified account.
    assert only_account(setup, setup.other)[1].status is AccountStatus.UNVERIFIED


def test_another_entity_cannot_read_runs(setup) -> None:
    invoice_id = import_ehf(setup)
    with pytest.raises(NotFoundError):
        service(setup).latest(setup.other, invoice_id)
    with pytest.raises(NotFoundError):
        service(setup).validate(setup.other, invoice_id)
    assert service(setup).latest_runs(setup.other) == {}
    assert set(service(setup).latest_runs(setup.owner)) == {invoice_id}


def test_runs_are_numbered_and_kept(setup) -> None:
    invoice_id = import_ehf(setup)
    validation = service(setup)
    second = validation.validate(setup.owner, invoice_id)
    assert second.run_number == 2
    latest = validation.latest_runs(setup.owner)[invoice_id]
    assert (latest.run_id, latest.summary) == (second.run_id, second.summary)
    with closing(sqlite3.connect(setup.database.path)) as connection:
        assert connection.execute("SELECT COUNT(*) FROM validation_runs").fetchone() == (2,)
        # Three findings per run: BANK-001, ACC-001 and the MVA-002 info.
        assert connection.execute("SELECT COUNT(*) FROM validation_results").fetchone() == (6,)


def test_a_new_revision_is_validated_as_that_revision(setup) -> None:
    invoice_id = import_ehf(setup)
    invoices = InvoiceService(setup.database.unit_of_work)
    record = invoices.get(setup.owner, invoice_id)
    due = record.invoice.due_date
    assert due is not None
    earlier = FieldValue(value=dt.date(2026, 9, 1), provenance=due.provenance)
    revised = record.invoice.model_copy(update={"due_date": earlier})
    invoices.revise(setup.owner, invoice_id, revised, expected_revision=1)
    run = service(setup).validate(setup.owner, invoice_id)
    assert run.revision == 2
    assert ("DAT-001", "dat_001") in codes(run)


def test_an_org_number_with_a_wrong_check_digit_is_not_registered(setup) -> None:
    invoice_id = import_ehf(setup, SyntheticEhf(supplier_org="123456784"))
    run = service(setup).latest(setup.owner, invoice_id)
    assert {code for code in codes(run)} >= {
        ("ID-001", "id_001"),
        ("BANK-001", "bank_001_unregistered"),
    }
    assert service(setup).suppliers(setup.owner) == []


def test_an_account_with_a_wrong_check_digit_is_not_registered(setup) -> None:
    invoice_id = import_ehf(setup, SyntheticEhf(account="12345678904"))
    run = service(setup).latest(setup.owner, invoice_id)
    assert set(codes(run)) == {("ID-002", "id_002"), ("BANK-001", "bank_001_unregistered")}
    (view,) = service(setup).suppliers(setup.owner)
    assert view.accounts == ()


def test_the_recipient_is_compared_with_the_entity(setup) -> None:
    from invoiceflow.application.services import EntityService

    scope_id = EntityService(setup.database.unit_of_work).create(
        name="Med orgnr AS", org_number="987654325"
    )
    from invoiceflow.application.scope import EntityScope

    scope = EntityScope(scope_id.entity_id)
    invoice_id = import_ehf(setup, scope=scope)
    run = service(setup).latest(scope, invoice_id)
    assert [(f.rule_id.value, f.severity) for f in f08a(run.findings)] == [
        ("BANK-001", Severity.ERROR),
        ("ENT-001", Severity.WARNING),
    ]


def test_a_failure_before_commit_stores_nothing(setup, monkeypatch) -> None:
    from invoiceflow.persistence.repositories import SqlAuditLog

    invoice_id = import_ehf(setup)
    original = SqlAuditLog.append

    def failing(self, draft, *, occurred_at):
        if draft.event_type == AuditEventType.INVOICE_VALIDATED:
            raise RuntimeError("simulated crash")
        return original(self, draft, occurred_at=occurred_at)

    monkeypatch.setattr(SqlAuditLog, "append", failing)
    with pytest.raises(RuntimeError):
        service(setup).validate(setup.owner, invoice_id)
    monkeypatch.undo()
    assert service(setup).latest(setup.owner, invoice_id).run_number == 1


def test_a_failed_validation_does_not_register_the_invoice(setup, monkeypatch) -> None:
    """Validation runs in the registration's unit of work: all or nothing."""
    from invoiceflow.application.processing_model import JobStatus

    def broken(*args, **kwargs):
        raise RuntimeError("simulated crash")

    monkeypatch.setattr(ValidationService, "validate_in", broken)
    document_id = setup.add(build_ehf(), "faktura.xml")
    with pytest.raises(RuntimeError):
        processing(setup).process(setup.owner, document_id)
    monkeypatch.undo()
    assert InvoiceService(setup.database.unit_of_work).summaries(setup.owner) == {}
    assert service(setup).suppliers(setup.owner) == []
    job = processing(setup).process(setup.owner, document_id)
    assert job.status in (JobStatus.SUCCEEDED, JobStatus.FAILED)


@pytest.mark.security
def test_the_register_and_runs_resist_tampering(setup) -> None:
    import_ehf(setup)
    with closing(sqlite3.connect(setup.database.path)) as connection:
        for statement in [
            "UPDATE supplier_bank_accounts SET account = '86011117947'",
            "UPDATE supplier_bank_accounts SET status = 'verified'",  # without time and user
            "DELETE FROM supplier_bank_accounts",
            "UPDATE suppliers SET name = 'Annen AS'",
            "DELETE FROM suppliers",
            "UPDATE validation_runs SET error_count = 0",
            "DELETE FROM validation_runs",
            "UPDATE validation_results SET severity = 'info'",
            "DELETE FROM validation_results",
        ]:
            with pytest.raises(sqlite3.IntegrityError):
                connection.execute(statement)
        connection.execute(
            "UPDATE supplier_bank_accounts SET status = 'blocked',"
            " status_changed_at = '2026-10-20T10:00:00.000000Z', status_changed_by = 'user/local'"
        )
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute(
                "UPDATE supplier_bank_accounts SET status = 'unverified',"
                " status_changed_at = NULL, status_changed_by = NULL"
            )
        connection.rollback()
