"""ProcessingService against a real database and archive (worker run in-process)."""

import json
import os
import stat
from pathlib import Path

import hostile_corpus as corpus
import pytest
from processing_fakes import ExitProcessor, InProcessProcessor, ScriptedProcessor, pdf_version

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.errors import InvoiceFlowError, NotFoundError
from invoiceflow.application.ports import WorkerExit, WorkerOutcome
from invoiceflow.application.processing_model import (
    DerivedKind,
    JobStatus,
    ProcessingErrorCode,
    TextLayer,
)
from invoiceflow.bootstrap.synthetic_pdf import text_pdf

pytestmark = pytest.mark.integration

PDF = text_pdf(["Faktura 2026-001 Syntetisk AS", "Side to"])


def events(setup, *types):
    with setup.database.unit_of_work() as uow:
        records = list(uow.audit.records())
    return [record for record in records if not types or record.event_type in types]


def processing_events(setup):
    return events(setup, AuditEventType.PROCESSING_STARTED, AuditEventType.PROCESSING_FINISHED)


def entity_dir(setup, scope=None) -> Path:
    return setup.store.root / (scope or setup.owner).entity_id.hex


def test_success_stores_pages_files_and_audit(setup) -> None:
    document_id = setup.add(PDF)
    service = setup.make()
    job = service.process(setup.owner, document_id)

    assert job.status is JobStatus.SUCCEEDED and job.page_count == 2
    assert (job.engine, job.engine_version, job.attempt) == ("pypdfium2", pdf_version(), 1)
    assert job.active_content is False and job.error_code is None
    pages = service.pages(setup.owner, job.job_id)
    assert [(page.page_number, page.text_layer_chars) for page in pages] == [(1, 29), (2, 7)]
    assert all((page.width_px, page.height_px) == (595, 842) for page in pages)
    files = service.derived_files(setup.owner, job.job_id)
    assert sorted((f.page_number, f.kind) for f in files) == [
        (1, DerivedKind.PAGE_RENDER),
        (1, DerivedKind.TEXT_LAYER),
        (2, DerivedKind.PAGE_RENDER),
        (2, DerivedKind.TEXT_LAYER),
    ]
    for record in files:
        path = setup.store.root / record.storage_path
        assert record.storage_path.startswith(
            f"{setup.owner.entity_id.hex}/derived/{document_id.hex}/{job.job_id.hex}/"
        )
        assert path.stat().st_size == record.size_bytes
        assert not path.stat().st_mode & stat.S_IWUSR  # read-only
        assert record.producer == f"pypdfium2/{pdf_version()}"
    layer = next(f for f in files if f.kind is DerivedKind.TEXT_LAYER and f.page_number == 1)
    text = TextLayer.model_validate_json((setup.store.root / layer.storage_path).read_bytes())
    assert text.text == "Faktura 2026-001 Syntetisk AS"
    # The worker's private folder is gone; originals are untouched.
    assert not any((entity_dir(setup) / "work").iterdir())
    assert setup.documents.verify_integrity(setup.owner) == {document_id: "ok"}

    started, finished = processing_events(setup)
    assert started.subject_id == finished.subject_id == str(document_id)
    assert dict(started.details) == {
        "job_id": str(job.job_id),
        "attempt": 1,
        "step": "page_analysis",
    }
    assert dict(finished.details) == {
        "job_id": str(job.job_id),
        "step": "page_analysis",
        "job_status": "succeeded",
        "page_count": 2,
        "active_content": False,
    }
    assert "Faktura" not in json.dumps([dict(event.details) for event in events(setup)])


def test_processing_is_idempotent(setup) -> None:
    document_id = setup.add(PDF)
    processor = InProcessProcessor()
    service = setup.make(processor)
    first = service.process(setup.owner, document_id)
    again = service.process(setup.owner, document_id)
    assert again == first
    assert len(processor.tasks) == 1 and len(processing_events(setup)) == 2
    assert service.process_pending(setup.owner) == []


def test_new_settings_mean_a_new_job(setup) -> None:
    document_id = setup.add(PDF)
    first = setup.make().process(setup.owner, document_id)
    second = setup.make(dpi=100).process(setup.owner, document_id)
    assert second.job_id != first.job_id and second.idempotency_key != first.idempotency_key
    assert setup.make(dpi=100).latest_jobs(setup.owner) == {document_id: second}


def test_pending_skips_done_and_failed_documents_and_retry_is_explicit(setup) -> None:
    good = setup.add(PDF, "a.pdf")
    locked = setup.add(corpus.pdf_encrypted(), "b.pdf")
    service = setup.make()
    jobs = service.process_pending(setup.owner)
    assert {(job.document_id, job.status, job.error_code) for job in jobs} == {
        (good, JobStatus.SUCCEEDED, None),
        (locked, JobStatus.FAILED, ProcessingErrorCode.ENCRYPTED),
    }
    assert service.process_pending(setup.owner) == []
    retried = service.process(setup.owner, locked)
    assert (retried.attempt, retried.error_code) == (2, ProcessingErrorCode.ENCRYPTED)
    later = setup.add(text_pdf(["ny"]), "c.pdf")
    assert [job.document_id for job in service.process_pending(setup.owner)] == [later]


def test_pending_stops_between_documents(setup) -> None:
    setup.add(PDF, "a.pdf")
    setup.add(text_pdf(["b"]), "b.pdf")
    calls = []

    def stop() -> bool:
        calls.append(1)
        return len(calls) > 1

    assert len(setup.make().process_pending(setup.owner, should_stop=stop)) == 1


def test_quarantined_documents_are_never_processed(setup) -> None:
    source = setup.tmp / "forkledd.pdf"
    source.write_bytes(b"MZ syntetisk, ikke en PDF")
    quarantined = setup.documents.import_file(setup.owner, source).document_id
    processor = InProcessProcessor()
    with pytest.raises(InvoiceFlowError) as error:
        setup.make(processor).process(setup.owner, quarantined)
    assert error.value.code == "DOCUMENT_NOT_PROCESSABLE" and processor.tasks == []
    assert setup.make().process_pending(setup.owner) == []


def test_other_entities_cannot_see_or_process(setup) -> None:
    document_id = setup.add(PDF)
    service = setup.make()
    job = service.process(setup.owner, document_id)
    with pytest.raises(NotFoundError):
        service.process(setup.other, document_id)
    assert service.latest_jobs(setup.other) == {}
    assert service.pages(setup.other, job.job_id) == []
    assert service.derived_files(setup.other, job.job_id) == []
    with setup.database.unit_of_work() as uow, pytest.raises(NotFoundError):
        uow.processing(setup.other).get_job(job.job_id)
    # The same file in the other entity is a separate document with its own job.
    other_document = setup.add(PDF, scope=setup.other)
    other_job = service.process(setup.other, other_document)
    assert other_job.idempotency_key != job.idempotency_key
    assert not (entity_dir(setup, setup.other) / "derived" / document_id.hex).exists()


def _tamper_original(setup, document_id, content: bytes | None) -> None:
    record = setup.documents.get(setup.owner, document_id)
    path = setup.store.root / record.storage_path
    os.chmod(path, stat.S_IWUSR | stat.S_IRUSR)
    if content is None:
        path.unlink()
    else:
        path.write_bytes(content)


@pytest.mark.security
@pytest.mark.parametrize(
    ("content", "code"),
    [
        (b"%PDF-1.4 endret", ProcessingErrorCode.SOURCE_CHANGED),
        (None, ProcessingErrorCode.SOURCE_MISSING),
    ],
)
def test_original_is_checked_before_processing(setup, content, code) -> None:
    document_id = setup.add(PDF)
    _tamper_original(setup, document_id, content)
    processor = InProcessProcessor()
    job = setup.make(processor).process(setup.owner, document_id)
    assert (job.status, job.error_code) == (JobStatus.FAILED, code)
    assert processor.tasks == []


@pytest.mark.security
def test_original_changed_while_the_worker_ran_is_detected(setup) -> None:
    document_id = setup.add(PDF)

    def change_original(report, output):
        _tamper_original(setup, document_id, b"%PDF-1.4 endret underveis")

    service = setup.make(ScriptedProcessor(change_original))
    job = service.process(setup.owner, document_id)
    assert job.error_code is ProcessingErrorCode.SOURCE_CHANGED
    assert service.derived_files(setup.owner, job.job_id) == []
    assert not (entity_dir(setup) / "derived").exists()


def _replace(path: Path, data: bytes) -> None:
    path.unlink()
    path.write_bytes(data)


TAMPERING = {
    "extra-field": lambda r, o: r.update(extra=True),
    "engine-version": lambda r, o: r.update(engine_version="0.0.1"),
    "other-hash": lambda r, o: r.update(sha256="0" * 64),
    "page-count": lambda r, o: r.update(page_count=3),
    "path-in-name": lambda r, o: r["pages"][0].update(render_file="../page-0001.png"),
    "foreign-code": lambda r, o: r.update(
        status="error", error_code="interrupted", pages=[], page_count=0
    ),
    "missing-text": lambda r, o: (o / "text-0001.json").unlink(),
    "empty-render": lambda r, o: _replace(o / "page-0002.png", b""),
    "png-size": lambda r, o: r["pages"][0].update(width_px=10),
    "text-length": lambda r, o: r["pages"][0].update(text_chars=3),
    "not-png": lambda r, o: _replace(o / "page-0001.png", b"GIF89a" + b"\x00" * 40),
    "bad-layer": lambda r, o: _replace(o / "text-0002.json", b'{"result_version": 1}'),
    "garbage": lambda r, o: b"\xff\xfe not json",
    "pixels": lambda r, o: r["pages"][0].update(width_px=100_000, height_px=100_000),
}


@pytest.mark.security
@pytest.mark.parametrize("tamper", list(TAMPERING.values()), ids=list(TAMPERING))
def test_untrustworthy_reports_publish_nothing(setup, tamper) -> None:
    document_id = setup.add(PDF)
    service = setup.make(ScriptedProcessor(tamper))
    job = service.process(setup.owner, document_id)
    assert (job.status, job.error_code) == (JobStatus.FAILED, ProcessingErrorCode.INVALID_RESULT)
    assert service.pages(setup.owner, job.job_id) == []
    assert not (entity_dir(setup) / "derived").exists()
    assert not any((entity_dir(setup) / "work").iterdir())


@pytest.mark.security
def test_a_link_planted_in_the_output_is_refused(setup, tmp_path) -> None:
    document_id = setup.add(PDF)
    outside = tmp_path / "utenfor.png"
    outside.write_bytes(corpus.png_page(595, 842))

    def plant_link(report, output):
        (output / "page-0001.png").unlink()
        try:
            (output / "page-0001.png").symlink_to(outside)
        except OSError:
            pytest.skip("symbolic links are not permitted for this user")

    job = setup.make(ScriptedProcessor(plant_link)).process(setup.owner, document_id)
    assert job.error_code is ProcessingErrorCode.INVALID_RESULT
    assert outside.exists()


@pytest.mark.security
def test_output_beyond_the_limit_is_refused(setup) -> None:
    document_id = setup.add(PDF)
    job = setup.make(max_output_bytes=2000).process(setup.owner, document_id)
    assert (job.status, job.error_code) == (JobStatus.FAILED, ProcessingErrorCode.OUTPUT_TOO_LARGE)


@pytest.mark.parametrize(
    ("exit", "status", "code"),
    [
        (WorkerExit.TIMED_OUT, JobStatus.TIMED_OUT, ProcessingErrorCode.TIMED_OUT),
        (WorkerExit.CANCELLED, JobStatus.CANCELLED, ProcessingErrorCode.CANCELLED),
        (WorkerExit.MEMORY_LIMIT, JobStatus.FAILED, ProcessingErrorCode.MEMORY_LIMIT),
        (WorkerExit.CRASHED, JobStatus.FAILED, ProcessingErrorCode.WORKER_CRASHED),
        (WorkerExit.INVALID_RESULT, JobStatus.FAILED, ProcessingErrorCode.INVALID_RESULT),
    ],
)
def test_worker_exits_map_to_stable_states(setup, exit, status, code) -> None:
    document_id = setup.add(PDF)
    job = setup.make(ExitProcessor(exit)).process(setup.owner, document_id)
    assert (job.status, job.error_code) == (status, code)
    (finished,) = events(setup, AuditEventType.PROCESSING_FINISHED)
    assert finished.details["job_status"] == str(status)
    assert finished.details["error_code"] == str(code)


def test_a_failing_worker_start_is_a_crash(setup) -> None:
    class Unstartable(InProcessProcessor):
        def run(self, task, should_stop):
            raise OSError("cannot start")

    job = setup.make(Unstartable()).process(setup.owner, setup.add(PDF))
    assert job.error_code is ProcessingErrorCode.WORKER_CRASHED


def test_a_running_job_blocks_a_second_run(setup) -> None:
    document_id = setup.add(PDF)
    service = setup.make()
    record = setup.documents.get(setup.owner, document_id)
    service._start(setup.owner, record, "system")  # simulates a run in progress
    with pytest.raises(InvoiceFlowError) as error:
        service.process(setup.owner, document_id)
    assert error.value.code == "PROCESSING_RUNNING"


def test_crash_before_the_final_commit_leaves_no_half_state(setup, monkeypatch) -> None:
    document_id = setup.add(PDF)
    service = setup.make()

    def database_lost(*args, **kwargs):
        raise RuntimeError("simulated crash")

    monkeypatch.setattr(service, "_finish_succeeded", database_lost)
    with pytest.raises(RuntimeError):
        service.process(setup.owner, document_id)
    (job,) = service.latest_jobs(setup.owner).values()
    assert (job.status, job.error_code) == (JobStatus.FAILED, ProcessingErrorCode.STORAGE_FAILED)
    assert service.pages(setup.owner, job.job_id) == []
    published = entity_dir(setup) / "derived" / document_id.hex / job.job_id.hex
    assert published.is_dir()  # files exist, but no row refers to them

    recovery = service.reconcile(setup.owner)
    assert (recovery.interrupted, recovery.derived_moved) == (0, 1)
    assert not published.exists()
    moved = list((entity_dir(setup) / "orphans").glob(f"derived-{job.job_id.hex}-*"))
    assert len(moved) == 1 and (moved[0] / "page-0001.png").is_file()  # moved, not deleted
    monkeypatch.undo()
    retried = service.process(setup.owner, document_id)
    assert (retried.status, retried.attempt) == (JobStatus.SUCCEEDED, 2)


def test_startup_reconciliation_finishes_interrupted_jobs(setup) -> None:
    document_id = setup.add(PDF)
    service = setup.make()
    record = setup.documents.get(setup.owner, document_id)
    job = service._start(setup.owner, record, "system")  # process killed afterwards
    work = setup.derived.create_work_dir(setup.owner.entity_id, job.job_id)
    (work / "page-0001.png").write_bytes(b"halv")

    recovery = service.reconcile(setup.owner)
    assert (recovery.interrupted, recovery.work_removed, recovery.failed) == (1, 1, 0)
    (current,) = service.latest_jobs(setup.owner).values()
    assert (current.status, current.error_code) == (
        JobStatus.FAILED,
        ProcessingErrorCode.INTERRUPTED,
    )
    assert not work.exists()
    assert service.reconcile(setup.owner).interrupted == 0
    assert service.process(setup.owner, document_id).status is JobStatus.SUCCEEDED


def test_succeeded_files_survive_reconciliation(setup) -> None:
    document_id = setup.add(PDF)
    service = setup.make()
    job = service.process(setup.owner, document_id)
    assert service.reconcile(setup.owner).derived_moved == 0
    for record in service.derived_files(setup.owner, job.job_id):
        assert (setup.store.root / record.storage_path).is_file()


def test_images_are_processed_by_the_image_adapter(setup) -> None:
    document_id = setup.add(corpus.tiff_pages(2), "skann.tif")
    job = setup.make().process(setup.owner, document_id)
    assert (job.status, job.engine, job.page_count) == (JobStatus.SUCCEEDED, "pillow", 2)
    pages = setup.make().pages(setup.owner, job.job_id)
    assert [page.has_text_layer for page in pages] == [False, False]
    kinds = {f.kind for f in setup.make().derived_files(setup.owner, job.job_id)}
    assert kinds == {DerivedKind.PAGE_RENDER}


def test_active_content_is_flagged_in_job_and_audit(setup) -> None:
    job = setup.make().process(setup.owner, setup.add(corpus.pdf_with_javascript()))
    assert job.status is JobStatus.SUCCEEDED and job.active_content is True
    (finished,) = events(setup, AuditEventType.PROCESSING_FINISHED)
    assert finished.details["active_content"] is True


def test_reports_of_any_shape_never_reach_the_database_unvalidated(setup) -> None:
    document_id = setup.add(PDF)

    def oversized_outcome(report, output):
        return WorkerOutcome(WorkerExit.COMPLETED, None)

    job = setup.make(ScriptedProcessor(oversized_outcome)).process(setup.owner, document_id)
    assert job.error_code is ProcessingErrorCode.INVALID_RESULT
