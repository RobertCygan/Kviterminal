"""Draft invoices from analysed documents (Phase 06): registration, parts, findings."""

import json
from dataclasses import replace

import pytest
from extraction_samples import COLUMNS, CREDIT_NOTE, ENTITY_ORG, NOT_AN_INVOICE, STANDARD, TWO_RATES
from processing_fakes import InProcessProcessor

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.document_model import (
    DocumentFormat,
    DocumentRecord,
    DocumentType,
    ImportSource,
)
from invoiceflow.application.extraction.service import ExtractionService, readable
from invoiceflow.application.processing import ProcessingService
from invoiceflow.application.processing_model import InvoiceFindingCode, ProcessingLimits
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import EntityService
from invoiceflow.application.validation.service import ValidationService
from invoiceflow.bootstrap.synthetic_pdf import layout_pdf

pytestmark = pytest.mark.integration


def service(setup, *, validator=None, processor=None) -> ProcessingService:
    return ProcessingService(
        setup.database.unit_of_work,
        setup.store,
        setup.derived,
        processor or InProcessProcessor(),
        validator=validator,
        extractor=ExtractionService(setup.database.unit_of_work, validator=validator),
        limits=ProcessingLimits(dpi=150),
    )


def invoices(setup, scope=None):
    scope = scope or setup.owner
    with setup.database.unit_of_work() as uow:
        repository = uow.invoices(scope)
        return [
            (
                repository.get(invoice_id).invoice,
                [code for _, code in repository.findings(invoice_id)],
            )
            for invoice_id in repository.list_ids()
        ]


def value(field):
    return None if field is None else field.value


def test_an_analysed_invoice_is_registered_once(setup) -> None:
    document_id = setup.add(layout_pdf(STANDARD.pages), "faktura.pdf")
    processing = service(setup)

    processing.process_pending(setup.owner)

    [(invoice, findings)] = invoices(setup)
    assert invoice.document_id == document_id and (invoice.first_page, invoice.last_page) == (1, 1)
    assert value(invoice.invoice_number) == "2026-0417"
    assert str(value(invoice.totals.gross_amount)) == "15793.13"
    assert findings == []
    assert processing.process_pending(setup.owner) == []
    assert processing.extract(setup.owner, document_id) == []
    assert len(invoices(setup)) == 1
    with setup.database.unit_of_work() as uow:
        created = [
            record
            for record in uow.audit.records()
            if record.event_type == AuditEventType.INVOICE_CREATED
        ]
    assert len(created) == 1 and "2026-0417" not in json.dumps(created[0].details)


def test_a_scanned_batch_gives_one_invoice_per_part(setup) -> None:
    pages = (STANDARD.pages[0], "separator", CREDIT_NOTE.pages[0])
    document_id = setup.add(layout_pdf(pages), "bunke.pdf")

    service(setup).process_pending(setup.owner)

    registered = sorted(invoices(setup), key=lambda item: item[0].first_page)
    assert [(i.first_page, i.last_page, value(i.invoice_type)) for i, _ in registered] == [
        (1, 1, "invoice"),
        (3, 3, "credit_note"),
    ]
    assert all(invoice.document_id == document_id for invoice, _ in registered)
    assert value(registered[1][0].referenced_invoice_number) == "2026-0100"


def test_what_does_not_add_up_or_cannot_be_read_is_flagged(setup) -> None:
    wrong_total = [
        (x, y, "15 793,14" if text == "15 793,13" else text) for x, y, text in STANDARD.pages[0]
    ]
    setup.add(layout_pdf((tuple(wrong_total),)), "feil.pdf")
    setup.add(layout_pdf(TWO_RATES.pages), "to-satser.pdf")

    service(setup).process_pending(setup.owner)

    findings = {value(invoice.invoice_number): codes for invoice, codes in invoices(setup)}
    assert findings["2026-0417"] == [InvoiceFindingCode.GROSS_MISMATCH]
    assert sorted(findings["5501"]) == [
        InvoiceFindingCode.MISSING_REQUIRED,  # no currency on the invoice
        InvoiceFindingCode.UNREADABLE_VALUE,  # 31.02.2026
    ]


def test_only_documents_that_may_be_invoices_are_read(setup) -> None:
    contract = setup.add(layout_pdf(NOT_AN_INVOICE.pages), "avtale.pdf")
    receipt = setup.add(layout_pdf(STANDARD.pages), "kvittering.pdf")
    setup.documents.set_type(setup.owner, receipt, DocumentType.RECEIPT)
    processing = service(setup)

    processing.process_pending(setup.owner)
    assert invoices(setup) == []

    # Typed as an invoice by the user, it is read although it has no title.
    setup.documents.set_type(setup.owner, contract, DocumentType.INVOICE)
    assert len(processing.extract(setup.owner, contract)) == 1


def test_the_recipient_and_duplicates_are_checked(setup) -> None:
    entities = EntityService(setup.database.unit_of_work)
    scope = EntityScope(entities.create(name="Syntetisk Kunde AS", org_number=ENTITY_ORG).entity_id)
    setup.add(layout_pdf(COLUMNS.pages), "kolonner.pdf", scope=scope)
    setup.add(layout_pdf(STANDARD.pages), "standard.pdf", scope=scope)
    copy = (*STANDARD.pages[0], (50, 700, "Kopi"))
    setup.add(layout_pdf((copy,)), "kopi.pdf", scope=scope)

    service(setup).process_pending(scope)

    found = sorted(
        (value(invoice.invoice_number), codes) for invoice, codes in invoices(setup, scope)
    )
    assert [(number, sorted(codes)) for number, codes in found] == [
        ("2026-0417", [InvoiceFindingCode.MISSING_RECIPIENT]),
        (
            "2026-0417",
            [InvoiceFindingCode.MISSING_RECIPIENT, InvoiceFindingCode.POSSIBLE_DUPLICATE],
        ),
        ("88812", []),
    ]
    assert invoices(setup) == []  # nothing for another entity


def test_registered_invoices_are_validated(setup) -> None:
    validator = ValidationService(setup.database.unit_of_work)
    setup.add(layout_pdf(STANDARD.pages), "faktura.pdf")
    service(setup, validator=validator).process_pending(setup.owner)
    assert len(invoices(setup)) == 1
    with setup.database.unit_of_work() as uow:
        [invoice_id] = uow.invoices(setup.owner).list_ids()
    assert validator.latest(setup.owner, invoice_id) is not None


def test_ehf_and_its_attachments_are_not_read_again(tmp_path) -> None:
    import datetime as dt
    from uuid import uuid4

    document = DocumentRecord(
        document_id=uuid4(),
        entity_id=uuid4(),
        document_type=DocumentType.UNCLASSIFIED,
        sha256="a" * 64,
        size_bytes=1,
        detected_format=DocumentFormat.PDF,
        display_name="vedlegg.pdf",
        storage_path="x/y",
        source=ImportSource.FILE_IMPORT,
        status="stored",
        imported_at=dt.datetime(2026, 10, 24, tzinfo=dt.UTC),
        imported_by="system",
    )
    assert readable(document)
    assert not readable(replace(document, source=ImportSource.EHF_ATTACHMENT))
    assert not readable(replace(document, detected_format=DocumentFormat.XML))
    assert not readable(replace(document, document_type=DocumentType.CONTRACT))


@pytest.mark.tesseract
def test_a_scanned_invoice_is_read_through_ocr(setup) -> None:
    import pypdfium2 as pdfium
    from ocr_samples import encode

    pdf = pdfium.PdfDocument(layout_pdf(STANDARD.pages))
    image = pdf[0].render(scale=300 / 72, grayscale=True).to_pil()
    pdf.close()
    setup.add(encode(image), "skann.png")

    service(setup, processor=InProcessProcessor(ocr=True)).process_pending(setup.owner)

    [(invoice, findings)] = invoices(setup)
    assert value(invoice.invoice_number) == "2026-0417"
    assert str(value(invoice.totals.gross_amount)) == "15793.13"
    assert findings == []
    assert invoice.totals.gross_amount.provenance.confidence is not None


def test_without_text_nothing_is_registered_yet(setup) -> None:
    from ocr_samples import encode, render

    setup.add(encode(render(("Faktura 77",), font_size=14)), "skann.png")
    service(setup).process_pending(setup.owner)  # OCR is off here
    assert invoices(setup) == []


def test_sums_are_checked_only_when_complete() -> None:
    import uuid

    from invoiceflow.application.extraction.fields import Extraction
    from invoiceflow.application.extraction.service import extraction_findings
    from invoiceflow.domain.invoice import CanonicalInvoice

    def field(amount: str) -> dict:
        evidence = {"page_number": 1, "raw_text": amount}
        return {"value": amount, "provenance": {"source": "extracted", "evidence": evidence}}

    def invoice(**parts) -> Extraction:
        data = {"document_id": str(uuid.uuid4()), "supplier": {}, "totals": {}} | parts
        return Extraction(CanonicalInvoice.model_validate(data), 0, True)

    lines = [
        {"line_number": 1, "net_amount": field("100.00")},
        {"line_number": 2, "net_amount": field("50.00")},
    ]
    vat = [{"vat_amount": field("30.00")}, {"vat_amount": field("7.50")}]
    totals = {
        "net_amount": field("140.00"),
        "vat_amount": field("37.00"),
        "gross_amount": field("-1.00"),
    }
    codes = extraction_findings(invoice(lines=lines, vat_breakdown=vat, totals=totals))
    assert {
        InvoiceFindingCode.LINE_SUM_MISMATCH,
        InvoiceFindingCode.VAT_MISMATCH,
        InvoiceFindingCode.GROSS_MISMATCH,
        InvoiceFindingCode.NEGATIVE_TOTAL,
    } <= set(codes)
    partial = [{"line_number": 1}, {"line_number": 2, "net_amount": field("50.00")}]
    codes = extraction_findings(invoice(lines=partial, totals={"net_amount": field("1.00")}))
    assert InvoiceFindingCode.LINE_SUM_MISMATCH not in codes
