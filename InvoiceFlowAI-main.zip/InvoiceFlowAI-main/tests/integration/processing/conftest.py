"""A real database and archive with a processing service in front of them."""

from collections.abc import Callable, Iterator
from dataclasses import dataclass
from pathlib import Path
from uuid import UUID

import pytest
from processing_fakes import InProcessProcessor

from invoiceflow.application.document_model import ImportOutcome
from invoiceflow.application.documents import DocumentService
from invoiceflow.application.processing import ProcessingService
from invoiceflow.application.processing_model import ProcessingLimits
from invoiceflow.application.scope import EntityScope
from invoiceflow.application.services import EntityService
from invoiceflow.documents.derived import FileDerivedStore
from invoiceflow.documents.store import FileDocumentStore
from invoiceflow.persistence.database import Database
from invoiceflow.persistence.migrator import initialize_database


@dataclass
class Setup:
    tmp: Path
    database: Database
    documents: DocumentService
    store: FileDocumentStore
    derived: FileDerivedStore
    owner: EntityScope
    other: EntityScope
    make: Callable[..., ProcessingService]

    def add(
        self, data: bytes, name: str = "dokument.pdf", scope: EntityScope | None = None
    ) -> UUID:
        source = self.tmp / "kilde" / name
        source.parent.mkdir(exist_ok=True)
        source.write_bytes(data)
        result = self.documents.import_file(scope or self.owner, source)
        assert result.outcome is ImportOutcome.IMPORTED, result
        assert result.document_id is not None
        return result.document_id


@pytest.fixture
def setup(tmp_path: Path) -> Iterator[Setup]:
    path = tmp_path / "database" / "invoiceflow.sqlite3"
    path.parent.mkdir()
    initialize_database(path, tmp_path / "backups")
    database = Database(path)
    root = tmp_path / "documents"
    store = FileDocumentStore(root)
    derived = FileDerivedStore(root)
    entities = EntityService(database.unit_of_work)
    owner = EntityScope(entities.create(name="Syntetisk A AS").entity_id)
    other = EntityScope(entities.create(name="Syntetisk B AS").entity_id)

    def make(processor=None, **limits) -> ProcessingService:
        return ProcessingService(
            database.unit_of_work,
            store,
            derived,
            processor or InProcessProcessor(),
            attachments=DocumentService(database.unit_of_work, store),
            limits=ProcessingLimits(**({"dpi": 72} | limits)),
        )

    yield Setup(
        tmp_path,
        database,
        DocumentService(database.unit_of_work, store),
        store,
        derived,
        owner,
        other,
        make,
    )
    database.close()
