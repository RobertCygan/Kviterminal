"""Reference data, standard posting and posting suggestions with a real database (Phase 08b)."""

import datetime as dt
import sqlite3
from contextlib import closing
from decimal import Decimal

import pytest
from processing_fakes import InProcessProcessor

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.documents import DocumentService
from invoiceflow.application.errors import InvoiceFlowError, NotFoundError
from invoiceflow.application.processing import ProcessingService
from invoiceflow.application.processing_model import ProcessingLimits
from invoiceflow.application.reference.csv_import import ReferenceImportError
from invoiceflow.application.reference.model import Dimension, ReferenceKind
from invoiceflow.application.reference.service import ReferenceService
from invoiceflow.application.services import InvoiceService
from invoiceflow.application.validation.model import AccountStatus
from invoiceflow.application.validation.service import ValidationService
from invoiceflow.bootstrap.synthetic_ehf import Line, SyntheticEhf, build_ehf
from invoiceflow.bootstrap.synthetic_reference import CHART_CSV, DIMENSIONS_CSV, VAT_CODES_CSV
from invoiceflow.domain.provenance import FieldValue

pytestmark = pytest.mark.integration

TODAY = dt.date(2026, 10, 20)


def validation(setup) -> ValidationService:
    return ValidationService(setup.database.unit_of_work, today=lambda: TODAY)


def references(setup) -> ReferenceService:
    return ReferenceService(setup.database.unit_of_work, validator=validation(setup))


def processing(setup) -> ProcessingService:
    return ProcessingService(
        setup.database.unit_of_work,
        setup.store,
        setup.derived,
        InProcessProcessor(),
        attachments=DocumentService(setup.database.unit_of_work, setup.store),
        validator=validation(setup),
        poster=references(setup),
        limits=ProcessingLimits(dpi=72),
    )


def import_csv(setup, kind: ReferenceKind, text: str, scope=None):
    source = setup.tmp / f"{kind}-{len(text)}.csv"
    source.write_text(text, encoding="utf-8")
    return references(setup).import_file(scope or setup.owner, kind, source)


def import_all(setup, scope=None) -> None:
    for kind, text in (
        (ReferenceKind.CHART, CHART_CSV),
        (ReferenceKind.VAT_CODES, VAT_CODES_CSV),
        (ReferenceKind.DIMENSIONS, DIMENSIONS_CSV),
    ):
        import_csv(setup, kind, text, scope)


def import_ehf(setup, spec=None, *, name="faktura.xml", scope=None):
    scope = scope or setup.owner
    document_id = setup.add(build_ehf(spec), name, scope=scope)
    processing(setup).process(scope, document_id)
    return InvoiceService(setup.database.unit_of_work).summaries(scope)[document_id].invoice_id


def posting(setup, invoice_id, scope=None):
    record = InvoiceService(setup.database.unit_of_work).get(scope or setup.owner, invoice_id)
    return record.revision, [
        (
            None if line.account is None else line.account.value,
            None if line.vat_code is None else line.vat_code.value,
            line.net_amount.value,
        )
        for line in record.invoice.accounting_lines
    ]


def rules(setup, invoice_id) -> list[str]:
    run = validation(setup).latest(setup.owner, invoice_id)
    return [f"{f.rule_id.value}:{f.message_key.removeprefix('validation.')}" for f in run.findings]


def events(setup, *types):
    with setup.database.unit_of_work() as uow:
        return [r for r in uow.audit.records() if r.event_type in types]


def verify_account(setup) -> None:
    (view,) = validation(setup).suppliers(setup.owner)
    (account,) = view.accounts
    validation(setup).set_account_status(
        setup.owner, account.account_id, AccountStatus.VERIFIED, expected=AccountStatus.UNVERIFIED
    )


def test_imports_are_snapshots_and_the_latest_applies(setup) -> None:
    first = import_csv(setup, ReferenceKind.CHART, CHART_CSV)
    assert first.row_count == 5
    second = import_csv(setup, ReferenceKind.CHART, "konto;navn\n4000;Varekjøp\n")
    service = references(setup)
    assert service.status(setup.owner) == {ReferenceKind.CHART: second}
    assert set(service.reference(setup.owner).accounts) == {"4000"}
    imported = events(setup, AuditEventType.REFERENCE_IMPORTED)
    assert [dict(e.details) for e in imported] == [
        {"reference_kind": "chart", "row_count": 5, "sha256": first.sha256},
        {"reference_kind": "chart", "row_count": 1, "sha256": second.sha256},
    ]
    with closing(sqlite3.connect(setup.database.path)) as connection:
        assert connection.execute("SELECT COUNT(*) FROM chart_of_accounts").fetchone() == (6,)


def test_a_refused_file_stores_nothing(setup) -> None:
    with pytest.raises(ReferenceImportError) as caught:
        import_csv(setup, ReferenceKind.VAT_CODES, "kode;sats;retning;gyldig_fra\n1;250;inn;x\n")
    assert caught.value.reason == "invalid_date"  # the first error in the row
    assert references(setup).status(setup.owner) == {}
    assert events(setup, AuditEventType.REFERENCE_IMPORTED) == []
    link = setup.tmp / "lenke.csv"
    link.symlink_to(setup.tmp)
    with pytest.raises(ReferenceImportError, match="REFERENCE_IMPORT_REFUSED"):
        references(setup).import_file(setup.owner, ReferenceKind.CHART, link)
    with pytest.raises(ReferenceImportError):
        references(setup).import_file(setup.owner, ReferenceKind.CHART, setup.tmp / "mangler.csv")


def test_reference_data_belongs_to_one_entity(setup) -> None:
    import_all(setup)
    other = references(setup).reference(setup.other)
    assert (other.accounts, other.vat_codes, other.dimensions) == (None, None, None)
    assert references(setup).status(setup.other) == {}


def test_a_new_invoice_gets_a_posting_suggestion(setup) -> None:
    import_all(setup)
    invoice_id = import_ehf(setup)
    # No standard posting yet: the VAT code is found, the account is missing.
    assert posting(setup, invoice_id) == (1, [(None, "1", Decimal("10500.00"))])
    assert rules(setup, invoice_id) == [
        "BANK-001:bank_001_unverified",
        "ACC-002:acc_002_no_account",
    ]


def test_standard_posting_suggests_again_and_clears_the_findings(setup) -> None:
    import_all(setup)
    invoice_id = import_ehf(setup)
    verify_account(setup)
    (view,) = validation(setup).suppliers(setup.owner)
    stored = references(setup).set_defaults(
        setup.owner,
        view.supplier.supplier_id,
        account="6300",
        vat_code="1",
        dimensions={Dimension.DEPARTMENT: "10", Dimension.PROJECT: ""},
    )
    assert (stored.account, stored.vat_code, dict(stored.dimensions)) == (
        "6300",
        "1",
        {Dimension.DEPARTMENT: "10"},
    )
    assert posting(setup, invoice_id) == (2, [("6300", "1", Decimal("10500.00"))])
    assert rules(setup, invoice_id) == []
    assert len(events(setup, AuditEventType.SUPPLIER_DEFAULTS_SET)) == 1
    # The next invoice from the supplier is posted at once.
    second = import_ehf(
        setup, SyntheticEhf(number="EHF-2026-002", issue_date="2026-10-02"), name="andre.xml"
    )
    assert posting(setup, second) == (1, [("6300", "1", Decimal("10500.00"))])
    assert rules(setup, second) == []


def test_several_rates_give_several_lines(setup) -> None:
    import_all(setup)
    spec = SyntheticEhf(lines=(Line("Mat", "1", "100.00", "15"), Line("Rom", "2", "500.00")))
    invoice_id = import_ehf(setup, spec)
    assert posting(setup, invoice_id)[1] == [
        (None, "11", Decimal("100.00")),
        (None, "1", Decimal("1000.00")),
    ]


def test_standard_posting_must_use_existing_values(setup) -> None:
    import_all(setup)
    import_ehf(setup)
    (view,) = validation(setup).suppliers(setup.owner)
    supplier_id = view.supplier.supplier_id
    service = references(setup)
    for values, key in [
        ({"account": "9999", "vat_code": None}, "reference.error.unknown_account"),
        ({"account": "6900", "vat_code": None}, "reference.error.unknown_account"),
        ({"account": None, "vat_code": "3"}, "reference.error.unknown_vat_code"),
        ({"account": None, "vat_code": "99"}, "reference.error.unknown_vat_code"),
    ]:
        with pytest.raises(InvoiceFlowError) as caught:
            service.set_defaults(setup.owner, supplier_id, **values)
        assert caught.value.message_key == key
    with pytest.raises(InvoiceFlowError) as caught:
        service.set_defaults(
            setup.owner,
            supplier_id,
            account=None,
            vat_code=None,
            dimensions={Dimension.PROJECT: "P9"},
        )
    assert caught.value.message_key == "reference.error.unknown_dimension"
    with pytest.raises(NotFoundError):
        service.set_defaults(setup.other, supplier_id, account="6300", vat_code=None)
    assert service.defaults(setup.owner, supplier_id) is None


def test_a_manual_posting_is_kept(setup) -> None:
    import_all(setup)
    invoice_id = import_ehf(setup)
    invoices = InvoiceService(setup.database.unit_of_work)
    record = invoices.get(setup.owner, invoice_id)
    line = record.invoice.accounting_lines[0]
    manual = FieldValue(
        value="6800",
        provenance={
            "source": "manual",
            "producer": "bruker/lokal",
            "recorded_at": "2026-10-20T10:00:00Z",
        },
    )
    changed = record.invoice.model_copy(
        update={"accounting_lines": (line.model_copy(update={"account": manual}),)}
    )
    invoices.revise(setup.owner, invoice_id, changed, expected_revision=1)
    assert references(setup).suggest(setup.owner, invoice_id) is None
    assert posting(setup, invoice_id) == (2, [("6800", "1", Decimal("10500.00"))])


def test_a_suggestion_without_change_makes_no_revision(setup) -> None:
    import_all(setup)
    invoice_id = import_ehf(setup)
    assert references(setup).suggest(setup.owner, invoice_id) is None
    assert posting(setup, invoice_id)[0] == 1


@pytest.mark.security
def test_reference_tables_resist_tampering(setup) -> None:
    import_all(setup)
    import_ehf(setup)
    (view,) = validation(setup).suppliers(setup.owner)
    references(setup).set_defaults(
        setup.owner, view.supplier.supplier_id, account="6300", vat_code="1"
    )
    with closing(sqlite3.connect(setup.database.path)) as connection:
        for statement in [
            "UPDATE chart_of_accounts SET name = 'x'",
            "DELETE FROM chart_of_accounts",
            "UPDATE vat_codes SET rate = '15'",
            "DELETE FROM dimension_values",
            "DELETE FROM reference_imports",
            "UPDATE supplier_defaults SET account = '6800'",
            "DELETE FROM supplier_defaults",
        ]:
            with pytest.raises(sqlite3.IntegrityError):
                connection.execute(statement)
        # Rows of one kind cannot be attached to an import of another kind.
        entity, chart = connection.execute(
            "SELECT entity_id, id FROM reference_imports WHERE kind = 'chart'"
        ).fetchone()
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute(
                "INSERT INTO vat_codes VALUES (?, ?, '9', '2026-01-01', NULL, '25', 'input',"
                " NULL, NULL)",
                (entity, chart),
            )
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute(
                "INSERT INTO chart_of_accounts VALUES (?, ?, '7000', '=FORMEL()', NULL, 1)",
                (entity, chart),
            )
        connection.rollback()
