"""The watched scan folder with a real archive, worker and database (Phase 11a)."""

import pytest
from processing_fakes import InProcessProcessor

from invoiceflow.application.audit import AuditEventType
from invoiceflow.application.processing import ProcessingService
from invoiceflow.application.processing_model import ProcessingLimits
from invoiceflow.application.scan.model import PageKind
from invoiceflow.application.scan.service import ScanPoll, ScanService
from invoiceflow.bootstrap.synthetic_pdf import batch_pdf, text_pdf
from invoiceflow.documents.scan_folder import IMPORTED_FOLDER, REFUSED_FOLDER, FileScanFolder

pytestmark = pytest.mark.integration


def scanning(setup, *, processor=None) -> ScanService:
    inbox = setup.tmp / "skann"
    inbox.mkdir(exist_ok=True)
    processing = ProcessingService(
        setup.database.unit_of_work,
        setup.store,
        setup.derived,
        processor or InProcessProcessor(),
        attachments=setup.documents,
        limits=ProcessingLimits(dpi=72),
    )
    return ScanService(setup.documents, processing, FileScanFolder(min_age_seconds=0), inbox)


def events(setup, kind):
    with setup.database.unit_of_work() as uow:
        return [r for r in uow.audit.records() if r.event_type == kind]


def test_finished_files_are_imported_set_aside_and_analysed(setup) -> None:
    service = scanning(setup)
    inbox = service.inbox
    (inbox / "bunke.pdf").write_bytes(
        batch_pdf(["Faktura 1", "blank", "Faktura 1 side 2", "separator", "Faktura 2"])
    )
    (inbox / "kopi.pdf").write_bytes(batch_pdf(["Faktura 1", "blank"]))
    (inbox / "falsk.pdf").write_bytes(b"MZ ikke en PDF")
    assert service.poll(setup.owner) == ScanPoll()  # nothing is stable yet

    result = service.poll(setup.owner)

    assert result == ScanPoll(imported=2, refused=1, processed=2)
    assert sorted(p.name for p in (inbox / IMPORTED_FOLDER).iterdir()) == [
        "bunke.pdf",
        "kopi.pdf",
    ]
    assert [p.name for p in (inbox / REFUSED_FOLDER).iterdir()] == ["falsk.pdf"]
    assert [p.name for p in inbox.iterdir() if p.is_file()] == []
    views = {view.document.display_name: view for view in service.batches(setup.owner)}
    batch = views["bunke.pdf"]
    assert batch.page_count == 5 and batch.split.parts == ((1, 3), (5, 5))
    assert batch.split.pages_of(PageKind.BLANK) == (2,)
    assert batch.split.pages_of(PageKind.SEPARATOR) == (4,)
    assert views["kopi.pdf"].split.parts == ((1, 1),)
    assert [page.page_number for page in batch.pages] == [1, 2, 3, 4, 5]
    assert batch.split.near == ()  # the synthetic pages are far from every threshold
    imported = events(setup, AuditEventType.DOCUMENT_IMPORTED)
    assert {e.details["source"] for e in imported} == {"inbox"}
    assert service.poll(setup.owner) == ScanPoll()  # nothing left


def test_a_known_file_is_set_aside_as_a_duplicate(setup) -> None:
    service = scanning(setup)
    data = text_pdf(["Allerede lest inn"])
    first = setup.tmp / "kilde.pdf"
    first.write_bytes(data)
    setup.documents.import_file(setup.owner, first)
    (service.inbox / "igjen.pdf").write_bytes(data)
    service.poll(setup.owner)
    assert service.poll(setup.owner) == ScanPoll(duplicates=1)
    assert (service.inbox / IMPORTED_FOLDER / "igjen.pdf").exists()


def test_scans_belong_to_the_entity_that_polled(setup) -> None:
    service = scanning(setup)
    (service.inbox / "bunke.pdf").write_bytes(batch_pdf(["Faktura"]))
    service.poll(setup.other)
    assert service.poll(setup.other).imported == 1
    assert service.batches(setup.owner) == []
    assert len(service.batches(setup.other)) == 1


def test_the_separator_sheet_is_saved_where_chosen(setup) -> None:
    target = setup.tmp / "skilleark.pdf"
    scanning(setup).save_separator_sheet(target, copies=2)
    assert target.read_bytes().startswith(b"%PDF")


@pytest.mark.tesseract
def test_a_scanned_page_counts_once_although_ocr_runs_too(setup) -> None:
    from ocr_samples import encode, render

    service = scanning(setup, processor=InProcessProcessor(ocr=True))
    (service.inbox / "skann.png").write_bytes(encode(render(("Faktura 7",), font_size=14)))
    service.poll(setup.owner)

    assert service.poll(setup.owner) == ScanPoll(imported=1, processed=1)
