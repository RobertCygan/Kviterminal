"""The EHF reader in-process: mapping, evidence and refusals (Phase 15).

In the program it only ever runs inside the isolated worker.
"""

import hashlib
import json
from decimal import Decimal
from pathlib import Path

import hostile_xml
import pytest

from invoiceflow.application.document_model import DocumentFormat, detect_format
from invoiceflow.application.ports import WorkerTask
from invoiceflow.application.processing_model import EhfReport, ProcessingLimits
from invoiceflow.bootstrap.synthetic_ehf import Attachment, Line, SyntheticEhf, build_ehf
from invoiceflow.bootstrap.synthetic_pdf import text_pdf
from invoiceflow.domain.invoice import CanonicalInvoice
from invoiceflow.processing import ehf

pytestmark = pytest.mark.security


def read(tmp_path: Path, data: bytes) -> dict:
    output = tmp_path / "out"
    output.mkdir(exist_ok=True)
    task = WorkerTask(
        tmp_path / "x.xml",
        hashlib.sha256(data).hexdigest(),
        DocumentFormat.XML,
        output,
        ProcessingLimits(),
    )
    report = json.loads(ehf.analyse_ehf(task, data))
    EhfReport.model_validate(report)  # always a valid report, whatever the input
    return report


def invoice_of(report: dict) -> CanonicalInvoice:
    return CanonicalInvoice.model_validate(report["invoice"])


def test_xml_is_recognised_only_by_declaration_or_ehf_root() -> None:
    assert detect_format(b'<?xml version="1.0"') is DocumentFormat.XML
    assert detect_format(b"\xef\xbb\xbf<Invoice xmlns") is DocumentFormat.XML
    assert detect_format(b"<CreditNote xmlns=") is DocumentFormat.XML
    assert detect_format(b"<html><body>") is None
    assert detect_format(b"<!DOCTYPE html>") is None


def test_invoice_mapping_with_evidence(tmp_path) -> None:
    report = read(tmp_path, build_ehf())
    assert report["status"] == "ok" and report["unreadable_values"] == 0
    invoice = invoice_of(report)
    assert invoice.invoice_type.value == "invoice"
    assert invoice.invoice_number.value == "EHF-2026-001"
    assert str(invoice.invoice_date.value) == "2026-10-01"
    assert str(invoice.due_date.value) == "2026-10-15"
    assert invoice.currency.value == "NOK"
    assert invoice.buyer_reference.value == "Ref-42"
    assert invoice.supplier.name.value == "Syntetisk Leverandør AS"
    assert invoice.supplier.org_number.value == "123456785"
    assert invoice.supplier.vat_registered.value is True
    assert invoice.supplier.address.city.value == "Narvik"
    assert invoice.customer.org_number.value == "314159268"
    assert invoice.payment.kid.value == "1234567890128"
    assert invoice.payment.bank_account.value == "12345678903"
    first, second = invoice.lines
    assert (first.line_number, first.description.value, first.unit.value) == (
        1,
        "Konsulenttimer",
        "EA",
    )
    assert (first.quantity.value, first.unit_price.value, first.net_amount.value) == (
        Decimal("10"),
        Decimal("1000.00"),
        Decimal("10000.00"),
    )
    assert first.vat_rate.value == Decimal("25")
    assert second.net_amount.value == Decimal("500.00")
    assert invoice.vat_breakdown[0].vat_amount.value == Decimal("2625.00")
    totals = invoice.totals
    assert (totals.net_amount.value, totals.vat_amount.value, totals.gross_amount.value) == (
        Decimal("10500.00"),
        Decimal("2625.00"),
        Decimal("13125.00"),
    )
    evidence = invoice.totals.gross_amount.provenance.evidence
    assert evidence.source_ref == "/Invoice/cac:LegalMonetaryTotal/cbc:PayableAmount"
    assert evidence.raw_text == "13125.00"
    line_evidence = second.net_amount.provenance.evidence
    assert line_evidence.source_ref == "/Invoice/cac:InvoiceLine[2]/cbc:LineExtensionAmount"
    provenance = invoice.invoice_number.provenance
    assert (provenance.source, provenance.producer) == ("extracted", f"ehf/{ehf.engine_version()}")
    assert report["monetary"]["payable"] == "13125.00" and report["monetary"]["currencies"] == [
        "NOK"
    ]


def test_credit_note_keeps_positive_totals_and_reference(tmp_path) -> None:
    report = read(tmp_path, build_ehf(SyntheticEhf(credit_note=True, referenced_invoice="F-1")))
    invoice = invoice_of(report)
    assert invoice.invoice_type.value == "credit_note"  # D-16: direction from the type
    assert invoice.referenced_invoice_number.value == "F-1"
    assert invoice.totals.gross_amount.value == Decimal("13125.00")
    assert invoice.lines[0].quantity.provenance.evidence.source_ref.endswith(
        "cac:CreditNoteLine[1]/cbc:CreditedQuantity"
    )


def test_amounts_keep_their_precision(tmp_path) -> None:
    spec = SyntheticEhf(lines=(Line("Presis", "3", "0.333333"),))
    invoice = invoice_of(read(tmp_path, build_ehf(spec)))
    assert invoice.lines[0].unit_price.value == Decimal("0.333333")
    assert invoice.lines[0].net_amount.value == Decimal("1.00")


def test_attachments_are_written_and_reported(tmp_path) -> None:
    pdf = text_pdf(["vis"])
    spec = SyntheticEhf(attachments=(Attachment(pdf), Attachment(b"\x89PNG", "b.png", "image/png")))
    report = read(tmp_path, build_ehf(spec))
    assert [item["file"] for item in report["attachments"]] == [
        "attachment-01.bin",
        "attachment-02.bin",
    ]
    assert (tmp_path / "out" / "attachment-01.bin").read_bytes() == pdf
    assert report["attachments"][0]["filename"] == "faktura.pdf"


@pytest.mark.parametrize(
    ("data", "code"),
    [
        (hostile_xml.external_entity(), "invalid_xml"),
        (hostile_xml.external_dtd(), "invalid_xml"),
        (hostile_xml.billion_laughs(), "invalid_xml"),
        (hostile_xml.quadratic_blowup(), "invalid_xml"),
        (hostile_xml.deep_nesting(), "invalid_xml"),
        (hostile_xml.invalid_utf8(), "invalid_xml"),
        (hostile_xml.invalid_base64(), "invalid_xml"),
        (b"", "invalid_xml"),
        (b"<?xml version='1.0'?><Invoice", "invalid_xml"),
        (hostile_xml.wrong_root(), "unsupported_format"),
        (hostile_xml.ehf_2(), "unsupported_version"),
    ],
    ids=[
        "xxe",
        "external-dtd",
        "billion-laughs",
        "quadratic",
        "deep",
        "utf8",
        "base64",
        "empty",
        "truncated",
        "wrong-root",
        "ehf-2",
    ],
)
def test_hostile_xml_is_refused_with_a_stable_code(tmp_path, data, code) -> None:
    report = read(tmp_path, data)
    assert (report["status"], report["error_code"]) == ("error", code)
    assert "passwd" not in json.dumps(report)


def test_too_many_lines_and_attachments(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr(ehf, "MAX_INVOICE_LINES", 1)
    assert read(tmp_path, build_ehf())["error_code"] == "too_many_lines"
    monkeypatch.setattr(ehf, "MAX_EHF_ATTACHMENTS", 1)
    spec = SyntheticEhf(
        attachments=(Attachment(b"a"), Attachment(b"b")), lines=(Line("x", "1", "1"),)
    )
    assert read(tmp_path, build_ehf(spec))["error_code"] == "too_many_attachments"
    monkeypatch.setattr(ehf, "MAX_ATTACHMENT_BYTES", 10)
    spec = SyntheticEhf(attachments=(Attachment(b"x" * 100),), lines=(Line("x", "1", "1"),))
    assert read(tmp_path, build_ehf(spec))["error_code"] == "attachment_too_large"


def test_wrong_numbers_are_kept_as_raw_text_never_guessed(tmp_path) -> None:
    report = read(tmp_path, hostile_xml.bad_numbers())
    assert report["status"] == "ok" and report["unreadable_values"] == 3
    invoice = invoice_of(report)
    assert invoice.totals.net_amount.value is None
    assert invoice.totals.net_amount.provenance.evidence.raw_text == "10 500,00"
    assert invoice.totals.gross_amount.value is None
    assert invoice.lines[0].quantity.value is None
    assert "payable" not in report["monetary"]  # not a number, so not compared


def test_missing_required_fields_stay_missing(tmp_path) -> None:
    invoice = invoice_of(read(tmp_path, hostile_xml.missing_required()))
    assert invoice.invoice_number is None and invoice.totals.gross_amount is None


def test_negative_quantities_are_allowed(tmp_path) -> None:
    invoice = invoice_of(read(tmp_path, hostile_xml.negative_quantity()))
    assert invoice.lines[0].quantity.value == Decimal("-2")


def test_external_attachments_are_counted_never_fetched(tmp_path) -> None:
    report = read(tmp_path, hostile_xml.external_attachment())
    assert report["external_attachments"] == 1 and report["attachments"] == []


def test_control_characters_in_text_are_evidence_not_values(tmp_path) -> None:
    data = build_ehf(SyntheticEhf(supplier_name="Linje\nskift AS"))
    invoice = invoice_of(read(tmp_path, data))
    assert invoice.supplier.name.value is None
    assert invoice.supplier.name.provenance.evidence.raw_text == "Linje\nskift AS"
