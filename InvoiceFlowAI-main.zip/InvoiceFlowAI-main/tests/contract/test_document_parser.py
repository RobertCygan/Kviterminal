"""Contract every DocumentParser adapter must pass (ADR-0023).

The adapters run in-process here; in the program they only ever run inside
the isolated worker.
"""

import hashlib
import json
from collections.abc import Iterator
from pathlib import Path

import hostile_corpus as corpus
import pytest

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.ports import WorkerTask
from invoiceflow.application.processing import png_size
from invoiceflow.application.processing_model import (
    ProcessingErrorCode,
    ProcessingLimits,
    TextLayer,
    WorkerResult,
)
from invoiceflow.bootstrap.synthetic_pdf import text_pdf
from invoiceflow.processing.image_pillow import PillowParser
from invoiceflow.processing.parser import ParsedPage, ParserError
from invoiceflow.processing.pdf_pdfium import PdfiumParser, scan_active_names
from invoiceflow.processing.worker import analyse

pytestmark = pytest.mark.security

LIMITS = ProcessingLimits()
SMALL = ProcessingLimits(dpi=72)


def pages_of(parser, data: bytes, fmt=DocumentFormat.PDF, limits=SMALL) -> list[ParsedPage]:
    document = parser.open(data, fmt, limits)
    try:
        return list(document.pages())
    finally:
        document.close()


def refused(parser, data: bytes, fmt=DocumentFormat.PDF, limits=SMALL) -> ProcessingErrorCode:
    with pytest.raises(ParserError) as error:
        pages_of(parser, data, fmt, limits)
    return error.value.code


# -- PDF ------------------------------------------------------------------------


def test_pdf_text_layer_with_positions() -> None:
    (page,) = pages_of(PdfiumParser(), text_pdf(["Faktura 2026-001 Syntetisk AS"]), limits=LIMITS)
    assert page.text == "Faktura 2026-001 Syntetisk AS"
    assert len(page.boxes) == len(page.text)
    x0, y0, x1, y1 = page.boxes[0]  # "F" at 72 pt from the left, 770 pt from the bottom
    assert x0 == pytest.approx(72 / 595, abs=0.005)
    assert y1 == pytest.approx((842 - 770) / 842, abs=0.005)
    assert x0 < x1 and y0 < y1
    assert all(0 <= value <= 1 for box in page.boxes for value in box)


def test_pdf_page_count_order_and_rasterisation() -> None:
    pages = pages_of(PdfiumParser(), text_pdf(["en", "to", "tre"]), limits=LIMITS)
    assert [page.page_number for page in pages] == [1, 2, 3]
    assert [page.text for page in pages] == ["en", "to", "tre"]
    first = pages[0]
    assert (first.width_px, first.height_px) == (2480, 3508) or (
        first.width_px,
        first.height_px,
    ) == (2480, 3509)
    assert png_size(first.png[:24]) == (first.width_px, first.height_px)


def test_pdf_rotation_is_reported_and_applied() -> None:
    (page,) = pages_of(PdfiumParser(), text_pdf(["rot"], page_extra=b"/Rotate 90 "))
    assert page.rotation_degrees == 90
    assert page.width_px > page.height_px
    x0, y0, _, _ = page.boxes[0]  # top-left text moves to the top right
    assert x0 > 0.8 and y0 < 0.2


@pytest.mark.parametrize(
    ("data", "code", "limits"),
    [
        (corpus.pdf_encrypted(), ProcessingErrorCode.ENCRYPTED, SMALL),
        (corpus.pdf_truncated(), ProcessingErrorCode.CORRUPT, SMALL),
        (corpus.pdf_cyclic_page_tree(), ProcessingErrorCode.CORRUPT, SMALL),
        (b"%PDF-" + b"\x00" * 100, ProcessingErrorCode.CORRUPT, SMALL),
        (
            corpus.pdf_many_pages(3),
            ProcessingErrorCode.TOO_MANY_PAGES,
            ProcessingLimits(max_pages=2),
        ),
        (corpus.pdf_huge_page(), ProcessingErrorCode.PAGE_TOO_LARGE, LIMITS),
        (
            corpus.pdf_long_text(50),
            ProcessingErrorCode.TOO_MUCH_TEXT,
            ProcessingLimits(dpi=72, max_chars_per_page=10),
        ),
    ],
    ids=["encrypted", "truncated", "cyclic", "garbage", "pages", "huge", "text"],
)
def test_pdf_refusals_have_stable_codes(data, code, limits) -> None:
    assert refused(PdfiumParser(), data, limits=limits) is code


def test_pdf_without_pages_is_refused() -> None:
    assert refused(PdfiumParser(), corpus.pdf_zero_pages()) in {
        ProcessingErrorCode.NO_PAGES,
        ProcessingErrorCode.CORRUPT,
    }


@pytest.mark.parametrize(
    "data",
    [
        corpus.pdf_with_javascript(),
        corpus.pdf_with_launch(),
        corpus.pdf_with_escaped_launch(),
        corpus.pdf_with_embedded_file(),
    ],
    ids=["javascript", "launch", "escaped-launch", "embedded-file"],
)
def test_active_content_is_flagged_never_run(data) -> None:
    document = PdfiumParser().open(data, DocumentFormat.PDF, SMALL)
    try:
        assert document.active_content is True
        assert len(list(document.pages())) == 1  # still analysed, nothing executed
    finally:
        document.close()


def test_plain_pdf_and_polyglot_have_no_active_content() -> None:
    for data in (text_pdf(["vanlig"]), corpus.pdf_polyglot()):
        document = PdfiumParser().open(data, DocumentFormat.PDF, SMALL)
        assert document.active_content is False
        document.close()
    assert not scan_active_names(b"/JSON /Launcher /JavaScriptX")


def test_pdf_parser_refuses_other_formats() -> None:
    code = refused(PdfiumParser(), corpus.png_page(), DocumentFormat.PNG)
    assert code is ProcessingErrorCode.UNSUPPORTED_FORMAT


# -- images ---------------------------------------------------------------------


def test_png_is_one_page_at_native_size() -> None:
    (page,) = pages_of(PillowParser(), corpus.png_page(400, 300), DocumentFormat.PNG)
    assert (page.width_px, page.height_px, page.text, page.boxes) == (400, 300, "", ())
    assert png_size(page.png[:24]) == (400, 300)


@pytest.mark.parametrize("mode", ["RGBA", "P", "LA", "1", "I;16", "CMYK"])
def test_image_modes_are_normalised(mode) -> None:
    fmt = DocumentFormat.TIFF if mode == "CMYK" else DocumentFormat.PNG
    data = corpus.tiff_pages(1) if mode == "CMYK" else corpus.png_page(20, 10, mode)
    (page,) = pages_of(PillowParser(), data, fmt)
    assert png_size(page.png[:24]) == (page.width_px, page.height_px)


def test_jpeg_orientation_is_applied_and_reported() -> None:
    (page,) = pages_of(
        PillowParser(), corpus.jpeg_page(320, 200, orientation=6), DocumentFormat.JPEG
    )
    assert page.rotation_degrees == 90
    assert (page.width_px, page.height_px) == (200, 320)


def test_tiff_pages() -> None:
    pages = pages_of(PillowParser(), corpus.tiff_pages(3), DocumentFormat.TIFF)
    assert [page.page_number for page in pages] == [1, 2, 3]


@pytest.mark.parametrize(
    ("data", "fmt", "code", "limits"),
    [
        (corpus.png_bomb(), DocumentFormat.PNG, ProcessingErrorCode.PAGE_TOO_LARGE, LIMITS),
        (
            corpus.png_page(200, 200),
            DocumentFormat.PNG,
            ProcessingErrorCode.PAGE_TOO_LARGE,
            ProcessingLimits(max_pixels=1000),
        ),
        (corpus.truncated_png(), DocumentFormat.PNG, ProcessingErrorCode.CORRUPT, LIMITS),
        (corpus.corrupt_jpeg(), DocumentFormat.JPEG, ProcessingErrorCode.CORRUPT, LIMITS),
        (
            corpus.tiff_pages(3),
            DocumentFormat.TIFF,
            ProcessingErrorCode.TOO_MANY_PAGES,
            ProcessingLimits(max_pages=2),
        ),
        # A PNG presented as JPEG: only the expected decoder is ever tried.
        (corpus.png_page(), DocumentFormat.JPEG, ProcessingErrorCode.CORRUPT, LIMITS),
        (corpus.png_page(), DocumentFormat.PDF, ProcessingErrorCode.UNSUPPORTED_FORMAT, LIMITS),
    ],
    ids=["bomb", "pixels", "truncated", "jpeg", "pages", "wrong-decoder", "pdf"],
)
def test_image_refusals_have_stable_codes(data, fmt, code, limits) -> None:
    assert refused(PillowParser(), data, fmt, limits) is code


# -- swapping the adapter -----------------------------------------------------------


class FakeDocument:
    page_count = 2
    active_content = True

    def pages(self) -> Iterator[ParsedPage]:
        for number in (1, 2):
            yield ParsedPage(
                number,
                30,
                20,
                0,
                "ab",
                ((0, 0, 0.5, 0.5), (0.5, 0.5, 1, 1)),
                corpus.png_page(30, 20),
            )

    def close(self) -> None:
        pass


class FakeParser:
    engine = "fake"
    engine_version = "1.0"
    formats = frozenset({DocumentFormat.PDF})

    def open(self, data, document_format, limits):
        if data.startswith(b"refuse"):
            raise ParserError(ProcessingErrorCode.ENCRYPTED)
        return FakeDocument()


def run_worker(tmp_path: Path, data: bytes, parser, **limits) -> tuple[WorkerResult, Path]:
    source = tmp_path / "original.bin"
    source.write_bytes(data)
    output = tmp_path / "out"
    output.mkdir()
    task = WorkerTask(
        source,
        hashlib.sha256(data).hexdigest(),
        DocumentFormat.PDF,
        output,
        ProcessingLimits(**limits),
    )
    return WorkerResult.model_validate_json(analyse(task, {DocumentFormat.PDF: parser})), output


@pytest.mark.parametrize("parser", [FakeParser(), PdfiumParser()], ids=["fake", "pdfium"])
def test_any_adapter_produces_a_valid_worker_report(tmp_path, parser) -> None:
    result, output = run_worker(tmp_path, text_pdf(["ab", "ab"]), parser, dpi=72)
    assert result.status == "ok" and result.page_count == 2
    assert (result.engine, result.engine_version) == (parser.engine, parser.engine_version)
    names = sorted(path.name for path in output.iterdir())
    assert names == ["page-0001.png", "page-0002.png", "text-0001.json", "text-0002.json"]
    layer = TextLayer.model_validate_json((output / "text-0001.json").read_bytes())
    assert layer.text == "ab" and len(layer.boxes) == 2


def test_refusal_by_any_adapter_is_reported_with_its_code(tmp_path) -> None:
    result, output = run_worker(tmp_path, b"refuse", FakeParser())
    assert (result.status, result.error_code, result.pages) == ("error", "encrypted", ())
    assert list(output.iterdir()) == []


def test_worker_report_is_plain_json_without_document_text(tmp_path) -> None:
    supplier = "Hemmelig Leverandør AS"
    result, _ = run_worker(tmp_path, text_pdf([supplier]), PdfiumParser(), dpi=72)
    report = result.model_dump_json()
    assert supplier not in report and "Hemmelig" not in json.dumps(result.model_dump())
