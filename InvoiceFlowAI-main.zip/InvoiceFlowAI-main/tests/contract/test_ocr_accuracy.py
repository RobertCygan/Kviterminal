"""OCR of synthetic scanned invoices in the real, isolated worker (Phase 05, NF-04).

The reference set is printed text, so the expected result is known exactly.
The character error rate is measured on the whole page; the limits are the
acceptance criteria of ADR-0040 and are deliberately not loose.
"""

import hashlib
import io
import time

import pytest
from ocr_samples import REFERENCE_LINES, character_error_rate, degrade, encode, render
from PIL import Image

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.ports import OcrInput, OcrTask, WorkerExit, WorkerTask
from invoiceflow.application.processing_model import (
    OcrLayer,
    OcrReport,
    OcrSettings,
    ProcessingLimits,
    ocr_input_name,
    ocr_name,
)
from invoiceflow.processing.isolation import IsolatedDocumentProcessor

pytestmark = [pytest.mark.integration, pytest.mark.tesseract]

EXPECTED = "\n".join(REFERENCE_LINES)
NF04_SECONDS = 10.0


def recognise(tmp_path, image: Image.Image, data: bytes) -> tuple[OcrLayer, float]:
    """One page through the isolated worker, as the service would run it."""
    work = tmp_path / "work"
    work.mkdir()
    # The service always hands the worker a PNG page image.
    png = data if data.startswith(b"\x89PNG") else encode(Image.open(io.BytesIO(data)))
    (work / ocr_input_name(1)).write_bytes(png)
    sha = hashlib.sha256(png).hexdigest()
    task = WorkerTask(
        source=work / ocr_input_name(1),
        sha256="0" * 64,
        document_format=DocumentFormat.PNG,
        output_dir=work,
        limits=ProcessingLimits(timeout_seconds=120),
        ocr=OcrTask(OcrSettings(), (OcrInput(1, ocr_input_name(1), sha, *image.size),), 60.0),
    )
    started = time.monotonic()
    outcome = IsolatedDocumentProcessor().run(task, lambda: False)
    elapsed = time.monotonic() - started
    assert outcome.exit is WorkerExit.COMPLETED, outcome
    report = OcrReport.model_validate_json(outcome.payload)
    assert report.status == "ok", report
    layer = OcrLayer.model_validate_json((work / ocr_name(1)).read_bytes())
    return layer, elapsed


VARIANTS = {
    # name: (image, JPEG instead of PNG, highest character error rate)
    "clean_300": (lambda: render(), False, 0.01),
    "noisy_rotated_300": (lambda: degrade(render(), angle=0.7, noise=0.002), False, 0.02),
    "jpeg_200": (lambda: render(dpi=200), True, 0.02),
    # A poor scan: below the recommended 300 dpi, more noise, more skew.
    "noisy_rotated_150": (lambda: degrade(render(dpi=150), angle=1.2, noise=0.004), False, 0.08),
}


@pytest.mark.parametrize("variant", VARIANTS)
def test_reference_pages_are_read_accurately_and_fast(tmp_path, variant: str) -> None:
    make, jpeg, limit = VARIANTS[variant]
    image = make()
    data = encode(image, "JPEG", quality=60) if jpeg else encode(image)

    layer, elapsed = recognise(tmp_path, image, data)

    error_rate = character_error_rate(EXPECTED, layer.text())
    assert error_rate <= limit, (variant, error_rate)
    assert elapsed < NF04_SECONDS, elapsed  # NF-04, including the worker start
    assert layer.mean_confidence() >= 80
    assert layer.line_count == len(REFERENCE_LINES) or variant == "noisy_rotated_150"


def test_amounts_and_identifiers_survive_exactly(tmp_path) -> None:
    image = degrade(render(), angle=-0.5, noise=0.001, seed=11)
    layer, _ = recognise(tmp_path, image, encode(image))
    text = layer.text()
    for value in (
        "2026-0417",
        "24.10.2026",
        "07.11.2026",
        "15 793,13",
        "1234.56.78903",
        "20260417005",
    ):
        assert value in text, value
