"""Field extraction on the synthetic reference set against golden files (Phase 06).

Each sample is laid out as a PDF and read twice: from its text layer, and as a
scanned page through rendering and Tesseract. Both must give exactly the
values of the golden file, no more: a value the file does not list is a
value that was made up.
"""

import hashlib
import io
import json
import subprocess
import uuid
from pathlib import Path

import pypdfium2 as pdfium
import pytest
from extraction_samples import ENTITY_NAME, ENTITY_ORG, NOT_AN_INVOICE, SAMPLES, Sample, flatten

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.extraction.fields import PRODUCER, Context, extract
from invoiceflow.application.extraction.layout import PageLayout, page_layout
from invoiceflow.application.ports import WorkerTask
from invoiceflow.application.processing_model import OcrLayer, ProcessingLimits, TextLayer
from invoiceflow.bootstrap.synthetic_pdf import layout_pdf
from invoiceflow.processing.ocr_tesseract import parse_tsv
from invoiceflow.processing.tesseract_install import locate
from invoiceflow.processing.worker import analyse

pytestmark = pytest.mark.integration

GOLDEN = Path(__file__).resolve().parents[1] / "fixtures" / "synthetic" / "extraction"


def from_text_layer(tmp_path: Path, sample: Sample) -> list[PageLayout]:
    data = layout_pdf(sample.pages)
    source, output = tmp_path / "faktura.pdf", tmp_path / "ut"
    source.write_bytes(data)
    output.mkdir()
    task = WorkerTask(
        source,
        hashlib.sha256(data).hexdigest(),
        DocumentFormat.PDF,
        output,
        ProcessingLimits(dpi=150),
    )
    report = json.loads(analyse(task))
    return [
        page_layout(
            page["page_number"],
            TextLayer.model_validate_json((output / page["text_file"]).read_bytes()),
        )
        for page in report["pages"]
        if page["text_file"]
    ]


def from_ocr(sample: Sample) -> list[PageLayout]:
    install = locate()
    assert install is not None
    document = pdfium.PdfDocument(layout_pdf(sample.pages))
    layouts = []
    try:
        for index in range(len(document)):
            image = document[index].render(scale=300 / 72, grayscale=True).to_pil()
            buffer = io.BytesIO()
            image.save(buffer, "PNG")
            tsv = subprocess.run(  # noqa: S603 - the located Tesseract, fixed arguments
                [
                    str(install.executable),
                    "stdin",
                    "stdout",
                    "-l",
                    "nor",
                    "--psm",
                    "3",
                    "-c",
                    "tessedit_create_tsv=1",
                ],
                input=buffer.getvalue(),
                capture_output=True,
                check=True,
                env={"OMP_THREAD_LIMIT": "1", "TESSDATA_PREFIX": str(install.tessdata)},
            ).stdout
            words = parse_tsv(tsv, *image.size)
            layer = OcrLayer.model_validate(
                {
                    "result_version": 1,
                    "page_number": index + 1,
                    "language": "nor",
                    "words": [word._asdict() for word in words],
                }
            )
            layouts.append(page_layout(index + 1, layer))
    finally:
        document.close()
    return layouts


def read(layouts: list[PageLayout], pages: int):
    context = Context(uuid.uuid4(), 1, pages, ENTITY_ORG, ENTITY_NAME)
    return extract(layouts, context)


def golden(sample: Sample) -> dict:
    data = json.loads((GOLDEN / f"{sample.name}.json").read_text(encoding="utf-8"))
    del data["sample"]
    return data


@pytest.mark.parametrize("sample", SAMPLES, ids=lambda sample: sample.name)
def test_text_layer_gives_exactly_the_golden_values(tmp_path, sample: Sample) -> None:
    extraction = read(from_text_layer(tmp_path, sample), len(sample.pages))
    assert extraction.titled
    assert flatten(extraction.invoice) == golden(sample)


@pytest.mark.tesseract
@pytest.mark.parametrize("sample", SAMPLES, ids=lambda sample: sample.name)
def test_a_scan_gives_the_same_values(sample: Sample) -> None:
    extraction = read(from_ocr(sample), len(sample.pages))
    assert flatten(extraction.invoice) == golden(sample)
    # OCR values carry the lowest word confidence; text layer values none.
    totals = extraction.invoice.totals
    assert totals.gross_amount is not None
    confidence = totals.gross_amount.provenance.confidence
    assert confidence is not None and 0.5 <= confidence <= 1


def test_every_value_points_at_its_source(tmp_path) -> None:
    sample = SAMPLES[0]
    invoice = read(from_text_layer(tmp_path, sample), 1).invoice
    number = invoice.invoice_number
    assert number is not None
    provenance = number.provenance
    assert provenance.source == "extracted" and provenance.producer == PRODUCER
    assert provenance.confidence is None  # a text layer is not a guess
    evidence = provenance.evidence
    assert evidence is not None and evidence.page_number == 1
    assert evidence.raw_text == "2026-0417"
    assert evidence.source_ref is not None and evidence.source_ref.startswith("tekstlag/s1/l")
    assert evidence.bbox is not None and 0.5 < evidence.bbox.x0 < evidence.bbox.x1 < 1


def test_a_value_that_is_not_a_date_is_kept_unread(tmp_path) -> None:
    sample = next(s for s in SAMPLES if s.name == "to-satser")
    extraction = read(from_text_layer(tmp_path, sample), 2)
    due = extraction.invoice.due_date
    assert due is not None and due.value is None
    assert due.provenance.evidence is not None and due.provenance.evidence.raw_text == "31.02.2026"
    assert extraction.unreadable == 1


def test_a_document_that_is_no_invoice_is_not_titled(tmp_path) -> None:
    extraction = read(from_text_layer(tmp_path, NOT_AN_INVOICE), 1)
    assert not extraction.titled
    assert (
        extraction.invoice.invoice_number is None and extraction.invoice.totals.gross_amount is None
    )
