"""The worker measures blank pages and separator sheets in PDF and TIFF (Phase 11a)."""

import hashlib
import io
import json

import pytest
from PIL import Image, ImageDraw

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.ports import WorkerTask
from invoiceflow.application.processing_model import PageRecord, ProcessingLimits
from invoiceflow.application.scan.model import PageKind, classify
from invoiceflow.bootstrap.synthetic_pdf import batch_pdf
from invoiceflow.processing.worker import analyse

KINDS = ("Faktura 1001 side 1", "blank", "separator", "Faktura 1002")
EXPECTED = [PageKind.CONTENT, PageKind.BLANK, PageKind.SEPARATOR, PageKind.CONTENT]


def measure(tmp_path, data: bytes, document_format: DocumentFormat, dpi: int) -> list[PageKind]:
    source = tmp_path / f"batch-{dpi}"
    source.write_bytes(data)
    output = tmp_path / f"out-{dpi}"
    output.mkdir()
    report = json.loads(
        analyse(
            WorkerTask(
                source,
                hashlib.sha256(data).hexdigest(),
                document_format,
                output,
                ProcessingLimits(dpi=dpi),
            )
        )
    )
    assert report["status"] == "ok", report
    return [
        classify(
            PageRecord(
                None,  # type: ignore[arg-type]
                None,  # type: ignore[arg-type]
                page["page_number"],
                page["width_px"],
                page["height_px"],
                0,
                page["text_chars"],
                page["dark_permille"],
                page["center_dark_permille"],
            )
        )
        for page in report["pages"]
    ]


@pytest.mark.parametrize("dpi", [72, 150, 300])
def test_pdf_batches_are_measured_at_every_resolution(tmp_path, dpi: int) -> None:
    assert measure(tmp_path, batch_pdf(KINDS), DocumentFormat.PDF, dpi) == EXPECTED


def scanned_page(kind: str) -> Image.Image:
    """An A4 page at 100 dpi without a text layer, like a scanner's TIFF."""
    image = Image.new("L", (827, 1169), 255)
    draw = ImageDraw.Draw(image)
    if kind == "separator":
        draw.rectangle((124, 292, 703, 877), fill=0)  # the sheet's box, slightly shifted
        draw.text((60, 60), "SKILLEARK", fill=0)
    elif kind == "content":
        for line in range(40):
            draw.text(
                (60, 60 + 25 * line), "Faktura 1001  Antall 3  Pris 1 250,00  MVA 25 %", fill=0
            )
    elif kind == "noise":
        for x in range(0, 827, 97):
            draw.point((x, 500), fill=0)
    return image


def test_scanned_tiff_pages_without_text_are_measured(tmp_path) -> None:
    pages = [scanned_page(kind) for kind in ("content", "noise", "separator", "content")]
    buffer = io.BytesIO()
    pages[0].save(buffer, format="TIFF", save_all=True, append_images=pages[1:])
    assert measure(tmp_path, buffer.getvalue(), DocumentFormat.TIFF, 150) == EXPECTED
