"""Reference data import, posting suggestion and the rules MVA-002, ACC-001-003 (Phase 08b)."""

import datetime as dt
from decimal import Decimal
from types import MappingProxyType
from uuid import UUID

import pytest
from plain_invoice import make, plain
from reference_data import DEFAULTS, REFERENCE, SUPPLIER_ID

from invoiceflow.application.reference import csv_import
from invoiceflow.application.reference.csv_import import (
    ReferenceImportError,
    parse_chart,
    parse_dimensions,
    parse_vat_codes,
)
from invoiceflow.application.reference.model import (
    EMPTY_REFERENCE,
    Dimension,
    ReferenceData,
    SupplierDefaults,
    VatDirection,
)
from invoiceflow.application.reference.posting import (
    PRODUCER,
    has_manual_posting,
    net_by_rate,
    suggest_accounting,
    with_suggestion,
)
from invoiceflow.application.validation.model import (
    AccountStatus,
    Severity,
    ValidationContext,
    ValidationSettings,
)
from invoiceflow.application.validation.rules import validate

pytestmark = pytest.mark.unit

CHART = "konto;navn;mva_kode;aktiv\n6300;Leie lokale;1;ja\n6900;Gammel;;nei\n"
VAT = (
    "kode;sats;retning;gyldig_fra;gyldig_til;saft_kode;navn\n"
    "1;25;inngående;2026-01-01;;1;Høy sats\n"
    "11;15;Inngående;01.01.2026;;11;Middels sats\n"
    "7;25;inngående;2020-01-01;31.12.2025;;\n"
    "7;11,11;inngående;2026-01-01;;;\n"
    "3;25;utgående;2026-01-01;;3;\n"
)
DIMENSIONS = "dimensjon;kode;navn;aktiv\navdeling;10;Narvik;\nprosjekt;P1;Prosjekt;nei\n"


def refused(parse, text: str | bytes) -> ReferenceImportError:
    data = text.encode("utf-8") if isinstance(text, str) else text
    with pytest.raises(ReferenceImportError) as caught:
        parse(data)
    return caught.value


# --- import ----------------------------------------------------------------------------


def test_a_chart_of_accounts_is_read() -> None:
    entries = parse_chart(("﻿" + CHART).encode("utf-8"))
    assert [(e.account, e.name, e.default_vat_code, e.is_active) for e in entries] == [
        ("6300", "Leie lokale", "1", True),
        ("6900", "Gammel", None, False),
    ]


def test_vat_codes_with_periods_norwegian_dates_and_decimal_commas() -> None:
    entries = parse_vat_codes(VAT.encode("utf-8"))
    assert [(e.code, e.rate, e.direction, e.valid_from, e.valid_to) for e in entries] == [
        ("1", Decimal("25"), VatDirection.INPUT, dt.date(2026, 1, 1), None),
        ("11", Decimal("15"), VatDirection.INPUT, dt.date(2026, 1, 1), None),
        ("7", Decimal("25"), VatDirection.INPUT, dt.date(2020, 1, 1), dt.date(2025, 12, 31)),
        ("7", Decimal("11.11"), VatDirection.INPUT, dt.date(2026, 1, 1), None),
        ("3", Decimal("25"), VatDirection.OUTPUT, dt.date(2026, 1, 1), None),
    ]
    assert entries[0].name == "Høy sats" and entries[0].saft_code == "1"


def test_dimensions_are_read() -> None:
    entries = parse_dimensions(DIMENSIONS.encode("utf-8"))
    assert [(e.dimension, e.code, e.is_active) for e in entries] == [
        (Dimension.DEPARTMENT, "10", True),
        (Dimension.PROJECT, "P1", False),
    ]


@pytest.mark.parametrize(
    ("parse", "text", "reason", "line", "column"),
    [
        (parse_chart, "", "empty", 0, ""),
        (parse_chart, "konto;navn\n", "empty", 0, ""),
        (parse_chart, "konto\n6300\n", "missing_column", 1, "navn"),
        (parse_chart, "konto;navn;farge\n6300;Leie;rød\n", "unknown_column", 1, ""),
        (parse_chart, "konto;navn;navn\n6300;a;b\n", "unknown_column", 1, ""),
        (parse_chart, "konto;navn\n6300;Leie;x\n", "column_count", 2, ""),
        (parse_chart, "konto;navn\n6300;\n", "missing_value", 2, "navn"),
        (parse_chart, "konto;navn\n63 00;Leie\n", "invalid_code", 2, "konto"),
        (parse_chart, "konto;navn\n6300;=HYPERLINK()\n", "formula", 2, "navn"),
        (parse_chart, "konto;navn\n6300;@SUM\n", "formula", 2, "navn"),
        (parse_chart, "konto;navn\n6300;Leie‮\n", "control_character", 2, "navn"),
        (parse_chart, "konto;navn\n6300;" + "x" * 301 + "\n", "too_long", 2, "navn"),
        (parse_chart, "konto;navn;aktiv\n6300;Leie;kanskje\n", "invalid_choice", 2, "aktiv"),
        (parse_chart, "konto;navn\n6300;Leie\n\n6300;Annen\n", "duplicate", 4, "konto"),
        (parse_chart, 'konto;navn\n6300;"Leie\n', "malformed", 2, ""),
        (parse_chart, b"konto;navn\n6300;\xff\n", "encoding", 0, ""),
        (parse_chart, "konto;navn\n6300;a\x00\n", "control_character", 0, ""),
        (
            parse_vat_codes,
            "kode;sats;retning;gyldig_fra\n1;25;inn;2026-01-01\n",
            "invalid_choice",
            2,
            "retning",
        ),
        (
            parse_vat_codes,
            "kode;sats;retning;gyldig_fra\n1;101;inngående;2026-01-01\n",
            "invalid_rate",
            2,
            "sats",
        ),
        (
            parse_vat_codes,
            "kode;sats;retning;gyldig_fra\n1;25 %;inngående;2026-01-01\n",
            "invalid_rate",
            2,
            "sats",
        ),
        (
            parse_vat_codes,
            "kode;sats;retning;gyldig_fra\n1;25;inngående;2026-13-01\n",
            "invalid_date",
            2,
            "gyldig_fra",
        ),
        (
            parse_vat_codes,
            "kode;sats;retning;gyldig_fra\n1;25;inngående;1.1.2026\n",
            "invalid_date",
            2,
            "gyldig_fra",
        ),
        (
            parse_vat_codes,
            "kode;sats;retning;gyldig_fra;gyldig_til\n1;25;inngående;2026-02-01;2026-01-01\n",
            "invalid_period",
            2,
            "gyldig_til",
        ),
        (
            parse_vat_codes,
            "kode;sats;retning;gyldig_fra\n1;25;inngående;2026-01-01\n1;15;inngående;2027-01-01\n",
            "overlapping_period",
            3,
            "gyldig_fra",
        ),
        (parse_dimensions, "dimensjon;kode;navn\nfarge;10;x\n", "invalid_choice", 2, "dimensjon"),
        (
            parse_dimensions,
            "dimensjon;kode;navn\navdeling;10;a\navdeling;10;b\n",
            "duplicate",
            3,
            "kode",
        ),
    ],
)
def test_every_error_refuses_the_whole_file(parse, text, reason, line, column) -> None:
    error = refused(parse, text)
    assert (error.reason, error.line, error.column) == (reason, line, column)
    assert error.message_key == f"reference.error.{reason}"
    assert set(error.params) == {"line", "column"}  # never the cell's content


def test_size_and_row_limits(monkeypatch) -> None:
    monkeypatch.setattr(csv_import, "MAX_REFERENCE_FILE_BYTES", 10)
    assert refused(parse_chart, CHART).reason == "too_large"
    monkeypatch.undo()
    monkeypatch.setattr(csv_import, "MAX_REFERENCE_ROWS", 1)
    assert refused(parse_chart, CHART).reason == "too_many_rows"


# --- posting suggestion ----------------------------------------------------------------


def account_lines(invoice) -> list[tuple]:
    return [
        (
            line.line_number,
            None if line.account is None else line.account.value,
            None if line.vat_code is None else line.vat_code.value,
            line.net_amount.value,
            line.source_line_numbers,
        )
        for line in invoice.accounting_lines
    ]


def test_one_posting_line_per_vat_rate() -> None:
    data = plain(
        lines=[
            {"line_number": 1, "net_amount": "100.00", "vat_rate": "25"},
            {"line_number": 2, "net_amount": "50.00", "vat_rate": "15"},
            {"line_number": 3, "net_amount": "20.00", "vat_rate": "25"},
        ]
    )
    invoice = with_suggestion(make(data), DEFAULTS, REFERENCE)
    assert account_lines(invoice) == [
        (1, "6300", "11", Decimal("50.00"), (2,)),
        (2, "6300", "1", Decimal("120.00"), (1, 3)),
    ]
    provenance = invoice.accounting_lines[0].account.provenance
    assert (provenance.source.value, provenance.producer) == ("calculated", PRODUCER)


def test_posting_from_the_vat_summary_or_the_total() -> None:
    from_summary = make(plain(lines=[]))
    assert account_lines(with_suggestion(from_summary, DEFAULTS, REFERENCE)) == [
        (1, "6300", "1", Decimal("1500.00"), ())
    ]
    from_total = make(plain(lines=[], vat_breakdown=[]))
    assert account_lines(with_suggestion(from_total, DEFAULTS, REFERENCE)) == [
        (1, "6300", None, Decimal("1500.00"), ())
    ]
    nothing = make(plain(lines=[], vat_breakdown=[], totals={"vat_amount": "1.00"}))
    assert net_by_rate(nothing) == []


def test_the_vat_code_is_left_empty_when_ambiguous_or_unknown() -> None:
    no_defaults = with_suggestion(make(), None, REFERENCE)
    # Only one valid input code has 25 % in 2026: code 1 (code 7 ended in 2025).
    assert account_lines(no_defaults) == [(1, None, "1", Decimal("1500.00"), (1, 2))]
    ambiguous = ReferenceData(vat_codes=(*REFERENCE.vat_codes, *REFERENCE.vat_codes[:1]))
    twice = ReferenceData(
        vat_codes=(
            REFERENCE.vat_codes[0],
            REFERENCE.vat_codes[0].__class__(
                "1B", Decimal("25"), VatDirection.INPUT, dt.date(2026, 1, 1)
            ),
        )
    )
    assert account_lines(with_suggestion(make(), None, twice))[0][2] is None
    assert account_lines(with_suggestion(make(), None, ambiguous))[0][2] == "1"
    assert account_lines(with_suggestion(make(), DEFAULTS, EMPTY_REFERENCE))[0][2] is None
    undated = make(plain(invoice_date=None, due_date=None))
    assert account_lines(with_suggestion(undated, DEFAULTS, REFERENCE))[0][2] is None
    # The supplier's standard code wins only when its rate fits the line.
    eleven = SupplierDefaults(SUPPLIER_ID, account="6300", vat_code="11")
    assert account_lines(with_suggestion(make(), eleven, REFERENCE))[0][2] == "1"


def test_dimensions_come_from_the_supplier_standard() -> None:
    defaults = SupplierDefaults(
        SUPPLIER_ID,
        account="6300",
        vat_code="1",
        dimensions=MappingProxyType({Dimension.DEPARTMENT: "10", Dimension.PROJECT: "P2"}),
    )
    (line,) = suggest_accounting(make(), defaults, REFERENCE)
    assert (line.department.value, line.project.value, line.cost_center) == ("10", "P2", None)


def test_a_manual_posting_is_never_replaced() -> None:
    suggested = with_suggestion(make(), DEFAULTS, REFERENCE)
    data = suggested.model_dump(mode="json")
    data["accounting_lines"][0]["account"] = {
        "value": "6800",
        "provenance": {
            "source": "manual",
            "producer": "bruker/lokal",
            "recorded_at": "2026-10-20T10:00:00Z",
        },
    }
    manual = type(suggested).model_validate(data)
    assert has_manual_posting(manual) and not has_manual_posting(suggested)
    assert with_suggestion(manual, DEFAULTS, REFERENCE) is manual


# --- rules -----------------------------------------------------------------------------


def run(invoice, reference=REFERENCE) -> list[tuple[str, Severity, str, str | None]]:
    context = ValidationContext(
        invoice_id=UUID(int=1),
        invoice=invoice,
        today=dt.date(2026, 10, 20),
        entity_org_number=None,
        settings=ValidationSettings(),
        account_statuses={"12345678903": AccountStatus.VERIFIED},
        reference=reference,
    )
    return [
        (f.rule_id.value, f.severity, f.message_key.removeprefix("validation."), f.field_path)
        for f in validate(context)
        if f.rule_id.value.startswith(("MVA-002", "ACC-"))
    ]


def test_a_complete_posting_has_no_findings() -> None:
    assert run(with_suggestion(make(), DEFAULTS, REFERENCE)) == []


def test_mva_002_needs_a_valid_input_code_for_each_rate() -> None:
    data = plain(
        lines=[
            {"line_number": 1, "net_amount": "1000.00", "vat_rate": "25"},
            {"line_number": 2, "net_amount": "500.00", "vat_rate": "6"},
        ]
    )
    invoice = with_suggestion(make(data), DEFAULTS, REFERENCE)
    assert ("MVA-002", Severity.ERROR, "mva_002", "vat_breakdown") in run(invoice)
    assert ("MVA-002", Severity.INFO, "mva_002_no_codes", None) in run(make(), EMPTY_REFERENCE)
    assert "MVA-002" not in {
        r[0]
        for r in run(
            with_suggestion(make(plain(invoice_date=None, due_date=None)), DEFAULTS, REFERENCE)
        )
    }


def test_acc_001_posting_must_exist_and_add_up() -> None:
    assert run(make()) == [("ACC-001", Severity.ERROR, "acc_001_none", "accounting_lines")]
    suggested = with_suggestion(make(), DEFAULTS, REFERENCE)
    data = suggested.model_dump(mode="json")
    data["accounting_lines"][0]["net_amount"]["value"] = "1499.00"
    assert run(type(suggested).model_validate(data)) == [
        ("ACC-001", Severity.ERROR, "acc_001", "accounting_lines")
    ]
    del data["accounting_lines"][0]["net_amount"]
    assert run(type(suggested).model_validate(data)) == [
        ("ACC-001", Severity.ERROR, "acc_001_incomplete", "accounting_lines")
    ]


def posted(**line: object):
    suggested = with_suggestion(make(), DEFAULTS, REFERENCE)
    data = suggested.model_dump(mode="json")
    calculated = {"source": "calculated", "producer": "test"}
    for name, value in line.items():
        if value is None:
            data["accounting_lines"][0].pop(name, None)
        else:
            data["accounting_lines"][0][name] = {"value": value, "provenance": calculated}
    return type(suggested).model_validate(data)


@pytest.mark.parametrize(
    ("line", "expected"),
    [
        ({"account": None}, ("ACC-002", "acc_002_no_account", "accounting_lines.1.account")),
        ({"account": "9999"}, ("ACC-002", "acc_002_unknown", "accounting_lines.1.account")),
        ({"account": "6900"}, ("ACC-002", "acc_002_inactive", "accounting_lines.1.account")),
        ({"project": "P1"}, ("ACC-002", "acc_002_dimension", "accounting_lines.1.project")),
        ({"cost_center": "X"}, ("ACC-002", "acc_002_dimension", "accounting_lines.1.cost_center")),
        ({"vat_code": None}, ("ACC-003", "acc_003_none", "accounting_lines.1.vat_code")),
        ({"vat_code": "3"}, ("ACC-003", "acc_003_output", "accounting_lines.1.vat_code")),
        ({"vat_code": "7"}, ("ACC-003", "acc_003_unknown", "accounting_lines.1.vat_code")),
        ({"vat_code": "99"}, ("ACC-003", "acc_003_unknown", "accounting_lines.1.vat_code")),
        ({"vat_code": "11"}, ("ACC-003", "acc_003_rate", "accounting_lines.1.vat_code")),
    ],
)
def test_acc_002_and_acc_003_check_the_posting_line(line, expected) -> None:
    rule, key, path = expected
    assert (rule, Severity.ERROR, key, path) in run(posted(**line))


def test_a_valid_department_passes_and_missing_data_is_reported_once() -> None:
    assert run(posted(department="10")) == []
    without = ReferenceData(vat_codes=REFERENCE.vat_codes)
    findings = run(posted(department="10", project="P9"), without)
    assert findings == [
        ("ACC-002", Severity.INFO, "acc_002_no_chart", None),
        ("ACC-002", Severity.INFO, "acc_002_no_dimensions", None),
    ]
    assert (
        run(posted(vat_code="99"), ReferenceData(accounts=REFERENCE.accounts))[-1][0] == "MVA-002"
    )


def test_an_optional_name_is_limited_too() -> None:
    text = "kode;sats;retning;gyldig_fra;navn\n1;25;inngående;2026-01-01;" + "x" * 301 + "\n"
    error = refused(parse_vat_codes, text)
    assert (error.reason, error.line, error.column) == ("too_long", 2, "navn")
