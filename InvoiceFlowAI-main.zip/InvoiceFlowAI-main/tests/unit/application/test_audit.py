"""Audit payload policy and chain verification without a database."""

import dataclasses
import datetime as dt
from uuid import UUID, uuid4

import pytest

from invoiceflow.application.audit import (
    GENESIS_HASH,
    AuditDraft,
    AuditEventType,
    AuditPayloadError,
    AuditRecord,
    chain,
    compute_event_hash,
    hash_payload,
    verify_chain,
)

pytestmark = pytest.mark.unit

ENTITY = UUID("11111111-1111-4111-8111-111111111111")
INVOICE = "22222222-2222-4222-8222-222222222222"
SHA = "a" * 64
NOW = dt.datetime(2026, 10, 20, 10, 0, tzinfo=dt.UTC)


def invoice_created(**overrides: object) -> AuditDraft:
    values: dict[str, object] = {
        "event_type": AuditEventType.INVOICE_CREATED,
        "actor": "system",
        "entity_id": ENTITY,
        "subject_id": INVOICE,
        "details": {"revision": 1, "content_sha256": SHA, "schema_version": "1.0"},
    }
    values.update(overrides)
    return AuditDraft(**values)  # type: ignore[arg-type]


def build_chain(length: int) -> list[AuditRecord]:
    records: list[AuditRecord] = []
    prev = GENESIS_HASH
    for sequence in range(1, length + 1):
        record = chain(
            invoice_created(details={"revision": sequence, "content_sha256": SHA}),
            sequence=sequence,
            prev_hash=prev,
            event_id=uuid4(),
            occurred_at=NOW + dt.timedelta(seconds=sequence),
        )
        records.append(record)
        prev = record.event_hash
    return records


@pytest.mark.security
@pytest.mark.parametrize(
    "details",
    [
        {"gross_amount": "5671.25"},  # amounts are not an allowed key
        {"revision": 1, "note": "Kopipapir til Nordlys AS"},  # free text
        {"schema_version": "1.0 Fjordkontor Rekvisita"},  # text smuggled into a value
        {"content_sha256": "not-a-hash"},
        {"revision": 1.0},  # float
        {"revision": True},  # bool is not an int
        {"revision": 0},
        {"revision": 10**12},
        {"content_sha256": "A" * 64},  # uppercase hex is not canonical
    ],
    ids=["amount", "free_text", "smuggled", "hash", "float", "bool", "zero", "huge", "upper"],
)
def test_details_outside_the_allowlist_are_rejected(details: dict[str, object]) -> None:
    with pytest.raises(AuditPayloadError):
        invoice_created(details=details)


@pytest.mark.security
def test_exception_messages_cannot_be_stored() -> None:
    with pytest.raises(AuditPayloadError):
        invoice_created(details={"error": "ValueError: synthetic invoice contents"})


@pytest.mark.parametrize(
    "overrides",
    [
        {"event_type": "invoice.deleted"},
        {"actor": "Robert Cygan"},
        {"actor": "system/" + "x" * 65},
        {"entity_id": None},
        {"entity_id": str(ENTITY)},
        {"subject_id": "not-a-uuid"},
        {"details": [("revision", 1)]},
    ],
    ids=["type", "actor_space", "actor_long", "entity_missing", "entity_str", "subject", "list"],
)
def test_structure_violations_are_rejected(overrides: dict[str, object]) -> None:
    with pytest.raises(AuditPayloadError):
        invoice_created(**overrides)


def test_global_events_must_not_name_an_entity() -> None:
    with pytest.raises(AuditPayloadError):
        AuditDraft(
            event_type=AuditEventType.DATABASE_CREATED,
            actor="system",
            entity_id=ENTITY,
            subject_id="0001_initial",
            details={"schema_revision": "0001_initial"},
        )


def test_details_are_frozen_after_validation() -> None:
    details = {"revision": 1}
    draft = invoice_created(details=details)
    details["note"] = "added later"
    assert dict(draft.details) == {"revision": 1}
    with pytest.raises(TypeError):
        draft.details["note"] = "x"  # type: ignore[index]


def test_hash_covers_every_field() -> None:
    record = build_chain(1)[0]
    base = {
        "sequence": record.sequence,
        "event_id": record.event_id,
        "occurred_at": record.occurred_at,
        "actor": record.actor,
        "event_type": record.event_type,
        "entity_id": record.entity_id,
        "subject_type": record.subject_type,
        "subject_id": record.subject_id,
        "details": record.details,
        "prev_hash": record.prev_hash,
    }
    assert compute_event_hash(**base) == record.event_hash
    assert set(hash_payload(**base)) == {*base, "hash_version"}
    for key, value in [
        ("sequence", 2),
        ("event_id", uuid4()),
        ("occurred_at", NOW + dt.timedelta(microseconds=1)),
        ("actor", "system/other"),
        ("entity_id", None),
        ("subject_id", "33333333-3333-4333-8333-333333333333"),
        ("details", {"revision": 2}),
        ("prev_hash", "b" * 64),
    ]:
        assert compute_event_hash(**{**base, key: value}) != record.event_hash, key


def test_hash_is_independent_of_timezone_representation() -> None:
    record = build_chain(1)[0]
    oslo = record.occurred_at.astimezone(dt.timezone(dt.timedelta(hours=2)))
    fields = {f.name: getattr(record, f.name) for f in dataclasses.fields(record)}
    fields.pop("event_hash")
    fields.pop("hash_version")
    fields["occurred_at"] = oslo
    assert compute_event_hash(**fields) == record.event_hash


def test_valid_chain_verifies() -> None:
    result = verify_chain(build_chain(5))
    assert result.valid and result.events_checked == 5


def test_empty_chain_is_valid() -> None:
    assert verify_chain([]).valid


@pytest.mark.security
@pytest.mark.parametrize(
    ("mutate", "reason", "position"),
    [
        (lambda r: r.__setitem__(2, dataclasses.replace(r[2], actor="system/x")), "hash", 3),
        (
            lambda r: r.__setitem__(
                2, dataclasses.replace(r[2], details={"revision": 99, "content_sha256": SHA})
            ),
            "hash",
            3,
        ),
        (lambda r: r.pop(2), "sequence", 4),
        (lambda r: r.__setitem__(1, r[1]) or r.reverse(), "sequence", 5),
        (lambda r: r.__setitem__(0, dataclasses.replace(r[0], prev_hash="c" * 64)), "link", 1),
        (lambda r: r.__setitem__(1, dataclasses.replace(r[1], hash_version=2)), "hash_version", 2),
        (
            lambda r: r.__setitem__(1, dataclasses.replace(r[1], details={"note": "free text"})),
            "payload",
            2,
        ),
        (
            lambda r: r.__setitem__(1, dataclasses.replace(r[1], subject_type="entity")),
            "payload",
            2,
        ),
    ],
    ids=["field", "details", "removed", "reordered", "genesis", "version", "policy", "subject"],
)
def test_tampering_is_detected(mutate, reason: str, position: int) -> None:
    records = build_chain(5)
    mutate(records)
    result = verify_chain(records)
    assert not result.valid
    assert result.reason == reason
    assert result.first_invalid_sequence == position


def test_relinked_chain_with_recomputed_hashes_is_not_detectable() -> None:
    """Documented limit: whoever can recompute every hash can rewrite history."""
    records = build_chain(3)
    forged = []
    prev = GENESIS_HASH
    for record in records:
        draft = invoice_created(details={"revision": 7, "content_sha256": SHA})
        new = chain(
            draft,
            sequence=record.sequence,
            prev_hash=prev,
            event_id=record.event_id,
            occurred_at=record.occurred_at,
        )
        forged.append(new)
        prev = new.event_hash
    assert verify_chain(forged).valid


def test_truncated_tail_is_not_detectable() -> None:
    """Documented limit: removing the newest events leaves a valid shorter chain."""
    assert verify_chain(build_chain(5)[:3]).valid


@pytest.mark.parametrize("value", [None, str(ENTITY), ENTITY.int])
def test_entity_scope_requires_a_uuid(value: object) -> None:
    from invoiceflow.application.scope import EntityScope

    with pytest.raises(TypeError):
        EntityScope(value)  # type: ignore[arg-type]
