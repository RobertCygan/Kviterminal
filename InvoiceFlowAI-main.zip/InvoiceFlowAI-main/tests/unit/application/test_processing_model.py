"""The worker report contract and the processing limits (pure, no I/O)."""

import json
from uuid import UUID

import pytest
from pydantic import ValidationError

from invoiceflow.application.audit import AuditDraft, AuditEventType, AuditPayloadError
from invoiceflow.application.processing import max_text_bytes, png_size
from invoiceflow.application.processing_model import (
    JobRecord,
    JobStatus,
    ProcessingLimits,
    ProcessingStep,
    TextLayer,
    WorkerResult,
    idempotency_key,
)
from invoiceflow.processing.parser import normalise_box, text_and_boxes

pytestmark = pytest.mark.unit

DOCUMENT = UUID("00000000-0000-4000-8000-000000000001")
PAGE = {
    "page_number": 1,
    "width_px": 10,
    "height_px": 20,
    "rotation_degrees": 0,
    "text_chars": 2,
    "render_file": "page-0001.png",
    "text_file": "text-0001.json",
    "dark_permille": 12,
    "center_dark_permille": 30,
}
OK = {
    "result_version": 1,
    "status": "ok",
    "engine": "pypdfium2",
    "engine_version": "5.13.0",
    "sha256": "a" * 64,
    "page_count": 1,
    "active_content": False,
    "pages": [PAGE],
}


def parse(data: dict) -> WorkerResult:
    return WorkerResult.model_validate_json(json.dumps(data))


def test_a_valid_report_is_accepted() -> None:
    assert parse(OK).pages[0].text_file == "text-0001.json"
    error = {**OK, "status": "error", "error_code": "encrypted", "pages": [], "page_count": 0}
    assert parse(error).error_code == "encrypted"


@pytest.mark.parametrize(
    "change",
    [
        {"extra": 1},
        {"status": "error"},
        {"error_code": "corrupt"},
        {"page_count": 2},
        {"page_count": 0},
        {"engine": "Fitz!"},
        {"engine_version": "1.0 && rm"},
        {"sha256": "A" * 64},
        {"active_content": "yes"},
        {"result_version": 2},
        {"error_code": "free text from a library"},
        {"pages": [{**PAGE, "render_file": "../page-0001.png"}]},
        {"pages": [{**PAGE, "text_file": "text-0002.json"}]},
        {"pages": [{**PAGE, "text_chars": 0}]},
        {"pages": [{**PAGE, "page_number": 2}]},
        {"pages": [{**PAGE, "rotation_degrees": 45}]},
        {"pages": [{**PAGE, "width_px": 0}]},
        {"pages": [{**PAGE, "width_px": 1.5}]},
        {"pages": [{**PAGE, "path": "C:/Windows"}]},
    ],
)
def test_inconsistent_or_extended_reports_are_refused(change) -> None:
    with pytest.raises(ValidationError):
        parse(OK | change)


def test_text_layer_needs_one_ordered_box_per_character() -> None:
    layer = {"result_version": 1, "page_number": 1, "text": "ab", "boxes": [[0, 0, 1, 1]] * 2}
    assert TextLayer.model_validate_json(json.dumps(layer)).text == "ab"
    for boxes in ([[0, 0, 1, 1]], [[0.5, 0, 0.4, 1]] * 2, [[0, 0, 1, 1.5]] * 2):
        with pytest.raises(ValidationError):
            TextLayer.model_validate_json(json.dumps(layer | {"boxes": boxes}))


def test_limits_have_safe_bounds_and_a_stable_settings_hash() -> None:
    assert ProcessingLimits().settings_hash() == ProcessingLimits(timeout_seconds=5).settings_hash()
    assert ProcessingLimits().settings_hash() != ProcessingLimits(dpi=200).settings_hash()
    for bad in (
        {"dpi": 601},
        {"dpi": 10},
        {"max_pages": 0},
        {"memory_bytes": 1},
        {"timeout_seconds": 0},
    ):
        with pytest.raises(ValueError):
            ProcessingLimits(**bad)
    assert max_text_bytes(ProcessingLimits(max_chars_per_page=10)) > 10 * 60


def test_idempotency_key_covers_document_engine_and_settings() -> None:
    base = (DOCUMENT, ProcessingStep.PAGE_ANALYSIS, "pypdfium2", "5.13.0", "a" * 64)
    key = idempotency_key(*base)
    assert key == idempotency_key(*base)
    assert key != idempotency_key(*base[:3], "5.14.0", base[4])
    assert key != idempotency_key(UUID(int=2), *base[1:])


def test_job_producer() -> None:
    job = JobRecord(
        DOCUMENT,
        DOCUMENT,
        DOCUMENT,
        ProcessingStep.PAGE_ANALYSIS,
        "a" * 64,
        1,
        JobStatus.RUNNING,
        "pillow",
        "13.0.0",
        "b" * 64,
        None,  # type: ignore[arg-type]
    )
    assert job.producer == "pillow/13.0.0"


def test_png_size_reads_only_the_header() -> None:
    header = (
        b"\x89PNG\r\n\x1a\n"
        + b"\x00\x00\x00\x0dIHDR"
        + (7).to_bytes(4, "big")
        + (9).to_bytes(4, "big")
    )
    assert png_size(header) == (7, 9)
    assert png_size(b"GIF89a" + b"\x00" * 30) is None
    assert png_size(header[:20]) is None


def test_text_units_become_valid_characters() -> None:
    box = (0.0, 0.0, 1.0, 1.0)
    text, boxes = text_and_boxes(
        [(0x46, box), (0xD83D, box), (0xDE00, box), (0xDC00, box), (0x07, box), (0x0A, box)]
    )
    assert text == "F\U0001f600\ufffd\ufffd\n" and len(boxes) == len(text)


def test_boxes_are_clamped_and_ordered() -> None:
    assert normalise_box(-5, 30, 20, 10, 10, 20) == (0.0, 0.5, 1.0, 1.0)


@pytest.mark.parametrize(
    "details",
    [
        {"job_id": "not-a-uuid", "attempt": 1, "step": "page_analysis"},
        {"job_id": str(DOCUMENT), "attempt": 0, "step": "page_analysis"},
        {"job_id": str(DOCUMENT), "attempt": 1, "step": "translation"},
        {"job_id": str(DOCUMENT), "attempt": 1, "step": "page_analysis", "text": "Faktura"},
    ],
)
def test_processing_audit_details_are_allowlisted(details) -> None:
    with pytest.raises(AuditPayloadError):
        AuditDraft(AuditEventType.PROCESSING_STARTED, "system", DOCUMENT, str(DOCUMENT), details)


def test_finished_audit_details_accept_only_codes() -> None:
    good = {
        "job_id": str(DOCUMENT),
        "step": "page_analysis",
        "job_status": "failed",
        "error_code": "encrypted",
    }
    AuditDraft(AuditEventType.PROCESSING_FINISHED, "system", DOCUMENT, str(DOCUMENT), good)
    with pytest.raises(AuditPayloadError):
        AuditDraft(
            AuditEventType.PROCESSING_FINISHED,
            "system",
            DOCUMENT,
            str(DOCUMENT),
            good | {"error_code": "Incorrect password error"},
        )
