"""Words and lines from a text layer or OCR (Phase 06). No I/O."""

import pytest

from invoiceflow.application.extraction.layout import (
    Line,
    TextOrigin,
    Word,
    lines_from_words,
    page_layout,
    words_from_text_layer,
)
from invoiceflow.application.processing_model import OcrLayer, TextLayer

pytestmark = pytest.mark.unit


def text_layer(chars: list[tuple[str, tuple[float, float, float, float]]]) -> TextLayer:
    return TextLayer(
        result_version=1,
        page_number=1,
        text="".join(char for char, _ in chars),
        boxes=tuple(box for _, box in chars),
    )


def row(text: str, x: float, y: float, width: float = 0.01) -> list:
    return [
        (char, (x + i * width, y, x + (i + 1) * width, y + 0.012)) for i, char in enumerate(text)
    ]


def test_words_split_on_spaces_and_wide_gaps() -> None:
    layer = text_layer(row("Fakturanr:", 0.1, 0.2) + row("2026", 0.5, 0.2) + row(" 1", 0.54, 0.2))
    words = words_from_text_layer(layer)
    assert [word.text for word in words] == ["Fakturanr:", "2026", "1"]
    assert words[0].box == pytest.approx((0.1, 0.2, 0.2, 0.212))


def test_lines_follow_the_geometry_not_the_source_order() -> None:
    words = [
        Word("15 793,13", (0.8, 0.5, 0.9, 0.512)),
        Word("betale", (0.15, 0.501, 0.22, 0.513)),
        Word("Sum", (0.1, 0.4, 0.13, 0.412)),
        Word("Å", (0.1, 0.5, 0.12, 0.512)),
    ]
    lines = lines_from_words(3, words)
    assert [line.text for line in lines] == ["Sum", "Å betale 15 793,13"]
    assert (lines[1].page_number, lines[1].index) == (3, 1)


def test_spans_map_back_to_words() -> None:
    line = Line(
        1, 0, (Word("KID:", (0, 0, 1, 1)), Word("123", (0, 0, 1, 1)), Word("45", (0, 0, 1, 1)))
    )
    assert line.text == "KID: 123 45"
    assert line.starts() == [0, 5, 9]
    assert [word.text for word in line.words_in(5, 11)] == ["123", "45"]
    assert line.words_in(3, 4) == (line.words[0],)


def test_ocr_words_keep_their_confidence() -> None:
    layer = OcrLayer.model_validate(
        {
            "result_version": 1,
            "page_number": 2,
            "language": "nor",
            "words": [
                {"text": "Faktura", "box": [0.1, 0.1, 0.2, 0.12], "confidence": 91, "line": 0},
                {"text": "17", "box": [0.25, 0.1, 0.28, 0.12], "confidence": 40, "line": 0},
            ],
        }
    )
    layout = page_layout(2, layer)
    assert layout.origin is TextOrigin.OCR
    [line] = layout.lines
    assert [(w.text, w.confidence) for w in line.words] == [("Faktura", 91), ("17", 40)]
    empty = page_layout(1, text_layer([]))
    assert empty.origin is TextOrigin.TEXT_LAYER and empty.lines == ()
