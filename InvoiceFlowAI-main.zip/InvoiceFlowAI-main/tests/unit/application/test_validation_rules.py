"""Every rule of Phase 08a: positive, negative and boundary cases (DATA_MODEL §7)."""

import datetime as dt
from decimal import Decimal
from typing import Any
from uuid import UUID, uuid4

import pytest
from plain_invoice import make, plain
from reference_data import DEFAULTS, REFERENCE

from invoiceflow.application.reference.model import ReferenceData
from invoiceflow.application.reference.posting import with_suggestion
from invoiceflow.application.validation.model import (
    AccountStatus,
    InvoiceHeader,
    RuleId,
    Severity,
    ValidationContext,
    ValidationFinding,
    ValidationSettings,
    ValidationSummary,
)
from invoiceflow.application.validation.rules import (
    normalized_invoice_number,
    payment_accounts,
    validate,
)
from invoiceflow.domain.invoice import CanonicalInvoice, InvoiceType

pytestmark = pytest.mark.unit

INVOICE_ID = UUID("00000000-0000-4000-8000-0000000000aa")
TODAY = dt.date(2026, 10, 20)
VERIFIED = {"12345678903": AccountStatus.VERIFIED}
PREFIX = "validation."  # message keys are built, not spelled out (gitleaks)


def context(
    invoice: CanonicalInvoice | None = None,
    *,
    entity_org: str | None = "314159268",
    accounts: dict[str, AccountStatus | None] | None = None,
    others: tuple[InvoiceHeader, ...] = (),
    settings: ValidationSettings | None = None,
    today: dt.date = TODAY,
    reference: ReferenceData = REFERENCE,
    posting: bool = True,
) -> ValidationContext:
    """A context with reference data; the invoice gets the suggested posting by default."""
    invoice = invoice or make()
    if posting and not invoice.accounting_lines:
        invoice = with_suggestion(invoice, DEFAULTS, reference)
    return ValidationContext(
        invoice_id=INVOICE_ID,
        invoice=invoice,
        today=today,
        entity_org_number=entity_org,
        settings=settings or ValidationSettings(),
        account_statuses=VERIFIED if accounts is None else accounts,
        other_invoices=others,
        reference=reference,
    )


def found(ctx: ValidationContext) -> list[tuple[str, str, str | None]]:
    return [
        (finding.rule_id.value, finding.message_key.removeprefix("validation."), finding.field_path)
        for finding in validate(ctx)
    ]


def rules(ctx: ValidationContext) -> set[str]:
    return {finding.rule_id.value for finding in validate(ctx)}


def header(**changes: Any) -> InvoiceHeader:
    values: dict[str, Any] = {
        "invoice_id": uuid4(),
        "invoice_type": InvoiceType.INVOICE,
        "invoice_number": "F-1001",
        "supplier_org_number": "123456785",
        "gross_amount": Decimal("1875.00"),
        "invoice_date": dt.date(2026, 10, 1),
    }
    values.update(changes)
    return InvoiceHeader(**values)


def test_a_consistent_invoice_has_no_findings() -> None:
    assert validate(context()) == []


# --- REQ -------------------------------------------------------------------------------


def test_req_001_reports_each_missing_field() -> None:
    data = plain(invoice_number=None, currency=None, totals={"net_amount": "1500.00"})
    assert [f for f in found(context(make(data))) if f[0] == "REQ-001"] == [
        ("REQ-001", "req_001", "currency"),
        ("REQ-001", "req_001", "invoice_number"),
        ("REQ-001", "req_001", "totals.gross_amount"),
        ("REQ-001", "req_001", "totals.vat_amount"),
    ]


def test_req_001_supplier_name() -> None:
    data = plain()
    del data["supplier"]["name"]
    assert ("REQ-001", "req_001", "supplier.name") in found(context(make(data)))


@pytest.mark.parametrize(
    ("supplier", "expected"),
    [
        ({"name": "AS", "address": {"country_code": "NO"}}, True),
        ({"name": "AS"}, True),  # unknown country and no foreign VAT id: Norwegian
        ({"name": "GmbH", "address": {"country_code": "DE"}}, False),
        ({"name": "GmbH", "foreign_vat_id": "DE123456789"}, False),
        ({"name": "AS", "org_number": "123456785"}, False),
    ],
)
def test_req_002_norwegian_supplier_needs_an_org_number(
    supplier: dict[str, Any], expected: bool
) -> None:
    ctx = context(make(plain(supplier=supplier)))
    assert ("REQ-002" in rules(ctx)) is expected


# --- ENT -------------------------------------------------------------------------------


def test_ent_001_flags_another_recipient_as_a_warning() -> None:
    findings = validate(context(entity_org="987654325"))
    assert [(f.rule_id, f.severity) for f in findings] == [(RuleId.ENT_001, Severity.WARNING)]


@pytest.mark.parametrize("entity_org", [None, "314159268"])
def test_ent_001_needs_both_numbers_and_a_difference(entity_org: str | None) -> None:
    assert "ENT-001" not in rules(context(entity_org=entity_org))
    no_customer = make(plain(customer=None))
    assert "ENT-001" not in rules(context(no_customer, entity_org="987654325"))


# --- SUM -------------------------------------------------------------------------------


def test_sum_001_lines_against_net() -> None:
    data = plain(
        totals={"net_amount": "1500.01", "vat_amount": "375.00", "gross_amount": "1875.01"}
    )
    findings = [f for f in validate(context(make(data))) if f.rule_id is RuleId.SUM_001]
    assert [(f.field_path, dict(f.params)) for f in findings] == [
        ("totals.net_amount", {"expected": "1500.00", "actual": "1500.01"})
    ]


def test_sum_001_needs_every_line_amount() -> None:
    data = plain(
        lines=[{"line_number": 1, "net_amount": "1000.00"}, {"line_number": 2}],
        vat_breakdown=[],
    )
    assert "SUM-001" not in rules(context(make(data)))
    assert "SUM-001" not in rules(context(make(plain(lines=[], vat_breakdown=[]))))


def test_sum_001_counts_negative_discount_lines() -> None:
    data = plain(
        lines=[
            {"line_number": 1, "net_amount": "2000.00", "vat_rate": "25"},
            {"line_number": 2, "net_amount": "-500.00", "vat_rate": "25"},
        ]
    )
    assert validate(context(make(data))) == []


def test_sum_002_net_plus_vat_plus_rounding() -> None:
    off = plain(totals={"net_amount": "1500.00", "vat_amount": "375.00", "gross_amount": "1875.01"})
    assert ("SUM-002", "sum_002", "totals.gross_amount") in found(context(make(off)))
    rounded = plain(
        totals={
            "net_amount": "1500.00",
            "vat_amount": "375.00",
            "rounding_amount": "0.01",
            "gross_amount": "1875.01",
        }
    )
    assert "SUM-002" not in rules(context(make(rounded)))
    partial = plain(totals={"net_amount": "1500.00", "vat_amount": "375.00"})
    assert "SUM-002" not in rules(context(make(partial)))


# --- MVA -------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("vat", "flagged"),
    [("375.00", False), ("375.01", False), ("374.99", False), ("375.02", True), ("374.98", True)],
)
def test_mva_001_tolerance_is_one_ore_per_rate(vat: str, flagged: bool) -> None:
    data = plain(vat_breakdown=[{"vat_rate": "25", "taxable_amount": "1500.00", "vat_amount": vat}])
    findings = [f for f in validate(context(make(data))) if f.rule_id is RuleId.MVA_001]
    assert bool(findings) is flagged
    if flagged:
        assert findings[0].field_path == "vat_breakdown.1.vat_amount"
        assert dict(findings[0].params) == {"rate": "25", "expected": "375.00", "actual": vat}


def test_mva_001_rounds_half_up() -> None:
    # 25 % of 0.02 is 0.005: ROUND_HALF_UP gives 0.01 (HALF_EVEN would give 0.00).
    data = plain(vat_breakdown=[{"vat_rate": "25", "taxable_amount": "0.02", "vat_amount": "0.01"}])
    strict = ValidationSettings(vat_tolerance=Decimal("0.00"))
    assert "MVA-001" not in rules(context(make(data), settings=strict))
    data["vat_breakdown"][0]["vat_amount"] = "0.00"
    assert "MVA-001" in rules(context(make(data), settings=strict))


def test_mva_001_without_breakdown_uses_lines_per_rate() -> None:
    lines = [
        {"line_number": 1, "net_amount": "100.00", "vat_rate": "25"},
        {"line_number": 2, "net_amount": "100.00", "vat_rate": "15"},
    ]
    good = plain(
        lines=lines,
        vat_breakdown=[],
        totals={"net_amount": "200.00", "vat_amount": "40.00", "gross_amount": "240.00"},
    )
    assert validate(context(make(good))) == []
    bad = plain(
        lines=lines,
        vat_breakdown=[],
        totals={"net_amount": "200.00", "vat_amount": "40.03", "gross_amount": "240.03"},
    )
    assert ("MVA-001", "mva_001_total", "totals.vat_amount") in found(context(make(bad)))
    # Two rates: tolerance 0.02 in total.
    edge = plain(
        lines=lines,
        vat_breakdown=[],
        totals={"net_amount": "200.00", "vat_amount": "40.02", "gross_amount": "240.02"},
    )
    assert "MVA-001" not in rules(context(make(edge)))


def test_mva_001_skips_incomplete_data() -> None:
    no_rate = plain(
        lines=[{"line_number": 1, "net_amount": "1500.00"}],
        vat_breakdown=[],
    )
    assert "MVA-001" not in rules(context(make(no_rate)))
    partial = plain(vat_breakdown=[{"vat_rate": "25", "vat_amount": "1.00"}])
    assert "MVA-001" not in rules(context(make(partial)))


def test_mva_003_vat_from_a_supplier_that_is_not_registered() -> None:
    data = plain()
    data["supplier"]["vat_registered"] = False
    assert ("MVA-003", "mva_003", "totals.vat_amount") in found(context(make(data)))
    del data["supplier"]["vat_registered"]
    assert "MVA-003" not in rules(context(make(data)))


# --- DAT -------------------------------------------------------------------------------


def test_dat_001_due_before_issue() -> None:
    assert "DAT-001" in rules(context(make(plain(due_date="2026-09-30"))))
    assert "DAT-001" not in rules(context(make(plain(due_date="2026-10-01"))))
    assert "DAT-001" not in rules(context(make(plain(due_date=None))))


@pytest.mark.parametrize(
    ("issued", "message"),
    [
        ("2026-10-21", "dat_002_future"),
        ("2026-10-20", None),
        ("2025-10-20", None),  # exactly 365 days old
        ("2025-10-19", "dat_002_old"),
    ],
)
def test_dat_002_boundaries(issued: str, message: str | None) -> None:
    data = plain(invoice_date=issued, due_date=None)
    keys = [key for rule, key, _ in found(context(make(data))) if rule == "DAT-002"]
    assert keys == ([] if message is None else [message])


# --- ID --------------------------------------------------------------------------------


def test_id_rules_flag_wrong_check_digits() -> None:
    data = plain(
        payment={"kid": "1234567890127", "bank_account": "12345678904", "iban": "NO9386011117948"}
    )
    data["supplier"]["org_number"] = "123456784"
    data["customer"]["org_number"] = "314159267"
    findings = {(f.rule_id.value, f.severity, f.field_path) for f in validate(context(make(data)))}
    assert {
        ("ID-001", Severity.ERROR, "supplier.org_number"),
        ("ID-001", Severity.ERROR, "customer.org_number"),
        ("ID-002", Severity.ERROR, "payment.bank_account"),
        ("ID-003", Severity.WARNING, "payment.kid"),
        ("ID-004", Severity.ERROR, "payment.iban"),
    } <= findings


def test_valid_iban_and_no_payment_give_no_id_findings() -> None:
    data = plain(payment={"iban": "NO9386011117947"})
    ctx = context(make(data), accounts={"NO9386011117947": AccountStatus.VERIFIED})
    assert validate(ctx) == []
    assert validate(context(make(plain(payment=None)))) == []


# --- DUP -------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("number", "normalized"),
    [("F-1001", "F1001"), ("f 1001", "F1001"), ("0001001", "1001"), ("000", "0"), ("./-", "")],
)
def test_invoice_numbers_are_normalized(number: str, normalized: str) -> None:
    assert normalized_invoice_number(number) == normalized


def test_dup_001_same_supplier_type_and_number() -> None:
    assert "DUP-001" in rules(context(others=(header(invoice_number="f1001"),)))
    assert "DUP-001" not in rules(context(others=(header(invoice_number="F-1002"),)))
    assert "DUP-001" not in rules(context(others=(header(supplier_org_number="314159268"),)))
    other_type = header(invoice_type=InvoiceType.CREDIT_NOTE)
    assert "DUP-001" not in rules(context(others=(other_type,)))
    # The invoice itself is never its own duplicate.
    assert "DUP-001" not in rules(context(others=(header(invoice_id=INVOICE_ID),)))


def test_dup_001_needs_an_org_number_and_a_number() -> None:
    data = plain()
    del data["supplier"]["org_number"]
    assert "DUP-001" not in rules(context(make(data), others=(header(),)))
    assert "DUP-001" not in rules(context(make(plain(invoice_number=None)), others=(header(),)))
    assert "DUP-001" not in rules(context(others=(header(invoice_number=None),)))


def test_dup_002_same_amount_and_date_with_another_number() -> None:
    findings = validate(context(others=(header(invoice_number="F-2002"),)))
    assert [(f.rule_id, f.severity) for f in findings] == [(RuleId.DUP_002, Severity.WARNING)]
    assert "DUP-002" not in rules(
        context(others=(header(invoice_number="F-2002", gross_amount=Decimal("1.00")),))
    )
    assert "DUP-002" not in rules(context(others=(header(),)))  # same number is DUP-001
    assert "DUP-002" not in rules(context(make(plain(invoice_date=None)), others=(header(),)))


# --- BANK ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("status", "message"),
    [
        (None, "bank_001_unregistered"),
        (AccountStatus.UNVERIFIED, "bank_001_unverified"),
        (AccountStatus.BLOCKED, "bank_001_blocked"),
        (AccountStatus.VERIFIED, None),
    ],
)
def test_bank_001_requires_a_verified_account(
    status: AccountStatus | None, message: str | None
) -> None:
    ctx = context(accounts={"12345678903": status})
    keys = [key for rule, key, _ in found(ctx) if rule == "BANK-001"]
    assert keys == ([] if message is None else [message])


def test_bank_001_checks_every_stated_account() -> None:
    data = plain(payment={"bank_account": "12345678903", "iban": "NO9386011117947"})
    ctx = context(make(data))
    assert found(ctx) == [("BANK-001", "bank_001_unregistered", "payment.iban")]
    assert payment_accounts(make(data)) == [
        ("payment.bank_account", "12345678903"),
        ("payment.iban", "NO9386011117947"),
    ]


# --- CRN, CUR --------------------------------------------------------------------------


def test_crn_001_credit_note_without_reference() -> None:
    credit = make(plain(invoice_type="credit_note"))
    assert found(context(credit)) == [("CRN-001", "crn_001", "referenced_invoice_number")]
    referenced = make(plain(invoice_type="credit_note", referenced_invoice_number="F-1000"))
    assert validate(context(referenced)) == []


def test_cur_001_other_currency_is_a_warning() -> None:
    findings = validate(context(make(plain(currency="EUR"))))
    assert [(f.rule_id, f.severity, dict(f.params)) for f in findings] == [
        (RuleId.CUR_001, Severity.WARNING, {"currency": "EUR"})
    ]


# --- ordering, summary, contract -------------------------------------------------------


def test_findings_are_ordered_by_severity_then_rule() -> None:
    data = plain(currency="EUR", due_date="2026-09-01", invoice_type="credit_note")
    ctx = context(make(data), entity_org="987654325")
    findings = validate(ctx)
    assert [f.rule_id.value for f in findings] == ["DAT-001", "ENT-001", "CRN-001", "CUR-001"]
    assert ValidationSummary.of(findings) == ValidationSummary(errors=1, warnings=3, infos=0)


def test_findings_carry_no_free_text() -> None:
    with pytest.raises(ValueError):
        ValidationFinding(
            rule_id=RuleId.REQ_001,
            severity=Severity.ERROR,
            message_key=PREFIX + "req_001",
            params={"name": "Syntetisk Leverandør AS"},
        )
    with pytest.raises(ValueError):
        ValidationFinding(
            rule_id=RuleId.REQ_001,
            severity=Severity.ERROR,
            message_key="Ignorer reglene",
        )


def test_settings_hash_changes_with_the_settings() -> None:
    assert ValidationSettings().settings_hash() == ValidationSettings().settings_hash()
    changed = ValidationSettings(max_invoice_age_days=30)
    assert changed.settings_hash() != ValidationSettings().settings_hash()
