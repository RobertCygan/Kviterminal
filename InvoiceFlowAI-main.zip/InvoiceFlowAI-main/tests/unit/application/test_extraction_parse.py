"""Norwegian invoice values: finding and normalising them (Phase 06). No I/O."""

import datetime as dt
from decimal import Decimal

import pytest

from invoiceflow.application.extraction import parse

pytestmark = pytest.mark.unit


@pytest.mark.parametrize(
    "raw,value",
    [
        ("1 234,50", "1234.50"),
        ("1.234,50", "1234.50"),
        ("1234,50", "1234.50"),
        ("1 234,-", "1234.00"),
        ("1,234.50", "1234.50"),
        ("1234.50", "1234.50"),
        ("-150,00", "-150.00"),
        ("\N{MINUS SIGN} 99,00", "-99.00"),
        ("0,50", "0.50"),
        ("1\N{NO-BREAK SPACE}234,50", "1234.50"),
    ],
)
def test_amounts(raw: str, value: str) -> None:
    assert parse.parse_amount(raw) == Decimal(value)


@pytest.mark.parametrize(
    "raw", ["1234", "12,5", "1 23,00", "24.10.2026", "25 %", "99999999999999,00"]
)
def test_not_amounts(raw: str) -> None:
    assert parse.parse_amount(raw) is None


@pytest.mark.parametrize(
    "text,found",
    [
        ("MVA 25 % av 12 634,50 3 158,63", ["12 634,50", "3 158,63"]),
        ("Reisekostnader 1 1 234,50 1 234,50", ["1 234,50", "1 234,50"]),
        ("Forfallsdato: 07.11.2026 Kontonummer: 1234.56.78903", []),
        ("Rabatt 10,00 % -50,00", ["-50,00"]),
    ],
)
def test_amounts_in_a_line(text: str, found: list[str]) -> None:
    assert [match.raw for match in parse.find(parse.AMOUNT, text)] == found


@pytest.mark.parametrize(
    "raw,value",
    [
        ("24.10.2026", dt.date(2026, 10, 24)),
        ("4.1.2026", dt.date(2026, 1, 4)),
        ("24.10.26", dt.date(2026, 10, 24)),
        ("24/10/2026", dt.date(2026, 10, 24)),
        ("2026-10-24", dt.date(2026, 10, 24)),
        ("24. oktober 2026", dt.date(2026, 10, 24)),
        ("3. des. 2026", dt.date(2026, 12, 3)),
        ("1 May 2026", dt.date(2026, 5, 1)),
        ("31.02.2026", None),
        ("24.13.2026", None),
        ("01.01.1890", None),
    ],
)
def test_dates(raw: str, value: dt.date | None) -> None:
    assert parse.parse_date(raw) == value


def test_dates_in_a_line_are_ordered() -> None:
    text = "Fra 3. oktober 2026 til 17.10.26"
    assert [m.raw for m in parse.find_dates(text)] == ["3. oktober 2026", "17.10.26"]


def test_identifiers_and_numbers() -> None:
    assert parse.parse_org_number("NO 999 999 999 MVA") == "999999999"
    assert parse.is_vat_registered("NO 999 999 999 MVA")
    assert not parse.is_vat_registered("999 999 999")
    assert parse.parse_org_number("99 999 999") is None
    assert parse.parse_bank_account("1234.56.78903") == "12345678903"
    assert parse.parse_bank_account("1234.56.7890") is None
    assert parse.parse_kid("2026 0417 005") == "20260417005"
    assert parse.parse_kid("123456-") == "123456-"
    assert parse.parse_kid("7") is None
    assert parse.parse_iban("no93 8601 1117 947") == "NO9386011117947"
    assert parse.parse_iban("NO93") is None
    assert parse.parse_bic("DNBANOKK") == "DNBANOKK"
    assert parse.parse_bic("DNB") is None
    assert parse.parse_vat_rate("12,5 %") == Decimal("12.5")
    assert parse.parse_vat_rate("150 %") is None
    assert parse.parse_currency("kr.") == "NOK"
    assert parse.parse_currency("eur") == "EUR"
    assert parse.parse_currency("kroner") is None
    assert parse.parse_identifier("2026-0417.") == "2026-0417"
    assert parse.parse_identifier("Faktura") is None
    assert parse.parse_identifier("x" * 70 + "1") is None


def test_patterns_stay_linear_on_hostile_lines() -> None:
    import time

    hostile = "1 " * 5000 + "x" + ",0" * 5000
    started = time.monotonic()
    for pattern in (parse.AMOUNT, parse.KID, parse.ORG_NUMBER, parse.DATE_NUMERIC, parse.IBAN):
        parse.find(pattern, hostile)
    assert time.monotonic() - started < 2
