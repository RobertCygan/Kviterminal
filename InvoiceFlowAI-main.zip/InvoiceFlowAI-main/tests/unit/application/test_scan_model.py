"""Blank pages, separator sheets and parts of a scanned batch (Phase 11a). No I/O."""

from uuid import UUID

import pytest

from invoiceflow.application.processing_model import PageRecord
from invoiceflow.application.scan.model import (
    BLANK_MAX_DARK,
    BLANK_NEAR_DARK,
    SEPARATOR_MIN_CENTER,
    SEPARATOR_NEAR_CENTER,
    SEPARATOR_SURE_CENTER,
    SEPARATOR_SURE_DARK,
    PageKind,
    classify,
    near_threshold,
    split_batch,
)
from invoiceflow.application.scan.separator import BOX, separator_sheet

JOB = UUID("00000000-0000-4000-8000-0000000000c1")
DOCUMENT = UUID("00000000-0000-4000-8000-0000000000c2")
MEASURES = {
    "content": (45, 30, 0),
    "text": (1, 0, 120),  # a text layer is never blank, however little ink
    "blank": (0, 0, 0),
    "noise": (BLANK_MAX_DARK, 0, 0),
    "separator": (445, 1000, 0),
    "logo": (900, 950, 0),  # almost all black: not a separator sheet
    "unknown": (None, None, 0),
}


def page(number: int, kind: str) -> PageRecord:
    dark, center, chars = MEASURES[kind]
    return PageRecord(JOB, DOCUMENT, number, 100, 140, 0, chars, dark, center)


def batch(*kinds: str) -> list[PageRecord]:
    return [page(number, kind) for number, kind in enumerate(kinds, start=1)]


@pytest.mark.parametrize(
    "kind,expected",
    [
        ("content", PageKind.CONTENT),
        ("text", PageKind.CONTENT),
        ("blank", PageKind.BLANK),
        ("noise", PageKind.BLANK),
        ("separator", PageKind.SEPARATOR),
        ("logo", PageKind.CONTENT),
        ("unknown", PageKind.UNKNOWN),
    ],
)
def test_pages_are_classified(kind: str, expected: PageKind) -> None:
    assert classify(page(1, kind)) is expected


def test_the_thresholds_are_strict_at_their_edges() -> None:
    assert classify(PageRecord(JOB, DOCUMENT, 1, 1, 1, 0, 0, BLANK_MAX_DARK + 1, 0)) is (
        PageKind.CONTENT
    )
    below = PageRecord(JOB, DOCUMENT, 1, 1, 1, 0, 0, 400, SEPARATOR_MIN_CENTER - 1)
    assert classify(below) is PageKind.CONTENT


@pytest.mark.parametrize(
    "kinds,parts,blank,separators",
    [
        (("content",), ((1, 1),), (), ()),
        (("content", "blank", "content", "blank"), ((1, 3),), (2, 4), ()),
        (
            ("separator", "content", "blank", "separator", "content", "content"),
            ((2, 2), (5, 6)),
            (3,),
            (1, 4),
        ),
        (("content", "separator", "separator", "content"), ((1, 1), (4, 4)), (), (2, 3)),
        (("blank", "blank"), (), (1, 2), ()),
        (("separator",), (), (), (1,)),
        ((), (), (), ()),
    ],
)
def test_batches_split_at_separators_and_skip_blank_edges(kinds, parts, blank, separators):
    split = split_batch(batch(*kinds))
    assert split.parts == parts
    assert split.pages_of(PageKind.BLANK) == blank
    assert split.pages_of(PageKind.SEPARATOR) == separators
    assert split.measured


def test_order_of_the_rows_does_not_matter_and_unmeasured_is_one_part() -> None:
    pages = batch("content", "separator", "content")
    assert split_batch(list(reversed(pages))).parts == ((1, 1), (3, 3))
    old = split_batch(batch("content", "unknown", "content"))
    assert old.parts == ((1, 3),) and not old.measured and old.needs_split
    assert not split_batch(batch("content", "content")).needs_split


def measured(dark: int, center: int, chars: int = 0) -> PageRecord:
    return PageRecord(JOB, DOCUMENT, 1, 1, 1, 0, chars, dark, center)


@pytest.mark.parametrize(
    "dark,center,chars,near",
    [
        (BLANK_NEAR_DARK, 0, 0, True),  # almost blank
        (BLANK_NEAR_DARK + 1, 0, 0, False),
        (BLANK_NEAR_DARK, 0, 5, False),  # a text layer is never blank
        (45, SEPARATOR_NEAR_CENTER, 0, True),  # almost a separator sheet
        (45, SEPARATOR_NEAR_CENTER - 1, 0, False),
        (900, 950, 0, True),  # dark centre, but far too much ink overall
        (445, SEPARATOR_SURE_CENTER - 1, 0, True),  # a weak separator sheet
        (445, SEPARATOR_SURE_CENTER, 0, False),
        (SEPARATOR_SURE_DARK[0] - 1, 1000, 0, True),
        (SEPARATOR_SURE_DARK[1] + 1, 1000, 0, True),
        (BLANK_MAX_DARK, 0, 0, False),  # blank is blank
        (45, 30, 0, False),
    ],
)
def test_pages_near_a_threshold_are_flagged(dark, center, chars, near) -> None:
    assert near_threshold(measured(dark, center, chars)) is near


def test_the_split_lists_pages_near_a_threshold() -> None:
    nearly_blank = PageRecord(JOB, DOCUMENT, 4, 1, 1, 0, 0, BLANK_NEAR_DARK, 0)
    pages = [*batch("content", "separator", "logo"), nearly_blank]
    assert split_batch(pages).near == (3, 4)
    assert split_batch(batch("unknown", "logo")).near == (2,)
    unmeasured = PageRecord(JOB, DOCUMENT, 1, 1, 1, 0, 0)
    assert not near_threshold(unmeasured)


def test_the_separator_sheet_is_a_small_valid_pdf() -> None:
    import pypdfium2 as pdfium

    data = separator_sheet(3)
    assert data.startswith(b"%PDF-1.7") and data.rstrip().endswith(b"%%EOF")
    document = pdfium.PdfDocument(data)
    try:
        assert len(document) == 3
        text = document[0].get_textpage().get_text_range()
        assert "SKILLEARK" in text
    finally:
        document.close()
    assert BOX[0] < 0.2 and BOX[2] > 0.8  # beyond the measured central area
    for copies in (0, 101):
        with pytest.raises(ValueError, match="copies"):
            separator_sheet(copies)
