"""OCR contracts: what the main process accepts from the worker (Phase 05)."""

import pytest
from pydantic import ValidationError

from invoiceflow.application.processing_model import (
    OcrLayer,
    OcrPageResult,
    OcrReport,
    OcrSettings,
    ProcessingLimits,
)

pytestmark = pytest.mark.unit


def word(text: str, line: int, confidence: int = 90, box=(0.1, 0.1, 0.2, 0.12)) -> dict:
    return {"text": text, "box": box, "confidence": confidence, "line": line}


def layer(*words: dict, **extra) -> OcrLayer:
    return OcrLayer.model_validate(
        {"result_version": 1, "page_number": 1, "language": "nor", "words": words} | extra
    )


def test_text_lines_and_confidence_follow_the_words() -> None:
    page = layer(word("Faktura", 0, 96), word("1", 0, 40), word("NOK", 1, 89))
    assert page.text() == "Faktura 1\nNOK" and page.line_count == 2
    assert page.mean_confidence() == 75
    empty = layer()
    assert (empty.text(), empty.line_count, empty.mean_confidence()) == ("", 0, 0)


@pytest.mark.parametrize(
    "words,extra",
    [
        ((word("a", 1),), {}),  # lines start at 0
        ((word("a", 0), word("b", 2)), {}),  # no gaps
        ((word("a", 1), word("b", 0)), {}),  # in order
        ((word("a", 0, box=(0.5, 0.1, 0.2, 0.2)),), {}),
        ((word("a", 0, confidence=101),), {}),
        ((word("", 0),), {}),
        ((word("a", 0),), {"language": "NOR"}),
        ((word("a", 0),), {"surplus": 1}),
    ],
)
def test_malformed_layers_are_refused(words, extra) -> None:
    with pytest.raises(ValidationError):
        layer(*words, **extra)


def page(**changes) -> dict:
    return {
        "page_number": 2,
        "file": "ocr-0002.json",
        "word_count": 3,
        "line_count": 2,
        "char_count": 12,
        "mean_confidence": 80,
        "low_confidence_words": 1,
    } | changes


@pytest.mark.parametrize(
    "changes",
    [{"file": "ocr-0001.json"}, {"line_count": 4}, {"low_confidence_words": 4}],
)
def test_page_results_must_be_consistent(changes) -> None:
    OcrPageResult.model_validate(page())
    with pytest.raises(ValidationError):
        OcrPageResult.model_validate(page(**changes))


def report(**changes) -> dict:
    return {
        "result_version": 1,
        "status": "ok",
        "engine": "tesseract",
        "engine_version": "5.3.4+ocr1+0451eb4f",
        "sha256": "a" * 64,
        "pages": [page()],
    } | changes


@pytest.mark.parametrize(
    "changes",
    [
        {"pages": []},
        {"error_code": "ocr_failed"},
        {"status": "error"},
        {"status": "error", "error_code": "ocr_failed"},
        {"pages": [page(), page()]},
    ],
)
def test_reports_must_be_consistent(changes) -> None:
    OcrReport.model_validate(report())
    OcrReport.model_validate(report(status="error", error_code="ocr_failed", pages=[]))
    with pytest.raises(ValidationError):
        OcrReport.model_validate(report(**changes))


def test_settings_are_bounded_and_change_the_hash() -> None:
    limits = ProcessingLimits()
    base = OcrSettings().settings_hash(limits)
    assert OcrSettings(language="nor+eng").settings_hash(limits) != base
    assert OcrSettings(page_segmentation=6).settings_hash(limits) != base
    assert OcrSettings().settings_hash(ProcessingLimits(dpi=200)) != base
    assert OcrSettings().settings_hash(ProcessingLimits(timeout_seconds=5)) == base
    for bad in ({"language": "../x"}, {"page_segmentation": 0}, {"low_confidence": 0}):
        with pytest.raises(ValueError, match="OCR settings"):
            OcrSettings(**bad)


@pytest.mark.parametrize(
    "dark,center,chars,expected",
    [
        (45, 30, 0, True),  # a scanned page
        (2, 0, 0, True),  # one short line: "blank" in the scan view, still read
        (None, None, 0, True),  # analysed before page metrics existed
        (0, 0, 0, False),  # no ink at all
        (445, 1000, 0, False),  # a separator sheet
        (45, 30, 120, False),  # the PDF has a text layer
    ],
)
def test_which_pages_are_recognised(dark, center, chars, expected) -> None:
    from uuid import uuid4

    from invoiceflow.application.processing import needs_ocr
    from invoiceflow.application.processing_model import PageRecord

    page = PageRecord(uuid4(), uuid4(), 1, 100, 140, 0, chars, dark, center)
    assert needs_ocr(page) is expected
