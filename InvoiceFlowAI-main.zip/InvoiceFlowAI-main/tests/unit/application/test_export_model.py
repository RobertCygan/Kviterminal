"""Export table, neutralization and mapping rules (Phase 10). No I/O."""

import datetime as dt
from decimal import Decimal
from uuid import UUID

import pytest
from plain_invoice import make

from invoiceflow.application.export.model import (
    STANDARD_FIELDS,
    STANDARD_MAPPING,
    ExportColumn,
    ExportError,
    ExportField,
    ExportSource,
    ExportTarget,
    FieldKind,
    build_rows,
    check_columns,
    check_header,
    columns_json,
    file_name,
    headers,
    kind_of,
    neutralize,
    parse_columns,
    totals,
)
from invoiceflow.domain.invoice import AccountingLine
from invoiceflow.domain.provenance import FieldValue, Provenance, ValueSource
from invoiceflow.i18n import t

INVOICE_ID = UUID("00000000-0000-4000-8000-0000000000aa")
DAY = dt.date(2026, 10, 24)


def _value(value: object) -> FieldValue:
    return FieldValue(
        value=value, provenance=Provenance(source=ValueSource.CALCULATED, producer="test/1")
    )


def posted(*lines: tuple[str, str]):
    invoice = make()
    accounting = tuple(
        AccountingLine(line_number=number, account=_value(account), net_amount=_value(amount))
        for number, (account, amount) in enumerate(lines, start=1)
    )
    return invoice.model_copy(update={"accounting_lines": accounting})


@pytest.mark.parametrize(
    "text",
    [
        "=CMD()",
        "+1",
        "-1+1",
        "@SUM(A1)",
        "\tx",
        "\rx",
        "\nx",
        "\N{FULLWIDTH EQUALS SIGN}1",
        "\N{FULLWIDTH COMMERCIAL AT}x",
    ],
)
def test_formula_starts_are_neutralized(text: str) -> None:
    assert neutralize(text) == "'" + text


@pytest.mark.parametrize("text", ["", "Leverandør AS", "1-2", "a=b", "'already"])
def test_plain_text_is_unchanged(text: str) -> None:
    assert neutralize(text) == text


@pytest.mark.parametrize("text", ["", " ", "x" * 41, "=A1", "-x", "@x", "a‮b", "a\x00b"])
def test_invalid_headers_are_refused(text: str) -> None:
    with pytest.raises(ExportError) as caught:
        check_header(text)
    assert caught.value.reason == "header"


def test_a_header_is_trimmed() -> None:
    assert check_header("  Bilagsnr  ") == "Bilagsnr"
    assert check_header("x" * 40) == "x" * 40


def test_columns_must_be_unique_and_round_trip_as_json() -> None:
    columns = check_columns(
        [ExportColumn(ExportField.KID, " KID-nr "), ExportColumn(ExportField.IBAN)]
    )
    assert columns == (ExportColumn(ExportField.KID, "KID-nr"), ExportColumn(ExportField.IBAN))
    assert parse_columns(columns_json(columns)) == columns
    with pytest.raises(ExportError):
        check_columns([])
    with pytest.raises(ExportError):
        check_columns([ExportColumn(ExportField.KID), ExportColumn(ExportField.KID)])


def test_headers_use_the_standard_text_and_refuse_duplicates() -> None:
    assert headers(STANDARD_MAPPING.columns, t)[0] == t("export.column.supplier_name")
    assert len(STANDARD_FIELDS) == len(set(STANDARD_FIELDS))
    with pytest.raises(ExportError) as caught:
        headers([ExportColumn(ExportField.KID), ExportColumn(ExportField.IBAN, "kid")], t)
    assert caught.value.reason == "duplicate_header"


def test_one_row_per_accounting_line_with_the_header_repeated() -> None:
    source = ExportSource(INVOICE_ID, posted(("6300", "8000.00"), ("6540", "2500.00")), DAY)
    columns = [
        ExportColumn(ExportField.INVOICE_NUMBER),
        ExportColumn(ExportField.LINE_NUMBER),
        ExportColumn(ExportField.ACCOUNT),
        ExportColumn(ExportField.LINE_NET_AMOUNT),
        ExportColumn(ExportField.APPROVED_ON),
        ExportColumn(ExportField.INVOICE_ID),
    ]
    assert build_rows([source], columns, t) == (
        ("F-1001", 1, "6300", Decimal("8000.00"), DAY, str(INVOICE_ID)),
        ("F-1001", 2, "6540", Decimal("2500.00"), DAY, str(INVOICE_ID)),
    )


def test_an_invoice_without_posting_is_one_row_with_empty_line_values() -> None:
    source = ExportSource(INVOICE_ID, make(), DAY)
    (row,) = build_rows([source], STANDARD_MAPPING.columns, t)
    values = dict(zip(STANDARD_FIELDS, row, strict=True))
    assert values[ExportField.LINE_NUMBER] is None and values[ExportField.ACCOUNT] is None
    assert values[ExportField.SUPPLIER_NAME] == "Syntetisk Leverandør AS"
    assert values[ExportField.INVOICE_TYPE] == t("export.type.invoice")


def test_totals_per_currency() -> None:
    sources = [
        ExportSource(INVOICE_ID, posted(("6300", "10500.00")), DAY),
        ExportSource(INVOICE_ID, make(), DAY),
    ]
    (nok,) = totals(sources).values()
    assert nok.invoice_count == 2
    assert nok.gross == 2 * make().totals.gross_amount.value
    assert nok.posted == Decimal("10500.00")


def test_credit_notes_are_negative_and_zero_stays_plain() -> None:
    credit = posted(("6300", "8000.00"), ("6540", "0.00")).model_copy(
        update={"invoice_type": _value("credit_note")}
    )
    source = ExportSource(INVOICE_ID, credit, DAY)
    columns = [
        ExportColumn(ExportField.GROSS_TOTAL),
        ExportColumn(ExportField.LINE_NET_AMOUNT),
        ExportColumn(ExportField.INVOICE_TYPE),
    ]
    rows = build_rows([source], columns, t)
    assert rows == (
        (-Decimal("1875.00"), -Decimal("8000.00"), t("export.type.credit_note")),
        (-Decimal("1875.00"), Decimal("0.00"), t("export.type.credit_note")),
    )
    assert not rows[1][1].is_signed()
    (nok,) = totals([source, ExportSource(INVOICE_ID, make(), DAY)]).values()
    assert (nok.gross, nok.posted) == (Decimal("0.00"), -Decimal("8000.00"))


def test_field_kinds_and_file_names() -> None:
    assert kind_of(ExportField.GROSS_TOTAL) is FieldKind.MONEY
    assert kind_of(ExportField.DUE_DATE) is FieldKind.DATE
    assert kind_of(ExportField.SUPPLIER_NAME) is FieldKind.TEXT
    moment = dt.datetime(2026, 10, 24, 9, 34, 5, tzinfo=dt.UTC)
    assert file_name(7, moment, ExportTarget.CSV) == "fakturaeksport-00007-20261024-093405.csv"
    assert ExportTarget.EXCEL.suffix == "xlsx"
