"""Manual correction of fields: strict Norwegian input and manual provenance (Phase 09)."""

import datetime as dt
from decimal import Decimal

import pytest
from plain_invoice import make, plain
from reference_data import DEFAULTS, REFERENCE

from invoiceflow.application.reference.posting import with_suggestion
from invoiceflow.application.review.editing import (
    MANUAL_PRODUCER,
    EditError,
    apply_edit,
    is_editable,
    parse_date,
    parse_digits,
    parse_money,
    parse_upper,
)
from invoiceflow.domain.provenance import Evidence, ValueSource

pytestmark = pytest.mark.unit

NOW = dt.datetime(2026, 10, 20, 10, 0, tzinfo=dt.UTC)


@pytest.mark.parametrize(
    ("text", "value"),
    [
        ("1 234,50", "1234.50"),
        ("1234.5", "1234.5"),
        ("-12,00", "-12.00"),
        ("\N{NO-BREAK SPACE}10\N{NO-BREAK SPACE}500", "10500"),
        ("0", "0"),
    ],
)
def test_amounts_in_norwegian_form(text, value) -> None:
    assert parse_money(text) == value


@pytest.mark.parametrize("text", ["1.234,50", "12,345", "1e3", "NaN", "kr 10", "", "  "])
def test_invalid_amounts_are_refused(text) -> None:
    with pytest.raises(EditError):
        parse_money(text)


@pytest.mark.parametrize(
    ("text", "value"),
    [("01.10.2026", "2026-10-01"), ("1.2.2026", "2026-02-01"), ("2026-10-01", "2026-10-01")],
)
def test_dates(text, value) -> None:
    assert parse_date(text) == value


@pytest.mark.parametrize("text", ["31.02.2026", "2026-13-01", "1/10/2026", "i går"])
def test_invalid_dates_are_refused(text) -> None:
    with pytest.raises(EditError) as caught:
        parse_date(text)
    assert caught.value.message_key == "review.error.date"


def test_digits_and_codes() -> None:
    assert parse_digits("1234.56.78903") == "12345678903"
    assert parse_digits("1234 56 78903") == "12345678903"
    assert parse_upper("no93 8601 1117 947") == "NO9386011117947"
    for text, parse in (("12a4", parse_digits), ("NO-93", parse_upper)):
        with pytest.raises(EditError):
            parse(text)
    with pytest.raises(EditError) as caught:
        parse_digits("12‮34")
    assert caught.value.reason == "control_character"


def test_an_edit_is_manual_and_keeps_the_evidence() -> None:
    invoice = make()
    evidence_invoice = invoice.model_copy(
        update={
            "invoice_number": invoice.invoice_number.model_copy(
                update={
                    "provenance": invoice.invoice_number.provenance.model_copy(
                        update={
                            "evidence": Evidence(source_ref="/Invoice/cbc:ID", raw_text="F-1001")
                        }
                    )
                }
            )
        }
    )
    changed = apply_edit(evidence_invoice, "invoice_number", " F-1002 ", NOW)
    field = changed.invoice_number
    assert field.value == "F-1002"
    assert (field.provenance.source, field.provenance.producer) == (
        ValueSource.MANUAL,
        MANUAL_PRODUCER,
    )
    assert field.provenance.recorded_at == NOW
    assert field.provenance.evidence.source_ref == "/Invoice/cbc:ID"


def test_edits_of_amounts_dates_payment_and_posting() -> None:
    invoice = with_suggestion(make(plain(payment=None)), DEFAULTS, REFERENCE)
    invoice = apply_edit(invoice, "totals.gross_amount", "1 875,00", NOW)
    invoice = apply_edit(invoice, "due_date", "30.10.2026", NOW)
    invoice = apply_edit(invoice, "payment.bank_account", "1234.56.78903", NOW)
    invoice = apply_edit(invoice, "accounting_lines.1.account", "6800", NOW)
    invoice = apply_edit(invoice, "accounting_lines.1.net_amount", "1500", NOW)
    assert invoice.totals.gross_amount.value == Decimal("1875.00")
    assert invoice.due_date.value == dt.date(2026, 10, 30)
    assert invoice.payment.bank_account.value == "12345678903"
    assert invoice.accounting_lines[0].account.value == "6800"
    assert invoice.accounting_lines[0].net_amount.value == Decimal("1500.00")


@pytest.mark.parametrize(
    ("path", "text", "reason"),
    [
        ("supplier.address.city", "Narvik", "unknown_field"),
        ("document_id", "x", "unknown_field"),
        ("accounting_lines.9.account", "6300", "unknown_field"),
        ("payment.bank_account", "123", "invalid_value"),
        ("currency", "NORSK", "invalid_value"),
        ("accounting_lines.1.account", "63 00", "invalid_value"),
        ("invoice_number", "", "empty"),
    ],
)
def test_invalid_edits_change_nothing(path, text, reason) -> None:
    invoice = with_suggestion(make(), DEFAULTS, REFERENCE)
    with pytest.raises(EditError) as caught:
        apply_edit(invoice, path, text, NOW)
    assert caught.value.reason == reason


def test_editable_paths() -> None:
    assert is_editable("accounting_lines.3.vat_code")
    assert is_editable("totals.net_amount")
    assert not is_editable("lines.1.net_amount")
    assert not is_editable("accounting_lines.x.account")
