"""EN 16931 arithmetic and recipient checks (pure)."""

import pytest

from invoiceflow.application.ehf import (
    arithmetic_findings,
    attachment_display_name,
    ordered,
    recipient_findings,
)
from invoiceflow.application.processing_model import (
    EhfAttachment,
    EhfMonetary,
    InvoiceFindingCode,
)
from invoiceflow.domain.invoice import CanonicalInvoice

pytestmark = pytest.mark.unit

GOOD = EhfMonetary(
    line_sum="100.00",
    line_extension="100.00",
    allowance_total="10.00",
    charge_total="5.00",
    tax_exclusive="95.00",
    tax_amount="23.75",
    tax_subtotal_sum="23.75",
    tax_inclusive="118.75",
    prepaid="18.75",
    rounding="0.00",
    payable="100.00",
)


def test_a_consistent_invoice_has_no_findings() -> None:
    assert arithmetic_findings(GOOD) == []
    assert arithmetic_findings(EhfMonetary()) == []  # nothing to compare


@pytest.mark.parametrize(
    ("change", "code"),
    [
        ({"line_sum": "99.00"}, InvoiceFindingCode.LINE_SUM_MISMATCH),
        ({"charge_total": "6.00"}, InvoiceFindingCode.NET_MISMATCH),
        ({"tax_subtotal_sum": "23.70"}, InvoiceFindingCode.VAT_MISMATCH),
        ({"tax_inclusive": "118.70", "payable": "99.95"}, InvoiceFindingCode.GROSS_MISMATCH),
        ({"rounding": "0.01"}, InvoiceFindingCode.PAYABLE_MISMATCH),
    ],
)
def test_each_rule_flags_its_own_deviation(change, code) -> None:
    assert arithmetic_findings(GOOD.model_copy(update=change)) == [code]


def test_negative_payable_is_flagged() -> None:
    negative = EhfMonetary(tax_inclusive="-10.00", payable="-10.00")
    assert arithmetic_findings(negative) == [InvoiceFindingCode.NEGATIVE_TOTAL]


def _invoice(customer_org: str | None) -> CanonicalInvoice:
    provenance = {"source": "extracted", "evidence": {"source_ref": "/x"}}
    data = {"document_id": "00000000-0000-4000-8000-000000000001", "supplier": {}, "totals": {}}
    if customer_org is not None:
        data["customer"] = {"org_number": {"value": customer_org, "provenance": provenance}}
    return CanonicalInvoice.model_validate(data)


def test_recipient_checks() -> None:
    assert recipient_findings(_invoice("314159268"), "314159268") == []
    assert recipient_findings(_invoice("123456785"), "314159268") == [
        InvoiceFindingCode.WRONG_RECIPIENT
    ]
    assert recipient_findings(_invoice(None), "314159268") == [InvoiceFindingCode.MISSING_RECIPIENT]
    assert recipient_findings(_invoice("123456785"), None) == []  # nothing to compare


def test_attachment_names_come_from_the_file_or_a_neutral_default() -> None:
    named = EhfAttachment(file="attachment-01.bin", filename="faktura.pdf", size_bytes=1)
    unnamed = EhfAttachment(file="attachment-02.bin", mime_code="application/pdf", size_bytes=1)
    unknown = EhfAttachment(file="attachment-03.bin", mime_code="text/html", size_bytes=1)
    assert attachment_display_name(named, 1) == "faktura.pdf"
    assert attachment_display_name(unnamed, 2) == "vedlegg-02.pdf"
    assert attachment_display_name(unknown, 3) == "vedlegg-03.bin"


def test_findings_are_unique_and_ordered() -> None:
    codes = [InvoiceFindingCode.POSSIBLE_DUPLICATE, InvoiceFindingCode.LINE_SUM_MISMATCH] * 2
    assert ordered(codes) == [
        InvoiceFindingCode.LINE_SUM_MISMATCH,
        InvoiceFindingCode.POSSIBLE_DUPLICATE,
    ]
