"""Backup format rules: passphrase, paths, header and manifest (Phase 12). No I/O."""

import json
from uuid import UUID

import pytest

from invoiceflow.application.backup.model import (
    MAX_PASSPHRASE,
    BackupError,
    BackupHeader,
    DatabaseCopy,
    Manifest,
    ManifestEntry,
    SnapshotInfo,
    backup_file_name,
    check_member,
    check_passphrase,
    is_backup_file_name,
    missing_documents,
    missing_or_changed,
)

BACKUP_ID = UUID("00000000-0000-4000-8000-0000000000b1")
CREATED = "2026-10-24T10:00:00.000000Z"


def header(**changes) -> BackupHeader:
    values = {
        "backup_id": BACKUP_ID,
        "created_at": CREATED,
        "salt": bytes(range(16)),
        "nonce_prefix": bytes(range(8)),
    }
    return BackupHeader(**(values | changes))


def test_a_passphrase_is_normalized_and_bounded() -> None:
    assert check_passphrase("Korrekt hest batteri", "Korrekt hest batteri") == (
        b"Korrekt hest batteri"
    )
    composed = "bl\N{LATIN SMALL LETTER A WITH RING ABOVE}b\N{LATIN SMALL LETTER AE}r-syltetøy"
    decomposed = "bla\N{COMBINING RING ABOVE}b\N{LATIN SMALL LETTER AE}r-syltetøy"
    assert check_passphrase(decomposed) == check_passphrase(composed)
    for wrong in (
        "kort",
        " " * 20,
        "a" * (MAX_PASSPHRASE + 1),
        "passord\x00passord",
        "a\N{RIGHT-TO-LEFT OVERRIDE}bcdefghijkl",
    ):
        with pytest.raises(BackupError) as caught:
            check_passphrase(wrong)
        assert caught.value.reason == "passphrase"
    with pytest.raises(BackupError) as caught:
        check_passphrase("en lang passordfrase", "en annen passordfrase")
    assert caught.value.reason == "mismatch"


@pytest.mark.parametrize(
    "path",
    [
        "database/invoiceflow.sqlite3",
        "documents/" + "a" * 32 + "/originals/ab/cd/" + "b" * 64 + ".pdf",
        "exports/" + "a" * 32 + "/fakturaeksport-00001-20261024-093400.xlsx",
        "config/config.json",
    ],
)
def test_known_member_paths(path: str) -> None:
    assert check_member(path) == path


@pytest.mark.parametrize(
    "path",
    [
        "manifest.json",
        "../database/x",
        "/database/x",
        "database/../../x",
        "database//x",
        "logs/invoiceflow.log",
        "documents/.hidden",
        "documents/a\\b",
        "documents/" + "/".join(["a"] * 10),
        "documents/" + "x" * 129,
        "database/x y",
    ],
)
def test_unexpected_member_paths_are_damage(path: str) -> None:
    with pytest.raises(BackupError) as caught:
        check_member(path)
    assert caught.value.reason == "damaged"


def test_the_header_round_trips_only_in_canonical_form() -> None:
    original = header()
    data = original.to_bytes()
    assert BackupHeader.from_bytes(data) == original
    raw = json.loads(data)
    for key, value in (
        ("format", 2),
        ("kdf", "pbkdf2"),
        ("cipher", "aes-128-gcm"),
        ("n", 3000),
        ("n", 2**21),
        ("n", True),
        ("r", 4),
        ("p", 9),
        ("chunk_size", 1024),
        ("salt", "00"),
        ("nonce_prefix", "zz" * 8),
        ("created_at", "i dag"),
        ("backup_id", "x"),
    ):
        changed = json.dumps(raw | {key: value}, sort_keys=True, separators=(",", ":"))
        with pytest.raises(BackupError):
            BackupHeader.from_bytes(changed.encode())
    with pytest.raises(BackupError):
        BackupHeader.from_bytes(json.dumps(raw, indent=1).encode())  # not canonical
    with pytest.raises(BackupError):
        BackupHeader.from_bytes(b"\xff")


def test_the_manifest_round_trips_and_compares_files() -> None:
    entry = ManifestEntry("database/invoiceflow.sqlite3", "a" * 64, 10)
    manifest = Manifest(BACKUP_ID, CREATED, "0009_backup", 7, "b" * 64, (entry,))
    assert Manifest.from_bytes(manifest.to_bytes()) == manifest
    assert manifest.files() == {entry.path: entry}
    assert missing_or_changed(manifest, {entry.path: ("a" * 64, 10)}) == []
    assert missing_or_changed(manifest, {entry.path: ("a" * 64, 11), "config/x": ("c", 1)}) == [
        "config/x",
        entry.path,
    ]
    for broken in (b"{}", b"[]", manifest.to_bytes().replace(b"database", b"logs")):
        with pytest.raises(BackupError):
            Manifest.from_bytes(broken)


def test_documents_referenced_by_the_database_must_be_in_the_backup() -> None:
    copy = DatabaseCopy(
        SnapshotInfo("0009_backup", 1, "0" * 64), {"documents/a/originals/x.pdf": "c" * 64}
    )
    assert missing_documents(copy, {"documents/a/originals/x.pdf": ("c" * 64, 3)}) == []
    assert missing_documents(copy, {}) == ["documents/a/originals/x.pdf"]


def test_file_names() -> None:
    import datetime as dt

    name = backup_file_name(dt.datetime(2026, 10, 24, 12, 0, 1, tzinfo=dt.UTC))
    assert name == "invoiceflow-sikkerhetskopi-20261024-120001.ifbak"
    assert is_backup_file_name(name) and not is_backup_file_name("x.ifbak")
