"""Pure document rules: signatures, extensions, display names and audit policy."""

from uuid import UUID

import pytest

from invoiceflow.application.audit import AuditDraft, AuditEventType, AuditPayloadError
from invoiceflow.application.document_model import (
    DocumentFormat,
    SizeClass,
    detect_format,
    extension_matches,
    sanitize_display_name,
    size_class,
)

pytestmark = pytest.mark.unit

ENTITY = UUID("11111111-1111-4111-8111-111111111111")
DOCUMENT = "22222222-2222-4222-8222-222222222222"
SHA = "b" * 64


@pytest.mark.parametrize(
    ("header", "expected"),
    [
        (b"%PDF-1.7\n", DocumentFormat.PDF),
        (b"\x89PNG\r\n\x1a\n\x00", DocumentFormat.PNG),
        (b"\xff\xd8\xff\xe0", DocumentFormat.JPEG),
        (b"II*\x00\x08", DocumentFormat.TIFF),
        (b"MM\x00*\x00", DocumentFormat.TIFF),
        (b"MZ\x90\x00", None),
        (b"PK\x03\x04", None),
        (b" %PDF-1.7", None),
        (b"", None),
    ],
    ids=["pdf", "png", "jpeg", "tiff_le", "tiff_be", "exe", "zip", "offset", "empty"],
)
def test_detect_format_uses_the_signature(header: bytes, expected: DocumentFormat | None) -> None:
    assert detect_format(header) == expected


@pytest.mark.parametrize(
    ("name", "document_format", "expected"),
    [
        ("faktura.pdf", DocumentFormat.PDF, True),
        ("FAKTURA.PDF", DocumentFormat.PDF, True),
        ("skann.JPEG", DocumentFormat.JPEG, True),
        ("skann.jpe", DocumentFormat.JPEG, True),
        ("skann.TIF", DocumentFormat.TIFF, True),
        ("faktura.png", DocumentFormat.PDF, False),
        ("faktura.pdf.exe", DocumentFormat.PDF, False),
        ("faktura", DocumentFormat.PDF, False),
        (r"C:\mappe.pdf\faktura", DocumentFormat.PDF, False),
    ],
)
def test_extension_must_match_the_detected_format(
    name: str, document_format: DocumentFormat, expected: bool
) -> None:
    assert extension_matches(name, document_format) is expected


@pytest.mark.security
@pytest.mark.parametrize(
    ("name", "expected"),
    [
        ("faktura.pdf", "faktura.pdf"),
        ("../../Windows/System32/faktura.pdf", "faktura.pdf"),
        (r"C:\Users\x\faktura.pdf", "faktura.pdf"),
        ("fak\u202etura.pdf", "faktura.pdf"),  # right-to-left override
        ("fak\x00tura\n.pdf", "faktura.pdf"),
        ("  faktura   2026 .pdf ", "faktura 2026 .pdf"),
        ("Ålesund kvittering.png", "Ålesund kvittering.png"),
        ("a\u0301.pdf", "á.pdf"),  # NFC
        ("CON.", "CON"),
        ("...", "dokument"),
        ("", "dokument"),
    ],
)
def test_display_name_is_sanitized(name: str, expected: str) -> None:
    assert sanitize_display_name(name) == expected


def test_display_name_is_bounded() -> None:
    assert len(sanitize_display_name("x" * 1000 + ".pdf")) == 255


@pytest.mark.parametrize(
    ("size", "expected"),
    [
        (1, SizeClass.UNDER_100KB),
        (100 * 1024, SizeClass.UNDER_1MB),
        (1024 * 1024, SizeClass.UNDER_10MB),
        (50 * 1024 * 1024, SizeClass.UP_TO_50MB),
    ],
)
def test_size_class(size: int, expected: SizeClass) -> None:
    assert size_class(size) == expected


def imported(**details: object) -> AuditDraft:
    values: dict[str, object] = {
        "sha256": SHA,
        "size_class": "under_1mb",
        "format": "pdf",
        "document_type": "unclassified",
        "source": "file_import",
    }
    values.update(details)
    return AuditDraft(
        event_type=AuditEventType.DOCUMENT_IMPORTED,
        actor="system",
        entity_id=ENTITY,
        subject_id=DOCUMENT,
        details=values,
    )


def test_document_events_accept_their_allowlisted_details() -> None:
    assert imported().subject_type == "document"


@pytest.mark.security
@pytest.mark.parametrize(
    "details",
    [
        {"display_name": "Faktura Nordlys AS.pdf"},
        {"storage_path": "abc/originals/x.pdf"},
        {"format": "faktura_nordlys"},
        {"document_type": "nordlys_as"},
        {"source": "C:/Users/x"},
        {"size_class": 12345},
        {"sha256": "faktura.pdf"},
    ],
    ids=["name", "path", "format", "type", "source", "size", "hash"],
)
def test_file_names_paths_and_free_codes_are_rejected(details: dict[str, object]) -> None:
    with pytest.raises(AuditPayloadError):
        imported(**details)


def test_document_events_require_an_entity() -> None:
    with pytest.raises(AuditPayloadError):
        AuditDraft(
            event_type=AuditEventType.DOCUMENT_REJECTED,
            actor="system",
            entity_id=None,
            subject_id=DOCUMENT,
            details={"reject_reason": "empty", "source": "inbox"},
        )
