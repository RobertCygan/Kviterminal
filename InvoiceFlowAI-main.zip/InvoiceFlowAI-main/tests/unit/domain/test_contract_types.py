"""Regression tests for weaknesses found in the Phase 00 final audit.

See docs/PHASE_00_AUDIT.md (findings F-07 to F-11).
"""

import copy
import datetime as dt
import json
from decimal import Decimal
from typing import Any

import pytest
from pydantic import ValidationError

from invoiceflow.domain import CanonicalInvoice, FieldValue, InvoiceLine, InvoiceType
from invoiceflow.domain.types import (
    Flag,
    Identifier,
    IsoDate,
    LongText,
    Money,
    Quantity,
    ShortText,
    UnitPrice,
    VatRate,
)

pytestmark = pytest.mark.unit

CALCULATED = {"source": "calculated", "producer": "regel/test/1"}


def _field(field_type: Any, value: Any) -> Any:
    return FieldValue[field_type].model_validate({"value": value, "provenance": CALCULATED})


class TestCanonicalDecimalForm:
    @pytest.mark.parametrize(
        ("field_type", "raw", "expected"),
        [
            (Money, "100", "100.00"),
            (Money, "1e2", "100.00"),
            (Money, "100.000", "100.00"),
            (Money, "-0.00", "0.00"),
            (Money, "-12.5", "-12.50"),
            (UnitPrice, "289", "289.00"),
            (UnitPrice, "0.012500", "0.0125"),
            (Quantity, "10.000", "10"),
            (Quantity, "2.50", "2.5"),
            (VatRate, "25.00", "25"),
            (VatRate, "2.5E1", "25"),
            (VatRate, "12.5", "12.5"),
        ],
    )
    def test_equal_values_serialise_identically(
        self, field_type: Any, raw: str, expected: str
    ) -> None:
        field = _field(field_type, raw)
        assert json.loads(field.model_dump_json())["value"] == expected
        assert field.value == Decimal(raw)

    def test_normalisation_never_rounds(self) -> None:
        with pytest.raises(ValidationError, match="decimal places"):
            _field(Money, "0.001")

    def test_content_of_equivalent_invoices_is_identical(
        self, example_invoice_data: dict[str, Any]
    ) -> None:
        variant = copy.deepcopy(example_invoice_data)
        variant["totals"]["gross_amount"]["value"] = "5671.250"
        variant["lines"][0]["quantity"]["value"] = "10.0"
        original = CanonicalInvoice.model_validate(example_invoice_data)
        assert CanonicalInvoice.model_validate(variant).model_dump_json() == (
            original.model_dump_json()
        )


@pytest.mark.security
class TestStrictDates:
    @pytest.mark.parametrize(
        "value",
        [
            1759276800,  # Unix timestamp at midnight: lax pydantic turns it into a date
            "2026-10-01T00:00:00",
            "01.10.2026",
            "2026-10-1",
            "\u0662\u0660\u0662\u0666-\u0661\u0660-\u0660\u0661",  # Arabic-Indic digits
            dt.datetime(2026, 10, 1, tzinfo=dt.UTC),
            True,
        ],
    )
    def test_only_iso_dates_are_accepted(self, value: Any) -> None:
        with pytest.raises(ValidationError):
            _field(IsoDate, value)

    @pytest.mark.parametrize("value", ["2026-10-01", dt.date(2026, 10, 1)])
    def test_iso_date_and_date_objects_are_accepted(self, value: Any) -> None:
        assert _field(IsoDate, value).value == dt.date(2026, 10, 1)

    def test_impossible_date_is_rejected(self) -> None:
        with pytest.raises(ValidationError):
            _field(IsoDate, "2026-02-30")

    def test_timestamp_in_json_is_rejected(self) -> None:
        with pytest.raises(ValidationError):
            FieldValue[IsoDate].model_validate_json(
                '{"value": 1759276800, "provenance": {"source": "calculated", "producer": "r"}}'
            )


@pytest.mark.security
class TestStrictScalars:
    @pytest.mark.parametrize("value", [True, "2", 2.0])
    def test_line_number_must_be_an_integer(self, value: Any) -> None:
        with pytest.raises(ValidationError):
            InvoiceLine.model_validate({"line_number": value})

    @pytest.mark.parametrize("value", ["yes", "true", 1, 0])
    def test_flag_must_be_a_boolean(self, value: Any) -> None:
        with pytest.raises(ValidationError):
            _field(Flag, value)

    def test_flag_accepts_json_boolean(self) -> None:
        field = FieldValue[Flag].model_validate_json(
            '{"value": true, "provenance": {"source": "calculated", "producer": "r"}}'
        )
        assert field.value is True

    @pytest.mark.parametrize(
        "provenance",
        [
            {"source": "ai_suggested", "producer": "ki/x", "confidence": True},
            {"source": "ai_suggested", "producer": "ki/x", "confidence": "0.5"},
        ],
    )
    def test_confidence_must_be_a_number(self, provenance: dict[str, Any]) -> None:
        with pytest.raises(ValidationError):
            FieldValue[ShortText].model_validate({"value": "x", "provenance": provenance})


@pytest.mark.security
class TestTextHygiene:
    @pytest.mark.parametrize(
        "value",
        [
            "AB\x00C",  # NUL
            "Faktura\x1b[31m",  # terminal escape
            "abc‮dcba",  # right-to-left override
            "a​b",  # zero-width space
            "   ",
            "\t",
        ],
    )
    @pytest.mark.parametrize("text_type", [ShortText, Identifier])
    def test_single_line_text_rejects_hidden_characters(self, text_type: Any, value: str) -> None:
        with pytest.raises(ValidationError):
            _field(text_type, value)

    def test_long_text_allows_line_breaks_and_tabs(self) -> None:
        assert _field(LongText, "Linje 1\n\tLinje 2").value == "Linje 1\n\tLinje 2"

    def test_single_line_text_rejects_line_breaks(self) -> None:
        with pytest.raises(ValidationError):
            _field(ShortText, "Linje 1\nLinje 2")

    def test_norwegian_letters_are_allowed(self) -> None:
        assert _field(ShortText, "Ærlig Øl & Å-gården AS").value == "Ærlig Øl & Å-gården AS"

    def test_raw_text_evidence_is_preserved_unchanged(self) -> None:
        field = FieldValue[ShortText].model_validate(
            {
                "value": None,
                "provenance": {
                    "source": "extracted",
                    "evidence": {"page_number": 1, "raw_text": "AB\x00C"},
                },
            }
        )
        assert field.provenance.evidence is not None
        assert field.provenance.evidence.raw_text == "AB\x00C"


class TestReviewableValues:
    def test_identifier_with_invalid_checksum_is_kept_for_review(
        self, example_invoice_data: dict[str, Any]
    ) -> None:
        # 123456789 has a wrong MOD11 check digit. The contract must still store
        # it so the user can see and correct it; the accounting engine flags it.
        data = copy.deepcopy(example_invoice_data)
        data["supplier"]["org_number"]["value"] = "123456789"
        invoice = CanonicalInvoice.model_validate(data)
        assert invoice.supplier.org_number is not None
        assert invoice.supplier.org_number.value == "123456789"

    def test_inconsistent_totals_are_kept_for_review(
        self, example_invoice_data: dict[str, Any]
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["totals"]["gross_amount"]["value"] = "9999.99"
        invoice = CanonicalInvoice.model_validate(data)
        assert invoice.totals.gross_amount is not None
        assert invoice.totals.gross_amount.value == Decimal("9999.99")


class TestCreditNote:
    def test_credit_note_with_reference_is_valid(
        self, example_invoice_data: dict[str, Any]
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["invoice_type"]["value"] = "credit_note"
        data["referenced_invoice_number"] = {"value": "2026-10001", "provenance": CALCULATED}
        invoice = CanonicalInvoice.model_validate(data)
        assert invoice.invoice_type is not None
        assert invoice.invoice_type.value is InvoiceType.CREDIT_NOTE

    @pytest.mark.parametrize("value", ["kreditnota", "CREDIT_NOTE", "faktura"])
    def test_unknown_invoice_type_is_rejected(
        self, example_invoice_data: dict[str, Any], value: str
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["invoice_type"]["value"] = value
        with pytest.raises(ValidationError):
            CanonicalInvoice.model_validate(data)


@pytest.mark.security
class TestAccountingLineReferences:
    def test_duplicate_references_are_rejected(self, example_invoice_data: dict[str, Any]) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["accounting_lines"][0]["source_line_numbers"] = [1, 1, 2]
        with pytest.raises(ValidationError, match="more than once"):
            CanonicalInvoice.model_validate(data)

    def test_reference_list_is_bounded(self, example_invoice_data: dict[str, Any]) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["accounting_lines"][0]["source_line_numbers"] = [1] * 5001
        with pytest.raises(ValidationError, match="at most 5000"):
            CanonicalInvoice.model_validate(data)
