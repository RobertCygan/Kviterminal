"""Canonical serialisation, content hashes and UTC text (docs/DATA_MODEL.md §4.4)."""

import copy
import datetime as dt
import json
from typing import Any

import pytest

from invoiceflow.domain import CanonicalInvoice, Provenance
from invoiceflow.domain.canonical import (
    canonical_json_bytes,
    content_sha256,
    format_utc,
    invoice_canonical_json,
    parse_utc,
)

pytestmark = pytest.mark.unit


def test_canonical_json_is_sorted_compact_utf8() -> None:
    assert canonical_json_bytes({"b": 1, "a": "Æ"}) == '{"a":"Æ","b":1}'.encode()


def test_canonical_json_rejects_nan() -> None:
    with pytest.raises(ValueError):
        canonical_json_bytes({"x": float("nan")})


def test_hash_is_stable_across_equivalent_inputs(example_invoice_data: dict[str, Any]) -> None:
    variant = copy.deepcopy(example_invoice_data)
    # Same values written differently: number formats, key order, UTC offset.
    variant["totals"]["gross_amount"]["value"] = "5671.250"
    variant["lines"][0]["quantity"]["value"] = "1E+1"
    variant["due_date"]["provenance"]["recorded_at"] = "2026-10-02T07:14:00Z"
    variant = dict(reversed(list(variant.items())))
    original = CanonicalInvoice.model_validate(example_invoice_data)
    other = CanonicalInvoice.model_validate(variant)
    assert invoice_canonical_json(original) == invoice_canonical_json(other)
    assert content_sha256(original) == content_sha256(other)


def test_hash_changes_with_content(example_invoice_data: dict[str, Any]) -> None:
    variant = copy.deepcopy(example_invoice_data)
    variant["totals"]["gross_amount"]["value"] = "5671.26"
    assert content_sha256(CanonicalInvoice.model_validate(example_invoice_data)) != content_sha256(
        CanonicalInvoice.model_validate(variant)
    )


def test_canonical_json_round_trip_is_byte_identical(example_invoice_json: str) -> None:
    invoice = CanonicalInvoice.model_validate_json(example_invoice_json)
    canonical = invoice_canonical_json(invoice)
    again = CanonicalInvoice.model_validate_json(canonical)
    assert again == invoice
    assert invoice_canonical_json(again) == canonical


def test_recorded_at_is_normalised_to_utc() -> None:
    # Regression (Phase 02): one instant with two offsets serialised differently.
    first = Provenance.model_validate(
        {"source": "manual", "producer": "bruker/x", "recorded_at": "2026-10-02T09:14:00+02:00"}
    )
    second = Provenance.model_validate(
        {"source": "manual", "producer": "bruker/x", "recorded_at": "2026-10-02T07:14:00Z"}
    )
    assert first.model_dump_json() == second.model_dump_json()
    assert first.recorded_at is not None
    assert first.recorded_at.utcoffset() == dt.timedelta(0)


def test_negative_zero_confidence_is_normalised() -> None:
    # Regression (Phase 02): -0.0 and 0.0 serialised differently.
    value = Provenance(source="ai_suggested", producer="ki/x", confidence=-0.0)
    assert json.loads(value.model_dump_json())["confidence"] == 0.0
    assert (
        value.model_dump_json()
        == Provenance(source="ai_suggested", producer="ki/x", confidence=0.0).model_dump_json()
    )


@pytest.mark.parametrize(
    "value",
    [
        dt.datetime(1, 1, 1, tzinfo=dt.UTC),
        dt.datetime(2026, 10, 2, 9, 14, 0, 123456, tzinfo=dt.timezone(dt.timedelta(hours=2))),
        dt.datetime(9999, 12, 31, 23, 59, 59, 999999, tzinfo=dt.UTC),
    ],
)
def test_utc_text_round_trip(value: dt.datetime) -> None:
    text = format_utc(value)
    assert len(text) == 27 and text.endswith("Z")
    assert parse_utc(text) == value


def test_utc_text_is_chronologically_sortable() -> None:
    early = dt.datetime(999, 1, 1, tzinfo=dt.UTC)
    late = dt.datetime(2026, 1, 1, tzinfo=dt.UTC)
    assert format_utc(early) < format_utc(late)


def test_naive_datetime_rejected() -> None:
    with pytest.raises(ValueError, match="naive"):
        format_utc(dt.datetime(2026, 1, 1))  # noqa: DTZ001 - deliberately naive


@pytest.mark.parametrize("value", ["2026-01-01", 20260101, dt.date(2026, 1, 1)])
def test_format_utc_rejects_non_datetimes(value: object) -> None:
    with pytest.raises(TypeError):
        format_utc(value)  # type: ignore[arg-type]


@pytest.mark.parametrize(
    "text",
    [
        "2026-10-20T10:00:00Z",
        "2026-10-20T10:00:00.000000+00:00",
        "2026-10-20 10:00:00.000000Z",
        "2026-13-20T10:00:00.000000Z",
        "",
        None,
    ],
)
def test_parse_utc_rejects_other_forms(text: object) -> None:
    with pytest.raises(ValueError):
        parse_utc(text)  # type: ignore[arg-type]


def test_decimal_normalisation_is_independent_of_context() -> None:
    from decimal import Decimal, localcontext

    from invoiceflow.domain.types import fixed_point

    value = Decimal("1.234567")
    with localcontext() as context:
        context.prec = 3
        assert fixed_point(value, 2) == value
        assert str(fixed_point(Decimal("-0.000"), 2)) == "0.00"
        assert str(fixed_point(Decimal("1.230000"), 2)) == "1.23"
        assert str(fixed_point(Decimal("1E+3"), 2)) == "1000.00"


def test_decimal_normalisation_preserves_more_than_28_digits() -> None:
    from decimal import Decimal

    from invoiceflow.domain.types import fixed_point

    value = Decimal("0.123456789012345678901234567891")
    assert fixed_point(value, 2) == value
    with pytest.raises(ValueError, match="finite"):
        fixed_point(Decimal("NaN"), 2)
