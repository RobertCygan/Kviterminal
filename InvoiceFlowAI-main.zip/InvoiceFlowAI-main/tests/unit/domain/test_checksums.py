"""Check digits for organisation numbers, accounts, KID and IBAN (Phase 08a)."""

import pytest

from invoiceflow.domain.checksums import (
    valid_bank_account,
    valid_iban,
    valid_kid,
    valid_org_number,
)

pytestmark = pytest.mark.unit


@pytest.mark.parametrize("value", ["123456785", "314159268", "000000000"])
def test_valid_org_numbers(value: str) -> None:
    assert valid_org_number(value)


@pytest.mark.parametrize(
    "value",
    [
        "123456784",  # wrong check digit
        "12345678",  # too short
        "1234567850",  # too long
        "12345678a",
        "".join(chr(0xFF10 + int(d)) for d in "123456785"),  # full-width digits
    ],
)
def test_invalid_org_numbers(value: str) -> None:
    assert not valid_org_number(value)


def test_an_org_number_whose_remainder_gives_ten_is_never_valid() -> None:
    weights = (3, 2, 7, 6, 5, 4, 3, 2)
    prefix = next(
        f"{number:08d}"
        for number in range(10_000_000, 99_999_999)
        if 11 - sum(int(d) * w for d, w in zip(f"{number:08d}", weights, strict=True)) % 11 == 10
    )
    assert not any(valid_org_number(prefix + digit) for digit in "0123456789")


@pytest.mark.parametrize("value", ["12345678903", "86011117947", "00000000000"])
def test_valid_bank_accounts(value: str) -> None:
    assert valid_bank_account(value)


@pytest.mark.parametrize("value", ["12345678904", "1234567890", "123456789031", "1234567890x"])
def test_invalid_bank_accounts(value: str) -> None:
    assert not valid_bank_account(value)


@pytest.mark.parametrize(
    "value",
    [
        "1234567890128",  # MOD10 (Luhn)
        "79927398713",  # textbook Luhn example
        "12345678903",  # MOD11 with weights 2..7
        "0000000000",
        "18",
    ],
)
def test_valid_kids(value: str) -> None:
    assert valid_kid(value)


def test_mod11_kid_with_dash_check_digit() -> None:
    # Find a body whose MOD11 remainder gives 10; "-" is then the check digit.
    body = next(
        f"{number:05d}"
        for number in range(100_000)
        if 11 - sum(int(d) * (2 + i % 6) for i, d in enumerate(reversed(f"{number:05d}"))) % 11
        == 10
    )
    assert valid_kid(body + "-")


@pytest.mark.parametrize("value", ["1", "12", "1234567890127", "12-4", "-", "a1", "1" * 26])
def test_invalid_kids(value: str) -> None:
    assert not valid_kid(value)


@pytest.mark.parametrize(
    "value", ["NO9386011117947", "GB82WEST12345698765432", "DE89370400440532013000"]
)
def test_valid_ibans(value: str) -> None:
    assert valid_iban(value)


@pytest.mark.parametrize(
    "value",
    [
        "NO9386011117948",  # wrong check
        "NO938601111794",  # too short
        "no9386011117947",  # lower case
        "N19386011117947",
        "NOAB86011117947",
        "NO93 8601 1117 947",
        "GB82WEST12345698765432" + "1" * 13,  # too long
    ],
)
def test_invalid_ibans(value: str) -> None:
    assert not valid_iban(value)


def test_mod11_kid_with_zero_check_digit() -> None:
    body = next(
        f"{number:05d}"
        for number in range(100_000)
        if sum(int(d) * (2 + i % 6) for i, d in enumerate(reversed(f"{number:05d}"))) % 11 == 0
        and not valid_kid(f"{number:05d}1")
    )
    assert valid_kid(body + "0")


def test_iban_with_lower_case_letters_inside_is_invalid() -> None:
    assert not valid_iban("GB82west12345698765432")
