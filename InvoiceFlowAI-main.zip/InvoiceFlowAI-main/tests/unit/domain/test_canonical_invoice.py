"""Contract tests for the canonical invoice model (docs/DATA_MODEL.md)."""

import copy
import json
from decimal import Decimal
from typing import Any

import pytest
from pydantic import ValidationError

from invoiceflow.domain import (
    CanonicalInvoice,
    Evidence,
    FieldValue,
    InvoiceType,
    Provenance,
    ValueSource,
)
from invoiceflow.domain.types import Money, Quantity, UnitPrice, VatRate

pytestmark = pytest.mark.unit

CALCULATED = {"source": "calculated", "producer": "regel/test/1"}


def _value(field: Any) -> Any:
    assert field is not None
    return field.value


class TestExampleInvoice:
    def test_example_json_validates(self, example_invoice_json: str) -> None:
        invoice = CanonicalInvoice.model_validate_json(example_invoice_json)

        assert _value(invoice.invoice_type) is InvoiceType.INVOICE
        assert _value(invoice.invoice_number) == "2026-10045"
        assert _value(invoice.totals.gross_amount) == Decimal("5671.25")
        assert len(invoice.lines) == 3

    def test_example_is_arithmetically_consistent(self, example_invoice_json: str) -> None:
        # Guards the documentation example against internal contradictions.
        invoice = CanonicalInvoice.model_validate_json(example_invoice_json)
        totals = invoice.totals

        line_net = sum((_value(line.net_amount) for line in invoice.lines), Decimal(0))
        line_vat = sum((_value(line.vat_amount) for line in invoice.lines), Decimal(0))
        for line in invoice.lines:
            expected_net = _value(line.quantity) * _value(line.unit_price)
            assert _value(line.net_amount) == expected_net
            expected_vat = (_value(line.net_amount) * _value(line.vat_rate) / 100).quantize(
                Decimal("0.01")
            )
            assert _value(line.vat_amount) == expected_vat

        assert _value(totals.net_amount) == line_net
        assert _value(totals.vat_amount) == line_vat
        assert _value(totals.net_amount) + _value(totals.vat_amount) == _value(totals.gross_amount)
        accounted = sum((_value(line.net_amount) for line in invoice.accounting_lines), Decimal(0))
        assert accounted == _value(totals.net_amount)

    def test_json_round_trip_is_lossless(self, example_invoice_json: str) -> None:
        invoice = CanonicalInvoice.model_validate_json(example_invoice_json)
        assert CanonicalInvoice.model_validate_json(invoice.model_dump_json()) == invoice

    def test_money_is_serialised_as_string(self, example_invoice_json: str) -> None:
        invoice = CanonicalInvoice.model_validate_json(example_invoice_json)
        dumped = json.loads(invoice.model_dump_json())
        assert dumped["totals"]["gross_amount"]["value"] == "5671.25"

    def test_json_schema_can_be_generated(self) -> None:
        schema = CanonicalInvoice.model_json_schema()
        assert schema["additionalProperties"] is False


@pytest.mark.security
class TestRejectsUntrustedShapes:
    def test_unexpected_top_level_field_is_rejected(
        self, example_invoice_data: dict[str, Any]
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["approved"] = True
        with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
            CanonicalInvoice.model_validate(data)

    def test_unexpected_nested_field_is_rejected(
        self, example_invoice_data: dict[str, Any]
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["totals"]["gross_amount"]["provenance"]["instruction"] = "ignore rules"
        with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
            CanonicalInvoice.model_validate(data)

    def test_float_money_in_json_is_rejected(self, example_invoice_json: str) -> None:
        tampered = example_invoice_json.replace('"value": "5671.25"', '"value": 5671.25')
        assert tampered != example_invoice_json
        with pytest.raises(ValidationError, match="never float"):
            CanonicalInvoice.model_validate_json(tampered)

    @pytest.mark.parametrize("value", [0.1, 1e3, True])
    def test_float_and_bool_money_in_python_are_rejected(self, value: object) -> None:
        with pytest.raises(ValidationError, match="never float or bool"):
            FieldValue[Money].model_validate({"value": value, "provenance": CALCULATED})

    @pytest.mark.parametrize("decimal_type", [Money, UnitPrice, Quantity, VatRate])
    @pytest.mark.parametrize("value", ["NaN", "Infinity", "-Infinity", "sNaN"])
    def test_non_finite_decimals_are_rejected(self, decimal_type: Any, value: str) -> None:
        with pytest.raises(ValidationError):
            FieldValue[decimal_type].model_validate({"value": value, "provenance": CALCULATED})

    def test_money_with_too_many_decimals_is_rejected_not_rounded(self) -> None:
        with pytest.raises(ValidationError, match="decimal places"):
            FieldValue[Money].model_validate({"value": "10.005", "provenance": CALCULATED})

    def test_integer_money_is_accepted_exactly(self) -> None:
        field = FieldValue[Money].model_validate({"value": 100, "provenance": CALCULATED})
        assert field.value == Decimal(100)

    def test_too_many_lines_are_rejected(self, example_invoice_data: dict[str, Any]) -> None:
        data = copy.deepcopy(example_invoice_data)
        template = data["lines"][0]
        data["lines"] = [{**template, "line_number": n} for n in range(1, 5002)]
        data["accounting_lines"] = []
        with pytest.raises(ValidationError, match="at most 5000"):
            CanonicalInvoice.model_validate(data)

    def test_overlong_text_is_rejected(self, example_invoice_data: dict[str, Any]) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["supplier"]["name"]["value"] = "A" * 301
        with pytest.raises(ValidationError, match="at most 300"):
            CanonicalInvoice.model_validate(data)

    def test_model_is_immutable(self, example_invoice_json: str) -> None:
        invoice = CanonicalInvoice.model_validate_json(example_invoice_json)
        with pytest.raises(ValidationError, match="frozen"):
            invoice.first_page = 2  # type: ignore[misc]


class TestStructuralRules:
    @pytest.mark.parametrize(
        ("path", "value"),
        [
            (("currency", "value"), "nok"),
            (("supplier", "org_number", "value"), "12345678"),
            (("payment", "bank_account", "value"), "1234.56.78903"),
            (("payment", "kid", "value"), "12A"),
            (("payment", "kid", "value"), "12-4"),
            (("payment", "kid", "value"), "1" * 26),
            (("invoice_date", "value"), "01.10.2026"),
        ],
    )
    def test_non_normalised_values_are_rejected(
        self, example_invoice_data: dict[str, Any], path: tuple[str, ...], value: str
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        target = data
        for key in path[:-1]:
            target = target[key]
        target[path[-1]] = value
        with pytest.raises(ValidationError):
            CanonicalInvoice.model_validate(data)

    @pytest.mark.parametrize("kid", ["12", "1234567890123456789012345", "123456-"])
    def test_valid_kid_shapes_are_accepted(
        self, example_invoice_data: dict[str, Any], kid: str
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["payment"]["kid"]["value"] = kid
        invoice = CanonicalInvoice.model_validate(data)
        assert invoice.payment is not None
        assert _value(invoice.payment.kid) == kid

    def test_unparseable_value_may_be_none_with_raw_text_kept(self) -> None:
        field = FieldValue[Money].model_validate(
            {
                "value": None,
                "provenance": {
                    "source": "extracted",
                    "evidence": {"page_number": 1, "raw_text": "1.234,5O"},
                },
            }
        )
        assert field.value is None
        assert field.provenance.evidence is not None
        assert field.provenance.evidence.raw_text == "1.234,5O"

    def test_duplicate_line_numbers_are_rejected(
        self, example_invoice_data: dict[str, Any]
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["lines"][1]["line_number"] = 1
        with pytest.raises(ValidationError, match="invoice line numbers must be unique"):
            CanonicalInvoice.model_validate(data)

    def test_duplicate_accounting_line_numbers_are_rejected(
        self, example_invoice_data: dict[str, Any]
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["accounting_lines"].append(copy.deepcopy(data["accounting_lines"][0]))
        with pytest.raises(ValidationError, match="accounting line numbers must be unique"):
            CanonicalInvoice.model_validate(data)

    def test_accounting_line_must_reference_existing_lines(
        self, example_invoice_data: dict[str, Any]
    ) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["accounting_lines"][0]["source_line_numbers"] = [1, 9]
        with pytest.raises(ValidationError, match=r"unknown invoice lines: \[9\]"):
            CanonicalInvoice.model_validate(data)

    def test_page_range_must_be_ordered(self, example_invoice_data: dict[str, Any]) -> None:
        data = copy.deepcopy(example_invoice_data)
        data["first_page"] = 3
        data["last_page"] = 2
        with pytest.raises(ValidationError, match="last_page"):
            CanonicalInvoice.model_validate(data)


class TestProvenanceRules:
    def test_extracted_requires_evidence(self) -> None:
        with pytest.raises(ValidationError, match="require evidence"):
            Provenance(source=ValueSource.EXTRACTED, producer="tesseract/5.5")

    @pytest.mark.parametrize(
        "source", [ValueSource.AI_SUGGESTED, ValueSource.CALCULATED, ValueSource.MANUAL]
    )
    def test_non_extracted_requires_producer(self, source: ValueSource) -> None:
        with pytest.raises(ValidationError, match="require a producer"):
            Provenance(source=source)

    @pytest.mark.parametrize("source", [ValueSource.CALCULATED, ValueSource.MANUAL])
    def test_deterministic_sources_have_no_confidence(self, source: ValueSource) -> None:
        with pytest.raises(ValidationError, match="must not carry a confidence"):
            Provenance(source=source, producer="x", confidence=0.5)

    @pytest.mark.parametrize("confidence", [-0.01, 1.01, float("nan")])
    def test_confidence_is_bounded(self, confidence: float) -> None:
        with pytest.raises(ValidationError):
            Provenance(source=ValueSource.AI_SUGGESTED, producer="ki/x", confidence=confidence)

    def test_evidence_requires_a_location(self) -> None:
        with pytest.raises(ValidationError, match="page_number or source_ref"):
            Evidence(raw_text="42")

    def test_bbox_requires_page(self) -> None:
        with pytest.raises(ValidationError, match="bbox requires page_number"):
            Evidence.model_validate(
                {"source_ref": "x", "bbox": {"x0": 0, "y0": 0, "x1": 1, "y1": 1}}
            )

    @pytest.mark.parametrize(
        "bbox",
        [
            {"x0": 0.5, "y0": 0.1, "x1": 0.4, "y1": 0.2},
            {"x0": 0.1, "y0": 0.1, "x1": 1.5, "y1": 0.2},
        ],
    )
    def test_invalid_bbox_is_rejected(self, bbox: dict[str, float]) -> None:
        with pytest.raises(ValidationError):
            Evidence.model_validate({"page_number": 1, "bbox": bbox})

    def test_recorded_at_must_be_timezone_aware(self) -> None:
        with pytest.raises(ValidationError, match="timezone"):
            Provenance.model_validate(
                {"source": "manual", "producer": "bruker/lokal", "recorded_at": "2026-10-02T09:14"}
            )
