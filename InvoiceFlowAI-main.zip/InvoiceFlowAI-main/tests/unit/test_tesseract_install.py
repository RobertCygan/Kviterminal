"""Finding Tesseract and naming its version, with stand-in programs (Phase 05)."""

import sys
from pathlib import Path

import pytest

from invoiceflow.application.processing_model import OcrSettings
from invoiceflow.processing import tesseract_install
from invoiceflow.processing.tesseract_install import TesseractInstall, locate, probe

pytestmark = [
    pytest.mark.unit,
    pytest.mark.skipif(sys.platform == "win32", reason="stand-ins are shell scripts"),
]


def stand_in(tmp_path: Path, version: str, languages: str, *, name: str = "tesseract") -> Path:
    tessdata = tmp_path / "tessdata"
    tessdata.mkdir(exist_ok=True)
    (tessdata / "nor.traineddata").write_bytes(b"synthetic language data")
    path = tmp_path / name
    path.write_text(
        "#!/bin/sh\n"
        'if [ "$1" = "--version" ]; then echo "' + version + '"; exit 0; fi\n'
        f"echo 'List of available languages in \"{tessdata}/\" (2):'\n"
        f"printf '{languages}'\n",
        encoding="utf-8",
    )
    path.chmod(0o755)
    return path


def test_a_tesseract_is_described_by_version_and_language_data(tmp_path) -> None:
    install = probe(stand_in(tmp_path, "tesseract 5.3.4\n leptonica-1.82.0", "eng\\nnor\\n"))

    assert install is not None
    assert (install.version, install.languages) == ("5.3.4", frozenset({"eng", "nor"}))
    version = install.engine_version(OcrSettings())
    assert version is not None and version.startswith("5.3.4+ocr1+") and len(version) <= 32
    (install.tessdata / "nor.traineddata").write_bytes(b"other language data")
    assert install.engine_version(OcrSettings()) != version  # new data, new OCR run


def test_windows_build_versions_are_accepted(tmp_path) -> None:
    install = probe(stand_in(tmp_path, "tesseract v5.3.0.20221214", "nor\\n"))
    assert install is not None and install.version == "5.3.0.20221214"
    version = install.engine_version(OcrSettings())
    assert version is not None and len(version) <= 32


@pytest.mark.parametrize(
    "version,languages",
    [
        ("tesseract 4.1.1", "nor\\n"),  # too old
        ("something else", "nor\\n"),
    ],
)
def test_unusable_programs_are_not_used(tmp_path, version, languages) -> None:
    assert probe(stand_in(tmp_path, version, languages)) is None


def test_a_missing_language_means_no_ocr(tmp_path) -> None:
    install = probe(stand_in(tmp_path, "tesseract 5.3.4", "eng\\n"))
    assert install is not None and install.engine_version(OcrSettings()) is None
    assert install.engine_version(OcrSettings(language="nor+eng")) is None


def test_missing_and_failing_programs_are_skipped(tmp_path) -> None:
    failing = tmp_path / "failing"
    failing.write_text("#!/bin/sh\nexit 1\n", encoding="utf-8")
    failing.chmod(0o755)
    good = stand_in(tmp_path, "tesseract 5.4.0", "nor\\n", name="good")

    assert probe(tmp_path / "missing") is None and probe(failing) is None
    found = locate([tmp_path / "missing", failing, good])
    assert isinstance(found, TesseractInstall) and found.executable == good
    assert locate([failing]) is None


def test_outside_windows_the_path_is_searched(monkeypatch) -> None:
    monkeypatch.setattr(tesseract_install.shutil, "which", lambda name: "/opt/bin/tesseract")
    assert tesseract_install.default_candidates() == [Path("/opt/bin/tesseract")]
    monkeypatch.setattr(tesseract_install.shutil, "which", lambda name: None)
    assert tesseract_install.default_candidates() == []


def test_on_windows_only_fixed_folders_are_searched(monkeypatch) -> None:
    monkeypatch.setattr(tesseract_install.sys, "platform", "win32")
    monkeypatch.setenv("PROGRAMFILES", "/programs")
    called = []
    monkeypatch.setattr(tesseract_install.shutil, "which", lambda name: called.append(name))
    candidates = tesseract_install.default_candidates()
    assert candidates[-1] == Path("/programs") / "Tesseract-OCR" / "tesseract.exe"
    assert candidates[0].parent.name == "tesseract" and not called
