"""Tesseract inside the worker, with a stand-in program (Phase 05, ADR-0040).

The stand-in prints fixed TSV, so parsing, limits and failures are tested
without Tesseract; the real engine is covered by the ``tesseract`` tests.
"""

import hashlib
import json
import sys
from pathlib import Path

import pytest

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.ports import OcrInput, OcrTask, WorkerTask
from invoiceflow.application.processing_model import (
    MAX_WORD_CHARS,
    OcrLayer,
    OcrReport,
    OcrSettings,
    ProcessingErrorCode,
    ProcessingLimits,
    ocr_input_name,
    ocr_name,
)
from invoiceflow.processing import ocr_tesseract
from invoiceflow.processing.ocr_tesseract import (
    TSV_COLUMNS,
    child_environment,
    clean_word,
    page_text,
    parse_tsv,
    run_tesseract,
)
from invoiceflow.processing.parser import ParserError
from invoiceflow.processing.worker import analyse

pytestmark = pytest.mark.unit
posix_only = pytest.mark.skipif(sys.platform == "win32", reason="stand-in is a shell script")

HEADER = "\t".join(TSV_COLUMNS)


def row(level, block, par, line, word, left, top, width, height, conf, text) -> str:
    return "\t".join(
        str(v) for v in (level, 1, block, par, line, word, left, top, width, height, conf, text)
    )


TSV = "\n".join(
    [
        HEADER,
        row(1, 0, 0, 0, 0, 0, 0, 1000, 2000, -1, ""),
        row(4, 1, 1, 1, 0, 100, 100, 800, 40, -1, ""),
        row(5, 1, 1, 1, 1, 100, 100, 200, 40, 96.4, "Faktura"),
        row(5, 1, 1, 1, 2, 320, 100, 100, 40, 41.6, "2026-0417"),
        row(5, 1, 1, 2, 1, 100, 160, 300, 40, 90, "Å betale"),
        row(5, 1, 1, 2, 2, 420, 160, 50, 40, 88, "   "),  # empty after cleaning
        row(5, 2, 1, 1, 1, 100, 400, 150, 40, 101.0, "NOK"),
    ]
).encode()


def test_words_lines_boxes_and_confidence_are_read() -> None:
    words = parse_tsv(TSV, 1000, 2000)

    assert [(w.text, w.line, w.confidence) for w in words] == [
        ("Faktura", 0, 96),
        ("2026-0417", 0, 42),
        ("Å betale", 1, 90),
        ("NOK", 2, 100),  # clamped
    ]
    assert words[0].box == (0.1, 0.05, 0.3, 0.07)
    assert page_text(words) == "Faktura 2026-0417\nÅ betale\nNOK"


@pytest.mark.parametrize(
    "data",
    [
        b"",
        b"level\tpage_num\n",
        (HEADER + "\n" + "5\t1\t1").encode(),
        (HEADER + "\n" + row(5, 1, 1, 1, 1, -5, 0, 10, 10, 90, "x")).encode(),
        (HEADER + "\n" + row(5, 1, 1, 1, 1, 0, 0, 10, 10, "nan", "x")).encode(),
        (HEADER + "\n" + row(5, "a", 1, 1, 1, 0, 0, 10, 10, 90, "x")).encode(),
    ],
    ids=["empty", "header", "short_row", "negative", "nan", "not_a_number"],
)
def test_malformed_tsv_is_ocr_failed(data: bytes) -> None:
    with pytest.raises(ParserError) as raised:
        parse_tsv(data, 100, 100)
    assert raised.value.code is ProcessingErrorCode.OCR_FAILED


def test_too_many_words_is_too_much_text(monkeypatch) -> None:
    monkeypatch.setattr(ocr_tesseract, "MAX_OCR_WORDS", 2)
    with pytest.raises(ParserError) as raised:
        parse_tsv(TSV, 1000, 2000)
    assert raised.value.code is ProcessingErrorCode.TOO_MUCH_TEXT


def test_words_are_cleaned() -> None:
    assert clean_word("A\N{COMBINING RING ABOVE}") == "\N{LATIN CAPITAL LETTER A WITH RING ABOVE}"
    replaced = clean_word(" a\N{NULL}b\N{RIGHT-TO-LEFT OVERRIDE} ")
    assert replaced == "a\N{REPLACEMENT CHARACTER}b\N{REPLACEMENT CHARACTER}"
    assert clean_word("x" * 500) == "x" * MAX_WORD_CHARS
    assert clean_word("\t \n") == ""


def test_the_child_gets_a_minimal_environment(monkeypatch) -> None:
    monkeypatch.setenv("SECRET_TOKEN", "x")
    environment = child_environment(Path("/data/tessdata"))
    assert environment["OMP_THREAD_LIMIT"] == "1"
    assert environment["TESSDATA_PREFIX"] == str(Path("/data/tessdata"))
    assert "SECRET_TOKEN" not in environment and "PATH" not in environment


def stand_in(tmp_path: Path, body: str) -> Path:
    path = tmp_path / "tesseract"
    path.write_text("#!/bin/sh\ncat > /dev/null\n" + body + "\n", encoding="utf-8")
    path.chmod(0o755)
    return path


@posix_only
@pytest.mark.parametrize(
    "body,code",
    [
        ("exit 3", ProcessingErrorCode.OCR_FAILED),
        ("sleep 5", ProcessingErrorCode.OCR_FAILED),
        ("head -c 2048 /dev/zero", ProcessingErrorCode.OUTPUT_TOO_LARGE),
    ],
    ids=["exit", "timeout", "output"],
)
def test_engine_failures_have_stable_codes(tmp_path, monkeypatch, body, code) -> None:
    monkeypatch.setattr(ocr_tesseract, "MAX_TSV_BYTES", 1024)
    with pytest.raises(ParserError) as raised:
        run_tesseract(stand_in(tmp_path, body), None, OcrSettings(), b"png", 0.5)
    assert raised.value.code is code


def test_a_missing_program_is_ocr_failed(tmp_path) -> None:
    with pytest.raises(ParserError) as raised:
        run_tesseract(tmp_path / "missing", None, OcrSettings(), b"png", 1)
    assert raised.value.code is ProcessingErrorCode.OCR_FAILED


def ocr_task(tmp_path: Path, executable: Path | None, *, sha: str | None = None, **limits):
    output = tmp_path / "work"
    output.mkdir(parents=True)
    png = b"\x89PNG synthetic"
    (output / ocr_input_name(1)).write_bytes(png)
    page = OcrInput(1, ocr_input_name(1), sha or hashlib.sha256(png).hexdigest(), 1000, 2000)
    return WorkerTask(
        output / ocr_input_name(1),
        "a" * 64,
        DocumentFormat.PNG,
        output,
        ProcessingLimits(**limits),
        OcrTask(OcrSettings(), (page,), 5.0, executable, None, "5.3.4+ocr1+00000000"),
    )


@posix_only
def test_the_worker_writes_one_validated_layer_per_page(tmp_path) -> None:
    tsv = TSV.decode().replace("\t", "\\t").replace("\n", "\\n")
    task = ocr_task(tmp_path, stand_in(tmp_path, f"printf '{tsv}'"))

    report = OcrReport.model_validate_json(analyse(task))

    assert report.status == "ok" and report.engine_version == "5.3.4+ocr1+00000000"
    [page] = report.pages
    layer = OcrLayer.model_validate_json((task.output_dir / ocr_name(1)).read_bytes())
    assert layer.text() == "Faktura 2026-0417\nÅ betale\nNOK"
    assert (page.word_count, page.line_count, page.char_count) == (4, 3, len(layer.text()))
    assert (page.mean_confidence, page.low_confidence_words) == (82, 1)


@posix_only
def test_too_much_text_for_the_limits_is_refused(tmp_path) -> None:
    tsv = TSV.decode().replace("\t", "\\t").replace("\n", "\\n")
    task = ocr_task(tmp_path, stand_in(tmp_path, f"printf '{tsv}'"), max_chars_per_page=5)
    assert json.loads(analyse(task))["error_code"] == "too_much_text"


def test_a_changed_or_missing_page_image_is_not_read(tmp_path) -> None:
    changed = ocr_task(tmp_path / "a", Path("/bin/true"), sha="0" * 64)
    assert json.loads(analyse(changed))["error_code"] == "source_changed"
    missing = ocr_task(tmp_path / "b", Path("/bin/true"))
    (missing.output_dir / ocr_input_name(1)).unlink()
    assert json.loads(analyse(missing))["error_code"] == "source_changed"


def test_without_a_program_the_worker_reports_ocr_failed(tmp_path) -> None:
    report = json.loads(analyse(ocr_task(tmp_path, None)))
    assert (report["status"], report["error_code"]) == ("error", "ocr_failed")
