"""Encrypted stream, backup archive and data folder (Phase 12)."""

import contextlib
import io
import os
import struct
import tarfile
from uuid import UUID

import pytest

from invoiceflow.application.backup.model import (
    MAGIC,
    MIN_CHUNK,
    BackupError,
    BackupHeader,
    Manifest,
)
from invoiceflow.backup.archive import FileBackupArchive
from invoiceflow.backup.crypto import TAG_BYTES, DecryptingReader, EncryptingWriter, derive_key
from invoiceflow.config.paths import AppPaths

ENTITY = "a" * 32
HEADER = BackupHeader(
    UUID("00000000-0000-4000-8000-0000000000b1"),
    "2026-10-24T10:00:00.000000Z",
    bytes(range(16)),
    bytes(range(8)),
    scrypt_n=2**10,
    chunk_size=MIN_CHUNK,
)
KEY = derive_key(b"en lang passordfrase", HEADER)


def encrypt(plain: bytes, header: BackupHeader = HEADER, key: bytes = KEY) -> bytes:
    raw = io.BytesIO()
    writer = EncryptingWriter(raw, key, header)
    writer.write(plain)
    writer.close()
    writer.close()  # idempotent
    return raw.getvalue()


def decrypt(data: bytes, header: BackupHeader = HEADER, key: bytes = KEY) -> bytes:
    return DecryptingReader(io.BytesIO(data), key, header).read()


@pytest.mark.parametrize("size", [0, 1, MIN_CHUNK - 1, MIN_CHUNK, MIN_CHUNK + 1, 3 * MIN_CHUNK])
def test_every_size_round_trips_and_ends_with_a_final_chunk(size: int) -> None:
    plain = os.urandom(size)
    data = encrypt(plain)
    chunks = max(1, -(-size // MIN_CHUNK))
    assert len(data) == size + chunks * TAG_BYTES
    assert decrypt(data) == plain


def test_the_key_depends_on_passphrase_and_salt() -> None:
    other = BackupHeader(HEADER.backup_id, HEADER.created_at, bytes(16), HEADER.nonce_prefix, 2**10)
    assert derive_key(b"en lang passordfrase", other) != KEY
    assert derive_key(b"en annen passordfrase", HEADER) != KEY
    assert len(KEY) == 32


def test_any_change_is_refused() -> None:
    plain = os.urandom(2 * MIN_CHUNK + 10)
    data = encrypt(plain)
    size = MIN_CHUNK + TAG_BYTES
    first, second, last = data[:size], data[size : 2 * size], data[2 * size :]
    flipped = bytearray(data)
    flipped[size + 5] ^= 1
    cases = {
        "flipped byte": bytes(flipped),
        "swapped chunks": second + first + last,
        "dropped chunk": first + last,
        "cut at a chunk boundary": first + second,
        "cut inside a chunk": data[:-1],
        "appended data": data + b"x",
        "empty": b"",
    }
    for name, broken in cases.items():
        with pytest.raises(BackupError):
            decrypt(broken)
        assert name
    with pytest.raises(BackupError) as caught:
        decrypt(data, key=derive_key(b"feil passordfrase!", HEADER))
    assert caught.value.reason == "passphrase_or_damaged"
    changed = BackupHeader(
        HEADER.backup_id,
        "2026-10-24T10:00:01.000000Z",
        HEADER.salt,
        HEADER.nonce_prefix,
        2**10,
        chunk_size=MIN_CHUNK,
    )
    with pytest.raises(BackupError):
        decrypt(data, header=changed)


@pytest.fixture
def data_dir(tmp_path):
    paths = AppPaths.resolve(tmp_path / "data")
    paths.ensure()
    originals = paths.documents / ENTITY / "originals" / "ab" / "cd"
    originals.mkdir(parents=True)
    (originals / ("b" * 64 + ".pdf")).write_bytes(b"%PDF syntetisk")
    for skipped in ("staging", "work"):
        (paths.documents / ENTITY / skipped).mkdir()
        (paths.documents / ENTITY / skipped / "x.part").write_bytes(b"temporary")
    exports = paths.exports / ENTITY
    exports.mkdir(parents=True)
    (exports / "fakturaeksport-00001-20261024-093400.csv").write_bytes(b"a;b")
    (exports / ".0123.part").write_bytes(b"half")
    paths.config_file.write_text("{}", encoding="utf-8")
    return paths


def test_data_files_skip_temporary_work_and_links(data_dir, tmp_path) -> None:
    outside = tmp_path / "secret.txt"
    outside.write_bytes(b"not ours")
    with contextlib.suppress(OSError):  # Windows without developer mode
        (data_dir.documents / ENTITY / "originals" / "link.pdf").symlink_to(outside)
    names = [name for name, _ in FileBackupArchive(data_dir).data_files()]
    assert names == [
        f"documents/{ENTITY}/originals/ab/cd/{'b' * 64}.pdf",
        f"exports/{ENTITY}/fakturaeksport-00001-20261024-093400.csv",
        "config/config.json",
    ]


def manifest_for(entries):
    return Manifest(HEADER.backup_id, HEADER.created_at, "0009_backup", 1, "0" * 64, entries)


def test_a_backup_round_trips_into_an_empty_folder(data_dir, tmp_path) -> None:
    archive = FileBackupArchive(data_dir)
    destination = tmp_path / "ut" / "kopi.ifbak"
    destination.parent.mkdir()
    digest, size, manifest = archive.write(
        destination, HEADER, KEY, archive.data_files(), manifest_for
    )
    assert destination.read_bytes().startswith(MAGIC) and size == destination.stat().st_size
    assert archive.file_sha256(destination) == digest
    assert list(destination.parent.iterdir()) == [destination]  # no temporary file left
    with pytest.raises(BackupError) as caught:
        archive.write(destination, HEADER, KEY, [], manifest_for)
    assert caught.value.reason == "exists"
    assert archive.read_header(destination) == HEADER

    target = tmp_path / "gjenopprettet"
    archive.prepare_target(target)
    restored, written = archive.extract(destination, HEADER, KEY, target)
    assert restored == manifest
    assert set(written) == {entry.path for entry in manifest.entries}
    assert (target / "config" / "config.json").read_text(encoding="utf-8") == "{}"


def test_targets_must_be_empty_and_outside_the_data_folder(data_dir, tmp_path) -> None:
    archive = FileBackupArchive(data_dir)
    for inside in (data_dir.data, data_dir.data / "gjenopprett", tmp_path):
        with pytest.raises(BackupError) as caught:
            archive.prepare_target(inside)
        assert caught.value.reason == "target_inside_data"
    full = tmp_path / "full"
    full.mkdir()
    (full / "x").write_bytes(b"x")
    with pytest.raises(BackupError) as caught:
        archive.prepare_target(full)
    assert caught.value.reason == "not_empty"
    (full / "dir").mkdir()
    (full / "dir" / "y").write_bytes(b"y")
    archive.clear(full)
    assert list(full.iterdir()) == []


def test_work_folders_are_removed(data_dir) -> None:
    archive = FileBackupArchive(data_dir)
    assert archive.discard_workspaces() == 0
    with archive.workspace() as work:
        (work / "invoiceflow.sqlite3").write_bytes(b"copy")
        assert work.is_dir()
    assert not work.exists()
    leftover = data_dir.data / "backups" / "work" / "crash"
    leftover.mkdir(parents=True)
    (leftover / "invoiceflow.sqlite3").write_bytes(b"unencrypted")
    assert archive.discard_workspaces() == 1 and not leftover.exists()


def forged(tmp_path, members, *, header: BackupHeader = HEADER):
    """A correctly encrypted file around a hand-made tar (needs the passphrase)."""
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name, data, kind in members:
            info = tarfile.TarInfo(name)
            info.type = kind
            info.size = len(data) if kind == tarfile.REGTYPE else 0
            if kind == tarfile.SYMTYPE:
                info.linkname = "/etc/passwd"
            archive.addfile(info, io.BytesIO(data) if kind == tarfile.REGTYPE else None)
    header_bytes = header.to_bytes()
    path = tmp_path / "forged.ifbak"
    path.write_bytes(
        MAGIC + struct.pack(">I", len(header_bytes)) + header_bytes + encrypt(buffer.getvalue())
    )
    return path


MANIFEST = manifest_for(()).to_bytes()


@pytest.mark.parametrize(
    "members",
    [
        [("../../evil.txt", b"x", tarfile.REGTYPE), ("manifest.json", MANIFEST, tarfile.REGTYPE)],
        [("/etc/evil", b"x", tarfile.REGTYPE), ("manifest.json", MANIFEST, tarfile.REGTYPE)],
        [("config/link", b"", tarfile.SYMTYPE), ("manifest.json", MANIFEST, tarfile.REGTYPE)],
        [("config/dir", b"", tarfile.DIRTYPE), ("manifest.json", MANIFEST, tarfile.REGTYPE)],
        [
            ("config/a.json", b"1", tarfile.REGTYPE),
            ("config/a.json", b"2", tarfile.REGTYPE),
            ("manifest.json", MANIFEST, tarfile.REGTYPE),
        ],
        [("manifest.json", MANIFEST, tarfile.REGTYPE), ("config/late", b"x", tarfile.REGTYPE)],
        [("config/a.json", b"1", tarfile.REGTYPE)],
        [("manifest.json", b"{}", tarfile.REGTYPE)],
    ],
    ids=["traversal", "absolute", "symlink", "directory", "duplicate", "after", "none", "bad"],
)
def test_hostile_archives_are_refused_without_writing_outside(data_dir, tmp_path, members):
    path = forged(tmp_path, members)
    target = tmp_path / "mål"
    target.mkdir()
    with pytest.raises(BackupError):
        FileBackupArchive(data_dir).extract(path, HEADER, KEY, target)
    assert not (tmp_path / "evil.txt").exists()


@pytest.mark.parametrize(
    "content,reason",
    [
        (b"", "not_a_backup"),
        (b"PK\x03\x04 zip", "not_a_backup"),
        (MAGIC + struct.pack(">I", 0), "damaged"),
        (MAGIC + struct.pack(">I", 99999), "damaged"),
        (MAGIC + struct.pack(">I", 10) + b"{}", "damaged"),
    ],
)
def test_headers_are_checked_before_anything_is_decrypted(data_dir, tmp_path, content, reason):
    path = tmp_path / "x.ifbak"
    path.write_bytes(content)
    with pytest.raises(BackupError) as caught:
        FileBackupArchive(data_dir).read_header(path)
    assert caught.value.reason == reason
    with pytest.raises(BackupError) as caught:
        FileBackupArchive(data_dir).read_header(tmp_path / "missing.ifbak")
    assert caught.value.reason == "unreadable"
