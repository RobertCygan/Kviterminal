"""Bootstrap validation, safe logging, formatting and CLI regressions."""

import json
from datetime import date
from decimal import Decimal

import pytest

from invoiceflow.__main__ import main
from invoiceflow.application.errors import InvoiceFlowError
from invoiceflow.bootstrap.logging_setup import close_logging, setup_logging
from invoiceflow.config.paths import AppPaths
from invoiceflow.config.settings import BootstrapConfig, load_config
from invoiceflow.i18n import t
from invoiceflow.i18n.catalog_nb_no import CATALOG
from invoiceflow.i18n.formatting import format_amount, format_date, format_percent
from invoiceflow.security.redaction import redact


def test_atomic_default_config_and_roundtrip(tmp_path):
    path = tmp_path / "config.json"
    config = load_config(path)
    assert config == BootstrapConfig()
    assert load_config(path) == config
    assert json.loads(path.read_text(encoding="utf-8")) == {
        "schema_version": 1,
        "log_level": "INFO",
        "locale": "nb-NO",
    }
    assert list(tmp_path.iterdir()) == [path]


@pytest.mark.parametrize(
    "raw",
    [
        "{",
        '{"api_key":"synthetic"}',
        '{"schema_version":true}',
        '{"schema_version":1.0}',
        '{"schema_version":2}',
        '{"log_level":"TRACE"}',
        '{"locale":"en"}',
        "[]",
        " " * 65537,
    ],
    ids=["json", "unknown", "bool", "float", "version", "level", "locale", "array", "oversized"],
)
def test_invalid_config_is_preserved(tmp_path, raw):
    path = tmp_path / "config.json"
    path.write_text(raw, encoding="utf-8")
    with pytest.raises(InvoiceFlowError) as error:
        load_config(path)
    assert error.value.code == "CONFIG_INVALID"
    assert path.read_text(encoding="utf-8") == raw


def test_paths_and_synced_detection(tmp_path, monkeypatch):
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    assert AppPaths.resolve().data == tmp_path / "InvoiceFlowAI"
    monkeypatch.setenv("OneDrive", str(tmp_path / "cloud"))
    paths = AppPaths.resolve(tmp_path / "cloud" / "data")
    paths.ensure()
    assert paths.is_synced()
    assert not AppPaths.resolve(tmp_path / "cloud-other").is_synced()
    assert {p.name for p in paths.data.iterdir()} == {
        "config",
        "logs",
        "database",
        "backups",
        "documents",
        "inbox",
        "exports",
    }
    monkeypatch.delenv("LOCALAPPDATA")
    with pytest.raises(InvoiceFlowError, match="DATA_DIR_UNAVAILABLE"):
        AppPaths.resolve()


def test_unavailable_data_directory(tmp_path):
    path = tmp_path / "file"
    path.write_text("occupied", encoding="utf-8")
    with pytest.raises(InvoiceFlowError, match="DATA_DIR_UNAVAILABLE"):
        AppPaths.resolve(path).ensure()


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (Decimal("1234.5"), "1\u00a0234,50"),
        (Decimal("-0.005"), "-0,01"),
        (0, "0,00"),
        (Decimal("1234567890123.455"), "1\u00a0234\u00a0567\u00a0890\u00a0123,46"),
    ],
)
def test_amount_format(value, expected):
    assert format_amount(value) == expected


@pytest.mark.parametrize("function", [format_amount, format_percent])
@pytest.mark.parametrize("value", [True, False, 1.5, "25"])
def test_inexact_types_rejected(function, value):
    with pytest.raises(TypeError):
        function(value)


@pytest.mark.parametrize("value", [Decimal("NaN"), Decimal("Infinity"), Decimal("1e1001")])
def test_nonfinite_and_unbounded_display_rejected(value):
    with pytest.raises(ValueError):
        format_amount(value)


def test_date_percent_and_catalog():
    assert format_percent(Decimal("25")) == "25\u00a0%"
    assert format_percent(Decimal("25.500")) == "25,5\u00a0%"
    assert format_date(date(2026, 1, 2)) == "02.01.2026"
    assert format_date(date(2026, 12, 31)) == "31.12.2026"
    with pytest.raises(TypeError):
        format_date("2026-01-02")
    assert all(isinstance(text, str) and text for text in CATALOG.values())
    with pytest.raises(KeyError):
        t("missing")
    assert t("self_test.failed", code="TEST") == "Selvtest feilet: TEST"


@pytest.mark.parametrize(
    "value",
    ["123456785", "12345678903", "1234.56.78903", "NO7112345678903", "synthetic@example.invalid"],
)
def test_sensitive_patterns_masked(value):
    assert value not in redact(value)


def test_identifiers_and_timestamps_preserved():
    value = "DATA_DIR_SYNCED 2026-10-20T10:00:00Z 01234567-89ab-cdef-0123-456789abcdef"
    assert redact(value) == value


def test_json_logging_drops_traceback_and_unapproved_extras(tmp_path):
    logger = setup_logging(tmp_path, "DEBUG")
    try:
        raise ValueError("synthetic document contents")
    except ValueError:
        logger.exception("event %s", "synthetic@example.invalid", extra={"secret": "never emit"})
    close_logging(logger)
    row = json.loads((tmp_path / "invoiceflow.log").read_text(encoding="utf-8"))
    assert "example.invalid" not in row["event"]
    assert set(row) == {"timestamp", "level", "event"}
    assert "synthetic document contents" not in json.dumps(row)
    assert logger.propagate is False
    assert logger.handlers == []


def test_cli_rejects_unknown_arguments_without_echo(capsys):
    assert main(["--synthetic-private-value"]) == 2
    assert "synthetic-private-value" not in capsys.readouterr().err


def test_cli_maps_expected_errors(monkeypatch):
    import invoiceflow.bootstrap.app as app

    for code, result in [("CONFIG_INVALID", 2), ("ALREADY_RUNNING", 3), ("UNEXPECTED", 1)]:

        def fail(*args, code=code):
            raise InvoiceFlowError(code, "error.unexpected")

        monkeypatch.setattr(app, "run", fail)
        assert main([]) == result
        assert main(["--self-test"]) == 1


def test_config_write_failure_and_cleanup(tmp_path, monkeypatch):
    from invoiceflow.config import settings

    def fail(*args):
        raise OSError("synthetic disk failure")

    monkeypatch.setattr(settings.os, "replace", fail)
    with pytest.raises(InvoiceFlowError, match="DATA_DIR_UNAVAILABLE"):
        load_config(tmp_path / "config.json")
    assert list(tmp_path.iterdir()) == []


def test_json_log_metadata_is_masked(tmp_path):
    logger = setup_logging(tmp_path, "INFO")
    logger.error(
        "app.error",
        extra={
            "code": "UNEXPECTED",
            "correlation_id": "12345678903",
            "exception_type": "ValueError",
        },
    )
    close_logging(logger)
    row = json.loads((tmp_path / "invoiceflow.log").read_text(encoding="utf-8"))
    assert row["correlation_id"] == "«maskert»"
    assert row["exception_type"] == "ValueError"


def test_path_resolution_failure(monkeypatch):
    from pathlib import Path

    def fail(*args, **kwargs):
        raise OSError("synthetic path failure")

    monkeypatch.setattr(Path, "resolve", fail)
    with pytest.raises(InvoiceFlowError, match="DATA_DIR_UNAVAILABLE"):
        AppPaths.resolve("synthetic")


def test_cli_unexpected_failure(monkeypatch, capsys):
    import invoiceflow.bootstrap.app as app

    def fail(*args):
        raise RuntimeError("private synthetic contents")

    monkeypatch.setattr(app, "run", fail)
    assert main([]) == 1
    assert "private synthetic contents" not in capsys.readouterr().err
    assert main(["--self-test"]) == 1


def test_linked_configuration_file_rejected(tmp_path, monkeypatch):
    from pathlib import Path

    original = Path.is_symlink
    monkeypatch.setattr(
        Path, "is_symlink", lambda self: self.name == "config.json" or original(self)
    )
    with pytest.raises(InvoiceFlowError, match="DATA_DIR_UNAVAILABLE"):
        AppPaths.resolve(tmp_path).ensure()


def test_help_uses_norwegian_catalog(capsys):
    with pytest.raises(SystemExit) as result:
        main(["--help"])
    assert result.value.code == 0
    assert capsys.readouterr().out == t("cli.help_text")
