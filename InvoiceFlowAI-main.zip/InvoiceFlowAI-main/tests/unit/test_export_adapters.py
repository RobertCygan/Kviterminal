"""CSV and Excel writers and the export folder (Phase 10)."""

import datetime as dt
import io
import os
import stat
from decimal import Decimal
from uuid import UUID

import openpyxl
import pytest

from invoiceflow.application.errors import StorageError
from invoiceflow.application.export.model import ExportSheet, FieldKind
from invoiceflow.export.csv_writer import CsvWriter, csv_text
from invoiceflow.export.files import FileExportStore
from invoiceflow.export.xlsx_writer import DATE_FORMAT, MONEY_FORMAT, XlsxWriter

ENTITY = UUID("00000000-0000-4000-8000-0000000000e1")
NAME = "fakturaeksport-00001-20261024-093400.csv"
SHEET = ExportSheet(
    headers=("Leverandør", "=Sum", "Dato", "Linje"),
    kinds=(FieldKind.TEXT, FieldKind.MONEY, FieldKind.DATE, FieldKind.NUMBER),
    rows=(
        ("=CMD()", Decimal("-1234.50"), dt.date(2026, 10, 1), 1),
        ('Semi;kolon "sitat"\nny linje', None, None, None),
    ),
    summary=(("Sum", Decimal("10.00")), ("Anker", "+abc")),
    sheet_name="Fakturaer",
    summary_name="Kontroll",
)


def test_csv_cells_are_formatted_for_a_norwegian_excel() -> None:
    assert csv_text(None) == ""
    assert csv_text(Decimal("-1234.50")) == "-1234,50"
    assert csv_text(Decimal("0.00")) == "0,00"
    assert csv_text(dt.date(2026, 1, 2)) == "02.01.2026"
    assert csv_text(7) == "7"
    assert csv_text("@x") == "'@x"


def test_csv_file_quotes_separators_and_neutralizes_headers() -> None:
    data = CsvWriter().render(SHEET)
    assert data.startswith(b"\xef\xbb\xbf")
    text = data.decode("utf-8-sig")
    assert text.splitlines()[0] == "Leverandør;'=Sum;Dato;Linje"
    assert "'=CMD();-1234,50;01.10.2026;1\r\n" in text
    assert '"Semi;kolon ""sitat""\nny linje";;;\r\n' in text


def test_xlsx_file_has_typed_cells_and_a_control_sheet() -> None:
    workbook = openpyxl.load_workbook(io.BytesIO(XlsxWriter().render(SHEET)))
    data, summary = workbook.worksheets
    assert (data.title, summary.title) == ("Fakturaer", "Kontroll")
    assert data["B1"].value == "=Sum" and data["B1"].data_type == "s" and data["B1"].quotePrefix
    assert data["A2"].value == "=CMD()" and data["A2"].quotePrefix
    assert data["B2"].value == Decimal("-1234.5") and data["B2"].number_format == MONEY_FORMAT
    assert data["C2"].value.date() == dt.date(2026, 10, 1)
    assert data["C2"].number_format == DATE_FORMAT
    assert data["A3"].value == 'Semi;kolon "sitat"\nny linje' and not data["A3"].quotePrefix
    assert data.freeze_panes == "A2"
    assert [tuple(r) for r in summary.iter_rows(values_only=True)] == [
        ("Sum", 10),
        ("Anker", "+abc"),
    ]


def test_a_file_is_written_once_read_only_and_never_replaced(tmp_path) -> None:
    store = FileExportStore(tmp_path)
    digest = store.write(ENTITY, NAME, b"data")
    path = tmp_path / ENTITY.hex / NAME
    assert path.read_bytes() == b"data" and not os.stat(path).st_mode & stat.S_IWUSR
    assert len(digest) == 64
    with pytest.raises(StorageError):
        store.write(ENTITY, NAME, b"other")
    assert store.read(ENTITY, NAME) == b"data"
    assert list((tmp_path / ENTITY.hex).iterdir()) == [path]


@pytest.mark.parametrize(
    "name",
    ["../x.csv", "faktura.csv", "fakturaeksport-1-20261024-093400.csv", NAME + ".exe", "CON"],
)
def test_unexpected_names_are_refused(tmp_path, name: str) -> None:
    with pytest.raises(StorageError):
        FileExportStore(tmp_path).write(ENTITY, name, b"x")


def test_a_missing_or_linked_file_reads_as_none(tmp_path) -> None:
    store = FileExportStore(tmp_path)
    assert store.read(ENTITY, NAME) is None
    target = tmp_path / "elsewhere.csv"
    target.write_bytes(b"x")
    try:
        (tmp_path / ENTITY.hex / NAME).symlink_to(target)
    except OSError:
        pytest.skip("symbolic links are not available")
    assert store.read(ENTITY, NAME) is None


def test_a_failed_write_leaves_no_file(tmp_path) -> None:
    def broken_fsync(_descriptor: int) -> None:
        raise OSError("disk full")

    store = FileExportStore(tmp_path, fsync=broken_fsync)
    with pytest.raises(StorageError):
        store.write(ENTITY, NAME, b"data")
    assert list((tmp_path / ENTITY.hex).iterdir()) == []


def test_temporary_files_are_removed_and_copies_replace(tmp_path) -> None:
    store = FileExportStore(tmp_path)
    store.write(ENTITY, NAME, b"data")
    (tmp_path / ENTITY.hex / f".{'b' * 32}.part").write_bytes(b"half")
    (tmp_path / ENTITY.hex / "notes.txt").write_bytes(b"keep")
    assert store.discard_temporary(ENTITY) == 1
    assert (tmp_path / ENTITY.hex / "notes.txt").exists()
    destination = tmp_path / "kopi.csv"
    destination.write_bytes(b"old")
    store.save_copy(b"new", destination)
    assert destination.read_bytes() == b"new"
    with pytest.raises(StorageError):
        store.save_copy(b"new", tmp_path / "missing" / "kopi.csv")
