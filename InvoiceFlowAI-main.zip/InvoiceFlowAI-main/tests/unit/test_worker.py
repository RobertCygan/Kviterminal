"""The worker body in-process: it never raises for bad input and keeps limits."""

import hashlib
import json
from pathlib import Path

import pytest

from invoiceflow.application.document_model import DocumentFormat
from invoiceflow.application.ports import WorkerTask
from invoiceflow.application.processing_model import ProcessingLimits, WorkerResult
from invoiceflow.bootstrap.synthetic_pdf import text_pdf
from invoiceflow.processing import worker
from invoiceflow.processing.pdf_pdfium import PdfiumParser

pytestmark = pytest.mark.unit


def task(tmp_path: Path, data: bytes, *, sha: str | None = None, **limits) -> WorkerTask:
    source = tmp_path / "original.pdf"
    source.write_bytes(data)
    output = tmp_path / "out"
    output.mkdir(exist_ok=True)
    return WorkerTask(
        source,
        sha or hashlib.sha256(data).hexdigest(),
        DocumentFormat.PDF,
        output,
        ProcessingLimits(**({"dpi": 72} | limits)),
    )


def report(task_: WorkerTask, parsers=None) -> WorkerResult:
    return WorkerResult.model_validate_json(worker.analyse(task_, parsers))


def test_a_changed_original_is_not_parsed(tmp_path) -> None:
    result = report(task(tmp_path, text_pdf(["x"]), sha="0" * 64))
    assert (result.status, result.error_code) == ("error", "source_changed")


def test_an_oversized_original_is_not_read(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr(worker, "MAX_DOCUMENT_BYTES", 10)
    assert report(task(tmp_path, text_pdf(["x"]))).error_code == "source_changed"


def test_output_budget_is_enforced(tmp_path) -> None:
    result = report(task(tmp_path, text_pdf(["x", "y"]), max_output_bytes=100))
    assert result.error_code == "output_too_large"


class Exploding:
    engine = "pypdfium2"
    formats = frozenset({DocumentFormat.PDF})

    def __init__(self, error: BaseException) -> None:
        self.engine_version = PdfiumParser().engine_version
        self._error = error

    def open(self, data, document_format, limits):
        raise self._error


@pytest.mark.parametrize(
    ("error", "code"),
    [(MemoryError(), "memory_limit"), (RuntimeError("Secret text from the PDF"), "corrupt")],
)
def test_unexpected_failures_become_codes_without_messages(tmp_path, error, code) -> None:
    payload = worker.analyse(task(tmp_path, b"%PDF-"), {DocumentFormat.PDF: Exploding(error)})
    assert json.loads(payload)["error_code"] == code
    assert b"Secret" not in payload


def test_existing_output_files_are_never_overwritten(tmp_path) -> None:
    task_ = task(tmp_path, text_pdf(["x"]))
    (task_.output_dir / "page-0001.png").write_bytes(b"planted")
    assert report(task_).error_code == "corrupt"
    assert (task_.output_dir / "page-0001.png").read_bytes() == b"planted"


def test_serve_ignores_anything_but_a_task(tmp_path) -> None:
    class Connection:
        def __init__(self) -> None:
            self.closed = False
            self.sent: list[bytes] = []

        def recv(self):
            return {"source": "/etc/passwd"}

        def send_bytes(self, data):
            self.sent.append(data)

        def close(self):
            self.closed = True

    connection = Connection()
    worker.serve(connection)  # type: ignore[arg-type]
    assert connection.closed and connection.sent == []
