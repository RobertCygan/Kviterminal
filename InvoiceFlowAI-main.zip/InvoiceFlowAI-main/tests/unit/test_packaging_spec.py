"""The PyInstaller specification ships every migration file Alembic needs."""

from pathlib import Path
from typing import Any

import pytest

from invoiceflow.persistence.migrator import MIGRATIONS_DIR

pytestmark = pytest.mark.unit

ROOT = Path(__file__).resolve().parents[2]
SPEC = ROOT / "packaging" / "invoiceflow.spec"
PACKAGE_ROOT = ROOT / "src"


def evaluate_spec() -> dict[str, Any]:
    """Run the spec with stand-ins for the PyInstaller build objects."""
    captured: dict[str, Any] = {}

    def analysis(scripts: list[str], **options: Any) -> object:
        captured.update(options, scripts=scripts)
        return type("Analysis", (), {"pure": [], "scripts": [], "binaries": [], "datas": []})()

    namespace = {
        "SPECPATH": str(SPEC.parent),
        "Analysis": analysis,
        "PYZ": lambda *args, **kwargs: object(),
        "EXE": lambda *args, **kwargs: object(),
        "COLLECT": lambda *args, **kwargs: object(),
    }
    exec(compile(SPEC.read_text(encoding="utf-8"), str(SPEC), "exec"), namespace)  # noqa: S102
    return captured


def test_every_migration_file_is_bundled_at_its_package_path() -> None:
    datas = {
        (Path(source).resolve(), target)
        for source, target in evaluate_spec()["datas"]
        if target.startswith("invoiceflow/")
    }
    expected = {
        (path.resolve(), path.parent.relative_to(PACKAGE_ROOT).as_posix())
        for path in MIGRATIONS_DIR.rglob("*")
        if path.is_file() and "__pycache__" not in path.parts
    }
    assert {name for name, _ in expected} >= {
        MIGRATIONS_DIR / "env.py",
        MIGRATIONS_DIR / "script.py.mako",
        MIGRATIONS_DIR / "versions" / "0001_initial.py",
    }
    assert datas == expected


def test_engine_versions_are_readable_in_the_frozen_program() -> None:
    """The worker reads its engine version from package metadata (Phases 04 and 15)."""
    targets = {target for _, target in evaluate_spec()["datas"]}
    assert any(target.startswith("pypdfium2-") for target in targets)
    assert any(target.startswith("pillow-") for target in targets)
    assert any(target.startswith("defusedxml-") for target in targets)


def test_database_drivers_are_hidden_imports() -> None:
    hidden = evaluate_spec()["hiddenimports"]
    assert {"sqlalchemy.dialects.sqlite.pysqlite", "alembic.ddl.sqlite"} <= set(hidden)


def test_migrations_are_package_data_for_wheels() -> None:
    import tomllib

    config = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    patterns = config["tool"]["setuptools"]["package-data"]["invoiceflow.persistence"]
    package = MIGRATIONS_DIR.parent
    shipped = {path for pattern in patterns for path in package.glob(pattern)}
    files = {
        path
        for path in MIGRATIONS_DIR.rglob("*")
        if path.is_file() and "__pycache__" not in path.parts
    }
    assert files and files <= shipped
