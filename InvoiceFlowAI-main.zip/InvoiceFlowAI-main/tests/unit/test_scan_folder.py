"""The watched scan folder: stable files, setting aside, writing (Phase 11a)."""

import contextlib
import os

import pytest

from invoiceflow.application.document_model import ImportOutcome
from invoiceflow.application.errors import StorageError
from invoiceflow.documents.scan_folder import IMPORTED_FOLDER, REFUSED_FOLDER, FileScanFolder


class Clock:
    def __init__(self) -> None:
        self.now = 2_000_000_000.0

    def __call__(self) -> float:
        return self.now


def write(path, data: bytes, at: float) -> None:
    path.write_bytes(data)
    os.utime(path, (at, at))


def test_a_file_is_ready_only_when_it_stopped_changing(tmp_path) -> None:
    clock = Clock()
    folder = FileScanFolder(min_age_seconds=2, clock=clock)
    scan = tmp_path / "bunke.pdf"
    write(scan, b"%PDF-1", clock.now - 10)
    assert folder.ready_files(tmp_path) == []  # first look
    write(scan, b"%PDF-1.7 more", clock.now - 10)  # still being written
    assert folder.ready_files(tmp_path) == []
    assert folder.ready_files(tmp_path) == [scan]
    write(scan, b"%PDF-1.7 more!", clock.now - 1)  # changed and too new
    assert folder.ready_files(tmp_path) == []
    clock.now += 5
    assert folder.ready_files(tmp_path) == [scan]


def test_empty_hidden_and_linked_files_and_folders_are_ignored(tmp_path) -> None:
    clock = Clock()
    folder = FileScanFolder(min_age_seconds=0, clock=clock)
    write(tmp_path / "tom.pdf", b"", clock.now - 10)
    write(tmp_path / "~lagres.pdf", b"x", clock.now - 10)
    write(tmp_path / ".delvis.pdf", b"x", clock.now - 10)
    (tmp_path / IMPORTED_FOLDER).mkdir()
    target = tmp_path.parent / "utenfor.pdf"
    target.write_bytes(b"secret")
    with contextlib.suppress(OSError):  # Windows without developer mode
        (tmp_path / "lenke.pdf").symlink_to(target)
    folder.ready_files(tmp_path)
    assert folder.ready_files(tmp_path) == []


@pytest.mark.parametrize(
    "outcome,subfolder",
    [
        (ImportOutcome.IMPORTED, IMPORTED_FOLDER),
        (ImportOutcome.DUPLICATE, IMPORTED_FOLDER),
        (ImportOutcome.REJECTED, REFUSED_FOLDER),
        (ImportOutcome.QUARANTINED, REFUSED_FOLDER),
    ],
)
def test_handled_files_are_set_aside_without_overwriting(tmp_path, outcome, subfolder) -> None:
    folder = FileScanFolder()
    for content in (b"first", b"second"):
        scan = tmp_path / "bunke.pdf"
        scan.write_bytes(content)
        folder.set_aside(tmp_path, scan, outcome)
        assert not scan.exists()
    kept = sorted(p.read_bytes() for p in (tmp_path / subfolder).iterdir())
    assert kept == [b"first", b"second"]


def test_failures_are_storage_errors(tmp_path) -> None:
    folder = FileScanFolder()
    with pytest.raises(StorageError):
        folder.ready_files(tmp_path / "mangler")
    with pytest.raises(StorageError):
        folder.set_aside(tmp_path, tmp_path / "mangler.pdf", ImportOutcome.IMPORTED)
    with pytest.raises(StorageError):
        folder.write_file(tmp_path / "mangler" / "skilleark.pdf", b"x")
    folder.write_file(tmp_path / "skilleark.pdf", b"%PDF")
    folder.write_file(tmp_path / "skilleark.pdf", b"%PDF-2")
    assert (tmp_path / "skilleark.pdf").read_bytes() == b"%PDF-2"
