# InvoiceFlow AI

Lokal Windows 11-applikasjon for sikker, automatisert behandling av inngående fakturaer – fra skanner eller fil til regnskapsklar eksport, med menneskelig godkjenning av alt som eksporteres.

> **Status: Fase 02 – database, migrasjoner og revisjonsspor.** Skrivebordsskallet har fortsatt seks plassholdersider. Lagringsgrunnlaget er implementert og kontrolleres i Windows CI; ingen dokumentimport eller OCR er tilgjengelig. Se [F02-rapport](docs/PHASE_02_REPORT.md), [F01-rapport](docs/PHASE_01_REPORT.md) og [F00-aksept](docs/PHASE_00_ACCEPTANCE.md).

## Hva programmet skal gjøre

1. Motta fakturaer fra skanner, filimport eller overvåket mappe.
2. Validere filen og lagre originalen uendret (SHA-256).
3. Hente tekst fra PDF eller kjøre OCR.
4. Tolke fakturafelt og linjer – regelbasert, eventuelt med KI.
5. Foreslå kontering (konto, MVA-kode, kostnadssted, avdeling, prosjekt).
6. Kontrollere beløp, MVA, datoer, identifikatorer og duplikater deterministisk.
7. La brukeren gjennomgå, korrigere og godkjenne.
8. Eksportere godkjente fakturaer til Excel/CSV (senere Unit4 ERP).

Programmet bokfører aldri automatisk og setter aldri i gang betalinger.

## Grunnprinsipper

- **Lokalt først:** Alt virker uten internett. Ingen data sendes ut uten eksplisitt samtykke.
- **Sporbarhet:** Hver verdi viser om den er *hentet fra dokumentet*, *foreslått av KI*, *beregnet* eller *manuelt korrigert*.
- **Eksakte beløp:** `decimal.Decimal` overalt – aldri flyttall.
- **Sikkerhet i alle faser:** Se [`docs/SECURITY.md`](docs/SECURITY.md) og [`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md).

## Dokumentasjon

| Dokument | Innhold |
|---|---|
| [`docs/MASTER_SPECIFICATION.md`](docs/MASTER_SPECIFICATION.md) | Krav, teknologistakk, Definisjon av ferdig, ordliste, **åpne spørsmål** |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) | Lag, moduler, diagrammer, Windows-hensyn, repostruktur |
| [`docs/DATA_MODEL.md`](docs/DATA_MODEL.md) | Databaseskjema, Pydantic-kontrakter, proveniens, eksempel |
| [`docs/SECURITY.md`](docs/SECURITY.md) | Sikkerhetsarkitektur og tillitsgrenser |
| [`docs/THREAT_MODEL.md`](docs/THREAT_MODEL.md) | Trusler, risiko, tiltak, restrisiko |
| [`docs/TEST_STRATEGY.md`](docs/TEST_STRATEGY.md) | Testnivåer, sikkerhetstester, kommandoer, bevis |
| [`docs/DEVELOPMENT_ROADMAP.md`](docs/DEVELOPMENT_ROADMAP.md) | Faser, avhengigheter og akseptansekriterier |
| [`docs/DECISIONS.md`](docs/DECISIONS.md) | Arkitekturbeslutninger (ADR) |
| [`docs/DEPENDENCIES.md`](docs/DEPENDENCIES.md) | Verifiserte versjoner, Windows-hjul og lisenser |
| [`docs/CHANGELOG.md`](docs/CHANGELOG.md) | Endringslogg |
| [`docs/PHASE_00_AUDIT.md`](docs/PHASE_00_AUDIT.md) | Uavhengig sluttrevisjon av Fase 00 |
| [`docs/PHASE_00_DECISION_REGISTER.md`](docs/PHASE_00_DECISION_REGISTER.md) | Beslutningsregister med anbefalinger, frister og status |
| [`docs/PHASE_00_ACCEPTANCE.md`](docs/PHASE_00_ACCEPTANCE.md) | Formell akseptsjekkliste for Fase 00 |
| [`AGENTS.md`](AGENTS.md) | Arbeidsregler for utviklere og KI-assistenter |

## Utviklingsmiljø (Windows PowerShell)

Krever Python 3.13 (64-bit) fra python.org.

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --require-hashes -r requirements\dev.lock.txt
python -m pip install --no-deps -e .

python -m pytest
python -m ruff check .
python -m bandit -c pyproject.toml -r src
python -m pip_audit --disable-pip --require-hashes -r requirements\dev.lock.txt
```

Flere kommandoer: [`docs/TEST_STRATEGY.md`](docs/TEST_STRATEGY.md) §9.

## Datasikkerhet i repoet

Ekte fakturaer, kundedata, databaser, OCR-utdata, logger og hemmeligheter skal **aldri** legges i Git. `.gitignore` blokkerer slike filer som standard, og Gitleaks kjører i CI. Testdata er syntetiske.

## Lisens

Ikke fastsatt (privat repo). Se åpent spørsmål Å-15 og PDF-lisensbeslutningen (ADR-0023, D-11 = C).


## Fase 01 – kjøring av skrivebordsskallet

Python 3.13 x64 er målversjonen. Etter installasjon av de låste avhengighetene:

```powershell
python -m pip install --require-hashes -r requirements/dev.lock.txt
python -m pip install --no-deps --no-build-isolation -e .
python -m invoiceflow
python -m invoiceflow --self-test --data-dir "$env:TEMP\InvoiceFlowAI-selftest"
```

Standard datakatalog er `%LOCALAPPDATA%\InvoiceFlowAI`. Uten `LOCALAPPDATA`
kreves `--data-dir`. Ingen fakturaer behandles i dette skallet.
Bygging: [packaging/README.md](packaging/README.md).

## Fase 02 – lagring og selvtest

Ved normal oppstart opprettes/verifiseres `database/invoiceflow.sqlite3` under datakatalogen. Ingen regnskapsenhet eller faktura opprettes automatisk. Før en fremtidig skjemaoppgradering tas en lokal migrasjonskopi i `backups/pre-migration`.

Kjør selvtest med en separat, eksplisitt testkatalog. Hele oppstarten kan initialisere/migrere databasen i valgt datakatalog; bare persistensproben bruker en midlertidig underkatalog. Bruk derfor ikke en katalog med verdifulle data til aksepttesten.

```powershell
python -m invoiceflow --self-test --data-dir "$env:LOCALAPPDATA\InvoiceFlowAI-F02-Acceptance"
```

Resultatet skal være «Selvtest bestått» og avslutningskode 0. Alle data må fortsatt være syntetiske. Prosedyre for Windows-bygget og manuell aksept står i F02-rapporten.
