# Fase 11b – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

Prosjekteier oppga Brother ADS-4700W som foreløpig skanner (G-22) og valgte variant A for F11b (G-23, «wariant A»):

- skanning via produsentens program til skannemappen;
- ingen WIA i programmet.

Utvikleren skrev promptet `docs/prompts/PHASE_11B_SCANNER_SETUP.md` v1.0 (D-37), og innholdet er ikke gjennomgått.

**GOAL:** skanneren kan brukes uten skannerdriver i programmet. Grenseverdiene for blanke sider og skilleark kan kontrolleres med ekte skann uten at dokumentinnhold forlater maskinen.

## 2. Leveranse

- **Sider nær en grense** (ren funksjon, 100 % dekning):
  - nesten blank: innhold uten tekstlag og høyst 10 ‰ mørkt;
  - nesten skilleark: midten minst 700 ‰ mørk;
  - svakt skilleark: midten under 900 ‰, eller siden utenfor 200–600 ‰.
- **Siden «Skanning»:**
  - kolonnen «Nær grensen»;
  - tabell med målingene for hver side i valgt dokument (type, mørkt på hele siden og i midten, tekstlag, merknad);
  - grenseverdiene vist som tekst;
  - «Kopier mappesti» (Alt+K).
- **`docs/SCANNER_SETUP.md`:**
  - skanneprofil for Brother iPrint&Scan (PDF med flere sider, 300 dpi, gråtoner, dupleks, uten sikker PDF);
  - daglig bruk;
  - prøvebunke på 8 ark for å kontrollere grenseverdiene;
  - feilsøking.
- **ADR-0039:** programmet styrer ikke skanneren, og skannemappen deles ikke på nettverket.

Ingen ny avhengighet, ingen migrasjon og ingen endring av grenseverdiene.

## 3. Valg og avvik

| Punkt | Valg | Begrunnelse |
|---|---|---|
| Skannerdriver | Ingen (variant A) | Valgt av prosjekteier. Ingen ny avhengighet eller kode som bare kan prøves med maskinvare |
| «Skann til nettverksmappe» | Frarådes | Skannemappen ligger i datakatalogen og skal ikke deles over SMB (T63) |
| Grenseverdier | Uendret | Endres først etter prøve med ekte skann |
| Målinger i grensesnittet | Bare tall | Kan sendes til utvikleren uten dokumentinnhold |
| Skanneprofiler, ADF, dupleks | I Brothers program | Roadmapen nevnte dem i programmet; ADR-0039 flytter dem til produsentens program |

## 4. Testresultater

Lokalt (Linux, Python 3.13, gren `claude/phase11b-scanner-setup`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen) | 1641 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | 93 % |
| Dekning `application/scan/model.py` | 100 % |
| Ruff, Bandit, pip-audit, Gitleaks (lokalt) | Ingen funn |

Windows-CI og `.exe`-selvtesten: se PR-en. GitHub Actions har ikke startet jobber på grunn av fakturering siden F09.

**Ikke prøvd:**

- Brother ADS-4700W og menynavnene i Brother iPrint&Scan;
- ekte skann av skilleark og blanke baksider;
- manuell Windows 11-test.

## 5. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Sider nær en grense | ✅ | ✅ | ✅ | se PR | – | – |
| Målinger per side og «Kopier mappesti» | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| Oppsettsveiledning for Brother ADS-4700W | ✅ | ✅ | – (ikke prøvd med skanner) | – | – | – |
| Variant A (ingen skannerdriver) | ✅ | ✅ | – | – | ✅ (G-23) | – |

## 6. Gjenstående risiko og beslutninger

- **T61:** grenseverdiene er bare prøvd på syntetiske sider. Første prøve etter `SCANNER_SETUP.md` §4 avgjør om de må justeres.
- **Akseptkriteriet** «testet med faktisk skannermodell» er ikke oppfylt før prøven.
- **Windows-CI:** F09–F12, F11a og F11b er ikke verifisert på Windows før CI kjører igjen.

## 7. Manuell Windows 11-aksept

1. Følg `SCANNER_SETUP.md` §1–2 og lag profilen «InvoiceFlow».
2. Skann prøvebunken i §4 med overvåking på.
3. Kontroller:
   - delene i tabellen;
   - typene i sidetabellen;
   - at ingen side er feil klassifisert.
4. Send et skjermbilde av sidetabellen (bare tall) til utvikleren.
5. Velg «Kopier mappesti» og lim inn i Utforsker. Mappen åpnes.

## 8. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- prosjekteiers gjennomgang av D-37;
- første prøve med Brother ADS-4700W og eventuell justering av grenseverdiene;
- manuell Windows 11-test.
