# Fase 03 – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

F03 er implementert etter `docs/prompts/PHASE_03_SECURE_DOCUMENT_IMPORT.md` v2.0, som prosjekteier godkjente 2026-10-22 sammen med D-22–D-24 (G-05). Grunnlaget er `main` etter F02 og PR #18. Godkjenningen omfatter implementering, ikke aksept av resultatet, restrisiko (D-19), PDF-lisens (D-11) eller ekte data.

**GOAL:** sikker import av syntetiske PDF-, PNG-, JPEG- og TIFF-filer til et enhetsavgrenset, innholdsadressert originalarkiv med generisk dokumentmodell.
**OUTPUT:** migrasjon `0002_documents`, `DocumentService`, `FileDocumentStore`, innboks-side, dialog for første enhet, gjenoppretting ved oppstart, dokumentasjon og ADR-0029.

## 2. Faktisk datamodell

Se `DATA_MODEL.md` §3.10 og ADR-0029.

- `documents`: generisk dokument uten fakturafelter; UNIQUE(`entity_id`, `sha256`) gir duplikatkontroll per enhet.
- `document_links`: koblinger innen én enhet; kun tilføyelse.
- Dokumenter kan ikke slettes, og identitet, eierskap og original er uforanderlige; bare type og integritetsfelt kan endres.
- `audit_events` er bygget om for emnetypen `document`; alle eksisterende rader og hasher er kopiert uendret.

## 3. Avvik fra promptet (åpent for bekreftelse)

| Avvik | Begrunnelse | Status |
|---|---|---|
| Faktura → dokument håndheves med utløseren `invoices_reference_document`, ikke en sammensatt FK via tabellombygging | SQLite kan ikke bygge om foreldretabellen `invoices` i en transaksjon med `foreign_keys=ON` (`ON DELETE RESTRICT` og telleren for utsatte FK-brudd); verifisert i prototype. Samme integritet med uforanderlige dokumenter og fakturaeierskap. | D-25 – godkjent av prosjekteier 2026-10-22 (G-06) |
| Ingen BitLocker-/antivirusvarsel i programmet | Krever Windows-spesifikke kall som ikke kan testes i CI uten administratorrettigheter; Å-12/Å-13 er ubesvart | Dokumentert begrensning; vurderes før port for ekte data (F12) |
| Hendelsen `document.rejected` lagt til | Sporbarhet også for avviste filer (tom, for stor, ulesbar, endret, lenke) | Innenfor revisjonsprinsippet |

## 4. Import, karantene og krasjmodell

1. Kilde kontrolleres med `lstat` (lenker, reparse-punkter og mapper avvises), størrelse ≤ 50 MB.
2. Kopi til `staging/` med SHA-256 og `fsync`; kilden sammenlignes før/etter (størrelse, endringstid).
3. Duplikat i samme enhet → ingen ny rad, hendelse `document.duplicate_rejected`.
4. Signatur og endelse kontrolleres; avvik → `quarantine/<uuid>.bin`, rad med status `quarantined`.
5. Ellers ny hashkontroll og atomisk publisering til `originals/ab/cd/<sha256>.<ext>`, skrivebeskyttet.
6. Rad og hendelse i én Unit of Work. Kildefilen beholdes alltid.

Gjenoppretting ved oppstart (hver enhet): rester i `staging/` fjernes, originaler uten rad flyttes til `orphans/`, rader uten fil merkes `missing`. Ingen original slettes. Testet for hvert krasjpunkt.

## 5. Enhetsisolasjon

`EntityScope` i alle dokumentoperasjoner; et annet enhets dokument ser ut som manglende (`NOT_FOUND`). Sammensatte FK-er for koblinger, utløser for faktura → dokument, egen mappe per enhet. Med flere enheter i databasen deaktiveres import (ingen implisitt valg, D-22).

## 6. Testresultater

Lokalt (Linux, Python 3.13, på F03-grenen før push):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning | **663 bestått** |
| Dekning utenfor domain/UI (`--fail-under=90`) | **96 %** |
| Ruff lint og format | Ingen funn |
| Bandit | Ingen funn |
| pip-audit | Ingen kjente sårbarheter |
| PyInstaller onedir (Linux) | Bygget; `0002_documents.py` med; `--self-test` bestått to ganger på samme katalog |

Windows-CI (GitHub Actions `windows-latest`, Python 3.13.16, kjøring 39799840112 på `e2c95fe`):

| Kontroll | Resultat |
|---|---|
| Ruff lint og format | Ingen funn |
| `pytest` med dekning | **663 bestått** |
| Dekning utenfor domain/UI | **96 %** |
| Bandit | Ingen funn |
| pip-audit | Ingen kjente sårbarheter |
| Onedir-røykbygg | Bygget; `0002_documents.py` med; `InvoiceFlowAI.exe --self-test` bestått |
| Gitleaks (full historikk) | Ingen funn |

Tidligere Windows-kjøringer avdekket to plattformfeil som er rettet med regresjonstester: `st_file_attributes` manglet i testenes falske `stat`-resultater, og `os.replace` mot en skrivebeskyttet original som en samtidig import av samme innhold allerede hadde publisert. Publisering er nå idempotent når målfilen har samme SHA-256. Dekning måler eksisterende kode, ikke fremtidige faser.

## 7. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Dokumentmodell og migrasjon 0002 | ✅ | ✅ | ✅ | ✅ | – | – |
| Import, karantene, duplikater | ✅ | ✅ | ✅ | ✅ | – | – |
| Krasjmodell og gjenoppretting | ✅ | ✅ | ✅ | ✅ | – | – |
| Innboks-UI og første enhet | ✅ | ✅ | ✅ (offscreen) | ✅ (offscreen) | – | – |
| Manuell Windows 11-test | ✅ | – | – | – | – | – |

## 8. Gjenstående risiko og beslutninger

- Å-12/Å-13: antivirus og BitLocker ikke kontrollert av programmet; originaler er ukrypterte.
- Signaturkontroll er ikke full validering; parserisolasjon og ressursgrenser kommer i F04 og krever D-11 (PDF-lisens).
- Ingen retensjon, sletting eller arkiveksport (egne beslutninger).
- D-19 (restrisiko) og porten for ekte data (SECURITY §17) er uendret åpne.

## 9. Manuell Windows 11-aksept

Bruk en ny testkatalog og bare syntetiske filer.

```powershell
$dir = "$env:TEMP\InvoiceFlowAI-F03-test"
.\InvoiceFlowAI.exe --self-test --data-dir $dir
.\InvoiceFlowAI.exe --data-dir $dir
```

1. Forvent «Selvtest bestått» og kode 0.
2. Åpne «Innboks», velg «Opprett regnskapsenhet …», skriv et fiktivt navn.
3. «Importer fil …» med en syntetisk PDF: raden vises som «Lagret», kildefilen ligger der fortsatt.
4. Importer samme fil igjen: statuslinjen viser én duplikat, ingen ny rad.
5. Gi en tekstfil endelsen `.pdf` og importer: raden vises som «Karantene».
6. Legg en PNG i `$dir\inbox` og velg «Les inn fra innboks».
7. Marker en rad og velg «Endre dokumenttype …».
8. Lukk og start programmet på nytt: listen er uendret.

## 10. Anbefaling

Teknisk leveranse klar til gjennomgang; Windows-CI er grønn. Manuell Windows 11-test og formell faseaksept gjenstår; D-25 er godkjent. F04 er bare beskrevet i et prompt og ikke påbegynt.

## 11. Etterkontroll 2026-10-22

Prosjekteier ba om grundighet framfor tempo. Etter fletting ble F03 kontrollert på nytt.

**Kodegjennomgang.** Tre svakheter ble funnet og reprodusert med syntetiske filer før retting (PR #25):

| Funn | Virkning før retting | Retting |
|---|---|---|
| Lagringsfeil for én fil stoppet resten av en import med flere filer | Resten av innboksen ble ikke importert; brukeren så bare en generell lagringsfeil | Importen fortsetter; filen får utfallet «Feilet» og kan importeres på nytt |
| Ingen nye forsøk når et annet program (antivirus, indeksering) holder en ny fil et øyeblikk | `STORAGE_UNAVAILABLE` ved første `PermissionError` | Nye forsøk i inntil ca. 1,5 s |
| En låst fil under oppstartsgjenopprettingen stanset programmet | Programmet startet ikke (`UNEXPECTED`) | Filen hoppes over og telles (`failed`); ingenting slettes |

Samtidighetsfeilen fra Windows-CI ble rettet i PR #21 (publisering under prosesslås) etter at første retting i PR #19 viste seg å være ufullstendig.

**Stresskjøring på Windows** (GitHub Actions `windows-latest`, Python 3.13.16; midlertidige grener som ikke flettes):

| Kjøring | Samtidighet og krasjmodell | Dokumentlager, -tjeneste og innboks-UI | Hele testsettet |
|---|---|---|---|
| `main` (62091cb), kjøring 39806720020 | 0 feil av 200 | 0 feil av 50 | 0 feil av 10 |
| PR #25, kjøring 39809636065 | 0 feil av 200 | 0 feil av 50 | 0 feil av 10 |

**Rettet etter prosjekteiers godkjenning av begge forslag (PR «etterkontroll 2»):**

| Funn | Reprodusert | Retting |
|---|---|---|
| `verify` kalte `resolve()`, som følger lenker, før lenkesjekken; sjekken var dødkode. En original erstattet av en symbolsk lenke til en identisk fil i arkivet ble meldt som «ok» | Ja, med syntetiske filer (lenke til identisk fil i arkivet → `ok`) | Den oppløste stien sammenlignes med stien slik den er lagret; lenker i hele stien (også lenkede mapper og hengende lenker) og alt som ikke er en vanlig fil gir `mismatch`. Tre av seks nye tester feiler på forrige kode |
| Avslutning midt i en lang innboksimport ventet maks 10 s og lukket deretter databasen under arbeidet | Ved gjennomgang av `app.py` og `documents_page.py` | Ved avslutning ber siden kontrolleren stoppe (`request_stop`); importen fullfører filen den er i gang med og starter ingen ny. Tidsavbrudd logges som `documents.shutdown_timeout` (uten detaljer). Kilder og allerede lagrede dokumenter er uendret; resten importeres ved neste kjøring |

**Dokumentasjonsgjennomgang.** `SECURITY.md` §18 sa at NTFS-/BitLocker-kontroller «kommer i F03», men F03 innførte dem ikke; setningen er rettet. §19, trusselmodellen og teststrategien er utvidet med låsing, nye forsøk, lenker i arkivet og stopp ved avslutning. Windows-CI for PR-en (`windows-latest`, Python 3.13.16, kjøring 39910170312): **683 tester bestått**, ingen hoppet over (symlink-testene kjørte altså også på Windows), 97 % dekning utenfor domain/UI, Bandit og pip-audit uten funn, onedir-bygg og selvtest bestått, Gitleaks uten funn.
