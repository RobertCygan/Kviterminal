# Fase 04 – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

F04 er implementert etter `docs/prompts/PHASE_04_ISOLATED_DOCUMENT_PROCESSING.md` v1.1. Prosjekteier godkjente promptet og valgte alternativ C i D-11 (pypdfium2) 2026-10-23 (G-09). Godkjenningen omfatter implementering, ikke aksept av resultatet, restrisiko (D-19) eller ekte data. F05 er ikke påbegynt.

**GOAL:** hente sideantall, tekstlag med tegnposisjoner og sidebilder fra lagrede originaler i en isolert arbeidsprosess, slik at en fiendtlig eller ødelagt fil aldri kan krasje, henge eller kompromittere hovedprosessen.
**OUTPUT:** migrasjon `0003_processing`, porten `DocumentParser` med adapterne pypdfium2 og Pillow, arbeidsprosess med Windows Job Object, `ProcessingService`, `FileDerivedStore`, visning i innboksen, ADR-0031, oppdatert dokumentasjon og denne rapporten.

## 2. Faktisk datamodell

Se `DATA_MODEL.md` §3.11.

- `processing_jobs`: én rad per kjøring; idempotensnøkkel over dokument, steg, motor, motorversjon og innstillinger; høyst én vellykket og én uferdig jobb per nøkkel; bare lagrede dokumenter; kan ikke slettes; sluttstatus er endelig.
- `document_pages` og `derived_files`: hører til én jobb og kan bare legges til mens jobben kjører. Sider, filer og sluttstatus skrives i én transaksjon.
- Sammensatte FK-er på `entity_id` overalt; `documents` er uendret.
- Revisjon: `document.processing_started` og `document.processing_finished`, bare med jobb-ID, forsøk, steg, status, feilkode, sideantall og flagg for aktivt innhold.

## 3. Avvik fra promptet (D-28, godkjent av prosjekteier 2026-10-23, G-10)

| Avvik | Begrunnelse |
|---|---|
| Ett steg `page_analysis` i stedet for separate `text_extraction` og `rendering` | Ett dokument åpnes én gang i én arbeidsprosess; to prosesser per dokument dobler oppstartskostnaden uten sikkerhetsgevinst. Nye steg (`ocr` osv.) kan legges til senere. |
| Sider og avledede filer per jobb, ikke UNIQUE(`document_id`, `page_number`) | Nye innstillinger eller en ny motorversjon gir en ny jobb uten å endre tidligere resultater. |
| Tekstlaget som avledet JSON-fil per side, ikke i databasen | Holder databasen liten; filen har hash, produsent og jobb-ID og valideres med Pydantic før den publiseres. |
| OpenCV og forbehandling (rotasjon, skjevhet) er ikke med | Promptet nevnte OpenCV som valgfritt; forbehandling hører sammen med OCR i F05. Sidens rotasjon fra PDF og EXIF registreres og brukes. |
| Job Object via `ctypes`, ikke `pywin32` | Ingen ny avhengighet; samme API (ADR-0031). |
| Pillow 13.0.0 (utgitt 2026-10-16) i stedet for 12.3.x | 35 sikkerhetsmeldinger mot 12.3.0 er rettet i 13.0.0; sikkerhetsunntak etter ADR-0024 pkt. 3 (`DEPENDENCIES.md` §7). |

Promptets åpne spørsmål 2 og 3 er ikke besvart. F04 bruker de forsiktige standardene: ingen egen Defender-skanning (Å-12 fortsatt åpen), og avledede filer slettes aldri (retensjon ikke avgjort).

## 4. Behandlingsløp og krasjmodell

1. Jobb med status `running` og hendelsen `document.processing_started` i én transaksjon. Er dokumentet allerede analysert med samme nøkkel, returneres den jobben (idempotent, ingen ny hendelse).
2. Originalens SHA-256 kontrolleres. Endret eller manglende original gir `source_changed` eller `source_missing`, og arbeidsprosessen startes ikke.
3. Arbeidsprosessen startes (`spawn`) og settes i et Job Object (2 GB, ingen underprosesser, drepes med hovedprosessen). Først da får den oppgaven. Den leser originalen selv, kontrollerer hashen og skriver bare i en fersk arbeidsmappe.
4. Rapporten leses som bytes (maks 1 MB) og valideres som `WorkerResult`. Hver lovet fil kontrolleres: vanlig fil, ikke lenke, størrelse, PNG-signatur og -mål. Hvert tekstlag valideres som `TextLayer`. Originalen kontrolleres på nytt.
5. Filene flyttes skrivebeskyttet til `derived/<dokument>/<jobb>/`. Sider, filer, sluttstatus og `document.processing_finished` skrives i én transaksjon.

Ved tidsavbrudd (120 s), stopp ved avslutning, krasj eller minnegrense drepes prosessen, og jobben avsluttes med en fast kode. Ved oppstart markeres jobber som fortsatt står som `running` som `interrupted`, arbeidsmapper fjernes, og avledede filer uten vellykket jobb flyttes til `orphans/`. Ingenting slettes. Hvert krasjpunkt er testet.

## 5. Enhetsisolasjon

`EntityScope` i alle operasjoner. Et annet enhets jobb, sider og filer ser ut som manglende. Sammensatte FK-er og egen mappe per enhet; samme fil i to enheter gir to uavhengige jobber.

## 6. Testresultater

Lokalt (Linux, Python 3.13, gren `claude/phase04-isolated-processing`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen) | Se kjøringen under; alle bestått unntatt én Windows-test som hoppes over på Linux |
| Dekning utenfor domain/UI (`--fail-under=90`) | 93 % |
| Ruff lint og format | Ingen funn |
| Bandit | Ingen funn |
| pip-audit | Ingen kjente sårbarheter |

Windows-CI: se PR-en. Onedir-røykbygget med `InvoiceFlowAI.exe --self-test` (som analyserer en syntetisk PDF i en ekte arbeidsprosess med Job Object) besto allerede på et tidlig mellomtrinn av grenen.

Fiendtlig korpus gjennom den ekte arbeidsprosessen (utfall på Linux):

| Fil | Utfall |
|---|---|
| PNG-bombe (60 000 × 60 000) | Avvist: `page_too_large` |
| PDF-bildebombe (20 000² piksler, 0,4 MB fil) | Behandlet innenfor grensene; med 512 MB minnegrense stoppes allokeringen |
| 101 sider, TIFF med 101 sider | Avvist: `too_many_pages` |
| Dyp nesting (50 000 nivåer), skadet xref | Behandlet (PDFium reparerer eller ignorerer) |
| Syklisk sidetre, avkortet fil, 0 sider, ødelagt JPEG | `corrupt` |
| Passordbeskyttet PDF | Avvist: `encrypted` |
| JavaScript, `Launch` (også `#`-kodet), innebygd fil | Behandlet, aktivt innhold flagget, ingenting utført |
| Polyglot PDF/ZIP | Behandlet som PDF |
| Side på 200 × 200 tommer | Avvist: `page_too_large` |

Ressursgrensene er bevist med egne arbeidsprosesser: endeløs løkke drepes ved fristen (3 s i testen), stoppforespørsel dreper prosessen, ubegrenset allokering stoppes av minnegrensen, krasj uten rapport og for stor rapport. Etter hver test er prosessen borte. At arbeidsprosessen ikke kan starte andre prosesser, testes bare på Windows.

**Ikke prøvd:** ekte fakturaer (forbudt før porten for ekte data), PDF-er med kjente CVE-utnyttelser mot PDFium, ytelse på 100-siders dokumenter (NF-03), manuell Windows 11-test, stresskjøring av arbeidsprosessen på Windows (som i F03-etterkontrollen).

## 7. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Migrasjon 0003 og repositorier | ✅ | ✅ | ✅ | se PR | – | – |
| Arbeidsprosess og Job Object | ✅ | ✅ | ✅ (POSIX-grense) | se PR | – | – |
| `DocumentParser`, pypdfium2 og Pillow | ✅ | ✅ | ✅ | se PR | D-11 ✅ | – |
| Tjeneste, avledede filer, gjenoppretting | ✅ | ✅ | ✅ | se PR | – | – |
| Innboks-visning | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| Manuell Windows 11-test | ✅ | – | – | – | – | – |

## 8. Gjenstående risiko og beslutninger

- **T30:** arbeidsprosessen kjører som samme Windows-bruker. Job Object begrenser minne, prosesser og levetid, ikke filsystem eller nettverk. AppContainer eller begrenset token bør vurderes før porten for ekte data.
- Å-12 (Defender-skanning) og retensjon av avledede filer er ubesvart. Avledede filer kan bruke opptil 1 GB per dokument.
- D-28 (avvikene i §3) er godkjent (G-10). D-19 (restrisiko) er åpen; porten for ekte data (SECURITY §17) er uendret.
- Sikkerhetsoppdateringer av PDFium og Pillow må tas inn raskt (ADR-0024 pkt. 3).

## 9. Manuell Windows 11-aksept

Bruk en ny testkatalog og bare syntetiske filer.

```powershell
$dir = "$env:TEMP\InvoiceFlowAI-F04-test"
.\InvoiceFlowAI.exe --self-test --data-dir $dir
.\InvoiceFlowAI.exe --data-dir $dir
```

1. Forvent «Selvtest bestått» og kode 0.
2. Opprett en fiktiv regnskapsenhet og importer en syntetisk PDF med tekst og et syntetisk PNG-bilde.
3. Velg «Behandle nye dokumenter»: begge får «Behandlet», og kolonnen «Sider» viser antallet.
4. Importer en passordbeskyttet PDF og behandle: «Avvist: passordbeskyttet eller kryptert PDF».
5. Kontroller at `$dir\documents\<enhet>\derived\` inneholder `page-0001.png` og `text-0001.json`, og at originalen er uendret.
6. Start et stort dokument, lukk programmet under behandlingen og start på nytt: jobben vises som «Mislyktes: avbrutt da programmet stanset», og den kan behandles på nytt med «Behandle valgt på nytt».

## 10. Anbefaling

Teknisk leveranse med grønn Windows-CI; prosjekteier har godkjent avvikene (D-28) og sammenslåing (G-10). Manuell Windows 11-test og formell faseaksept gjenstår. F05 (OCR) er ikke påbegynt.
