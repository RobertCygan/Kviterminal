# Fase 15 – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

F15 er implementert etter `docs/prompts/PHASE_15_EHF_IMPORT.md` v1.0. Prosjekteier godkjente promptet, D-29 (F15 foran F05) og D-16 (positive totaler for kreditnota) 2026-10-23 (G-11). Godkjenningen omfatter implementering, ikke aksept av resultatet, restrisiko (D-19) eller ekte data. F05, F08 og F09 er ikke påbegynt.

**GOAL:** importere EHF-fakturaer og -kreditnotaer (PEPPOL BIS Billing 3.0, UBL 2.1) som originaldokumenter, lese dem i den isolerte arbeidsprosessen og registrere dem som kanoniske fakturaer med eksakte verdier og proveniens, uten OCR og uten gjetting.

**OUTPUT:** migrasjon `0004_ehf`, utvidet migrator (ADR-0032), XML-gjenkjenning, EHF-leser i arbeidsprosessen, kontroller og flagg i hovedprosessen, import og kobling av vedlegg, registrering som utkast, visning i innboksen, selvtest med syntetisk EHF, dokumentasjon og denne rapporten.

## 2. Faktisk datamodell

Se `DATA_MODEL.md` §3.12.

- `documents` og `processing_jobs` er bygget om etter SQLites tolvstegsprosedyre. De tillater nå `xml`, `ehf_attachment`, `ehf_extraction` og de nye feilkodene. Alle rader, hasher, indekser og utløsere er beholdt.
- `invoice_findings` (ny): flagg per faktura og revisjon med faste koder, enhetsavgrenset med sammensatte FK-er, kun tilføyelse.
- Fakturaen ligger i `invoices`/`invoice_revisions` (status `draft`), knyttet til XML-dokumentet. Vedleggene er egne dokumenter, koblet med `document_links` (`attachment`).
- Revisjon: `document.processing_started`/`finished` (nå også med `line_count`, `attachment_count`, `finding_count`) og `invoice.created`. Aldri beløp, navn eller tekst fra fakturaen.

## 3. Migrasjon `0004` (ADR-0032)

ADR-0029 viste at en foreldretabell ikke kan bygges om i en transaksjon med `foreign_keys=ON`. Revisjonen erklærer derfor `FOREIGN_KEYS_OFF = True`. Migratoren slår av fremmednøkler på tilkoblingen før `BEGIN` og bare når en ventende revisjon krever det. Før commit, i samme transaksjon, kontrolleres:

- antall rader før og etter;
- at `PRAGMA foreign_key_check` er tom;
- innstillingene;
- hele revisjonskjeden.

Sikkerhetskopien tas før migrasjonen som i ADR-0028. `legacy_alter_table=ON` brukes bare rundt `RENAME`, fordi utløseren `invoices_reference_document` viser til `documents`.

Testet: en F04-database med dokumenter, jobber, sider, avledede filer og koblinger migreres med alle rader og hasher uendret, ren FK-kontroll, gyldig kjede og sikkerhetskopi. En dangling referanse stopper migrasjonen og etterlater originalen uendret.

## 4. Behandlingsløp

1. **Import (F03):** filen gjenkjennes som XML ved signatur (valgfri UTF-8 BOM, `<?xml`, eller rotelementet `<Invoice`/`<CreditNote`) og endelsen `.xml`. Ellers havner den i karantene.
2. **Jobb** `ehf_extraction` med motor `ehf` og versjon `1.0+0.7.1` (leser + defusedxml). Den er idempotent som i F04.
3. **Arbeidsprosessen** (Job Object, 120 s, 2 GB):
   - leser filen og kontrollerer hashen;
   - parser strømmet med `defusedxml`; DTD, entiteter og eksterne referanser er forbudt, med dybde ≤ 64 og ≤ 500 000 elementer;
   - kontrollerer rotens navnerom, `CustomizationID` og `ProfileID`;
   - mapper til `CanonicalInvoice`;
   - dekoder innebygde vedlegg (base64, streng) til `attachment-NN.bin`.

   Rapporten er bytes og valideres med Pydantic.
4. **Hovedprosessen:**
   - kontrollerer motor, versjon og hash;
   - validerer fakturaen;
   - kontrollerer størrelsen på hvert vedlegg;
   - importerer vedleggene gjennom `DocumentService` med F03-kontrollene. Oppgitt filnavn og MIME-type stoles ikke på.

   Deretter beregnes flaggene, og fakturaen, flaggene, koblingene og sluttstatusen skrives i **én** transaksjon.
5. **Innboksen** viser «EHF», leverandør, fakturanummer, beløp og avvik på norsk. En PDF-visning blant vedleggene kan analyseres med «Behandle nye dokumenter» (F04).

**Mapping** (OUTPUT punkt 3). Hver verdi har XPath i `source_ref` og teksten slik den står i `raw_text`. En verdi som ikke kan tolkes (f.eks. `1 234,50`, `1E3`, `NaN`), blir `None` med råtekst og gir flagget `unreadable_value`. Mappingen dekker:

- **Hode:**
  - `cbc:ID`, utstedelses- og forfallsdato, type (380/381);
  - valuta, `BuyerReference`;
  - `BillingReference` for kreditnota.
- **Parter:** leverandør og kunde med navn, organisasjonsnummer (`schemeID` 0192), MVA-nummer og adresse.
- **Betaling:** KID (`PaymentID`), konto eller IBAN, BIC.
- **Linjer:** nummer, beskrivelse, mengde og enhet, pris, nettobeløp, MVA-sats.
- **MVA og totaler:** MVA-spesifikasjon og totaler (eks. MVA, MVA, øreavrunding, å betale).

**Kontroller** (flagges, stoppes aldri stille):

- **Regneregler:**
  - BR-CO-10: linjesum = `LineExtensionAmount`;
  - BR-CO-13: netto − rabatter + gebyrer = eks. MVA;
  - BR-CO-14: MVA = sum av MVA-spesifikasjonen;
  - BR-CO-15: eks. MVA + MVA = inkl. MVA;
  - BR-CO-16: inkl. MVA − forskudd + avrunding = å betale.
- **Øvrige flagg:**
  - avvikende valuta, negativt beløp å betale;
  - feil eller manglende mottaker (mot regnskapsenhetens organisasjonsnummer);
  - mulig duplikat (samme leverandør og fakturanummer i enheten);
  - manglende obligatoriske felt;
  - ekstern vedleggsreferanse (hentes aldri);
  - vedlegg i karantene.

## 5. Avvik og tolkninger

| Punkt | Valg | Begrunnelse |
|---|---|---|
| Gyldne filer | Bygges i testene av `bootstrap/synthetic_ehf.py`, ikke lagret som XML-filer | Offisielle eksempelfiler fra OpenPEPPOL/DFØ er ikke tatt inn, fordi lisensen ikke er verifisert. Generatoren regner MVA per sats som BIS 3.0. |
| Vedlegg over grensen (50 MB) eller flere enn 20 vedlegg | Hele EHF-filen avvises (`attachment_too_large`, `too_many_attachments`) | Vedleggene dekodes i arbeidsprosessen før noe registreres; en delvis faktura uten de lovede vedleggene registreres ikke. |
| Promptets spørsmål 2 (feil mottaker) | Bare flagg (`wrong_recipient`) | Forsiktig standard til prosjekteier har svart; ingenting bokføres uansett. |
| Promptets spørsmål 3 (vedlegg som ikke er PDF eller bilde) | Karantene via F03, og flagget `attachment_refused` | Samme løp som andre ukjente filer; ingenting kastes. |
| Promptets spørsmål 4 (UDIs organisasjonsnummer) | Ikke i koden; leses fra regnskapsenheten. Uten nummer gjøres ingen mottakerkontroll. | Må registreres på enheten. |
| Tom regnskapsenhet uten organisasjonsnummer | Ingen mottakerflagg | Det finnes ingenting å sammenligne med. |

## 6. Testresultater

Lokalt (Linux, Python 3.13, gren `claude/phase15-ehf`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen) | 1031 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | Total 94 %; `processing/ehf.py` 87 %, `synthetic_ehf.py` 100 % |
| Ruff lint og format | Ingen funn |
| Bandit | Ingen funn |
| pip-audit (`--require-hashes`) | Ingen kjente sårbarheter |

Windows-CI og `.exe`-selvtesten: se PR-en.

Fiendtlig XML (kontraktstester; utvalg merket ✱ også gjennom den ekte arbeidsprosessen):

| Fil | Utfall |
|---|---|
| Ekstern entitet (XXE) ✱, ekstern DTD | `invalid_xml`; ingenting lest utenfor filen |
| «Billion laughs» ✱, kvadratisk oppblåsing | `invalid_xml` |
| Dyp nesting ✱ | `invalid_xml` (dybdegrense) |
| Ugyldig UTF-8, ugyldig base64, tom og avkortet fil | `invalid_xml` |
| Feil rotelement | `unsupported_format` |
| EHF 2.x ✱ | `unsupported_version` |
| For mange linjer, for mange og for store vedlegg (nedskalerte grenser) | `too_many_lines`, `too_many_attachments`, `attachment_too_large` |
| Tall med feil format | Registrert med `None` og råtekst, flagget `unreadable_value` |
| Manglende obligatoriske felt | Registrert med manglende felt, flagget `missing_required` |
| Negative mengder | Tillatt (rabattlinjer) |
| Ekstern vedleggsreferanse | Ikke hentet, flagget `external_attachment` |
| Forkledd vedlegg (`MZ` som `.pdf`) | Karantene, flagget `attachment_refused` |

Etter hver kjøring gjennom den ekte arbeidsprosessen er prosessen borte, originalen er uendret, og arbeidsmappen er tom.

**Ikke prøvd:**

- ekte EHF-fakturaer (forbudt før porten for ekte data);
- offisielle eksempelfiler fra OpenPEPPOL eller DFØ (lisensen er ikke verifisert);
- full PEPPOL-validering med Schematron og kodelister (Java-basert, utenfor omfanget);
- EHF-filer fra Tripletex eller et aksesspunkt (Å-24 er åpen);
- ytelse på svært store filer nær 50 MB;
- manuell Windows 11-test.

## 7. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Migrasjon 0004 og migrator (ADR-0032) | ✅ | ✅ | ✅ | se PR | – | – |
| XML-gjenkjenning | ✅ | ✅ | ✅ | se PR | – | – |
| EHF-leser i arbeidsprosessen | ✅ | ✅ | ✅ | se PR | – | – |
| Kontroller, flagg, duplikat, mottaker | ✅ | ✅ | ✅ | se PR | – | – |
| Vedlegg og koblinger | ✅ | ✅ | ✅ | se PR | – | – |
| Innboks-visning | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| Manuell Windows 11-test | ✅ | – | – | – | – | – |

## 7b. Etterfølgende avklaring (2026-10-24)

Prosjekteier delegerte svarene på Å-24 og spørsmål 2–4 til utvikleren (D-30, G-12):

- Standardene i §5 gjelder videre.
- EHF kommer som XML-filer via «Importer fil» eller innboksen.
- Om UDIs Tripletex allerede tar imot EHF direkte, må fortsatt bekreftes med UDI.

## 8. Gjenstående risiko og beslutninger

- **Å-24 er åpen:** hvordan kommer EHF-filene inn, og tar UDIs Tripletex allerede imot EHF direkte? Svaret avgjør nytten for UDI.
- **Promptets spørsmål 2–4 er åpne:** feil mottaker, vedlegg som ikke er PDF eller bilde, og UDIs organisasjonsnummer. Standardene står i §5.
- **T36:** uten full Schematron-validering kan en fil som bryter andre BIS-regler, registreres som utkast. Flaggene og gjennomgangen i F09 er kontrollen. Ingenting bokføres eller eksporteres automatisk.
- **defusedxml 0.7.1** er fra 2021 og har lite vedlikehold. Det er ingen kjente sårbarheter, men pakken må følges.
- **T30 (F04)** gjelder også XML-leseren: arbeidsprosessen kjører som samme Windows-bruker.
- D-19 (restrisiko) er åpen; porten for ekte data (SECURITY §17) er uendret.

## 9. Manuell Windows 11-aksept

Bruk en ny testkatalog og bare syntetiske filer.

```powershell
$dir = "$env:TEMP\InvoiceFlowAI-F15-test"
.\InvoiceFlowAI.exe --self-test --data-dir $dir
.\InvoiceFlowAI.exe --data-dir $dir
```

1. Forvent «Selvtest bestått» og kode 0. Selvtesten importerer og behandler en syntetisk EHF-faktura.
2. Opprett en fiktiv regnskapsenhet med organisasjonsnummer `314159268`. Importer en syntetisk EHF-fil laget med `invoiceflow.bootstrap.synthetic_ehf.build_ehf()` og lagret som `.xml`.
3. Velg «Behandle nye dokumenter». Forvent:
   - format «EHF»;
   - leverandør «Syntetisk Leverandør AS»;
   - fakturanummer `EHF-2026-001`;
   - beløp 13 125,00 NOK;
   - ingen avvik.
4. Endre organisasjonsnummeret på enheten (eller bruk en annen enhet), importer på nytt og behandle. Forvent avviket «feil mottaker».
5. Importer en tekstfil med endelsen `.xml`. Forvent karantene eller «Avvist: ugyldig XML».

## 10. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- prosjekteiers gjennomgang og godkjenning av sammenslåing;
- svar på Å-24 og spørsmål 2–4;
- manuell Windows 11-test;
- formell faseaksept.

F05, F08 og F09 er ikke påbegynt.
