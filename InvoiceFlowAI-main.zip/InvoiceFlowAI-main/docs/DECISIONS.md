# InvoiceFlow AI – Arkitekturbeslutninger (ADR)

Hver beslutning har status:

- **Akseptert** – teknisk beslutning tatt av arkitekten i tråd med masterprompten. Betyr **ikke** at prosjekteier har godkjent den; godkjenningsstatus føres i `PHASE_00_DECISION_REGISTER.md`.
- **Foreslått** – anbefaling som krever godkjenning fra prosjekteier.
- **Krever beslutning** – prosjekteier må velge før angitt fase.
- **Erstattet** – avløst av senere ADR (lenke).

Nye beslutninger føyes til nederst med neste nummer. Eksisterende ADR-er endres ikke i innhold; de erstattes.

## Oversikt

| ADR | Tittel | Status |
|---|---|---|
| 0001 | Modulær monolitt med porter og adaptere | Akseptert |
| 0002 | Python 3.13 (64-bit) som målversjon | Akseptert |
| 0003 | Kanonisk fakturamodell med proveniens per felt (Pydantic v2) | Akseptert |
| 0004 | Beløp som `Decimal`; strenger i JSON; `TEXT` i SQLite | Akseptert |
| 0005 | SQLite + SQLAlchemy 2.0 + Alembic med WAL og `synchronous=FULL` | Akseptert |
| 0006 | Datakatalog i `%LOCALAPPDATA%`, innholdsadresserte originaler | Akseptert (lagringssti utvidet av ADR-0022) |
| 0007 | OCR: Tesseract først, PaddleOCR som valgfri adapter | Foreslått |
| 0008 | KI: adapter, av som standard, lokal før sky, proveniens settes av kode | Akseptert (arkitektur) / Krever beslutning (leverandør) |
| 0009 | Hemmeligheter i Windows Credential Manager via `keyring` | Foreslått |
| 0010 | Isolert arbeidsprosess for parsing av ikke-klarerte filer | Implementert i F04 (ADR-0031); implementering godkjent (G-09) |
| 0011 | `opencv-python-headless` i stedet for `opencv-python` | Akseptert |
| 0012 | Lisens for PyMuPDF (AGPL-3.0) | Erstattet av ADR-0023 |
| 0013 | Godkjenning bundet til innholdshash; idempotent eksport | Akseptert |
| 0014 | PyInstaller *onedir* | Foreslått |
| 0015 | Sentral oversettelseskatalog i Python | Foreslått |
| 0016 | Revisjonslogg med hashkjede, kun tilføyelse | Akseptert |
| 0017 | Avhengighetsstyring: intervaller i `pyproject.toml` + universell låsefil med hasher | Erstattet av ADR-0024 |
| 0018 | Utviklingsverktøy og CI på Windows | Akseptert |
| 0019 | XML-parsing kun med `defusedxml` | Akseptert |
| 0020 | Fortegnskonvensjon for kreditnota | Akseptert – godkjent 2026-10-23 (D-16, G-11) |
| 0021 | `AGENTS.md` for leverandørnøytral kontinuitet | Akseptert |
| 0022 | Regnskapsenhet (`accounting_entity`) i persistensmodellen fra start | Akseptert (teknisk) – business-avklaring Å-17 gjenstår |
| 0023 | PDF-lisens og utskiftbar PDF-adapter (erstatter ADR-0012) | Akseptert – alternativ C (pypdfium2), godkjent 2026-10-23 (D-11, G-09) |
| 0024 | Avhengighetsoppdatering: karantene med sikkerhetsunntak (erstatter ADR-0017) | Foreslått |
| 0025 | Kanonisk tallform og strenge skalartyper i kontraktene | Akseptert (implementert og testet) |
| 0026 | Fakturarevisjoner som autoritativt snapshot; eksplisitt enhet | Teknisk akseptert i F02; godkjent av prosjekteier 2026-10-22 (D-20, D-21) |
| 0027 | Global append-only revisjonskjede | Teknisk akseptert i F02 |
| 0028 | Kontrollert migrasjon og sikkerhetskopi | Teknisk akseptert i F02 |
| 0029 | Generisk dokumentarkiv: modell, lager, krasjmodell og fakturakobling | Teknisk akseptert i F03 (G-05); avvik pkt. 4 godkjent (D-25, G-06) |
| 0030 | Utgående nettverk for ERP-integrasjoner (Tripletex, Xledger) | Akseptert – godkjent av prosjekteier 2026-10-23 (D-26, G-08) |
| 0031 | Arbeidsprosess for dokumentbehandling: Job Object via `ctypes`, ett dokument per prosess | Teknisk akseptert i F04 |
| 0032 | Migrasjon med ombygging av foreldretabeller: `foreign_keys` av utenfor transaksjonen | Teknisk akseptert i F15 |
| 0033 | Valideringsmotor, lagring per kjøring og leverandørregister med kontostatus | Teknisk akseptert i F08a |
| 0034 | Referansedata som øyeblikksbilder, leverandørstandard og konteringsforslag | Teknisk akseptert i F08b |
| 0035 | Godkjenning bundet til innholdshash, overstyring med begrunnelse og blokkerende funn | Teknisk akseptert i F09 |
| 0036 | Krasjsikker filseksport med databasehindring av dobbel eksport og formelvern | Teknisk akseptert i F10 |
| 0037 | Kryptert sikkerhetskopi i én fil med autentiserte biter og kontrollert gjenoppretting | Teknisk akseptert i F12 |
| 0038 | Overvåket skannemappe og oppdeling av bunker etter målt sidemørkhet | Teknisk akseptert i F11a |
| 0039 | Skanning via produsentens program til skannemappen, uten skannerdriver i programmet | Teknisk akseptert i F11b |
| 0040 | OCR med Tesseract som eget steg i den isolerte arbeidsprosessen | Teknisk akseptert i F05 |
| 0041 | Regelbasert feltuttrekk fra ord med posisjon, ett fakturautkast per del | Teknisk akseptert i F06 |

---

## ADR-0001 – Modulær monolitt med porter og adaptere

- **Status:** Akseptert
- **Kontekst:** Én lokal bruker, krav om utskiftbare OCR-/KI-/ERP-leverandører og streng ansvarsdeling.
- **Beslutning:** Én skrivebordsapplikasjon med lagene presentasjon → applikasjon → domene, og adaptere bak porter (`Protocol`). Komposisjonsrot i `bootstrap`. Grenser håndheves av arkitekturtester.
- **Alternativer:** (a) Lokal klient/server med REST – unødvendig kompleksitet, flere angrepsflater. (b) Flat skriptstruktur – rask start, men bryter med testbarhet og utskiftbarhet. (c) Plugin-system med dynamisk lasting – YAGNI og økt risiko for kodekjøring.
- **Begrunnelse:** Enklest arkitektur som oppfyller utskiftbarhet (DIP) og testbarhet.
- **Risiko:** Grenser kan erodere over tid → arkitekturtester utvides for hver ny pakke.

## ADR-0002 – Python 3.13 (64-bit)

- **Status:** Akseptert
- **Kontekst:** Stakken må ha Windows-hjul (`win_amd64`) for alle native pakker.
- **Beslutning:** Python 3.13 x64. `requires-python = ">=3.13,<3.14"`.
- **Alternativer:** 3.12 (støttes til okt. 2028; trygt, men eldre); 3.14 (PaddlePaddle 3.3.1 har ikke `cp314`-hjul for Windows per 2026-10-20).
- **Begrunnelse:** Verifisert hjulstøtte for PySide6, PyMuPDF, OpenCV, Pillow, SQLAlchemy, pydantic-core, PaddlePaddle og pywin32 for `cp313-win_amd64` (se `DEPENDENCIES.md`). Sikkerhetsoppdateringer til oktober 2029.
- **Risiko:** Ny overgang (3.14/3.15) før 2029 må planlegges.

## ADR-0003 – Kanonisk fakturamodell med proveniens per felt

- **Status:** Akseptert (implementert og testet i Fase 00)
- **Kontekst:** Verdier kommer fra tekstlag, OCR, KI, regler og brukere; kilden må alltid være synlig.
- **Beslutning:** `CanonicalInvoice` der hver verdi er `FieldValue[T]` = verdi + `Provenance` (kilde, produsent, konfidens, kildehenvisning, tidspunkt). Alle kontrakter `extra="forbid"` og `frozen=True`. Arbeidsflytstatus er utenfor kontrakten.
- **Alternativer:** (a) Flat modell + proveniens bare i database – mister proveniens i JSON/KI-grensesnitt. (b) Proveniens bare per faktura – for grovt for gjennomgang.
- **Begrunnelse:** Én kontrakt for alle adaptere; sporbarhet per felt; strenge skjema er også et sikkerhetstiltak.
- **Risiko:** Mer omfangsrik JSON. Akseptabelt lokalt.

## ADR-0004 – Beløp som `Decimal`; strenger i JSON; `TEXT` i SQLite

- **Status:** Akseptert (kontraktsdelen implementert)
- **Kontekst:** `float` gir avrundingsfeil. SQLite har ingen desimaltype; SQLAlchemy `Numeric` på SQLite går via flyttall.
- **Beslutning:** `Decimal` i all kode; `float` og `bool` avvises ved grensen; JSON-beløp er strenger; SQLite-lagring som `TEXT` via egen `TypeDecorator` (Fase 02). Avrunding med eksplisitt `ROUND_HALF_UP`.
- **Alternativer:** `INTEGER` i øre – fint for totaler, men enhetspriser og mengder trenger flere desimaler, og valuta varierer. `REAL` – forkastet.
- **Risiko:** Sortering/summering i SQL fungerer ikke direkte på `TEXT`; beregninger gjøres i Python. Ved behov kan beregnede heltallskolonner legges til senere.

## ADR-0005 – SQLite + SQLAlchemy 2.0 + Alembic

- **Status:** Akseptert
- **Beslutning:** SQLAlchemy 2.0-linjen (2.0.x per 2026-10; 2.1 vurderes når den har modnet), Alembic for migrasjoner, PRAGMA `foreign_keys=ON`, `journal_mode=WAL`, `synchronous=FULL`, `trusted_schema=OFF`, `secure_delete=ON`.
- **Alternativer:** Rå `sqlite3` (mindre avhengighet, mer egenkode); SQLCipher for kryptert database (krever native bygg og nøkkelforvaltning – vurderes dersom BitLocker ikke kan garanteres, Å-13).
- **Begrunnelse:** Alembic er standard for SQLAlchemy og oppfyller kravet om ikke-destruktive migrasjoner. `FULL` fordi tapt eksportbekreftelse kan føre til dobbel eksport.
- **Risiko:** Alembic er et tillegg til stakktabellen (implisitt av migrasjonskravet) – bekreftes av prosjekteier.

## ADR-0006 – Datakatalog og fillagring

- **Status:** Akseptert
- **Beslutning:** Standard datakatalog `%LOCALAPPDATA%\InvoiceFlowAI` (konfigurerbar). Originaler lagres innholdsadressert som `originals\ab\cd\<sha256>.<ext>`, skrivebeskyttet, adskilt fra `derived\` og `quarantine\`. Brukerens filnavn brukes aldri i stier.
- **Alternativer:** `Dokumenter` (synkroniseres ofte til OneDrive = utilsiktet overføring); `%APPDATA%` (Roaming – kan synkroniseres i domene); `%ProgramData%` (delt mellom brukere).
- **Risiko:** Brukeren kan velge en synkronisert mappe → oppstartsadvarsel.

## ADR-0007 – OCR-motor

- **Status:** Foreslått (Å-05)
- **Beslutning:** Tesseract 5 med norsk språkdata (`nor`) som første adapter, via `pytesseract` (kaller `tesseract.exe` uten skall, med tidsavbrudd). PaddleOCR implementeres som alternativ adapter først etter sammenlignende måling på det syntetiske referansesettet.
- **Alternativer:** PaddleOCR først – ofte bedre på vanskelige skann, men stor avhengighet (PaddlePaddle), tyngre PyInstaller-pakking og automatisk modellnedlasting som må deaktiveres.
- **Begrunnelse:** Tesseract er moden, liten, frakoblet, Apache-2.0 og har norsk språkmodell; prosessgrensen gir naturlig isolasjon.
- **Risiko:** Lavere treffsikkerhet på dårlige skann → forbehandling (F04) og målt sammenligning (F05).

## ADR-0008 – KI-tolkning

- **Status:** Akseptert (arkitektur) / Krever beslutning (leverandør, Å-03/Å-04)
- **Beslutning:** Port `AiInterpreter`. Standard er `DisabledAiInterpreter`; systemet skal fungere fullt uten KI. Første aktive adapter er lokal (f.eks. modellserver på `localhost`). Skyleverandører kun med eksplisitt samtykke per leverandør. KI får ingen verktøy; svar valideres mot eget skjema; proveniens settes av applikasjonskoden.
- **Alternativer:** Skyleverandør som standard – i strid med lokal-først og konfidensialitet.
- **Risiko:** Lokal modell kan være treg uten GPU; måles i F07.

## ADR-0009 – Hemmeligheter

- **Status:** Foreslått
- **Beslutning:** Port `SecretStore` med adapter for Windows Credential Manager via `keyring` (Windows-backend, DPAPI-beskyttet per bruker).
- **Alternativer:** Direkte DPAPI via `pywin32` (`win32crypt`) med egen fil; miljøvariabler (forkastet: lekker lett).
- **Risiko:** Skadevare som samme bruker kan lese hemmeligheten (akseptert restrisiko, T03).

## ADR-0010 – Isolert arbeidsprosess

- **Status:** Implementert i F04; detaljene står i ADR-0031. Implementering godkjent via F04-promptet (D-12, G-09).
- **Beslutning:** Parsing/rasterisering/OCR i `multiprocessing`-prosess (spawn) per oppgave, med tidsavbrudd, minnegrense via Windows Job Object, ingen DB/nett/hemmeligheter, og JSON-resultat validert med Pydantic.
- **Alternativer:** Samme prosess (krasj tar ned appen); AppContainer/sandkasse (sterkere, men kompleks på Windows – vurderes senere).
- **Risiko:** Oppstartskostnad per prosess (~0,5–1 s); akseptabelt for fakturavolum.

## ADR-0011 – `opencv-python-headless`

- **Status:** Akseptert
- **Begrunnelse:** Standardpakken `opencv-python` har egne GUI-avhengigheter (Qt/HighGUI) som kan komme i konflikt med PySide6 og gjør bygget større. Applikasjonen trenger bare bildeoperasjoner. OpenCV 4.x-linjen velges inntil 5.x er vurdert.

## ADR-0012 – Lisens for PyMuPDF

- **Status:** Erstattet av ADR-0023 (2026-10-20). Opprinnelig: Krever beslutning før F04 (Å-06)
- **Kontekst:** PyMuPDF er dobbeltlisensiert: AGPL-3.0 eller kommersiell lisens fra Artifex. AGPL kan kreve at kildekoden til hele programmet gjøres tilgjengelig for mottakere ved distribusjon.
- **Alternativer:** (a) Behold PyMuPDF – greit ved kun intern bruk, men må vurderes juridisk ved distribusjon. (b) Kjøp kommersiell lisens. (c) Bytt til `pypdfium2` (Apache-2.0/BSD) for tekst og rasterisering – avvik fra obligatorisk stakk, krever godkjenning.
- **Anbefaling:** Behold PyMuPDF for intern testbruk; avklar før eventuell distribusjon. PDF-tilgang holdes bak porten `DocumentParser`, slik at bytte er avgrenset.

## ADR-0013 – Godkjenning og eksport

- **Status:** Akseptert
- **Beslutning:** Godkjenning lagrer `content_sha256` og et øyeblikksbilde av kanonisk JSON. Endring etter godkjenning opphever den. Eksport krever gyldig godkjenning og registreres i `export_items` med delvis unik indeks (`invoice_id`, `target`) for aktive rader; re-eksport er eksplisitt og begrunnet.
- **Begrunnelse:** Menneske i løkken, idempotens, sporbarhet.

## ADR-0014 – PyInstaller *onedir*

- **Status:** Foreslått
- **Begrunnelse:** *Onefile* pakker ut til `%TEMP%` ved hver start (tregere, flere falske antiviruspositiver, midlertidige filer). *Onedir* starter raskere, gjør Qt-bibliotekene utskiftbare (LGPL) og er enklere å signere og verifisere.
- **Risiko:** Flere filer å distribuere → installasjonspakke/zip med hasher i F13.

## ADR-0015 – Oversettelseskatalog

- **Status:** Foreslått (F01)
- **Beslutning:** Nøkkelbasert katalog i Python (`invoiceflow.i18n`) med `nb-NO` som eneste språk; funksjon for oppslag med navngitte parametere; tester for manglende nøkler. Qt sine egne standardtekster lastes fra Qt-oversettelser dersom norsk (`nb`) finnes, ellers settes tekstene eksplisitt.
- **Alternativer:** Qt Linguist (`.ts`/`.qm`) – krever Qt-verktøy i byggekjeden og virker bare i Qt-laget, mens valideringsmeldinger og eksportoverskrifter også trenger oversettelse; `gettext` – godt alternativ, men nøkkelbasert katalog er enklere å teste for fullstendighet.

## ADR-0016 – Revisjonslogg med hashkjede

- **Status:** Akseptert
- **Beslutning:** `audit_events` er kun-tilføyelse (triggere), hver hendelse har SHA-256 av forrige; ankre i sikkerhetskopier og eksportbatcher. Ingen sensitive verdier i detaljene.
- **Risiko:** Se T11.

## ADR-0017 – Avhengighetsstyring

- **Status:** Erstattet av ADR-0024 (2026-10-20). Opprinnelig: Foreslått
- **Beslutning:** `pyproject.toml` angir kompatible intervaller for avhengigheter som faktisk brukes. `requirements/dev.lock.txt` er en universell låsefil (Windows og Linux) med eksakte versjoner og SHA-256-hasher, generert med `uv pip compile` og installert med `pip --require-hashes`. Nye versjoner tas inn etter **30 dagers karantene** (`--exclude-newer`), unntatt sikkerhetsrettinger.
- **Regenerering:**

  ```powershell
  uv pip compile pyproject.toml --extra dev --extra security --universal `
    --python-version 3.13 --generate-hashes --exclude-newer <dato minus 30 dager> `
    --no-header -o requirements/dev.lock.txt
  ```

- **Alternativer:** `pip-tools` (`pip-compile --generate-hashes`) – likeverdig; uv valgt fordi den lager én universell fil. Låsefilen er vanlig pip-format, så pip er fortsatt installasjonsverktøyet.
- **Risiko:** Byggeverktøyet (`setuptools`) hentes uten hash ved redigerbar installasjon – lav risiko, adresseres i F13.

## ADR-0018 – Utviklingsverktøy og CI

- **Status:** Akseptert
- **Beslutning:** Ruff (lint + formatering, inkl. `S`- og `DTZ`-regler), pytest (+ pytest-cov), Bandit, pip-audit, Gitleaks. GitHub Actions kjører tester og analyse på `windows-latest` og Gitleaks på Ubuntu.
- **Merknad:** Ruff er et tillegg til stakktabellen (utviklingsverktøy, ikke kjøretid). Forhåndsvisningsregelen `PLW1514` (fil-I/O uten `encoding`) er slått på eksplisitt fordi Windows bruker cp1252 som standard; andre forhåndsvisningsregler er ikke aktivert.

## ADR-0019 – XML-parsing

- **Status:** Akseptert
- **Beslutning:** All XML (EHF/PEPPOL) parses med `defusedxml`; aldri `xml.etree`/`lxml` direkte på ikke-klarert inndata. Størrelsesgrense før parsing.

## ADR-0020 – Fortegn for kreditnota

- **Status:** Akseptert. Godkjent av prosjekteier 2026-10-23 (D-16, G-11); regnskapsansvarlig bør bekrefte før porten for ekte data.
- **Beslutning:** Kanoniske totaler for kreditnotaer lagres som positive beløp; `invoice_type = credit_note` angir retning, og fortegnet anvendes i eksportadapteren etter ERP-ets konvensjon. Negative linjer tillates (rabatt).
- **Risiko:** Leverandører som skriver negative beløp på kreditnota må normaliseres i uttrekket (F06); valideringsregel kontrollerer konsistens.

## ADR-0021 – `AGENTS.md`

- **Status:** Akseptert
- **Beslutning:** `AGENTS.md` i rotkatalogen gir leverandørnøytrale arbeidsregler for KI-assistenter og utviklere (lesrekkefølge, kommandoer, sikkerhetsregler, Definisjon av ferdig). Ingen leverandørspesifikke instruksjonsfiler er nødvendige.
- **Begrunnelse:** Mange KI-verktøy leser `AGENTS.md`; innholdet er vanlig Markdown og fungerer også for mennesker.

## ADR-0022 – Regnskapsenhet i persistensmodellen fra start

- **Status:** Akseptert (teknisk). Om installasjonen faktisk skal brukes for flere selskaper (Å-17), er fortsatt et forretningsspørsmål, men arkitekturen avhenger ikke lenger av svaret.
- **Kontekst:** Første versjon brukes av én bruker og trolig én regnskapsenhet. Å legge til et enhetsbegrep etter at data finnes krever migrering av nesten alle tabeller, endrede unike nøkler og risiko for at data fra ulike selskaper blandes.
- **Beslutning:**
  1. Ny tabell `accounting_entities` (regnskapsenhet: navn, organisasjonsnummer, standardvaluta, aktiv). Fase 02 oppretter nøyaktig én enhet ved første oppstart.
  2. Alle tabeller med regnskapsdata får `entity_id NOT NULL`: dokumenter, fakturaer, leverandører, kontoplan, MVA-koder, dimensjoner, godkjenninger, eksportbatcher, eksportlinjer og prosesseringsjobber. Revisjonshendelser og innstillinger har `entity_id` som kan være NULL (globale hendelser/innstillinger).
  3. Unike nøkler og duplikatnøkler er enhetsavgrenset: `UNIQUE(entity_id, sha256)` for dokumenter, `duplicate_key` starter med `entity_id`, kontoplanen har `PRIMARY KEY(entity_id, account)`.
  4. **Databasen hindrer blanding:** Barn refererer foreldre med sammensatte fremmednøkler `(entity_id, id)` (f.eks. faktura → leverandør, eksportlinje → eksportbatch og faktura), slik at en faktura aldri kan kobles til en leverandør eller batch i en annen enhet.
  5. **Applikasjonen hindrer blanding:** Repositorier tar et obligatorisk `EntityScope`-objekt; det finnes ingen uavgrensede spørringer. Håndheves med arkitekturtest fra F02.
  6. Dokumentlageret er delt per enhet: `documents\<entity_id>\originals\ab\cd\<sha256>.<ext>` (utvider ADR-0006).
  7. Den kanoniske fakturakontrakten får **ikke** et enhetsfelt. Hvilken enhet som eier en faktura er en eierskaps- og arbeidsflytopplysning (avgjort ved import), ikke fakturainnhold. Godkjenning binder `entity_id` sammen med innholdshashen.
  8. Grensesnittet er én-enhets i første versjon (enheten vises, men kan ikke byttes). Administrasjon av flere enheter er ikke i omfang.
- **Alternativer:** (a) Én database per enhet – sterk isolasjon, men duplisert migrering/backup og ingen felles leverandørsøk; kan fortsatt velges senere for strengere krav. (b) Utsette til behov oppstår – avvist, migreringskostnaden er høy og risikoen for blanding reell.
- **Konsekvenser:** Litt mer kode og flere kolonner i F02; ingen datamigrering senere. Duplikatkontroll (DUP-001/002) og leverandørkontoer (BANK-001) gjelder innenfor én enhet.
- **Fremtidige akseptansetester (F02+):** innsetting av faktura med leverandør fra annen enhet avvises av databasen; samme PDF kan importeres i to enheter, men ikke to ganger i samme; duplikatsjekk finner ikke treff på tvers av enheter; repositoriemetoder uten `EntityScope` finnes ikke (arkitekturtest); eksportbatch med fakturaer fra to enheter avvises.

## ADR-0023 – PDF-lisens og utskiftbar PDF-adapter

- **Status:** Akseptert. Prosjekteier valgte alternativ (C) 2026-10-23 (D-11, G-09): pypdfium2 er standardadapter, og PyMuPDF utgår av den obligatoriske stakken. Erstatter ADR-0012.
- **Kontekst:** PyMuPDF (og MuPDF) er dobbeltlisensiert: GNU AGPL-3.0 eller kommersiell lisens fra Artifex. Dette er ikke en implementasjonsdetalj: lisensen kan påvirke hvordan hele InvoiceFlow AI kan distribueres. Vurderingen under er teknisk, ikke juridisk rådgivning.
- **AGPL-3.0 – relevante forpliktelser (forenklet):**
  1. Den som *formidler* («convey») programmet – også som PyInstaller-pakket `.exe` – må gi mottakeren tilgang til korresponderende kildekode for hele det kombinerte verket under AGPL-3.0, lisensteksten og informasjon som gjør det mulig å bytte ut/endre komponenten.
  2. Et lukket, proprietært program kan normalt ikke formidles sammen med AGPL-kode uten kommersiell lisens.
  3. AGPL §13 (nettverksinteraksjon) gjelder endrede versjoner som brukere samhandler med over nettverk; lite relevant for en lokal skrivebordsapp, men relevant hvis funksjonalitet senere tilbys som tjeneste.
- **Intern bruk kontra distribusjon:** Kjøring og kopiering innen én organisasjon regnes ofte ikke som formidling. Men det er **ikke** automatisk trygt: å gi programmet til et annet selskap (f.eks. et søsterselskap i et flerenhetsscenario), en regnskapsfører, en kunde eller en innleid konsulent kan være formidling. Et privat repo endrer ikke dette – forpliktelsen utløses av hvem som mottar programmet, ikke av hvor koden ligger.
- **Kommersiell lisens:** Artifex tilbyr kommersielle lisenser som fjerner AGPL-forpliktelsene. Pris og vilkår må innhentes fra leverandøren.
- **Alternativer (verifisert på PyPI 2026-10-20):**

  | Bibliotek | Lisens | Tekst med posisjon | Rasterisering (til OCR/visning) | Merknad |
  |---|---|---|---|---|
  | PyMuPDF 1.28.x | AGPL-3.0 / kommersiell | Ja, svært god | Ja, rask | Obligatorisk i stakken i dag |
  | pypdfium2 5.x | Apache-2.0 / BSD-3 (+ avhengighetslisenser) | Ja (tegnposisjoner) | Ja (PDFium) | Windows-hjul; nærmeste permissive erstatning |
  | pdfminer.six | MIT | Ja, god layoutanalyse | Nei | Ren Python, tregere |
  | pypdf 6.x | BSD-3 | Grunnleggende | Nei | Ren Python |
  | Poppler-baserte verktøy | GPL | Ja | Ja | Copyleft – løser ikke problemet |

  Kombinasjonen pypdfium2 (rasterisering og tekst) eventuelt med pdfminer.six (layout) dekker behovene uten copyleft. Det er likevel et avvik fra obligatorisk stakk og krever godkjenning.
- **Beslutning:**
  1. All PDF-tilgang går gjennom porten `DocumentParser` i den isolerte arbeidsprosessen; ingen annen modul importerer et PDF-bibliotek (arkitekturtest fra F04).
  2. F04 lager et felles sett kontraktstester (tekst, posisjoner, sideantall, rasterisering, feilhåndtering for fiendtlige filer) som enhver PDF-adapter må bestå.
  3. **Beslutningsport før F04:** Prosjekteier velger (A) PyMuPDF under AGPL for strengt intern bruk, bekreftet juridisk; (B) PyMuPDF med kommersiell lisens; eller (C) pypdfium2 som standardadapter (stakkendring). Uten avklaring startes ikke F04.
  4. Valgt: (C). (B) kan vurderes på nytt bare hvis måling viser at PyMuPDF gir vesentlig bedre resultater, og krever da ny godkjenning. Begrunnelse: unngår at en fremtidig distribusjon – for eksempel til en annen regnskapsenhet – låser prosjektet til AGPL eller lisenskjøp.
- **Risiko:** Feil vurdering kan gi krav om kildekodeutlevering eller lisenskostnad. Restrisikoen reduseres av at bytte er avgrenset til én adapter.

## ADR-0024 – Avhengighetsoppdatering: karantene med sikkerhetsunntak

- **Status:** Foreslått. Erstatter ADR-0017 (innholdet derfra videreføres).
- **Beslutning:**
  1. `pyproject.toml` angir kompatible intervaller for avhengigheter som faktisk brukes; `requirements/dev.lock.txt` låser eksakte versjoner med SHA-256-hasher og installeres med `pip --require-hashes`.
  2. **Normal oppdatering:** nye versjoner tas inn først etter 30 dagers karantene (`uv pip compile --exclude-newer <dato − 30 dager>`). Begrunnelse: de fleste ondsinnede pakkeversjoner oppdages og trekkes tilbake innen dager.
  3. **Sikkerhetsunntak:** Når pip-audit, en sikkerhetsmelding (GHSA/PYSEC/CVE) eller leverandøren melder en sårbarhet som berører en låst pakke, kan rettet versjon tas inn **umiddelbart**, uten karantene, når: (a) sårbarheten er relevant for bruken vår eller alvorlighetsgraden er høy/kritisk, (b) rettet versjon kommer fra pakkens offisielle utgivelseskanal, (c) endringslogg/diff er sett gjennom, (d) hele testsettet og CI på Windows er grønne. Unntaket begrunnes i commit-melding og `CHANGELOG.md`.
  4. Kan sårbarheten ikke rettes (ingen rettet versjon), dokumenteres risikovurdering og eventuell `--ignore-vuln` med utløpsdato i `DEPENDENCIES.md`.
  5. Låsefilen regenereres minst månedlig, og pip-audit kjører i CI på hver push.
  6. Fra F01 deles låsefilene i kjøretid og utvikling (`runtime.lock.txt`, `dev.lock.txt`), slik at det pakkede programmet ikke inneholder utviklingsverktøy.
- **Regenerering (normal):**

  ```powershell
  uv pip compile pyproject.toml --extra dev --extra security --universal `
    --python-version 3.13 --generate-hashes --exclude-newer <dato minus 30 dager> `
    --no-header -o requirements/dev.lock.txt
  ```

- **Risiko:** Karantenen forsinker også ikke-sikkerhetsrelaterte feilrettinger; akseptabelt.

## ADR-0025 – Kanonisk tallform og strenge skalartyper

- **Status:** Akseptert (implementert og testet i revisjonen av Fase 00).
- **Kontekst:** Revisjonen fant at like beløp kunne serialiseres ulikt (`"1E+2"`, `"100"`, `"100.000"`, `"-0.00"`), at et heltall som Unix-tidsstempel ble godtatt som dato, at `True` ble godtatt som linjenummer og `"yes"` som boolsk verdi, og at tekst kunne inneholde NUL og usynlige retningstegn. Innholdshashen som binder en godkjenning (ADR-0013) krever én entydig serialisering.
- **Beslutning:** Beløp normaliseres til fast punktum med nøyaktig to desimaler, enhetspris med minst to, mengde og MVA-sats uten overflødige nuller; negativ null blir null. Normaliseringen er eksakt og runder aldri. Datoer godtas kun som `YYYY-MM-DD` eller `date`-objekt. Heltall, boolske verdier og flyttall er strenge. Normaliserte tekstverdier avviser kontroll- og formattegn (Unicode `Cc`/`Cf`) og tom/blank tekst; `raw_text` i kildehenvisningen bevares uendret som bevis.
- **Konsekvenser:** Adaptere (OCR/KI/EHF) må normalisere før de bygger kontrakten; verdier som ikke kan normaliseres lagres som `value=None` med råtekst (uendret prinsipp).

---

## Uavklarte spørsmål

Spørsmålene står i `MASTER_SPECIFICATION.md` §12. Anbefaling, frist og status for hvert spørsmål og hver ADR føres i `PHASE_00_DECISION_REGISTER.md`.

## ADR-0026 – Fakturarevisjoner som autoritativt øyeblikksbilde i F02

- **Status:** Teknisk akseptert innenfor F02-oppdraget. Snapshot-modellen (D-20) og fravær av automatisk standardenhet (D-21) er **godkjent av prosjekteier 2026-10-22** (G-04). Formell faseaksept gjenstår.
- **Erstatter:** De konkrete F02-lagringsforutsetningene i ADR-0022 punkt 1 og `DATA_MODEL.md` §2; øvrige enhetsgrenser videreføres.
- **Beslutning:** Fire forretningstabeller opprettes: `accounting_entities`, `invoices`, `invoice_revisions`, `audit_events`, i tillegg til `alembic_version`. Hele den kanoniske fakturaen, inkludert linjer og proveniens, lagres i en uforanderlig revisjon som kanonisk JSON med SHA-256. Headerkolonnene i `invoices` er en projeksjon for søk, ikke en annen autoritativ kilde. Begge skrives i samme transaksjon. Lesing kontrollerer snapshot-hash, kanonisk representasjon, dokumenttilhørighet og gjeldende projeksjon.
- **Avgrensning:** Normaliserte linje-, MVA- og provenienstabeller i det langsiktige skjemaet er ikke implementert ennå. Fremtidige projeksjoner skal utledes fra snapshotet gjennom en migrasjon; historiske revisjoner må aldri omskrives for å innføre dem.
- **Regnskapsenhet:** Oppstart oppretter ingen fiktiv standardenhet. `EntityService.create` krever eksplisitte opplysninger og fakturatjenestene krever `EntityScope(UUID)`. Administrasjon og valg av enhet i UI er utsatt. Dette erstatter forutsetningen om automatisk opprettelse av én enhet i ADR-0022; forretningsspørsmål Å-17 er fortsatt åpent.
- **Kanonisering:** Sorterte JSON-nøkler, kompakte skilletegn, UTF-8 uten ASCII-escaping, ingen NaN. Provenienstidspunkter normaliseres til UTC og negativt null i koordinater/konfidens normaliseres. F02 etablerer de første vedvarende snapshot-hashene; senere endring av kanonisering krever kompatibilitetsanalyse.
- **Alternativ:** Full normalisering nå ville introdusert mange foreløpig ubrukte tabeller og flere mappingregler. Snapshotet gir tapsfri historikk og en avgrenset start.
- **Konsekvens:** Nye søkefelt må ha eksplisitt, testet projeksjon. Regnskapsregler, duplikatdeteksjon og godkjenning er fremtidige faser.

## ADR-0027 – Én global, append-only revisjonskjede

- **Status:** Teknisk akseptert; utfyller ADR-0016. Prosjekteiers risikoaksept gjenstår.
- **Beslutning:** Hendelser ordnes etter en sammenhengende `sequence` fra 1. Genesis er 64 nuller. Hashversjon 1 dekker alle hendelseskolonner gjennom `application.audit.hash_payload`, inkludert enhet, sekvens, forrige hash og kanoniske detaljer. Globale databasehendelser har NULL-enhet; faktura-/enhetshendelser må ha enhet.
- **Samtidighet:** `BEGIN IMMEDIATE` tar SQLite-skrivelåsen før enden leses. Unike hasher og triggeren `audit_events_extend_chain` hindrer forgrening. Commit er eksplisitt; Unit of Work ruller tilbake som standard.
- **Personvern:** Hendelsestyper og detaljnøkler har en tillatelsesliste med verdityper. Detaljer lagrer ikke fakturatekst eller beløp. `actor` er et teknisk identifikatorfelt, ikke et visningsnavn; gjeldende tjenester bruker `system`. Mønsterkontrollen alene kan ikke bevise at en valgt identifikator ikke er personopplysning. Fremtidige brukerkoblinger må bruke ugjennomsiktige ID-er.
- **Tilgang:** Fakturarepositorier er enhetsavgrenset. Hele auditkjeden leses bare av intern integritetskontroll; den er ikke en flerenhetsrapport eller et UI-API.
- **Begrensning:** Triggere er vern mot feil og vanlig SQL, ikke mot noen som kan fjerne dem. Hashkjeden oppdager ikke sletting fra slutten uten et eksternt anker, eller en full omskriving med nye hasher. Eksterne ankre og krypterte sikkerhetskopier kommer i F12.

## ADR-0028 – Kontrollert migrasjon med sikkerhetskopi og transaksjon

- **Status:** Teknisk akseptert innenfor F02-oppdraget; utfyller ADR-0005.
- **Beslutning:** Eksisterende filer inspiseres lesebeskyttet med `quick_check`, kjent Alembic-revisjon og nødvendige InvoiceFlow-tabeller før skrivemotoren åpnes. Ukjent/nyere/korrupt database avvises uten automatisk reparasjon eller nedgradering. Dette er strukturgjenkjenning, ikke kryptografisk autentisering av hele skjemaet.
- **Sikkerhetskopi:** Før oppgradering av en versjonert database brukes SQLite backup-API til en `.partial`-fil. `integrity_check` og forventet revisjon kontrolleres, journalmodus settes til DELETE for en selvstendig fil, og filen publiseres med `os.replace`. Eksisterende ferdig kopi overskrives ikke. En eksisterende tom fil initialiseres uten sikkerhetskopi; den har ingen versjonerte data.
- **Transaksjon:** Migrasjons-DDL, versjonsendring og audit-hendelse er i én transaksjon. Innstillinger og hele auditkjeden verifiseres før commit. SQL som lykkes, men skader kjeden, rulles dermed også tilbake. Etter oppstart verifiseres kjeden på nytt.
- **PRAGMA:** WAL er vedvarende, mens foreign_keys, FULL, trusted_schema=OFF, secure_delete og busy_timeout=5000 settes på hver ny tilkobling. Også lesetransaksjoner bruker foreløpig BEGIN IMMEDIATE; dette prioriterer enkel konsistens fremfor samtidige lesere. Ingen DB-kall ligger i normale GUI-callbacker i F02.
- **Begrensning:** Migrasjonskopiene er ukrypterte og lokale. De erstatter ikke F12, og filsystemrettigheter/BitLocker må vurderes før ekte data. Det finnes ingen automatisk restore-knapp eller migrasjonsnedgradering.

## ADR-0029 – Generisk dokumentarkiv: modell, lager, krasjmodell og fakturakobling

- **Status:** Teknisk akseptert i F03 innenfor G-05 (F03-prompt v2.0, D-22–D-24). Punkt 4 avviker fra promptets ordlyd og er godkjent av prosjekteier 2026-10-22 (D-25, G-06).
- **Kontekst:** `DOCUMENT_ARCHIVE_SCOPE.md` krever at dokument og faktura er adskilt, at originaler bevares uendret og SHA-256-identifisert, at alt er enhetsavgrenset, og at ingenting slettes automatisk.
- **Beslutning:**
  1. **Modell:** `documents` er et generisk dokument uten fakturafelter (`document_type`, `sha256`, `size_bytes`, `detected_format`, renset `display_name`, `storage_path`, `source`, `status`, integritetsfelt). UNIQUE(`entity_id`, `sha256`) gir duplikatkontroll per enhet. `document_links` kobler to dokumenter i samme enhet (`attachment`, `supersedes`, `related`) med sammensatte FK-er; koblinger er kun-tilføyelse. Ingen UI for koblinger i F03.
  2. **Lager:** `documents/<entity_hex>/originals/ab/cd/<sha256>.<ext>`, `staging/`, `quarantine/<uuid>.bin`, `orphans/`. Stier bygges bare av ID-er og hasher; brukerens filnavn er bare en visningsetikett. Originaler og karantenefiler settes skrivebeskyttet. Ingen kode sletter en original eller karantenefil.
  3. **Krasjmodell:** (a) kopi til `staging` med hash og `fsync`, kontroll av at kilden ikke ble endret under lesing; (b) ny hashkontroll og atomisk `os.replace` til endelig sti (idempotent for samme innhold); (c) dokumentrad og revisjonshendelse i én Unit of Work. Ved oppstart fjernes rester i `staging`, publiserte originaler uten rad flyttes til `orphans/`, og rader uten fil får `integrity_status = 'missing'`. Kildefilen beholdes alltid.
  4. **Fakturakobling (avvik):** Promptet beskrev en sammensatt FK `invoices(entity_id, document_id) → documents(entity_id, id)` via tabellombygging. SQLite kan ikke bygge om en foreldretabell (`invoices` er forelder for `invoice_revisions`) inne i en transaksjon med `foreign_keys=ON`: `ON DELETE RESTRICT` avviser `DROP TABLE` umiddelbart, og telleren for utsatte FK-brudd nullstilles ikke ved `RENAME`, så `COMMIT` feiler (verifisert i prototype). Å slå av fremmednøkler under migrasjonen ville svekke ADR-0028. I stedet håndhever utløseren `invoices_reference_document` på `INSERT` at dokumentet finnes, tilhører samme enhet og har status `stored`. Sammen med eksisterende uforanderlig eierskap for fakturaer og uforanderlige, ikke-slettbare dokumenter gir dette samme integritet som en FK. Tjenesten kontrollerer i tillegg dokumentet og gir `NOT_FOUND`.
  5. **Eksisterende fakturaer:** Migrasjon `0002` avbrytes hvis fakturaer finnes (de har ikke noe dokument). Ingen stille reparasjon eller oppdiktede dokumenter; originalen og sikkerhetskopien beholdes.
  6. **Revisjon:** `audit_events` bygges om i migrasjonen (barnetabell, trygt i transaksjonen) for å tillate emnetypen `document`. Alle rader og hasher kopieres uendret; antall og siste hash kontrolleres, og hele kjeden verifiseres før commit. Nye hendelser: `document.imported`, `document.duplicate_rejected`, `document.quarantined`, `document.rejected`, `document.type_changed`, med detaljer bare fra faste verdilister (format, type, kilde, årsak, størrelsesklasse) og hash – aldri filnavn eller sti.
  7. **Mistenkelige filer:** Ukjent signatur eller endelse som ikke passer formatet gir karantene (rad med status `quarantined`, uten format). Tom, for stor (> 50 MB), ulesbar, endret under lesing eller ikke-vanlig fil (lenke, mappe) avvises uten kopi, men revisjonsføres.
- **Konsekvenser:** F04 kan bygge sideanalyse på `documents`; F06/F08 knytter fakturaer til dokumenter. Retensjon, sletting, arkiveksport og fulltekstsøk krever egne beslutninger. NTFS-rettigheter og BitLocker kontrolleres ikke av programmet i F03 (Å-12/Å-13 åpne).

## ADR-0030 – Utgående nettverk for ERP-integrasjoner (Tripletex, Xledger)

- **Status:** Akseptert. Godkjent av prosjekteier 2026-10-23 (D-26, G-08). Kontrollene er planlagte og implementeres i F14b/F14c; inntil da kan ingen ERP-adapter bruke nettverk.
- **Kontekst:** Prosjekteier ønsker eksport til Tripletex og Xledger i tillegg til Unit4/Agresso (G-07). Tripletex og Xledger er skytjenester; integrasjon skjer i praksis via API. I dag tillater `SECURITY.md` §3 nettverk bare for KI-skyadaptere, og `AGENTS.md` forbyr nettverkskall uten samtykkemekanisme og ADR.
- **Beslutning:**
  1. **Samme port som KI:** ERP-adaptere kan bruke den sentrale HTTP-klientfabrikken med de samme tre kravene: (a) aktivert mål, (b) registrert samtykke per regnskapsenhet og mål i `app_settings`, revisjonsført, (c) fast liste over tillatte vertsnavn per mål. Bare HTTPS med sertifikatkontroll; ingen omdirigering til andre verter.
  2. **Kun eksportretning:** Adapteren sender godkjente fakturadata med originalfil og leser bare referansedata (kontoplan, MVA-koder, dimensjoner, leverandører) og status for egne innsendinger. Den sletter eller endrer aldri eksisterende data i ERP.
  3. **Ingen automatisk bokføring:** Fakturaen opprettes som ikke-bokført bilag eller i bilagsmottak. Hvis målet bare kan ta imot bokførte posteringer, brukes fil eller integrasjonen avvises.
  4. **Hemmeligheter** (API-nøkler, tokens) lagres per regnskapsenhet i Windows Credential Manager via `SecretStore` (ADR-0009); aldri i logg, fil eller feilmelding.
  5. **Dataminimering:** Bare felt målet trenger. Aldri OCR-råtekst, KI-råsvar eller dokumenter som ikke er godkjent.
  6. **Svar er ikke-klarerte data:** Svar fra ERP valideres med Pydantic (`extra="forbid"` der det er mulig), størrelsesgrense og tidsavbrudd; feil gir norsk melding uten innhold.
  7. **Idempotens:** `export_items` får ekstern referanse og tilstanden `unknown` for usikkert utfall (tidsavbrudd). Nytt forsøk krever oppslag i målet. Databasen hindrer dobbel eksport som i F10.
  8. **Revisjon:** Hver innsending logges med mål, batch, antall, status og hash – aldri innhold.
  9. **Testbarhet:** Kjernefunksjonene kjøres fortsatt med blokkert `socket.connect`; adaptertester bruker innspilte, syntetiske svar. Ingen nettverk i CI.
- **Alternativer:** (a) Bare fil (Excel/CSV eller ERP-format) som brukeren laster opp selv – ingen nettverksrisiko, mer manuelt arbeid; forblir alltid tilgjengelig. (b) Integrasjonsplattform hos tredjepart – forkastet: data via ny databehandler.
- **Konsekvenser:** `SECURITY.md` §3 og TB3 er utvidet (se tillegget om ERP-integrasjoner); nye trusler T24–T29 i `THREAT_MODEL.md`; `DATA_MODEL.md` får nye `target`-verdier og ekstern referanse i F14b/F14c; eventuelt valg av HTTP-klient følger ADR-0024. Åpne spørsmål: Å-21, Å-22, Å-23.

## ADR-0031 – Arbeidsprosess for dokumentbehandling: Job Object via `ctypes`, ett dokument per prosess

- **Status:** Teknisk akseptert i F04 (implementering godkjent G-09). Ikke eiergodkjent som faseaksept.
- **Kontekst:** ADR-0010 krever en `spawn`-prosess per oppgave med tidsavbrudd, minnegrense via Windows Job Object, ingen database, nettverk eller hemmeligheter, og JSON-resultat validert med Pydantic. F04-promptet lot valget mellom `pywin32` og `ctypes` stå åpent. PDFium og Pillow er C-biblioteker med jevnlige minnesikkerhetsfeil.
- **Beslutning:**
  1. **Én prosess per dokument** (`multiprocessing`, `spawn`), aldri gjenbrukt. Inngangspunktet kaller `multiprocessing.freeze_support()`, så det samme virker i PyInstaller-bygget (selvtesten kjører en ekte arbeidsprosess).
  2. **Job Object via `ctypes`** (ingen ny avhengighet): minnegrense per prosess 2 GB (`JOB_OBJECT_LIMIT_PROCESS_MEMORY`), høyst én prosess (`ActiveProcessLimit = 1`, arbeidsprosessen kan ikke starte andre prosesser), `KILL_ON_JOB_CLOSE` (dør også hvis hovedprosessen dør) og `DIE_ON_UNHANDLED_EXCEPTION` (ingen feildialog).
  3. **Rekkefølge:** prosessen startes og venter; den tilordnes jobben; først da sendes oppgaven. Grensene gjelder altså før første byte av dokumentet tolkes.
  4. **Tidsavbrudd og stopp i hovedprosessen:** 120 s per dokument (`ProcessingLimits`), og stoppforespørsel ved avslutning. Ved overskridelse avsluttes jobben (`TerminateJobObject`), og hovedprosessen venter til prosessen er borte.
  5. **Kommunikasjon:** hovedprosess → arbeidsprosess: oppgaven (pickle, klarert retning). Arbeidsprosess → hovedprosess: **bare bytes** (`recv_bytes`, maks 1 MB), som valideres som `WorkerResult`. Ingenting fra arbeidsprosessen blir noen gang unpicklet.
  6. **Original:** arbeidsprosessen leser filen selv (maks 50 MB) og kontrollerer SHA-256; hovedprosessen kontrollerer originalen før og etter kjøringen.
  7. **Utdata:** bare i en fersk arbeidsmappe; filnavn fra faste mønstre (`page-0001.png`, `text-0001.json`), skrevet med `x` (aldri overskriving). Hovedprosessen kontrollerer at hver lovet fil er en vanlig fil (ikke lenke), at summen holder seg under grensen, PNG-signatur og -mål, og validerer hvert tekstlag med Pydantic før filene flyttes til `derived/` og radene skrives i én transaksjon.
  8. **POSIX (bare utvikling og test):** `RLIMIT_AS` settes i arbeidsprosessen; ingen Job Object.
- **Alternativer:** (a) `pywin32` – samme API, men en ny avhengighet på ca. 10 MB; forkastet. (b) Eget kommandolinjeprogram via `subprocess` – samme isolasjon, mer kode for argumenter og frosset bygg. (c) AppContainer eller begrenset token – sterkere (også filsystem og nettverk), men kompleks på Windows; vurderes før porten for ekte data. (d) Gjenbrukt prosesspool – raskere, men tilstand mellom dokumenter; forkastet.
- **Konsekvenser:** ca. 0,2–1 s oppstart per dokument. Job Object begrenser minne, prosesser og levetid, **ikke** filsystem eller nettverk: arbeidsprosessen kjører som samme Windows-bruker. Den har ingen nettverks- eller databasekode (arkitekturtester), men kode som utnytter en feil i PDFium eller Pillow, kunne lese det brukeren kan lese. Restrisikoen står i `THREAT_MODEL.md` §12.
- **Risiko:** Minnegrensen gjelder privat, reservert minne; en krasj nær grensen rapporteres som `memory_limit`, ellers `worker_crashed`.

## ADR-0032 – Migrasjon med ombygging av foreldretabeller: `foreign_keys` av utenfor transaksjonen

- **Status:** Teknisk akseptert i F15 (promptet godkjent G-11). Utfyller ADR-0028; ikke eiergodkjent som faseaksept.
- **Kontekst:** F15 må utvide CHECK-begrensningene i `documents` (`detected_format` = `xml`, `source` = `ehf_attachment`) og `processing_jobs` (steget `ehf_extraction` og nye feilkoder). SQLite kan ikke endre en CHECK; tabellen må bygges om. Begge er foreldretabeller (`documents` for `document_links`, `processing_jobs`, `document_pages`, `derived_files`; `processing_jobs` for sider og filer). ADR-0029 pkt. 4 viste at dette ikke går i én transaksjon med `foreign_keys=ON`. `PRAGMA foreign_keys` virker ikke inne i en transaksjon.
- **Beslutning:**
  1. **Erklæring per revisjon:** en migrasjon som bygger om en foreldretabell, setter `FOREIGN_KEYS_OFF = True`. Migratoren slår da av fremmednøkler på DBAPI-tilkoblingen **før** `BEGIN` og bare hvis en ventende revisjon krever det. Alle andre migrasjoner kjører uendret med `foreign_keys=ON`.
  2. **Tolvstegsprosedyren** (sqlite.org/lang_altertable.html): ny tabell med nytt navn, kopi av alle rader med eksplisitte kolonnelister, `DROP` av den gamle, `RENAME`, nye indekser og utløsere. `legacy_alter_table=ON` brukes bare rundt `RENAME`, fordi utløsere på andre tabeller (f.eks. `invoices_reference_document`) viser til tabellen og ellers ville blitt skrevet om eller avvist.
  3. **Kontroller før commit, i samme transaksjon:** antall rader før og etter for hver ombygd tabell; `PRAGMA foreign_key_check` må være tom (ellers `DATABASE_INTEGRITY_FAILED` og tilbakerulling); innstillingene kontrolleres mot de forventede med `foreign_keys = 0`; hele revisjonskjeden verifiseres. Sikkerhetskopien tas før, som i ADR-0028.
  4. **Ny tilkobling etterpå:** motoren som brukte migrasjonen, kastes; den vanlige motoren åpnes med `foreign_keys=ON`, og kjeden verifiseres på nytt ved oppstart.
- **Alternativer:** (a) Utløsere i stedet for CHECK (som ADR-0029 pkt. 4) – mulig for formatet, men gir to steder å lese gyldige verdier og løser ikke neste behov. (b) Ny tabell ved siden av (`documents_v2`) – permanent dobbeltmodell; forkastet. (c) `writable_schema` for å endre CHECK-teksten direkte – udokumentert risiko for korrupsjon; forkastet.
- **Konsekvenser:** I migrasjonstransaksjonen håndheves ikke FK-er; det kompenseres med `foreign_key_check` og radtelling før commit. Testet: `0003 → 0004` med F04-data (alle rader og hasher uendret, kjeden gyldig, sikkerhetskopi tatt) og en dangling referanse som stopper migrasjonen og etterlater originalen uendret.

## ADR-0033 – Valideringsmotor, lagring per kjøring og leverandørregister med kontostatus

- **Status:** Teknisk akseptert i F08a (start autorisert G-12, utforming D-31). Ikke gjennomgått av prosjekteier eller regnskapsansvarlig.
- **Kontekst:** `DATA_MODEL.md` §7 har en regelkatalog. §3.5 skisserte `validation_results` med status som endres (`open`, `resolved`, `overridden`). Resultatet av en kontroll avhenger ikke bare av fakturaen, men også av leverandørregisteret, andre fakturaer og datoen. Betalingssvindel med endret kontonummer er den viktigste regnskapsrisikoen (T09).
- **Beslutning:**
  1. **Ren motor:**
     - Reglene er rene funksjoner over en `ValidationContext`, uten I/O (arkitekturtest).
     - Hver regel har ID, versjon, alvorlighet, feltsti og en oversettelsesnøkkel.
     - Parametrene er korte koder, tall og datoer (mønster i kontrakten). Fritekst fra dokumentet kan ikke bli del av et funn.
     - Regelsettet har en egen versjon (`1.0`).
  2. **Kjøringer, ikke status:**
     - Hver kontroll lagres som en ny rad i `validation_runs`, nummerert per faktura, med revisjon, regelsettversjon, hash av innstillingene og antall per alvorlighet.
     - Funnene lagres i `validation_results`. Begge tabellene er kun tilføyelse.
     - Gjeldende resultat er siste kjøring for gjeldende revisjon.
     - Overstyring med begrunnelse kommer i F09 som egen tabell som viser til et funn. Ingen eksisterende rad endres.
  3. **Når kontrollen kjøres:**
     - i samme transaksjon som registreringen av en EHF-faktura;
     - på forespørsel;
     - for berørte fakturaer når en konto bekreftes eller sperres.

     Motoren endrer aldri en faktura, en arbeidsflytstatus eller en konto.
  4. **Leverandørregister:**
     - En leverandør identifiseres med organisasjonsnummer (med gyldig kontrollsiffer), ellers utenlandsk MVA-ID. Raden er uforanderlig.
     - Kontoer fra fakturaer med gyldig kontrollsiffer registreres som `unverified`.
     - Bare en bevisst brukerhandling med bekreftelsesdialog setter `verified` eller `blocked`. Handlingen registrerer tid og den tekniske aktøren `user/local` og revisjonsføres.
     - Utløsere sørger for at kontonummer og kobling aldri endres, at en konto aldri går tilbake til `unverified` og at ingenting slettes.
  5. **Revisjon:** `invoice.validated` (kjøring, revisjon, regelsettversjon og antall), `supplier.created`, `supplier.account_added` (konto-ID og type) og `supplier.account_status_changed` (ny og forrige status). Aldri kontonummer, navn eller beløp. `audit_events` er bygget om for emnetypen `supplier`.
- **Alternativer:**
  - (a) Status på én resultatrad som oppdateres: enklere spørringer, men historikken går tapt og samtidige kjøringer kan overskrive hverandre. Forkastet.
  - (b) Kontoer bekreftes automatisk ved første faktura (tillit ved første bruk): dette er nettopp det svindel med falsk faktura utnytter. Forkastet.
  - (c) Oppslag i Enhetsregisteret: krever nettverk, ADR og samtykke. Utsatt.
- **Konsekvenser:**
  - En ny leverandør gir alltid BANK-001 til kontoen er bekreftet. Det er tilsiktet.
  - DUP-001 og DUP-002 bruker organisasjonsnummeret fra header-projeksjonen. Utenlandske leverandører uten organisasjonsnummer får derfor ingen duplikatkontroll ennå.
  - Regnskapsansvarlig bør bekrefte alvorlighetene før porten for ekte data.

## ADR-0034 – Referansedata som øyeblikksbilder, leverandørstandard og konteringsforslag

- **Status:** Teknisk akseptert i F08b (start autorisert G-13, utforming D-32). Ikke gjennomgått av prosjekteier eller regnskapsansvarlig. Å-18 er åpen: ingen ekte ERP-eksport er prøvd.
- **Kontekst:** Kontering og reglene MVA-002 og ACC-001–003 krever enhetens egen kontoplan, MVA-koder med gyldighet og dimensjoner. `DATA_MODEL.md` §3.3 skisserte tabeller som oppdateres på stedet. Satsene skal være data, ikke konstanter.
- **Beslutning:**
  1. **Import som øyeblikksbilde:**
     - Hver vellykket import av en CSV-fil er en rad i `reference_imports` med type, SHA-256 og antall rader, og radene ligger i egne tabeller.
     - Gjeldende data er siste import av hver type. Tidligere import beholdes uendret, og alle tabellene er kun tilføyelse.
     - En utløser sørger for at radene bare kan høre til en import av riktig type.
  2. **Streng parsing:**
     - Eget, enkelt CSV-format: UTF-8, semikolon, norske kolonnenavn.
     - Hele filen valideres før noe lagres. Første feil avviser filen med linje og kolonne, aldri innhold.
     - Grensene er 5 MB og 20 000 rader. Kontrolltegn avvises.
     - Navnefelt som begynner med `=`, `+`, `-` eller `@`, avvises, også av en CHECK i databasen, så de ikke kan bli formler ved eksport (F10).
  3. **Leverandørstandard:** `supplier_defaults` er versjonert og kun tilføyelse. Bare verdier som finnes og er aktive i gjeldende data, kan settes. Endringen revisjonsføres (`supplier.defaults_set`).
  4. **Konteringsforslag:**
     - Rene funksjoner lager én linje per MVA-sats.
     - Konto og dimensjoner kommer fra leverandørstandarden.
     - MVA-koden er leverandørens kode når satsen passer. Ellers er det den eneste gyldige inngående koden med satsen. Er valget tvetydig, står feltet tomt.
     - Proveniensen er `calculated` med produsent `regel/kontering/1`.
     - Ved registrering legges forslaget inn i revisjon 1. Senere forslag blir nye revisjoner.
     - Manuelle verdier erstattes aldri.
  5. **Regler** (regelsett 1.1): MVA-002 og ACC-001–003. Mangler referansedata, gis ett infofunn i stedet for mange feil. En utgående MVA-kode på en innkommende faktura er feil.
- **Alternativer:**
  - (a) Oppdatering på stedet: enklere, men historikken og grunnlaget for tidligere kontroller går tapt. Forkastet.
  - (b) Innebygd standard kontoplan og MVA-koder: i strid med `DATA_MODEL.md` §3.3, og kodene følger enhetens ERP. Forkastet.
  - (c) Direkte import fra Tripletex: krever nettverk (ADR-0030) eller kjent eksportformat (Å-18). Utsatt.
- **Konsekvenser:**
  - Alle fakturaer får feil (ACC-001/ACC-002) til referansedata og leverandørstandard finnes. Det er tilsiktet: ingen faktura kan godkjennes uten kontering.
  - Importfunn i `invoice_findings` vises nå for alle revisjoner, fordi de beskriver kildedokumentet.

## ADR-0035 – Godkjenning bundet til innholdshash, overstyring med begrunnelse og blokkerende funn

- **Status:** Teknisk akseptert i F09 (start autorisert G-13, utforming D-33). Ikke gjennomgått av prosjekteier eller regnskapsansvarlig.
- **Kontekst:** `DATA_MODEL.md` §3.5 krever at en godkjenning bare er gyldig når siste beslutning er `approved` og hashen er lik fakturaens gjeldende hash. Roadmapen krever at BANK-001 og DUP-001 blokkerer godkjenning, og at endring etter godkjenning opphever den.
- **Beslutning:**
  1. **Beslutninger:**
     - `approvals` er kun tilføyelse og nummerert per faktura (`sequence`).
     - Hver beslutning (`approved`, `rejected`, `revoked`) gjelder én revisjon og dens `content_sha256`.
     - En godkjenning viser til kontrollkjøringen den bygger på, og kan bare skrives for gjeldende revisjon og hash (utløser).
  2. **Status i databasen:**
     - `invoices.workflow_status = 'approved'` krever at siste beslutning er en godkjenning av gjeldende revisjon og hash (utløser).
     - Innholdet i en godkjent faktura kan ikke endres (utløser).
     - Hver ny revisjon setter status `draft`. Tjenesten skriver `revoked` og revisjonshendelsen i samme transaksjon.
  3. **Fersk kontroll:** godkjenning kjører kontrollen på nytt i samme transaksjon og sammenligner med forventet revisjon. En foreldet side gir konflikt.
  4. **Overstyring:**
     - Et feilfunn kan overstyres med begrunnelse (10–500 tegn) for én revisjon. Funnet identifiseres med regel, feltsti og meldingsnøkkel.
     - Overstyringer følger ikke med til nytt innhold.
     - BANK-001 og DUP-001 kan ikke overstyres. Tjenesten og en CHECK i databasen avviser det.
  5. **Retting:**
     - Bare felt fra en fast liste kan rettes. Norsk inndata tolkes strengt.
     - Ny verdi får proveniensen `manual` (`bruker/lokal` og tidspunkt), og tidligere bevis beholdes.
     - Hver retting gir en ny revisjon og en ny kontroll.
  6. **Personvern i revisjonskjeden:** begrunnelser og kommentarer lagres bare i databasen. Hendelsene inneholder bare ID-er, revisjon, hash, regel og antall.
- **Alternativer:**
  - (a) Status uten egen beslutningstabell: historikk og hashbinding går tapt. Forkastet.
  - (b) Godkjenning uten ny kontroll: risiko for å godkjenne på foreldede funn. Forkastet.
  - (c) To personer (attestasjon og anvisning): utsatt til Å-10 er besvart.
- **Konsekvenser:** F10 kan eksportere bare fakturaer med gyldig godkjenning. Én person kan i dag både rette og godkjenne. Det er en akseptert restrisiko til Å-10 er besvart.

## ADR-0036 – Krasjsikker filseksport med databasehindring av dobbel eksport og formelvern

- **Status:** Teknisk akseptert i F10 (start autorisert G-16, utforming D-34). Ikke gjennomgått av prosjekteier eller regnskapsansvarlig.
- **Kontekst:** ADR-0013 krever at bare godkjente fakturaer eksporteres, at dobbel eksport hindres av databasen og at ny eksport er eksplisitt og begrunnet. `DATA_MODEL.md` §3.5 beskriver en krasjsikker rekkefølge. `SECURITY.md` §13 krever vern mot formelinjeksjon. ERP-formatet er ikke avklart (Å-02, Å-21, Å-22).
- **Beslutning:**
  1. **Batcher og rader:**
     - `export_batches` har status `created`, `written` eller `failed` og avsluttes nøyaktig én gang (utløser). Batchen lagrer kolonnene den brukte, filens SHA-256 og revisjonsankeret (hash av siste revisjonshendelse da batchen ble opprettet).
     - `export_items` binder hver faktura til godkjenning, revisjon og hash. Den delvise unike indeksen på (`entity_id`, `invoice_id`, `target`) for `pending` og `exported` hindrer dobbel eksport til samme mål.
     - Utløseren `export_items_approved_content` hindrer dobbel eksport på tvers av formater: en vanlig batch tar bare fakturaer med status `approved`, og en ny eksport tar bare `exported`.
  2. **Status i databasen:**
     - `exported` krever en eksportert rad for gjeldende revisjon og hash.
     - En eksportert faktura kan ikke endre innhold eller status.
     - Mens en rad er `pending`, kan fakturaen verken endres eller få nye beslutninger.
     - `approvals` tar ingen nye beslutninger for en eksportert faktura.
  3. **Rekkefølge:**
     1. batch og rader (`pending`) i én transaksjon;
     2. fil til midlertidig navn, `fsync`, endelig navn og skrivebeskyttelse;
     3. `exported`, `written`, fakturastatus og revisjonshendelser i én transaksjon.

     Gjenoppretting ved oppstart og før hver eksport: finnes den endelige filen, er den komplett, og batchen fullføres (`recovered`). Ellers markeres batchen `failed` (`interrupted`), og midlertidige filer fjernes.
  4. **Ny eksport:** gjelder fakturaene i en tidligere batch der den batchen har deres siste eksport. Begrunnelse på 10–500 tegn lagres i batchen, ikke i revisjonskjeden. Forrige rad blir `superseded` i samme transaksjon.
  5. **Filformat:**
     - én rad per konteringslinje;
     - CSV med BOM, semikolon og desimalkomma;
     - Excel med tall- og datoceller og et kontrollark;
     - kreditnotaer med negative beløp (ADR-0020).

     Kolonner og overskrifter er versjonert per enhet (`export_mappings`), og versjon 0 er standarden i koden.
  6. **Formelvern:**
     - CSV-tekst som kan tolkes som formel, får apostrof.
     - Excel-tekst er alltid tekstcelle med apostrofmerke.
     - Egne overskrifter avvises hvis de begynner som en formel.
  7. **Kopi:** filen gis bare ut hvis SHA-256 stemmer med databasen.
- **Alternativer:**
  - (a) Status i fakturaen uten egne rader: ingen historikk og ingen databasehindring på tvers av batcher. Forkastet.
  - (b) Lagre filen direkte under endelig navn: et krasj kan etterlate en halv fil som ser gyldig ut. Forkastet.
  - (c) Eksport direkte til en mappe brukeren velger: atomisk navnebytte og gjenoppretting er ikke mulig på for eksempel nettverksstasjoner eller minnepinner. Valgt i stedet: en fast eksportmappe og en kontrollert kopi.
  - (d) Én rad per faktura: konteringen per MVA-sats går tapt. Forkastet for standardoppsettet; kolonnene kan velges.
- **Konsekvenser:**
  - F14a–c bruker samme batcher og rader med egne mål.
  - En eksportert faktura er endelig. Feil må rettes i regnskapssystemet eller med en kreditnota.
  - Filene i eksportmappen er ikke kryptert; se T52.

## ADR-0037 – Kryptert sikkerhetskopi i én fil med autentiserte biter og kontrollert gjenoppretting

- **Status:** Teknisk akseptert i F12 (start autorisert G-18, utforming D-35). Ikke gjennomgått av prosjekteier eller regnskapsansvarlig. Å-07 og Å-14 er ikke besvart.
- **Kontekst:** `SECURITY.md` §12 krever kryptering, manifest med SHA-256 og revisjonsanker, og automatisk gjenopprettingstest. Valget mellom et kryptert arkiv og et BitLocker To Go-medium var åpent (Å-14). Én database dekker alle regnskapsenheter (ADR-0022).
- **Beslutning:**
  1. **Kryptert arkiv**, ikke kryptert medium. Det virker på alle lagringssteder og kan testes automatisk. Et kryptert medium kan likevel brukes i tillegg.
  2. **Format** (`.ifbak`):
     - magisk tall og et åpent JSON-hode i kanonisk form med versjon, scrypt-parametere (N = 2^17, r = 8, p = 1, 16 byte salt) og 8 byte nonceprefiks;
     - deretter AES-256-GCM i biter på 1 MiB med nonce = prefiks ‖ løpenummer;
     - tilknyttede data = SHA-256(hode) ‖ løpenummer ‖ sluttmerke. Endret hode, byttede, manglende, tilføyde eller avkortede biter og feil nøkkel avvises.
     - Innholdet er et tar-arkiv. `manifest.json` er siste medlem, med SHA-256 og størrelse for hver fil, skjemaversjon og revisjonsanker (sekvens og hash).
  3. **Innhold:**
     - databasen kopiert med SQLite backup-API fra en lesetilkobling (ADR-0028) til en privat arbeidsmappe;
     - dokumentarkivet uten `staging` og `work`;
     - eksportmappen;
     - `config.json`.

     Lenker og skjulte midlertidige filer tas ikke med. Mangler et dokument som databasen viser til, lages ingen sikkerhetskopi.
  4. **Gjenoppretting** bare til en tom mappe utenfor datakatalogen. Utpakking godtar bare vanlige filer med kjente, relative stier, hver én gang, og ingenting etter manifestet. Kontroller:
     - manifest mot innhold;
     - `quick_check` og kjent skjemaversjon;
     - hele revisjonskjeden;
     - anker mot kjedens ende;
     - hvert dokument databasen viser til.

     Ved feil tømmes mappen. Kontroll uten gjenoppretting gjør det samme i en arbeidsmappe som slettes.
  5. **Passordfrase:** 12–1024 tegn, NFC, uten kontrolltegn. Den gis to ganger når en sikkerhetskopi lages, og lagres aldri.
  6. **Register og revisjon:**
     - `backups` (migrasjon `0009_backup`) har én rad per fil. Sletting registreres én gang; rader slettes aldri.
     - Revisjonshendelsene `backup.created`, `backup.verified`, `backup.restored` og `backup.deleted` er globale (som migrasjoner) og inneholder bare ID, hash, antall, anker og utfall.
  7. **Oppstart:** arbeidsmapper etter avbrudd slettes, fordi de kan inneholde en ukryptert databasekopi.
- **Alternativer:**
  - (a) BitLocker To Go alene: avhenger av medium og Windows-utgave, og kan ikke kontrolleres av programmet. Forkastet som eneste tiltak.
  - (b) ZIP med AES (WinZip AE-2): krever eget bibliotek og autentiserer ikke helheten (filliste og rekkefølge). Forkastet.
  - (c) Én GCM-operasjon for hele filen: hele innholdet må i minnet, og ingen strømming. Forkastet.
  - (d) Nøkkel i Windows Credential Manager for automatisk sikkerhetskopi: knytter sikkerhetskopien til én Windows-konto og ett system. Utsatt til egen beslutning.
- **Konsekvenser:**
  - Ny avhengighet `cryptography`, bare i `backup/crypto.py`.
  - Glemt passordfrase betyr tapt sikkerhetskopi.
  - Ingen automatisk tidsplan eller retensjon før Å-07/Å-14.
  - Ankeret i sikkerhetskopien gjør at avkorting av revisjonskjeden kan oppdages mot en ekstern kopi (T11).

## ADR-0038 – Overvåket skannemappe og oppdeling av bunker etter målt sidemørkhet

- **Status:** Teknisk akseptert i F11a (start autorisert G-21, utforming D-36). Ikke gjennomgått av prosjekteier. Grenseverdiene er ikke prøvd mot ekte skann (Å-01).
- **Kontekst:**
  - Skannermodellen er ukjent, så WIA kan verken bygges eller testes.
  - En bunke skannes ofte som én fil med flere fakturaer, skilleark og blanke baksider.
  - `CanonicalInvoice` har allerede `first_page`/`last_page` for fakturaer i samme dokument.
- **Beslutning:**
  1. **Overvåket mappe** (innboksmappen) som første vei for skannere:
     - bare filer med samme størrelse og endringstid ved to påfølgende titter, minst 2 sekunder gamle;
     - vanlig import;
     - etterpå flytting til `importert` eller `avvist` i samme mappe (`os.rename`, aldri overskriving);
     - deretter sideanalyse.

     Manuell «Les inn fra innboks» (D-23) flytter fortsatt ingenting.
  2. **Målinger i arbeidsprosessen:** andel mørke piksler innenfor marg og i sentralt område, på en gråtonekopi på høyst 512 piksler. Lagres i `document_pages`. Tillegget `+side1` til motorversjonen gjør at eldre analyser kjøres på nytt.
  3. **Rene regler for sidetype og deler:**
     - skilleark: sentralt område ≥ 850 ‰ og siden totalt 150–650 ‰;
     - blank: ≤ 3 ‰ og uten tekstlag.

     Deler beregnes ved visning og lagres ikke.
  4. **Eget skilleark:** en PDF med en svart boks som når 5 % utenfor det målte området, skrevet uten bibliotek. Den samme skriveren brukes av de syntetiske testfilene.
  5. **Originaler deles ikke.** En del er et sideintervall i det originale dokumentet.
- **Alternativer:**
  - (a) Strekkode eller patch-kode som skilleark: krever strekkodebibliotek eller OCR. Forkastet nå.
  - (b) Blank side som skilleark: kolliderer med blanke baksider ved dupleks. Forkastet.
  - (c) Ny PDF-fil per del: dobbel lagring, nye dokumenttyper og tabellombygging. Forkastet; sideintervaller holder.
  - (d) Varsling fra filsystemet (`watchdog`): ny avhengighet og upålitelig på nettverksstasjoner. Forkastet; en titt hvert 10. sekund er nok.
- **Konsekvenser:**
  - F05/F06 lager én faktura per del.
  - F11b legger til WIA, profiler og dupleks når Å-01 er besvart; da justeres grenseverdiene med ekte skann.
  - Alle PDF- og bildedokumenter analyseres på nytt én gang.

## ADR-0039 – Skanning via produsentens program til skannemappen, uten skannerdriver i programmet

- **Status:** Teknisk akseptert i F11b. Prosjekteier valgte variant A (G-23); utformingen (D-37) er ikke gjennomgått. Skanneren er foreløpig Brother ADS-4700W (G-22), ikke prøvd.
- **Kontekst:**
  - Brother ADS-4700W har drivere for TWAIN, WIA, ISIS og SANE. Brothers eget Windows-program kan lagre PDF med flere sider i en valgt mappe, med dupleks og hopp over blanke sider.
  - Skannemappen fra F11a (ADR-0038) virker med enhver skanner som lagrer i en mappe.
  - WIA i programmet krever en ny avhengighet bare for Windows (COM) og kan ikke testes uten skanner og Windows-CI.
- **Beslutning:**
  1. Programmet styrer ikke skanneren. Brother iPrint&Scan (eller tilsvarende) skanner til fil i skannemappen; `docs/SCANNER_SETUP.md` beskriver profilen.
  2. Skannemappen deles ikke på nettverket («skann til nettverksmappe»), fordi den ligger i programmets datakatalog.
  3. Grenseverdiene fra ADR-0038 beholdes til de er prøvd med ekte skann. Siden «Skanning» viser målingene per side og merker sider nær en grense, slik at prøven kan vurderes uten å sende dokumentinnhold.
- **Alternativer:**
  - (a) WIA via COM i programmet (variant B): skanneknapp i programmet, men ny avhengighet, kode som bare kan prøves med maskinvare, og feilhåndtering for driverdialoger. Forkastet nå; kan vurderes senere med ny ADR.
  - (b) TWAIN: 32/64-bitsproblemer og leverandørspesifikke dialoger. Forkastet.
  - (c) Skann til nettverksmappe direkte fra skanneren: krever at datakatalogen deles over SMB. Forkastet.
- **Konsekvenser:**
  - Profiler, ADF og dupleks styres i Brothers program, ikke i InvoiceFlow AI.
  - Akseptkriteriet «testet med faktisk skannermodell» oppfylles ved første prøve etter `docs/SCANNER_SETUP.md` §4.
  - Endrede grenseverdier gir en ny versjon av ADR-0038s regler, med tester.

## ADR-0040 – OCR med Tesseract som eget steg i den isolerte arbeidsprosessen

- **Status:** Teknisk akseptert i F05. OCR-valget (D-13: Tesseract 5) er godkjent av prosjekteier (G-24). Utformingen (D-38) er ikke gjennomgått. Utfyller ADR-0007, med ett avvik (punkt 3).
- **Kontekst:**
  - F04 lager et PNG-bilde og eventuelt et tekstlag per side.
  - Skannede sider har ikke tekstlag, og F06 trenger tekst med posisjon for å hente fakturafelt.
  - Tesseract er et eget, innebygd program som tolker ikke-klarerte bilder.
- **Beslutning:**
  1. **Eget steg `ocr`** per dokument etter en vellykket sideanalyse. Egen jobb med samme krasjmodell (arbeidsmappe, kontroll, publisering, én transaksjon).
     - Idempotensnøkkelen dekker programversjon, utdataformat (`ocr1`), hash av språkdata og innstillinger (språk, sidesegmentering, grense for usikre ord, sideanalysens innstillinger).
     - Ny Tesseract eller nye språkdata gir en ny kjøring; tidligere resultater beholdes.
  2. **Bare sidebilder fra analysen leses.** De kopieres inn i arbeidsmappen etter hash-kontroll og kontrolleres igjen i arbeidsprosessen. Tesseract ser aldri originalen, bare PNG-er programmet selv har laget.
  3. **Tesseract kalles direkte, ikke via `pytesseract`** (avvik fra ADR-0007).
     - Ingen ny avhengighet.
     - Bildet går inn på standard inn og TSV ut på standard ut, så ingen dokumentdata havner i midlertidige filer.
     - Kallet har faste argumenter, ikke noe skall, et minimalt miljø (`OMP_THREAD_LIMIT=1`) og tidsavbrudd per side.
  4. **Isolasjon:** Tesseract startes av arbeidsprosessen.
     - På Windows tillater Job Object da to aktive prosesser i stedet for én; minnegrense og kill-on-close gjelder begge.
     - Hele kjøringen har en frist på sidens frist ganger antall sider, høyst én time.
  5. **Tolkning i arbeidsprosessen:**
     - ut går bare ord (NFC, uten kontrolltegn, høyst 100 tegn) med normalisert boks, sikkerhet 0–100 og linjenummer, høyst 20 000 ord per side;
     - hovedprosessen kontrollerer hver fil mot rapporten (antall, tekstlengde, snittsikkerhet, usikre ord).
  6. **Lagring:** ordene i en avledet fil per side (`ocr-0001.json`, skrivebeskyttet). Tabellen `ocr_pages` holder tall, sti og hash og peker på sidebildet den bygger på.
  7. **Hvilke sider:** sider uten tekstlag som har blekk og ikke er skilleark. En side skannevisningen kaller blank (≤ 3 ‰), kan ha én linje og gjenkjennes derfor likevel.
  8. **Tesseract finnes bare på faste steder:** ved siden av programmet (F13), i `%ProgramFiles%\Tesseract-OCR` og, utenfor Windows, i `PATH`. Det sjekkes én gang per programstart. Uten Tesseract hoppes OCR over, og grensesnittet sier fra.
- **Alternativer:**
  - (a) `pytesseract`: ny avhengighet og midlertidige bildefiler. Forkastet.
  - (b) `tesserocr` (C-binding i samme prosess): kompileringsavhengighet på Windows, og en krasj i Tesseract ville treffe arbeidsprosessen uten egen grense. Forkastet.
  - (c) OCR inne i sideanalysen: ny Tesseract-versjon ville kjøre hele analysen på nytt, og analysen ble tregere for digitale PDF-er. Forkastet.
  - (d) PaddleOCR: utsatt til ekte skann finnes (ADR-0007).
- **Konsekvenser:**
  - F06 leser tekstlag eller OCR-ord per side.
  - F13 pakker Tesseract og norsk språkdata (anbefalt).
  - Windows-CI installerer Tesseract 5.4.0 og `nor` fra tessdata 4.1.0 med låste kontrollsummer.

## ADR-0041 – Regelbasert feltuttrekk fra ord med posisjon, ett fakturautkast per del

- **Status:** Teknisk akseptert i F06 (start autorisert G-25, utforming D-39). Ikke gjennomgått av prosjekteier eller regnskapsansvarlig.
- **Kontekst:**
  - Tekstlag (F04) og OCR (F05) gir ord med boks; skannede bunker deles i deler (F11a).
  - EHF-fakturaer registreres fra XML (F15).
  - Fakturaer i PDF og på papir trenger samme vei inn i kontroll og godkjenning.
- **Beslutning:**
  1. **Felles sideoppsett** for tekstlag og OCR.
     - Ordene grupperes i linjer etter geometrien, og linjene deles i celler ved brede mellomrom.
     - En verdi kan ikke strekke seg over to kolonner.
  2. **Verdier bare ved ledetekst** (samme linje, eller rett under innenfor samme kolonne), eller i entydig form (`NO 999 999 999 MVA`).
     - Ingen verdi fylles inn eller beregnes.
     - En verdi som ser ut som en verdi, men ikke er gyldig, blir `value=None` med råtekst og funnet `unreadable_value`.
  3. **Proveniens** `extracted` med `producer` `regel/fakturafelt/1`.
     - Bevis: side, boks og råtekst. `source_ref` er `tekstlag/s1/l12` eller `ocr/s1/l12`.
     - OCR-verdier får laveste ordsikkerhet som konfidens; tekstlag har ingen konfidens.
  4. **Kunde og leverandør** skilles ved regnskapsenhetens organisasjonsnummer.
  5. **Ett fakturautkast per del** av dokumentet (sideintervall), registrert én gang.
     - Kontrollen skjer på samme måte som for EHF: funn, konteringsforslag og validering i én transaksjon.
     - En ny versjon av reglene registrerer ikke samme del på nytt.
  6. **Hvilke dokumenter leses:**
     - typen faktura eller kreditnota;
     - `unclassified` bare når teksten selv sier faktura eller kreditnota;
     - aldri EHF eller EHF-vedlegg.
     - Dokumenttypen endres ikke (D-24).
  7. **Kjøres i hovedprosessen** som rene funksjoner: inndata er validerte, hash-kontrollerte tekstfiler, og mønstrene er lineære med begrenset linjelengde.
- **Alternativer:**
  - (a) Maler per leverandør: presist, men krever vedlikehold per leverandør. Utsatt; kan legges oppå reglene.
  - (b) KI-tolkning (F07): valgfri, krever avklaring (Å-03/Å-04).
  - (c) Uttrekk i arbeidsprosessen: ingen ekstra beskyttelse, fordi teksten allerede er validert data og regelkoden er ren Python. Forkastet.
- **Konsekvenser:**
  - Fakturaer fra PDF og skann vises i «Innboks» og «Gjennomgang» som utkast med funn.
  - Treffsikkerheten mot ekte fakturaer er ikke målt før porten for ekte data.
