# InvoiceFlow AI – Datamodell

| | |
|---|---|
| **Dokumentversjon** | 1.2 (Fase 02, etter sluttgjennomgang) |
| **Status** | Pydantic-kontraktene (§4) er **implementert og testet**. F02-delskjemaet (§3.9) er implementert; resten av §3 er langsiktig utforming. |
| **Kode** | `src/invoiceflow/domain/` |
| **Eksempel** | `docs/examples/eksempel_faktura_kanonisk.json` |

---

## 1. Prinsipper

| Prinsipp | Konsekvens |
|---|---|
| **Kanonisk modell** | `CanonicalInvoice` er uavhengig av OCR-motor, KI-leverandør og ERP. Alle adaptere oversetter til eller fra den. |
| **Proveniens per felt** | Hver verdi har kilde: hentet fra dokument, foreslått av KI, beregnet eller manuelt korrigert (§5). |
| **Én autoritativ kilde** | Se §2. Hver opplysning har ett sted der den er sann. |
| **Eksakte beløp** | `decimal.Decimal` overalt. JSON: strenger. SQLite: `TEXT` (ADR-0004). Aldri `float`. |
| **Valider, ikke rett** | Ugyldige verdier avvises eller lagres som «ikke tolket» med råtekst – de rundes aldri av eller gjettes. |
| **Ingen oppdiktede verdier** | Manglende felt er `None`. Kun deterministisk kode kan beregne verdier, og de merkes som beregnet. |
| **Tid** | Tidspunkter i UTC med tidssone (ISO 8601). Datoer som `YYYY-MM-DD`. Lokal visning i `nb-NO`. |
| **Identifikatorer** | UUID v4 for hovedentiteter; heltall for høyvolums barnetabeller. |
| **Regnskapsenhet** | Alle regnskapsdata tilhører én regnskapsenhet (`entity_id`). Enhetsgrensen håndheves både av databasen og av repositoriene (ADR-0022). |
| **Transaksjoner** | En tilstandsendring og revisjonshendelsen for den skrives i samme transaksjon (§3.8). |
| **Migrasjoner** | Alembic; aldri destruktive skjemaendringer uten migrasjon og sikkerhetskopi. |

## 2. Autoritative kilder

| Opplysning | Autoritativ kilde | Merknad |
|---|---|---|
| Hvilken regnskapsenhet data tilhører | `entity_id` på rotentiteten (dokument, faktura, leverandør, batch) | Arves ikke implisitt; sammensatte fremmednøkler hindrer blanding |
| Dokumentets innhold | Originalfilen i dokumentlageret + `documents.sha256` | Endres aldri |
| Avledede data (sidebilder, OCR) | `derived_files`, `ocr_results` | Kan gjenskapes fra original |
| Gjeldende fakturaverdier (F02) | `invoice_revisions.canonical_json` som `invoices.current_revision` peker på | Typede headerkolonner er kontrollerte projeksjoner, ADR-0026 |
| Opprinnelse og historikk per felt (F02) | Proveniens i uforanderlige `invoice_revisions.canonical_json` | `field_provenance` er en fremtidig projeksjon, ADR-0026 |
| Hva som ble godkjent | `approvals.snapshot_json` + `content_sha256` | Kun tilføyelse |
| Hva som ble eksportert | `export_batches`, `export_items` | Unik aktiv eksport per faktura og mål |
| Hvem gjorde hva og når | `audit_events` (hashkjede, kun tilføyelse) | |
| Forretningsinnstillinger | `app_settings` | Endringer revisjonslogges |
| Hemmeligheter | Windows Credential Manager | Aldri i databasen |

Repositoriet gjenoppretter `CanonicalInvoice` fra revisjonens snapshot. Ved lesing av gjeldende revisjon kontrolleres den typede headerprojeksjonen mot snapshotet. Det langsiktige normaliserte skjemaet under er ikke den faktiske F02-databasen; se §3.9 og ADR-0026.

## 3. Databaseskjema (SQLite + SQLAlchemy)

### 3.0 Regnskapsenheter (ADR-0022)

**`accounting_entities`** – `id` UUID PK, `name`, `org_number` NULL, `default_currency` (standard `NOK`), `is_active`, `created_at`, `updated_at`. F02 oppretter ingen enhet automatisk; den opprettes eksplisitt gjennom EntityService. Enhetsvalg i UI er ikke implementert (ADR-0026).

Regler for alle tabeller med regnskapsdata:

| Regel | Gjennomføring |
|---|---|
| `entity_id` er påkrevd | `entity_id UUID NOT NULL REFERENCES accounting_entities(id)` på `documents`, `processing_jobs`, `invoices`, `suppliers`, `chart_of_accounts`, `vat_codes`, `dimension_values`, `approvals`, `export_batches`, `export_items`. Barnetabeller uten egne regnskapsdata (`document_pages`, `invoice_lines`, `field_provenance` o.l.) arver enheten via forelderen. |
| Ingen kobling på tvers | Foreldre har `UNIQUE(entity_id, id)`; barn refererer med sammensatt fremmednøkkel, f.eks. `FOREIGN KEY (entity_id, supplier_id) REFERENCES suppliers(entity_id, id)` |
| Enhetsavgrensede nøkler | `UNIQUE(entity_id, sha256)`, `duplicate_key` = `entity_id | …`, `PRIMARY KEY(entity_id, account)` for kontoplanen |
| Repositorier | Krever `EntityScope`; ingen uavgrensede spørringer (arkitekturtest fra F02) |
| Revisjon og innstillinger | `entity_id` NULL betyr global hendelse/innstilling |

Kolonnen `entity_id` nevnes ikke i hver tabellbeskrivelse under, men gjelder etter tabellen over.

### 3.1 Relasjoner

```mermaid
erDiagram
    ACCOUNTING_ENTITIES ||--o{ DOCUMENTS : "eier"
    ACCOUNTING_ENTITIES ||--o{ INVOICES : "eier"
    ACCOUNTING_ENTITIES ||--o{ SUPPLIERS : "eier"
    ACCOUNTING_ENTITIES ||--o{ CHART_OF_ACCOUNTS : "eier"
    ACCOUNTING_ENTITIES ||--o{ EXPORT_BATCHES : "eier"
    DOCUMENTS ||--o{ DOCUMENT_PAGES : "har"
    DOCUMENTS ||--o{ DERIVED_FILES : "har"
    DOCUMENTS ||--o{ PROCESSING_JOBS : "behandles av"
    DOCUMENTS ||--o{ INVOICES : "inneholder"
    DOCUMENT_PAGES ||--o{ OCR_RESULTS : "har"
    OCR_RESULTS ||--o{ OCR_TEXT_BLOCKS : "inneholder"
    SUPPLIERS |o--o{ INVOICES : "utsteder"
    SUPPLIERS ||--o{ SUPPLIER_BANK_ACCOUNTS : "har"
    INVOICES ||--o{ INVOICE_LINES : "har"
    INVOICES ||--o{ INVOICE_VAT_BREAKDOWN : "har"
    INVOICES ||--o{ ACCOUNTING_LINES : "konteres som"
    INVOICES ||--o{ FIELD_PROVENANCE : "dokumenteres av"
    INVOICES ||--o{ VALIDATION_RESULTS : "har"
    INVOICES ||--o{ APPROVALS : "har"
    INVOICES ||--o{ EXPORT_ITEMS : "eksporteres som"
    EXPORT_BATCHES ||--o{ EXPORT_ITEMS : "inneholder"
    APPROVALS ||--o{ EXPORT_ITEMS : "er grunnlag for"
    CHART_OF_ACCOUNTS |o..o{ ACCOUNTING_LINES : "valideres mot"
    VAT_CODES |o..o{ ACCOUNTING_LINES : "valideres mot"
    DIMENSION_VALUES |o..o{ ACCOUNTING_LINES : "valideres mot"
```

Stiplede linjer er logiske koblinger uten fremmednøkkel: en foreslått konto som ikke finnes i kontoplanen skal kunne lagres og vises som valideringsfeil, ikke avvises av databasen.

Diagrammet viser eierskap for de viktigste tabellene; alle tabeller med regnskapsdata har `entity_id` (§3.0).

Typenotasjon: `UUID` = `TEXT(36)`, `DEC` = `TEXT` med `Decimal` (ADR-0004), `DATE` = `TEXT` `YYYY-MM-DD`, `UTC` = `TEXT` ISO 8601 med tidssone, `BOOL` = `INTEGER` 0/1. Alle `status`-/`type`-kolonner har `CHECK`-begrensning mot tillatte verdier. Fremmednøkler bruker `ON DELETE RESTRICT` med mindre annet er angitt.

### 3.2 Dokumenter

**`documents`** – én rad per importert fil (originalen).

| Kolonne | Type | Regler |
|---|---|---|
| `id` | UUID | PK |
| `entity_id` | UUID | NOT NULL, regnskapsenheten dokumentet er importert for |
| `sha256` | TEXT(64) | NOT NULL; UNIQUE(`entity_id`, `sha256`) – identisk fil importeres ikke to ganger i samme enhet |
| `size_bytes` | INTEGER | NOT NULL, > 0 |
| `detected_type` | TEXT | `pdf`, `png`, `jpeg`, `tiff` (senere `xml`) – fra filsignatur, ikke filendelse |
| `original_filename` | TEXT(255) | Renset visningsnavn; **brukes aldri som filsti** |
| `storage_path` | TEXT | NOT NULL, UNIQUE, relativ sti under lagringsroten |
| `source` | TEXT | `file_import`, `watched_folder`, `scanner` |
| `page_count` | INTEGER | NULL inntil kjent |
| `status` | TEXT | `stored`, `processing`, `processed`, `failed`, `quarantined` |
| `imported_at` | UTC | NOT NULL |
| `imported_by` | TEXT | Windows-bruker |
| `integrity_checked_at` | UTC | NULL |
| `integrity_status` | TEXT | `ok`, `mismatch`, `missing`, NULL |

Duplikat på (`entity_id`, `sha256`) gir ingen ny rad; importen avvises med revisjonshendelsen `document.duplicate_rejected` som peker på eksisterende dokument.

**`document_pages`** – `id` INTEGER PK, `document_id` FK, `page_number` ≥ 1, `width_px`, `height_px`, `rotation_degrees` (0/90/180/270), `has_text_layer` BOOL, `text_layer_chars` INTEGER. UNIQUE(`document_id`, `page_number`).

**`derived_files`** – avledede filer, lagret adskilt fra originaler. `id` INTEGER PK, `document_id` FK, `page_id` FK NULL, `kind` (`page_render`, `preprocessed`, `thumbnail`), `storage_path` UNIQUE, `sha256`, `producer` (f.eks. `pymupdf/1.28.2`), `job_id` FK, `created_at` UTC.

**`ocr_results`** – `id` INTEGER PK, `page_id` FK, `job_id` FK, `engine`, `engine_version`, `language` (f.eks. `nor`), `settings_hash`, `mean_confidence` REAL 0–1, `created_at`. UNIQUE(`page_id`, `engine`, `engine_version`, `settings_hash`) – gir idempotent OCR.

**`ocr_text_blocks`** – `id` INTEGER PK, `ocr_result_id` FK (`ON DELETE CASCADE`, avledet data), `block_index`, `level` (`word`, `line`, `block`), `text`, `x0`, `y0`, `x1`, `y1` REAL (normalisert 0–1), `confidence` REAL NULL.

**`processing_jobs`** – `id` UUID PK, `document_id` FK, `step` (`file_validation`, `text_extraction`, `rendering`, `preprocessing`, `ocr`, `field_extraction`, `ai_interpretation`, `validation`), `idempotency_key` UNIQUE, `status` (`queued`, `running`, `succeeded`, `failed`, `timed_out`, `cancelled`), `attempt`, `engine`, `engine_version`, `settings_hash`, `queued_at`, `started_at`, `finished_at`, `error_code` (stabil kode, aldri fritekst fra dokumentet).

### 3.3 Leverandører og referansedata

**`suppliers`** (leverandørregister per regnskapsenhet) – `id` UUID PK, `entity_id`, `name`, `org_number` NULL med UNIQUE(`entity_id`, `org_number`), `vat_registered` BOOL, `country_code`, `foreign_vat_id` NULL, `default_account`, `default_vat_code`, `default_cost_center`, `default_department`, `default_project` (alle NULL), `is_active`, `created_at`, `updated_at`.

**`supplier_bank_accounts`** – kjente betalingskontoer per leverandør (kontroll mot fakturasvindel). `id` INTEGER PK, `supplier_id` FK, `bank_account` NULL, `iban` NULL, CHECK (minst én satt), `status` (`unverified`, `verified`, `blocked`), `first_seen_invoice_id` FK NULL, `verified_by`, `verified_at`. UNIQUE(`supplier_id`, `bank_account`), UNIQUE(`supplier_id`, `iban`).

**`chart_of_accounts`** (kontoplan per enhet) – PK (`entity_id`, `account`), `name`, `default_vat_code` NULL, `is_active`, `valid_from` DATE, `valid_to` DATE NULL, `origin` (`ns4102`, `erp_import`, `manual`).

**`vat_codes`** (MVA-koder per enhet, fordi kodene følger enhetens ERP) – PK (`entity_id`, `code`, `valid_from`), `valid_to` NULL, `rate` DEC, `direction` (`input`, `output`), `saft_code` NULL, `label_key` (oversettelsesnøkkel). Satsene er **data med gyldighetsperiode**, ikke konstanter i koden.

**`dimension_values`** – `id` INTEGER PK, `dimension` (`cost_center`, `department`, `project`), `code`, `name`, `is_active`, `valid_from`, `valid_to`. UNIQUE(`entity_id`, `dimension`, `code`).

### 3.4 Fakturaer

**`invoices`** – gjeldende verdier for én faktura/kreditnota (speiler `CanonicalInvoice`).

| Kolonnegruppe | Kolonner |
|---|---|
| Nøkler | `id` UUID PK, `entity_id`, `document_id` (sammensatt FK med `entity_id`), `first_page`, `last_page`, `schema_version`, `supplier_id` NULL (sammensatt FK med `entity_id`) |
| Hode | `invoice_type`, `invoice_number`, `invoice_number_normalized`, `invoice_date` DATE, `due_date` DATE, `currency`, `referenced_invoice_number`, `buyer_reference` |
| Leverandør (som på fakturaen) | `supplier_name`, `supplier_org_number`, `supplier_vat_registered`, `supplier_foreign_vat_id`, `supplier_street`, `supplier_postal_code`, `supplier_city`, `supplier_country_code` |
| Kunde (som på fakturaen) | `customer_name`, `customer_org_number`, `customer_vat_registered`, `customer_foreign_vat_id`, `customer_street`, `customer_postal_code`, `customer_city`, `customer_country_code` |
| Betaling | `kid`, `bank_account`, `iban`, `bic` |
| Beløp | `net_amount`, `vat_amount`, `rounding_amount`, `gross_amount` (alle DEC NULL) |
| Arbeidsflyt | `workflow_status` (`draft`, `needs_review`, `approved`, `rejected`, `exported`), `duplicate_key`, `content_sha256`, `row_version` (optimistisk låsing), `created_at`, `updated_at` |

Indekser: `duplicate_key`, (`supplier_id`, `invoice_date`), `workflow_status`. `duplicate_key` = normalisert `entity_id | leverandør-ID eller orgnr | fakturatype | fakturanummer` – duplikater søkes bare innenfor samme regnskapsenhet. Duplikater stoppes av valideringsregel DUP-001 (blokkerer godkjenning) i stedet for en unik indeks, fordi feiltolkede verdier fortsatt må kunne lagres og rettes.

**`invoice_lines`** – `id` INTEGER PK, `invoice_id` FK, `line_number`, `description`, `quantity` DEC, `unit`, `unit_price` DEC, `net_amount` DEC, `vat_rate` DEC, `vat_amount` DEC. UNIQUE(`invoice_id`, `line_number`).

**`invoice_vat_breakdown`** (MVA-spesifikasjon) – `id` INTEGER PK, `invoice_id` FK, `entry_index`, `vat_rate` DEC, `taxable_amount` DEC, `vat_amount` DEC. UNIQUE(`invoice_id`, `entry_index`).

**`accounting_lines`** (konteringslinjer) – `id` INTEGER PK, `invoice_id` FK, `line_number`, `account`, `vat_code`, `net_amount` DEC, `cost_center`, `department`, `project`, `source_line_numbers` (JSON-liste), `explanation`. UNIQUE(`invoice_id`, `line_number`).

**`field_provenance`** – kun tilføyelse; én rad per verdiendring.

| Kolonne | Type | Regler |
|---|---|---|
| `id` | INTEGER | PK; høyeste `id` per (`invoice_id`, `field_path`) er gjeldende |
| `invoice_id` | UUID | FK |
| `field_path` | TEXT | Sti i kanonisk modell, f.eks. `totals.gross_amount`, `lines.2.unit_price`, `supplier.address.city` (linjer adresseres med `line_number`) |
| `value_text` | TEXT | Kanonisk strengform (Decimal som `"1234.50"`, dato ISO, bool `true`/`false`); NULL = ikke tolket |
| `is_absent` | BOOL | 1 = feltet er fjernet |
| `source` | TEXT | `extracted`, `ai_suggested`, `calculated`, `manual` |
| `producer` | TEXT | Motor/modell/regel/bruker |
| `confidence` | REAL | 0–1, NULL for `calculated` og `manual` |
| `evidence_page`, `bbox_x0`, `bbox_y0`, `bbox_x1`, `bbox_y1`, `evidence_ref`, `raw_text` | | Kildehenvisning; `raw_text` er sensitiv |
| `recorded_at` | UTC | NOT NULL |
| `recorded_by` | TEXT | Windows-bruker eller `system` |
| `job_id` | UUID | FK NULL – jobben som produserte verdien |

### 3.5 Validering, godkjenning og eksport

**`validation_results`** – `id` INTEGER PK, `invoice_id` FK, `validation_run_id` UUID, `rule_id` (f.eks. `MVA-001`), `rule_version`, `severity` (`info`, `warning`, `error`), `field_path` NULL, `message_key` (oversettelsesnøkkel – ikke ferdig tekst), `params_json`, `status` (`open`, `resolved`, `overridden`), `overridden_by`, `override_reason`, `created_at`, `resolved_at`.

**`approvals`** – kun tilføyelse. `id` UUID PK, `entity_id`, `invoice_id` (sammensatt FK), `decision` (`approved`, `rejected`, `revoked`), `content_sha256` NOT NULL, `snapshot_json` NOT NULL (kanonisk JSON slik den ble godkjent), `overridden_rule_ids` (JSON), `decided_by`, `decided_at`, `comment`. Gjeldende godkjenning er gyldig bare hvis siste beslutning er `approved` **og** `content_sha256` = `invoices.content_sha256`.

**`export_batches`** – `id` UUID PK, `entity_id` (en batch inneholder aldri flere enheter), `target` (`excel`, `csv`, `unit4`; planlagt `tripletex`, `xledger` i F14b/F14c, ADR-0030), `mapping_version`, `status` (`created`, `written`, `failed`), `file_name`, `file_sha256`, `item_count`, `is_reexport` BOOL, `reexport_reason`, `created_by`, `created_at`, `completed_at`.

**`export_items`** – `id` INTEGER PK, `entity_id`, `batch_id` og `invoice_id` (begge sammensatt FK med `entity_id`), `approval_id` FK NOT NULL, `target`, `status` (`pending`, `exported`, `failed`, `superseded`). **Delvis unik indeks** på (`entity_id`, `invoice_id`, `target`) `WHERE status IN ('pending', 'exported')` – databasen hindrer dobbel eksport. Re-eksport setter forrige rad til `superseded` i samme transaksjon og krever begrunnelse.

Eksportrekkefølge (krasjsikker): (1) opprett batch og `pending`-rader i én transaksjon → (2) skriv fil til midlertidig navn, `fsync`, atomisk omdøping → (3) sett `exported` og filhash. Ved oppstart kontrolleres `pending`-rader mot filsystemet før ny eksport tillates.

### 3.6 Revisjon og innstillinger

**`audit_events`** – kun tilføyelse, håndhevet med triggere som avviser `UPDATE` og `DELETE`.

| Kolonne | Type | Regler |
|---|---|---|
| `id` | INTEGER | PK AUTOINCREMENT (sekvens) |
| `event_id` | UUID | UNIQUE |
| `occurred_at` | UTC | NOT NULL |
| `actor` | TEXT | Windows-bruker eller `system` |
| `event_type` | TEXT | f.eks. `document.imported`, `ocr.completed`, `ai.extraction_completed`, `accounting.classified`, `validation.failed`, `invoice.field_corrected`, `invoice.approved`, `export.completed`, `settings.changed`, `integrity.mismatch_detected` |
| `entity_id` | UUID | Regnskapsenhet; NULL for globale hendelser |
| `subject_type`, `subject_id` | TEXT | Hva hendelsen gjelder (f.eks. `invoice`, UUID) |
| `details_json` | TEXT | Kun ID-er, feltstier, regel-ID-er, antall og hasher – **ikke** beløp, navn, kontonumre eller dokumenttekst |
| `prev_hash` | TEXT(64) | Hash av forrige hendelse (første: 64 nuller) |
| `event_hash` | TEXT(64) | SHA-256 av `prev_hash` + kanonisk JSON av hendelsen |

**`app_settings`** – `entity_id` NULL (NULL = global innstilling), `key` (fra en tillatt liste) med unik indeks på (`coalesce(entity_id, '')`, `key`), `value_json`, `schema_version`, `updated_at`, `updated_by`. Hemmeligheter kan ikke lagres her (nøkkellisten tillater dem ikke).

### 3.7 SQLite-konfigurasjon

Settes for hver tilkobling:

| PRAGMA | Verdi | Begrunnelse |
|---|---|---|
| `foreign_keys` | `ON` | Av som standard i SQLite |
| `journal_mode` | `WAL` | Samtidig lesing under skriving |
| `synchronous` | `FULL` | Bekreftet eksport/godkjenning skal overleve strømbrudd |
| `busy_timeout` | `5000` | Unngå sporadiske «database is locked» |
| `trusted_schema` | `OFF` | Hindrer at funksjoner i skjemaet utføres med økte rettigheter |
| `secure_delete` | `ON` | Slettet innhold overskrives (retensjon/sletting) |

`PRAGMA quick_check` ved oppstart; `PRAGMA integrity_check` før sikkerhetskopi.

### 3.8 Transaksjonsgrenser

| Operasjon | Én transaksjon omfatter | Utenfor transaksjonen |
|---|---|---|
| Import | `documents`-rad + revisjonshendelse | Filen skrives og hashes **før** transaksjonen (midlertidig navn → `fsync` → atomisk omdøping); ved feil slettes kun den midlertidige filen |
| Lagre uttrekk/korrigering | Typede kolonner + nye `field_provenance`-rader + ny `content_sha256` + statusendring + revisjonshendelse | – |
| Validering | Nye `validation_results` + statusendring + revisjonshendelse | Selve reglene kjøres før skriving |
| Godkjenning | Kontroll av `content_sha256` og `row_version` + `approvals`-rad + status + revisjonshendelse | – |
| Eksport | Se §3.5: (1) batch + `pending`, (2) fil skrives atomisk, (3) `exported` + filhash + revisjonshendelse | Filskriving mellom (1) og (3) |

Optimistisk låsing (`row_version`) hindrer at en godkjenning registreres på et innhold som er endret i mellomtiden.


### 3.9 Faktisk F02-skjema (ADR-0026–0028)

Denne delen beskriver implementert lagring og har forrang foran de langsiktige tabellskissene ved vurdering av F02.

| Tabell | Faktisk ansvar og viktige grenser |
|---|---|
| `accounting_entities` | Eksplisitt UUID, navn, valgfritt organisasjonsnummer, valuta og UTC-tider. Unikt organisasjonsnummer når oppgitt. Ingen automatisk standardrad. |
| `invoices` | UUID, entity_id, document_id, current_revision, hash, arbeidsflytstatus og typet headerprojeksjon. Sammensatt UNIQUE(entity_id,id). Eier og dokument er uforanderlige. |
| `invoice_revisions` | PK(invoice_id,revision), enhet, kanonisk JSON, hash, type endring, tidspunkt og teknisk aktør. Sammensatt, utsatt FK til fakturaens enhet/id. UPDATE/DELETE avvises. |
| `audit_events` | Global sequence, event_id, UTC-tid, aktør, type, valgfri enhet, subjekt, detalj-JSON, hash_version, prev_hash, event_hash. Triggere hindrer endring/sletting og krever utvidelse av kjedeenden. |
| `alembic_version` | Gjeldende migrasjonsrevisjon, nå `0001_initial`. |

UUID lagres som 32 små heksadesimale tegn av SQLAlchemy `Uuid`, ikke TEXT(36) som i de langsiktige skissene. Tidspunkter lagres som 27-tegns UTC med mikrosekunder (`YYYY-MM-DDTHH:MM:SS.ffffffZ`). Penger lagres som eksakt tekst. `DecimalText` avviser float/bool, ikke-endelige verdier og representasjoner over 40 tegn. Normalisering bruker ikke aktiv Decimal-presisjon og kan ikke runde verdien.

`invoices` peker med utsatt FK til sin gjeldende revisjon; revisjonen peker tilbake med sammensatt enhets-FK. Triggerne kontrollerer at gjeldende referanse har samme enhet og hash. Repositoriet kontrollerer i tillegg snapshotet og headerprojeksjonen ved lesing. Et snapshot inneholder linjer, MVA og proveniens tapsfritt; det er ennå ingen separate linje-/provenienstabeller.

Fakturatjenestens register/revise-operasjon og audit-hendelsen skrives i samme Unit of Work. Lik revisjon med samme innhold er idempotent. Konkurrerende revisjoner bruker expected_revision og row_version. Direkte intern bruk av repositorier innebærer ikke at en hendelse automatisk skrives; atomisk forretningsflyt går gjennom applikasjonstjenestene.

`document_id` er i F02 en identifikator uten FK til dokumentlager: dokumenttabellen kommer i F03. Leverandørregister, duplikatnøkler, godkjenninger og eksporttabeller er ikke implementert.

### 3.10 Faktisk F03-skjema (ADR-0029, migrasjon `0002_documents`)

| Tabell | Faktisk ansvar og viktige grenser |
|---|---|
| `documents` | Generisk dokument per enhet: `document_type` (`unclassified`, `invoice`, `credit_note`, `receipt`, `contract`, `payment_confirmation`, `correspondence`, `other`), `sha256`, `size_bytes` (1–52 428 800), `detected_format` (`pdf`, `png`, `jpeg`, `tiff`; NULL bare i karantene), renset `display_name` (kun visning), relativ `storage_path`, `source` (`file_import`, `inbox`), `status` (`stored`, `quarantined`), import- og integritetsfelt. UNIQUE(`entity_id`, `sha256`), UNIQUE(`entity_id`, `id`), UNIQUE(`storage_path`). Ingen fakturafelter. |
| `document_links` | PK(`entity_id`, `from_document_id`, `to_document_id`, `link_type`), `link_type` ∈ {`attachment`, `supersedes`, `related`}, sammensatte FK-er til `documents(entity_id, id)`, ingen selvkobling. Kun tilføyelse. |
| `audit_events` | Uendrede kolonner og rader; emnetypen `document` er lagt til. |

Utløsere: `documents_no_delete`; `documents_immutable` (ID, enhet, hash, størrelse, format, sti, kilde, status, importtid/-aktør og visningsnavn kan ikke endres; type og integritet kan); `document_links_no_update/_no_delete`; `invoices_reference_document` (en ny faktura må peke på et lagret dokument i samme enhet – erstatter den planlagte FK-en, se ADR-0029 pkt. 4). Migrasjonen avbrytes hvis det finnes fakturaer fra F02, fordi de ikke har dokumenter.

Filene ligger utenfor databasen under `documents/<entity_hex>/` (`originals/ab/cd/<sha256>.<ext>`, `staging/`, `quarantine/`, `orphans/`); se ADR-0029.

### 3.11 Faktisk F04-skjema (ADR-0031, migrasjon `0003_processing`)

| Tabell | Faktisk ansvar og viktige grenser |
|---|---|
| `processing_jobs` | Én rad per kjøring av arbeidsprosessen for ett lagret dokument: `step` (`page_analysis`), `idempotency_key` (SHA-256 av dokument, steg, motor, motorversjon og innstillingshash), `attempt`, `status` (`queued`, `running`, `succeeded`, `failed`, `timed_out`, `cancelled`), `engine`/`engine_version` (f.eks. `pypdfium2`/`5.13.0`), `settings_hash`, tidspunkter, `error_code` (fast liste, aldri fritekst), `page_count`, `active_content`. Høyst én vellykket og høyst én uferdig jobb per nøkkel og enhet (delvise unike indekser). Sammensatt FK til `documents(entity_id, id)`; bare dokumenter med status `stored` (utløser). Kan ikke slettes; en jobb går bare fra `running` til en sluttstatus, og en avsluttet jobb er endelig. |
| `document_pages` | PK(`job_id`, `page_number`), mål i piksler ved valgt dpi, `rotation_degrees` (0/90/180/270), `has_text_layer` = (`text_layer_chars` > 0). FK (`entity_id`, `document_id`, `job_id`) til jobben. Kun tilføyelse, og bare mens jobben kjører. |
| `derived_files` | Sidebilde (`page_render`) eller tekstlag (`text_layer`) per side: `storage_path` (under `<enhet>/derived/`), `sha256`, `size_bytes`, `producer` (f.eks. `pypdfium2/5.13.0`), `created_at`. FK til jobben og til siden. Kun tilføyelse, og bare mens jobben kjører. |

Sider og avledede filer hører til **jobben**, ikke direkte til dokumentet: samme dokument kan analyseres på nytt med andre innstillinger eller en ny motorversjon uten at tidligere resultater endres. Tekstlaget lagres som avledet JSON-fil per side (tekst og én boks per tegn, normalisert 0–1 mot sidebildet), ikke i databasen. Skissen i §3.2 (`text_extraction`, `rendering`, UNIQUE(`document_id`, `page_number`), produsent `pymupdf`) er erstattet av dette. `documents` er uendret.

Filene ligger under `documents/<entity_hex>/derived/<document_hex>/<job_hex>/`, skrivebeskyttet; arbeidsmapper under `work/` er midlertidige.

### 3.12 Faktisk F15-skjema (ADR-0032, migrasjon `0004_ehf`)

| Tabell | Endring |
|---|---|
| `documents` | Bygget om (ADR-0032): `detected_format` tillater `xml`, `source` tillater `ehf_attachment`. Alle rader, hasher, indekser og utløsere er beholdt. |
| `processing_jobs` | Bygget om: steget `ehf_extraction` og feilkodene `invalid_xml`, `unsupported_version`, `too_many_lines`, `too_many_attachments`, `attachment_too_large`. `page_count` kreves bare for vellykket `page_analysis`. |
| `invoice_findings` (ny) | Flagg fra kontrollene i F15: `entity_id`, `invoice_id`, `revision`, `code` (bare `[a-z0-9_]`, fast liste i `InvoiceFindingCode`), `created_at`. PK(`invoice_id`, `revision`, `code`). Sammensatt FK (`entity_id`, `invoice_id`) til `invoices` og (`invoice_id`, `revision`) til `invoice_revisions`. Kun tilføyelse (utløsere). |

En EHF-faktura registreres som `invoices`/`invoice_revisions` (status `draft`, revisjon 1) med `document_id` = XML-dokumentet. Vedlegg er egne dokumenter (kilde `ehf_attachment`) koblet med `document_links` (`attachment`). Flaggkodene: `line_sum_mismatch` (BR-CO-10), `net_mismatch` (BR-CO-13), `vat_mismatch` (BR-CO-14), `gross_mismatch` (BR-CO-15), `payable_mismatch` (BR-CO-16), `currency_mismatch`, `negative_total`, `wrong_recipient`, `missing_recipient`, `possible_duplicate`, `unreadable_value`, `missing_required`, `external_attachment`, `attachment_refused`.

### 3.13 Faktisk F08a-skjema (ADR-0033, migrasjon `0005_validation`)

| Tabell | Faktisk ansvar og viktige grenser |
|---|---|
| `suppliers` | Leverandør per regnskapsenhet:<br>• `name` slik den sto på første faktura;<br>• `org_number` (unik per enhet) eller `foreign_vat_id` (unik per enhet), minst én av dem;<br>• `created_at`, `created_by`.<br>Uforanderlig og kan ikke slettes. Standardkonto og MVA-kode fra §3.3 kommer i F08b. |
| `supplier_bank_accounts` | Betalingskonto per leverandør:<br>• `account_kind` (`bban`, `iban`) og `account` (11 sifre eller IBAN, unik per leverandør);<br>• `status` (`unverified`, `verified`, `blocked`);<br>• `first_seen_invoice_id` (sammensatt FK til fakturaen);<br>• `status_changed_at` og `status_changed_by`, påkrevd når statusen ikke er `unverified`.<br>Ny rad er alltid `unverified`. Bare statusen kan endres, aldri tilbake til `unverified`. Raden kan ikke slettes. |
| `validation_runs` | Én kjøring av regelkatalogen:<br>• faktura og revisjon (sammensatte FK-er);<br>• `run_number`, unik per faktura;<br>• `ruleset_version`, `settings_sha256`;<br>• antall feil, advarsler og info;<br>• `created_at`, `created_by`.<br>Kun tilføyelse. |
| `validation_results` | Funn i en kjøring, posisjon 1–200:<br>• `rule_id` (f.eks. `BANK-001`), `rule_version`, `severity`;<br>• `field_path`, `message_key` (`validation.*`);<br>• `params_json` (objekt, høyst 1 KB, bare koder, tall og datoer).<br>Kun tilføyelse. |

Gjeldende kontrollresultat er siste kjøring for gjeldende revisjon. Statusfeltene i skissen i §3.5 (`open`, `resolved`, `overridden`, `overridden_by`, `override_reason`) er erstattet av kjøringer. Overstyringer kommer i F09 som egen tabell. `audit_events` tillater emnetypen `supplier`.

### 3.14 Faktisk F08b-skjema (ADR-0034, migrasjon `0006_reference`)

| Tabell | Faktisk ansvar og viktige grenser |
|---|---|
| `reference_imports` | Én vellykket import:<br>• `kind` (`chart`, `vat_codes`, `dimensions`);<br>• `sha256` for filen, `row_count` (1–20 000);<br>• `created_at`, `created_by`.<br>Siste import av hver type gjelder. Kun tilføyelse. |
| `chart_of_accounts` | Rader i én kontoplan-import:<br>• `account` (kode), `name`;<br>• `default_vat_code`, `is_active`.<br>PK(`import_id`, `account`). Bare for import av typen `chart` (utløser). Navn som begynner med `= + - @`, avvises (CHECK). |
| `vat_codes` | Rader i én MVA-kode-import:<br>• `code`, `valid_from`, `valid_to`;<br>• `rate` (eksakt desimaltekst, 0–100), `direction` (`input`, `output`);<br>• `saft_code`, `name`.<br>PK(`import_id`, `code`, `valid_from`). Overlappende perioder for samme kode avvises ved import. |
| `dimension_values` | Rader i én dimensjonsimport: `dimension` (`cost_center`, `department`, `project`), `code`, `name`, `is_active`. PK(`import_id`, `dimension`, `code`). |
| `supplier_defaults` | Standardkontering per leverandør, versjonert (`version` unik per leverandør, høyeste gjelder):<br>• `account`, `vat_code`;<br>• `cost_center`, `department`, `project`;<br>• `set_at`, `set_by`.<br>Kun tilføyelse. |

Skissen i §3.3 (oppdatering på stedet, `origin`, `label_key`) er erstattet av øyeblikksbilder. `suppliers` er uendret; standarden ligger i egen tabell. Konteringen ligger i fakturaens revisjon (`accounting_lines`), ikke i egen tabell.

### 3.15 Faktisk F09-skjema (ADR-0035, migrasjon `0007_review`)

| Tabell | Faktisk ansvar og viktige grenser |
|---|---|
| `approvals` | Beslutning om én revisjon:<br>• `sequence` (fortløpende per faktura);<br>• `revision`, `content_sha256`;<br>• `decision` (`approved`, `rejected`, `revoked`);<br>• `run_id` (påkrevd ved godkjenning og fra samme revisjon);<br>• `comment` (ren tekst, høyst 500 tegn);<br>• `decided_at`, `decided_by`.<br>Kun tilføyelse. Godkjenning bare av gjeldende innhold (utløser). |
| `finding_overrides` | Overstyring av et feilfunn for én revisjon:<br>• `rule_id`, `field_path`, `message_key`;<br>• `reason` (10–500 tegn);<br>• `created_at`, `created_by`.<br>BANK-001 og DUP-001 avvises (CHECK). Kun tilføyelse. |

Utløsere på `invoices`: `approved` krever at siste beslutning er en godkjenning av gjeldende revisjon og hash, og innholdet kan ikke endres mens statusen er `approved`. En ny revisjon setter `draft`. Skissen i §3.5 (`overridden_rule_ids`, `snapshot_json`) er erstattet: snapshotet er revisjonen som hashen peker på, og overstyringene er egne rader.

### 3.16 Faktisk F10-skjema (ADR-0036, migrasjon `0008_export`)

| Tabell | Faktisk ansvar og viktige grenser |
|---|---|
| `export_batches` | Én fil:<br>• `sequence` (fortløpende per enhet), `target` (`excel`, `csv`);<br>• `mapping_version` (0 = standard) og `columns_json` (kolonnene som ble brukt);<br>• `status` (`created` → `written` eller `failed`, nøyaktig én gang);<br>• `file_name` (fast mønster `fakturaeksport-NNNNN-ÅÅÅÅMMDD-TTMMSS.xlsx/csv`), `file_sha256`;<br>• `item_count`, `is_reexport`, `reexport_reason` (10–500 tegn, påkrevd ved ny eksport);<br>• `audit_anchor` (hash av siste revisjonshendelse ved opprettelse);<br>• `created_at`, `created_by`, `completed_at`.<br>Kan ikke slettes. |
| `export_items` | Én faktura i én batch:<br>• `approval_id`, `revision`, `content_sha256`;<br>• `target`, `status` (`pending` → `exported` eller `failed`; deretter `superseded`).<br>Delvis unik indeks `uq_export_items_active` på (`entity_id`, `invoice_id`, `target`) for `pending` og `exported`. Kan ikke slettes. |
| `export_mappings` | Kolonneoppsett per enhet: `version` (fortløpende), `columns_json` (felt og valgfri overskrift), `created_at`, `created_by`. Kun tilføyelse. |

Utløsere:

- En eksportrad kan bare skrives som `pending` i en åpen batch med samme mål, for gjeldende revisjon og hash og med siste beslutning som godkjenning. En vanlig batch tar bare `approved`, en ny eksport bare `exported`.
- `invoices.workflow_status = 'exported'` krever en eksportert rad for gjeldende innhold. En eksportert faktura kan ikke endre innhold eller status.
- Mens en rad er `pending`, kan fakturaen ikke endres, og `approvals` tar ingen nye beslutninger. Det samme gjelder etter eksport.

Avvik fra skissen i §3.5: batchen lagrer i tillegg kolonnene, løpenummeret og revisjonsankeret, og radene binder revisjon og hash i tillegg til godkjenningen. Filene ligger i `<data>/exports/<enhet>/`; se ADR-0036 for rekkefølge og gjenoppretting.

### 3.17 Faktisk F12-skjema (ADR-0037, migrasjon `0009_backup`)

| Tabell | Faktisk ansvar og viktige grenser |
|---|---|
| `backups` | Én sikkerhetskopifil laget fra denne databasen:<br>• `file_name` (fast mønster `invoiceflow-sikkerhetskopi-ÅÅÅÅMMDD-TTMMSS.ifbak`), `file_sha256` (unik);<br>• `byte_count`, `file_count`;<br>• `schema_revision`, `audit_sequence`, `audit_anchor` (kjedens ende i kopien);<br>• `created_at`, `created_by`;<br>• `deleted_at`, `deleted_by` (settes én gang, samtidig).<br>Rader slettes aldri (utløser). Ingen `entity_id`: sikkerhetskopien omfatter hele datakatalogen, som revisjonskjeden. |

Hvor filen ligger, lagres ikke. Personen velger filen når den skal kontrolleres, gjenopprettes eller slettes, og den kjennes igjen på SHA-256.

### 3.18 Faktisk F11a-skjema (ADR-0038, migrasjon `0010_page_metrics`)

`document_pages` får to kolonner:

- `dark_permille`: andel mørke piksler innenfor en marg på 5 %, 0–1000;
- `center_dark_permille`: det samme i det sentrale området (20–80 % bredde, 30–70 % høyde).

Begge er NULL for sider analysert før F11a. Sidetype (innhold, blank, skilleark) og deler beregnes av rene funksjoner ved visning og lagres ikke. En del er et sideintervall i det originale dokumentet, slik `CanonicalInvoice.first_page`/`last_page` beskriver.

### 3.19 Faktisk F05-skjema (ADR-0040, migrasjon `0011_ocr`)

- **`processing_jobs`** bygges om (ADR-0032) og godtar steget `ocr` og feilkoden `ocr_failed`. En vellykket OCR-jobb har antall gjenkjente sider i `page_count`.
- **`ocr_pages`:** én rad per gjenkjent side.
  - `job_id` og `page_number` er primærnøkkel.
  - `source_job_id` peker på sideanalysen hvis sidebilde ble lest, med fremmednøkkel til `document_pages`.
  - Tall: `word_count`, `line_count`, `char_count`, `mean_confidence` (0–100) og `low_confidence_words`.
  - Filen med ordene: `storage_path`, `sha256`, `size_bytes`, `producer` og `created_at`.
- **Regler i databasen:**
  - rader legges bare til av transaksjonen som avslutter en kjørende OCR-jobb;
  - kildejobben må være en vellykket sideanalyse av samme dokument;
  - tabellen er bare-tillegg (ingen endring eller sletting).
- **Ordene** ligger i den avledede filen `ocr-0001.json` (`OcrLayer`). Hvert ord har tekst, boks normalisert til sidebildet, sikkerhet og linjenummer. Teksten lagres aldri i databasen.

## 4. Pydantic-kontrakter (implementert)

Alle kontrakter arver `ContractModel` (`extra="forbid"`, `frozen=True`). Samlinger er `tuple` slik at modellen er uforanderlig hele veien ned.

### 4.1 Skalartyper (`domain/types.py`)

| Type | Grunnlag | Begrensning |
|---|---|---|
| `Money` | `Decimal` | maks 15 sifre, 2 desimaler; `float`/`bool` avvises; NaN/uendelig avvises; normaliseres til nøyaktig 2 desimaler (`"100"` → `"100.00"`) |
| `UnitPrice` | `Decimal` | maks 18 sifre, 6 desimaler; minst 2 desimaler i kanonisk form |
| `Quantity` | `Decimal` | maks 18 sifre, 6 desimaler; uten overflødige nuller |
| `VatRate` | `Decimal` | 0–100, 2 desimaler (prosent); uten overflødige nuller (`"25"`) |
| `IsoDate` | `date` | kun `YYYY-MM-DD` eller `date`-objekt; tidsstempler og `datetime` avvises |
| `Position` | `int` (strengt) | ≥ 1; linje- og sidenummer; `True`, `"2"` og `2.0` avvises |
| `Flag` | `bool` (strengt) | kun `true`/`false` |
| `Confidence`, `UnitInterval` | `float` (strengt) | 0–1 (modellscore og normaliserte koordinater, ikke penger) |
| `OrgNumber` | `str` | `^\d{9}$` |
| `BankAccount` | `str` | `^\d{11}$` |
| `Kid` | `str` | 2–25 tegn, siffer; siste tegn kan være `-` (MOD11) |
| `Iban`, `Bic`, `CurrencyCode`, `CountryCode` | `str` | ISO-mønstre |
| `ShortText`, `LongText`, `Identifier`, `UnitText`, `ReferenceText`, `ExplanationText`, `DimensionCode` | `str` | Lengdegrenser (motvirker ressursmisbruk); minst ett synlig tegn; ingen kontroll- eller formattegn (Unicode `Cc`/`Cf`, f.eks. NUL og retningsoverstyring); linjeskift og tabulator bare i `LongText`/`ExplanationText` |

Normaliseringen er eksakt og runder aldri (ADR-0025). `raw_text` i kildehenvisningen bevares uendret som bevis og må vises som escapet ren tekst.

Kontraktene kontrollerer **form**. Kontrollsiffer (MOD10/MOD11/MOD97), summer, MVA og duplikater er **forretningsregler** i regnskapsmotoren (§7), slik at en feillest verdi fortsatt kan lagres, vises og rettes.

### 4.2 Proveniens (`domain/provenance.py`)

```text
FieldValue[T]
├── value: T | None          # None = funnet, men ikke tolkbar (råtekst i evidence)
└── provenance: Provenance
    ├── source: ValueSource  # extracted | ai_suggested | calculated | manual
    ├── producer: str | None # "tesseract/5.5", "regel/linje-mva/1", "bruker/lokal"
    ├── confidence: float | None
    ├── evidence: Evidence | None
    │   ├── page_number, bbox (normalisert 0–1), source_ref, raw_text
    └── recorded_at: datetime (med tidssone) | None
```

Regler håndhevet av kontrakten:

- `extracted` krever `evidence` (side eller kildereferanse).
- Alle andre kilder krever `producer`.
- `calculated` og `manual` kan ikke ha `confidence`.
- `bbox` krever sidetall, og `x0 ≤ x1`, `y0 ≤ y1`.

### 4.3 Faktura (`domain/invoice.py`)

```text
CanonicalInvoice
├── schema_version "1.0", document_id, first_page, last_page
├── invoice_type, invoice_number, invoice_date, due_date, currency,
│   referenced_invoice_number, buyer_reference              (FieldValue)
├── supplier: Party            name, org_number, vat_registered, foreign_vat_id, address
├── customer: Party | None
├── payment: PaymentDetails    kid, bank_account, iban, bic
├── lines: tuple[InvoiceLine]  line_number, description, quantity, unit, unit_price,
│                              net_amount, vat_rate, vat_amount       (maks 5000)
├── vat_breakdown: tuple[VatBreakdownEntry]  vat_rate, taxable_amount, vat_amount
├── totals: InvoiceTotals      net_amount, vat_amount, rounding_amount, gross_amount
└── accounting_lines: tuple[AccountingLine]  account, vat_code, net_amount,
                               cost_center, department, project,
                               source_line_numbers, explanation       (maks 1000)
```

Strukturregler: unike linjenumre, konteringslinjer kan bare referere til eksisterende fakturalinjer, `last_page ≥ first_page`.

**Arbeidsflytstatus er ikke en del av kontrakten.** Validerings- og godkjenningsstatus lagres i egne tabeller (§3.5). Dermed kan innholdet hashes og bindes til en godkjenning, og samme kontrakt kan brukes av OCR, KI og eksport.

### 4.4 Innholdshash

`content_sha256` = SHA-256 av UTF-8-kodet kanonisk JSON: `model_dump(mode="json")` serialisert med sorterte nøkler, uten mellomrom (`separators=(",", ":")`) og `ensure_ascii=False`. Fordi kontraktene normaliserer tall, datoer og tekst (ADR-0025), gir likt innhold alltid lik JSON og dermed lik hash (testet: `tests/unit/domain/test_contract_types.py`). Hashfunksjonen implementeres i Fase 02. Godkjenningen binder i tillegg `entity_id` (ADR-0022); enheten er ikke en del av fakturainnholdet.

### 4.5 Fortegn for kreditnota

Beløp lagres slik de framgår av dokumentet, normalisert til positive totaler for kreditnotaer; retningen bestemmes av `invoice_type` og anvendes i eksportadapteren (ADR-0020). Negative linjer (rabatt) er tillatt på vanlige fakturaer. Excel- og CSV-eksporten (F10) skriver kreditnotaer med negative beløp.

## 5. Proveniens – utforming

| Kilde | Settes av | Typisk `producer` | Krav |
|---|---|---|---|
| **Hentet fra dokument** (`extracted`) | Tekstlag-, OCR- eller XML-adapter | `pymupdf/1.28`, `tesseract/5.5` | Kildehenvisning; råtekst bevares |
| **Foreslått av KI** (`ai_suggested`) | Applikasjonslaget etter Pydantic-validering av KI-svar | `ki/<leverandør>:<modell>` | Må godkjennes av menneske; markeres tydelig i UI |
| **Beregnet** (`calculated`) | Deterministisk regel | `regel/<regel-id>/<versjon>` | Ingen konfidens; reproduserbar |
| **Manuelt** (`manual`) | Brukerhandling i UI | `bruker/<windows-bruker>` | Tidspunkt; revisjonshendelse `invoice.field_corrected` |

Implementert i F06 (ADR-0041): feltuttrekket gir `extracted` med `producer` `regel/fakturafelt/1`.

- Bevis: side, normalisert boks, `source_ref` (`tekstlag/s1/l12` eller `ocr/s1/l12`) og råtekst.
- OCR-verdier har laveste ordsikkerhet som konfidens (0–1).
- `recorded_at` settes ikke, slik at innholdshashen er den samme ved nytt uttrekk.

Viktige regler:

1. **Proveniens settes alltid av applikasjonskoden**, aldri av KI-modellen selv. KI-svar har et eget, smalere skjema uten proveniensfelt.
2. Godkjenning endrer ikke proveniens: en KI-foreslått konto forblir `ai_suggested`, men er dekket av en godkjenning bundet til innholdshashen.
3. Ved konflikt mellom kilder vinner ikke automatisk den «sikreste»: konflikten blir en valideringsmelding som brukeren tar stilling til.
4. Historikk tas aldri bort; ny verdi gir ny rad i `field_provenance`.

## 6. Eksempel – fiktiv norsk faktura

Fullstendig fil: [`examples/eksempel_faktura_kanonisk.json`](examples/eksempel_faktura_kanonisk.json). Alle navn, numre og adresser er **fiktive**. Organisasjonsnumrene `123456785` og `314159268`, kontonummeret `1234.56.78903` og KID `2026100459` har gyldige kontrollsiffer, men er valgt som kjente testverdier.

| Felt | Verdi | Kilde |
|---|---|---|
| Leverandør | Fjordkontor Rekvisita AS, org.nr. 123 456 785 MVA | Hentet (OCR) |
| Kunde | Nordlys Testbedrift AS | Hentet (OCR) |
| Fakturanummer | 2026-10045 | Hentet (OCR) |
| Fakturadato | 01.10.2026 | Hentet (OCR) |
| Forfallsdato | 15.10.2026 | **Manuelt** – OCR leste «l5.10.2026» |
| Fakturatype | Faktura | Foreslått av KI |
| Linjer | Kopipapir 10 × 289,00 · Toner 2 × 749,00 · Frakt 1 × 149,00 | Hentet; linje-MVA beregnet |
| Sum eks. MVA / MVA 25 % / Å betale | 4 537,00 / 1 134,25 / 5 671,25 | Hentet |
| Kontering | Konto 6800, MVA-kode 1, avdeling 100 | KI-forslag / beregnet / manuelt |

Utdrag:

```json
{
  "due_date": {
    "value": "2026-10-15",
    "provenance": {
      "source": "manual",
      "producer": "bruker/lokal",
      "recorded_at": "2026-10-02T09:14:00+02:00",
      "evidence": {
        "page_number": 1,
        "bbox": { "x0": 0.62, "y0": 0.18, "x1": 0.78, "y1": 0.2 },
        "raw_text": "l5.10.2026"
      }
    }
  },
  "totals": {
    "gross_amount": {
      "value": "5671.25",
      "provenance": {
        "source": "extracted",
        "producer": "tesseract/5.5",
        "confidence": 0.97,
        "evidence": { "page_number": 1, "raw_text": "5 671,25" }
      }
    }
  }
}
```

Testene (`tests/unit/domain/test_canonical_invoice.py`) kontrollerer at eksempelet er gyldig, at JSON-rundtur er tapsfri, og at linjer, MVA, totaler og kontering stemmer aritmetisk.

## 7. Valideringsregler – første katalog (Fase 08)

| Regel | Kontroll | Alvorlighet |
|---|---|---|
| REQ-001 | Påkrevde felt: leverandørnavn, fakturanummer, fakturadato, valuta, netto, MVA, brutto | Feil |
| REQ-002 | Norsk leverandør uten organisasjonsnummer | Feil |
| ENT-001 | Kundens organisasjonsnummer på fakturaen avviker fra regnskapsenhetens (feil selskap?) | Advarsel |
| SUM-001 | Sum linjer (netto) = total netto | Feil |
| SUM-002 | Netto + MVA + øreavrunding = brutto | Feil |
| MVA-001 | MVA per sats = grunnlag × sats, avrundet `ROUND_HALF_UP` til 2 desimaler (toleranse konfigurerbar, standard 0,01 per sats) | Feil |
| MVA-002 | MVA-sats gyldig på fakturadato (fra `vat_codes`) | Feil |
| MVA-003 | MVA beregnet av leverandør som ikke er MVA-registrert | Feil |
| DAT-001 | Forfallsdato ≥ fakturadato | Feil |
| DAT-002 | Fakturadato i fremtiden eller eldre enn konfigurerbar grense | Advarsel |
| ID-001 | Organisasjonsnummer: MOD11, vekter 3,2,7,6,5,4,3,2 | Feil |
| ID-002 | Kontonummer: MOD11, vekter 5,4,3,2,7,6,5,4,3,2 | Feil |
| ID-003 | KID: MOD10 (Luhn) eller MOD11 | Advarsel |
| ID-004 | IBAN: ISO 13616 MOD97 | Feil |
| DUP-001 | Samme leverandør + fakturatype + fakturanummer finnes | Feil |
| DUP-002 | Samme leverandør + brutto + fakturadato med annet nummer | Advarsel |
| BANK-001 | Betalingskonto ikke registrert/verifisert for leverandøren | Feil |
| ACC-001 | Konteringslinjer summerer til total netto | Feil |
| ACC-002 | Konto finnes og er aktiv i kontoplanen | Feil |
| ACC-003 | MVA-kode samsvarer med MVA-sats | Feil |
| CRN-001 | Kreditnota uten referanse til opprinnelig faktura | Advarsel |
| CUR-001 | Annen valuta enn NOK (inntil støttet) | Advarsel |
| AI-001 | KI-foreslått verdi finnes ikke i dokumentteksten | Advarsel |

**Status F08a/F08b:** Alle regler unntatt AI-001 (F07) er implementert. MVA-002 og ACC-001–003 kom med regelsett 1.1 i F08b; de gir ett infofunn når referansedataene ikke er importert, og ACC-003 avviser utgående MVA-koder. Reglene er implementert i `application/validation/rules.py`. Presiseringer:

- **SUM-001:** krever at alle linjer har netto.
- **MVA-001:**
  - bruker MVA-spesifikasjonen;
  - uten spesifikasjon brukes linjene gruppert per sats, og toleransen er 0,01 per sats.
- **MVA-003:** bare når fakturaen sier at leverandøren ikke er MVA-registrert.
- **DUP-001:**
  - fakturanummeret normaliseres: store bokstaver, uten mellomrom og `-_./`, uten ledende nuller;
  - bare for leverandører med organisasjonsnummer.
- **BANK-001:** gjelder både kontonummer og IBAN, og skiller mellom ikke registrert, ikke bekreftet og sperret.

Merk: Python `Decimal` bruker `ROUND_HALF_EVEN` som standard. All avrunding skal angi `ROUND_HALF_UP` eksplisitt.

## 8. Lagring av filer

```text
%LOCALAPPDATA%\InvoiceFlowAI\
├── data\invoiceflow.sqlite3           database (+ -wal, -shm)
├── documents\<entity_id>\             ett lager per regnskapsenhet (ADR-0022)
│   ├── originals\ab\cd\<sha256>.<ext>  originaler, skrivebeskyttet, innholdsadressert
│   ├── derived\<document_id>\         sidebilder og forbehandlede bilder
│   └── quarantine\<uuid>.bin          avviste/mistenkelige filer (aldri åpnet igjen automatisk)
├── inbox\                             overvåket mappe (valgfri, konfigurerbar)
├── exports\                           eksportfiler
├── logs\                              roterende JSON-logger
└── config\config.json                 oppstartskonfigurasjon (ingen hemmeligheter)
```

Filendelsen i lagret navn kommer fra **gjenkjent** filtype, ikke fra brukerens filnavn.

## 9. Migrasjoner

- Alembic-revisjoner versjonskontrolleres; hver revisjon har `upgrade` og, der det er trygt, `downgrade`.
- Migrasjoner kjøres ved oppstart **etter** automatisk sikkerhetskopi av databasen.
- Tester: tom database → siste versjon; forrige versjon med testdata → siste versjon uten tap (Fase 02).
- SQLite-begrensninger (`ALTER TABLE`) håndteres med Alembics `batch_alter_table`.


## Tillegg – fremtidig dokumentarkiv

Datamodellen må kunne knytte generiske dokumenter, dokumenttyper og dokumentrelasjoner til regnskapsenheter (`entity_id`) og eventuelt fakturaer, uten å gjøre fakturafelter obligatoriske for andre dokumenttyper. Eksisterende `CanonicalInvoice` forblir fakturaspesifikk. Nærmere tabell- og migrasjonsdesign besluttes før F02; se [`DOCUMENT_ARCHIVE_SCOPE.md`](DOCUMENT_ARCHIVE_SCOPE.md).

## Tillegg – ERP-integrasjoner via API (planlagt, ADR-0030)

Ikke implementert. Ved F14b/F14c utvides `export_items` med ekstern referanse (målsystemets ID og vår stabile innsendingsreferanse) og tilstanden `unknown` for usikkert utfall. Den delvise unike indeksen omfatter da også `unknown`, slik at en faktura ikke kan sendes på nytt før utfallet er avklart. Tilordning og samtykke lagres per `entity_id` og mål; tilgangsnøkler lagres aldri i databasen (ADR-0009).
