# Tekstgjenkjenning (OCR): installasjon og kontroll

Gjelder InvoiceFlow AI fra fase 05 (ADR-0040). Programmet bruker Tesseract 5 med norsk språkdata. Uten Tesseract virker alt annet som før, men skannede sider får ingen tekst. Fra F13 skal Tesseract følge med programmet. Til da installeres det separat.

## 1. Installere på Windows 11

1. Last ned Tesseract 5.4.0 for Windows (64-bit) fra UB Mannheim:
   - fil: `tesseract-ocr-w64-setup-5.4.0.20240606.exe`;
   - SHA-256: `c885fff6998e0608ba4bb8ab51436e1c6775c2bafc2559a19b423e18678b60c9`.

   Kontroller kontrollsummen i PowerShell før du kjører filen:

   ```powershell
   Get-FileHash .\tesseract-ocr-w64-setup-5.4.0.20240606.exe -Algorithm SHA256
   ```

2. Installer til standardmappen `C:\Program Files\Tesseract-OCR`. Programmet leter bare der (og fra F13 ved siden av seg selv), aldri i `PATH`.
3. Legg til norsk språkdata:
   - kryss av for **Norwegian** under «Additional language data» i installasjonsprogrammet; eller
   - kopier `nor.traineddata` fra tessdata 4.1.0 til `C:\Program Files\Tesseract-OCR\tessdata`. SHA-256: `b859e4de24d2d23900d993d74819d33339255414057b5098dad2819a1894aa22`.
4. Start InvoiceFlow AI på nytt. Programmet ser etter Tesseract én gang ved oppstart.

## 2. Kontrollere

1. Åpne «Innboks». Meldingen «Tekstgjenkjenning (OCR) er ikke installert» skal være borte.
2. Kjør selvtesten:

   ```powershell
   InvoiceFlowAI.exe --self-test
   ```

   Med Tesseract leser selvtesten også et sidebilde uten tekstlag.
3. Les inn en skannet side og velg «Behandle nye dokumenter». Kolonnen «Tekst (OCR)» viser «Gjenkjent, 1 s.». Med «Vis tekst …» ser du teksten og sikkerheten per side.

## 3. Hva som gjenkjennes

| Side | OCR |
|---|---|
| Har tekstlag (PDF laget digitalt) | Nei. Tekstlaget brukes |
| Skannet side med innhold | Ja |
| Helt tom side | Nei |
| Skilleark (F11a) | Nei |
| Nesten tom side (for eksempel én linje) | Ja. Siden kan regnes som blank i skannevisningen, men leses likevel |

Sikkerheten (0–100 %) er Tesseracts eget anslag. Ord under 60 % telles som usikre. Feltene kontrolleres uansett av et menneske før godkjenning.

## 4. Hvis noe går galt

| Hva du ser | Hva du gjør |
|---|---|
| Meldingen om manglende OCR blir stående | Kontroller at `tesseract.exe` ligger i `C:\Program Files\Tesseract-OCR` og at `nor.traineddata` ligger i `tessdata`. Start programmet på nytt |
| «Ikke gjenkjent: tekstgjenkjenningen (OCR) mislyktes» | Velg dokumentet og «Behandle valgt» for et nytt forsøk. Gjentar det seg, kan sidebildet være ødelagt |
| «Ikke gjenkjent: tidsavbrutt» | Svært store eller mange sider. Behandle dokumentet på nytt. Skann helst med 300 dpi |
| Lav sikkerhet | Skann på nytt med 300 dpi, gråtoner og rett ark (`SCANNER_SETUP.md`) |
| Ny versjon av Tesseract eller språkdata | Dokumentene gjenkjennes på nytt ved neste «Behandle nye dokumenter». Tidligere resultater beholdes |
