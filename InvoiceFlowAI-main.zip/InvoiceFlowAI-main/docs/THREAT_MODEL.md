# InvoiceFlow AI – Trusselmodell

| | |
|---|---|
| **Dokumentversjon** | 1.2 (Fase 02, etter sluttgjennomgang) |
| **Metode** | Aktiva → aktører → tillitsgrenser → trusler (STRIDE-kategorier) → risiko → tiltak → restrisiko |
| **Status** | Oppdatert for F02 (§10). Revideres ved hver fase som innfører ny tillitsgrense, og minst før «port for ekte data» (`SECURITY.md` §17). |

---

## 1. Omfang og forutsetninger

- Én bruker, én Windows 11-maskin, kontrollert testmiljø.
- Maskinen er domene- eller lokalt administrert, med oppdatert Windows og Microsoft Defender.
- Brukeren er klarert til å godkjenne fakturaer; trusselen er primært **ondsinnet innhold**, **feil** og **tap/tyveri**, ikke en ondsinnet bruker.
- Skadevare som kjører som samme Windows-bruker kan i prinsippet lese alt brukeren kan lese. Dette kan bare delvis motvirkes av applikasjonen (se T03).

## 2. Aktiva

| ID | Aktivum | Viktigste egenskap |
|---|---|---|
| A1 | Originale fakturadokumenter | Konfidensialitet, integritet |
| A2 | Database (fakturaverdier, leverandører, kontering) | Integritet, konfidensialitet |
| A3 | Revisjonslogg | Integritet, tilgjengelighet |
| A4 | Eksportfiler | Integritet (korrekte beløp, ingen duplikater) |
| A5 | Hemmeligheter (API-nøkler) | Konfidensialitet |
| A6 | Sikkerhetskopier | Konfidensialitet, integritet, tilgjengelighet |
| A7 | Kildekode, bygg og avhengigheter | Integritet |
| A8 | Leverandørers bankkontoinformasjon | Integritet (svindel) |

## 3. Trusselaktører

| Aktør | Motivasjon / mekanisme |
|---|---|
| Ekstern angriper via dokument | Ondsinnet PDF/bilde, prompt-injeksjon, falsk faktura |
| Svindler | Falsk eller endret faktura med nytt kontonummer |
| Tyv | Stjålet bærbar PC eller USB-disk |
| Skadevare på maskinen | Lese data, stjele nøkler, endre filer |
| Kompromittert avhengighet | Ondsinnet pakkeversjon på PyPI |
| Uaktsomhet / feil | Feil OCR/KI, sletting, dobbel eksport, hemmelighet i Git |

Tillitsgrensene TB1–TB7 er beskrevet i `SECURITY.md` §2.

## 4. Risikoskala

**Sannsynlighet (S)** og **konsekvens (K)**: 1 = lav, 2 = middels, 3 = høy. **Risiko = S × K**: 1–2 lav, 3–4 middels, 6–9 høy. Prioritet følger risikoen etter at tiltakene i *Fase* er gjennomført.

## 5. Trusler

| ID | Trussel | STRIDE | Grense | S | K | Risiko | Tiltak | Fase | Restrisiko |
|---|---|---|---|---|---|---|---|---|---|
| T01 | **Ondsinnet PDF eller bilde** utnytter sårbarhet i parser (minnefeil, dekompresjonsbombe, uendelig løkke) | T, D, E | TB1 | 2 | 3 | 6 høy | Signaturkontroll; størrelses-, side- og pikselgrenser; isolert arbeidsprosess uten DB/nett; tidsavbrudd og minnegrense; aldri aktivt innhold; oppdaterte biblioteker (pip-audit); karantene | 03–04 | Middels: ukjente sårbarheter i MuPDF/Pillow/OpenCV kan fortsatt gi kodekjøring i arbeidsprosessen med brukerens rettigheter |
| T02 | **Prompt-injeksjon** via fakturatekst manipulerer KI-tolkning | T, E | TB2 | 3 | 2 | 6 høy | Ingen verktøy for KI; strengt Pydantic-skjema (`extra="forbid"` – implementert); proveniens settes av kode; deterministisk beløpskontroll; AI-001 grunnlagssjekk; menneskelig godkjenning; ren tekst-visning | 00 ✅ / 07 | Lav: feil forslag kan passere hvis brukeren godkjenner uten kontroll |
| T03 | **Uautorisert tilgang til dokumenter** (annen lokal bruker, skadevare) | I | TB5 | 2 | 3 | 6 høy | Per-bruker-katalog i `%LOCALAPPDATA%`; kontroll av NTFS-rettigheter ved oppstart; ingen data i `%TEMP%`/OneDrive; Defender | 01–03 | Middels: skadevare som samme bruker har samme tilgang |
| T04 | **Stjålet bærbar PC eller flyttbart medium** | I | – | 2 | 3 | 6 høy | BitLocker (kontroll og varsel); krypterte sikkerhetskopier; ingen eksport til ukryptert USB uten advarsel | 03, 12 | Lav med BitLocker + sterk pålogging; høy uten (Å-13) |
| T05 | **Eksponering av legitimasjon** (API-nøkler) i kode, logg, konfigurasjon eller Git | I | TB3, TB7 | 2 | 2 | 4 middels | Credential Manager; aldri i fil/logg; maskering; Gitleaks i CI; `.gitignore` (implementert) | 00 ✅ / 07 | Lav |
| T06 | **Databasekorrupsjon** (strømbrudd, diskfeil, feil migrasjon) | T, D | – | 2 | 3 | 6 høy | WAL + `synchronous=FULL`; `quick_check` ved oppstart; sikkerhetskopi før migrasjon; transaksjoner; gjenopprettingstest | 02, 12 | Lav |
| T07 | **Dobbel eksport / dobbel betaling** av samme faktura | T | TB4 | 2 | 3 | 6 høy | Delvis unik indeks på eksport; DUP-001/DUP-002; SHA-256-duplikat ved import; krasjsikker eksportrekkefølge; re-eksport krever begrunnelse | 03, 08, 10 | Lav: samme faktura mottatt både som papir og PDF med ulike hasher fanges av DUP-001, men krever korrekt uttrekk |
| T08 | **Utilsiktet sletting eller overskriving** av dokumenter | T, D | TB5 | 2 | 3 | 6 høy | Ingen overskrivingsfunksjon; skrivebeskyttede originaler; RESTRICT-fremmednøkler; sletting kun via retensjon med revisjon; sikkerhetskopi | 02–03, 12 | Lav |
| T09 | **Uautorisert nettverksoverføring** (sky-KI uten samtykke, telemetri i bibliotek, modellnedlasting, OneDrive-synk) | I | TB3 | 2 | 3 | 6 høy | Nett av som standard; sentral utgående kontroll; samtykke per leverandør; test med blokkert socket; frakoblet modus for modeller; datakatalog utenfor OneDrive; revisjon | 01, 05, 07 | Lav |
| T10 | **Sårbare eller ondsinnede avhengigheter** (forsyningskjede) | T, E | TB7 | 2 | 3 | 6 høy | Låsefil med hasher (implementert); 30 dagers karantene for nye versjoner; pip-audit i CI; minimalt antall avhengigheter; vurdering før nye pakker | 00 ✅ | Middels: kompromittert eldre versjon eller byggeverktøy (setuptools hentes ved bygg uten hash) |
| T11 | **Tap eller manipulasjon av revisjonsspor** | T, R | – | 1 | 3 | 3 middels | Kun-tilføyelse med triggere; hashkjede; anker i sikkerhetskopi og eksport; verifisering ved oppstart | 02, 12 | Middels: lokal administrator kan skrive om kjeden; oppdages mot eksterne ankre |
| T12 | **Kompromittert sikkerhetskopi** (tyveri, endring, ugjenopprettelig) | I, T, D | TB6 | 2 | 3 | 6 høy | Kryptering; manifest med SHA-256; regelmessig gjenopprettingstest; atskilt lagring | 12 | Lav–middels: avhenger av nøkkelforvaltning (Å-14) |
| T13 | **Fakturasvindel**: falsk faktura eller endret kontonummer | S, T | TB1 | 2 | 3 | 6 høy | Leverandørregister med verifiserte kontoer; BANK-001 blokkerer; ukjent leverandør flagges; menneskelig godkjenning; ingen automatisk betaling | 08 | Middels: sosial manipulering av godkjenner |
| T14 | **Formelinjeksjon** i Excel/CSV-eksport fra fakturatekst | T, E | TB4 | 2 | 2 | 4 middels | Tekst som starter med `= + - @` m.fl. skrives som ren tekst; beløp som tall; tester med fiendtlige verdier | 10 | Lav |
| T15 | **Sensitive data i logger, feilmeldinger eller krasjdumper** | I | – | 2 | 2 | 4 middels | Loggingspolicy; maskering; unntak fra parsere logges som type + kode; ingen stakkspor til bruker; tester | 01 | Lav |
| T16 | **Feil OCR/KI-tolkning** gir feil beløp eller kontering (ikke ondsinnet) | T | TB2 | 3 | 2 | 6 høy | Proveniens og konfidens; deterministiske kontroller; manuell gjennomgang; ingen eksport uten godkjenning; regresjonssett | 05–09 | Lav–middels |
| T17 | **HTML-/rik-tekst-injeksjon** i Qt-visning (QLabel tolker tekst som HTML) | T, I | TB2 | 2 | 2 | 4 middels | `Qt.PlainText` for alle dokumentdata; ingen automatisk åpning av lenker; GUI-test | 01, 09 | Lav |
| T18 | **Sti-traversering og ondsinnede filnavn** | T, E | TB1 | 2 | 2 | 4 middels | Filnavn brukes aldri i lagringssti; innholdsadressert lagring; rensing for visning og eksportnavn; tester med `..\`, `CON`, Unicode | 03 | Lav |
| T19 | **Ekte data eller hemmeligheter havner i repoet** | I | TB7 | 2 | 3 | 6 høy | `.gitignore` blokkerer dokumenter/data (implementert); kun syntetiske testdata; Gitleaks; kodegjennomgang | 00 ✅ | Lav |
| T20 | **Manipulert kjørbar fil / DLL-kapring** av installert program | T, E | TB7 | 1 | 3 | 3 middels | Onedir i beskyttet katalog (`Program Files`) eller per bruker med kontroll; kodesignering (Å-11); reproduserbart bygg med hasher | 13 | Middels inntil kodesignering |
| T21 | **Blanding av data mellom regnskapsenheter** (faktura koblet til annen enhets leverandør, eksport på tvers, duplikatkontroll som gir falske treff/misser) | T, I | – | 2 | 3 | 6 høy | `entity_id` på alle regnskapsdata; sammensatte fremmednøkler `(entity_id, id)`; enhetsavgrensede unike nøkler og duplikatnøkkel; obligatorisk `EntityScope` i repositorier; ENT-001 (kundens orgnr ≠ enhetens) | 00 (utformet) / 02 | Lav |
| T22 | **Svakheter i CI og forsyningskjede for bygg** (hemmelighetsskanning som hopper over commits, feil som skjules av skall, actions låst til flyttbare versjonsmerker, token lagret i arbeidskopi) | T, E, I | TB7 | 2 | 2 | 4 middels | Gitleaks som låst binærfil med kontrollsum og full historikk; bash `-eo pipefail` på Windows; `persist-credentials: false`; `contents: read` (implementert i sluttrevisjonen). SHA-låsing av actions og Dependabot: F01 | 00 ✅ / 01 | Lav–middels inntil SHA-låsing |
| T23 | **Push av prosjektfiler til feil repository** (observert: arbeidskopiens `origin` ble tilbakestilt til et annet repo ved omstart av utviklingsøkten) | I | TB7 | 2 | 2 | 4 middels | Kontroll av `git remote -v` før push (`AGENTS.md`); lokal `pre-push`-krok som bare tillater `RobertCygan/InvoiceFlowAI` og blokkerer direkte push til `main`; grenbeskyttelse for `main` anbefales (prosjekteier) | 00 ✅ (lokalt) | Lav–middels: kroken er ikke versjonskontrollert og må settes opp i hver arbeidskopi |

## 6. Prioritert tiltaksliste

| Prioritet | Tiltak | Trusler | Fase |
|---|---|---|---|
| 1 | Streng skjemavalidering og `Decimal` uten `float` | T02, T16 | 00 ✅ |
| 2 | Låste avhengigheter med hasher + pip-audit + Gitleaks i CI | T10, T05, T19 | 00 ✅ |
| 3 | Logging uten sensitivt innhold, maskering, ingen nettverk som standard | T15, T09 | 01 |
| 4 | Revisjonslogg med hashkjede; RESTRICT; WAL/FULL | T11, T06, T08 | 02 |
| 5 | Filvalidering, karantene, innholdsadressert lagring, SHA-256, duplikat ved import | T01, T18, T07, T08 | 03 |
| 6 | Isolert arbeidsprosess med tidsavbrudd og minnegrense | T01 | 04 |
| 7 | KI uten verktøy, eget utdataskjema, samtykke for sky | T02, T09 | 07 |
| 8 | Regnskapsregler inkl. BANK-001 og DUP-001 | T13, T07, T16 | 08 |
| 9 | Godkjenning bundet til hash; ren tekst-visning | T16, T17 | 09 |
| 10 | Idempotent eksport, formelinjeksjonsvern | T07, T14 | 10 |
| 11 | Kryptert sikkerhetskopi og gjenopprettingstest | T12, T04, T06 | 12 |
| 12 | Kodesignering og beskyttet installasjon | T20 | 13 |
| 13 | Regnskapsenhet som grense i database og repositorier | T21 | 02 |
| 14 | SHA-låste actions, Dependabot, grenbeskyttelse for `main` | T22, T23 | 01 |

## 7. Akseptert restrisiko (krever bekreftelse fra prosjekteier)

1. Skadevare som kjører som samme Windows-bruker kan lese data applikasjonen har tilgang til.
2. En lokal administrator kan manipulere database og revisjonslogg; manipulasjon oppdages bare mot eksterne ankre.
3. Ukjente sårbarheter i PDF-/bildebiblioteker kan gi kodekjøring i den isolerte arbeidsprosessen (begrenset, men ikke eliminert, uten OS-sandkasse).
4. Uten BitLocker er data på disk ukryptert (Å-13).
5. Menneskelig godkjenning er siste forsvarslinje mot overbevisende svindel.
6. Lisensrisiko ved PyMuPDF (AGPL-3.0) er fjernet: prosjekteier valgte pypdfium2 med permissive lisenser (D-11 = C, ADR-0023, G-09).

## 8. Vedlikehold

Trusselmodellen oppdateres når en fase innfører ny inndata, ny utgående forbindelse, ny lagring eller ny avhengighet med native kode. Endringer føres i `CHANGELOG.md`.

## 9. Kontrollstatus (etter sluttrevisjonen av Fase 00)

**Implementert** = finnes i kode/konfigurasjon og er testet. **Spesifisert** = beskrevet i dokumentasjonen med fase. **Planlagt** = nevnt i veikartet, ikke detaljert. **Ikke adressert** = kjent mangel uten tiltak ennå.

| Kontroll | Trusler | Status | Bevis / fase |
|---|---|---|---|
| Ukjente felt avvises i kontraktene | T02 | Implementert | `extra="forbid"`; tester i `tests/unit/domain/` |
| `float`/`bool` avvises for beløp; NaN/uendelig avvises | T16 | Implementert | `types.py`; tester |
| Entydig kanonisk tallform (grunnlag for innholdshash) | T16, T11 | Implementert | ADR-0025; `test_contract_types.py` |
| Strenge datoer, heltall og boolske verdier | T02, T16 | Implementert | ADR-0025; tester |
| Tekst uten kontroll-/formattegn; lengde- og antallsgrenser | T02, T17, T01 | Implementert | `types.py`; tester |
| Arkitekturvakt for domenelaget | – | Implementert | `tests/architecture/` |
| `.gitignore` blokkerer data, dokumenter og nøkler | T19 | Implementert | `.gitignore` |
| Låste avhengigheter med hasher; pip-audit i CI | T10 | Implementert | `requirements/dev.lock.txt`; CI |
| Gitleaks på full historikk i CI | T05, T19 | Implementert | `.github/workflows/ci.yml` (sluttrevisjonen) |
| CI: minst privilegium, korrekt feilstatus | T22 | Implementert | `ci.yml` |
| Lokal push-sperre mot feil repo | T23 | Implementert (lokalt, ikke versjonskontrollert) | `.git/hooks/pre-push` i arbeidskopien |
| Logging uten sensitivt innhold; maskering | T15 | Spesifisert | `SECURITY.md` §7; F01 |
| Ingen nettverk som standard; test med blokkert socket | T09 | Spesifisert | `SECURITY.md` §3; F01 |
| Regnskapsenhet som grense | T21 | Spesifisert | ADR-0022; F02 |
| Revisjonslogg med hashkjede og triggere | T11 | Spesifisert | `DATA_MODEL.md` §3.6; F02 |
| WAL + `synchronous=FULL`; transaksjonsgrenser | T06, T07 | Spesifisert | `DATA_MODEL.md` §3.7–3.8; F02 |
| Filvalidering, karantene, innholdsadressert lagring | T01, T08, T18 | Spesifisert | `SECURITY.md` §8; F03 |
| Isolert arbeidsprosess med tidsavbrudd og minnegrense | T01 | Spesifisert | ADR-0010; F04 |
| KI uten verktøy; eget utdataskjema; samtykke for sky | T02, T09 | Spesifisert | `SECURITY.md` §9; F07 |
| Regnskapsregler inkl. BANK-001, DUP-001, ENT-001 | T13, T07, T21 | Spesifisert | `DATA_MODEL.md` §7; F08 |
| Godkjenning bundet til innholdshash | T16 | Spesifisert | ADR-0013; F09 |
| Idempotent eksport; formelinjeksjonsvern | T07, T14 | Implementert (F10) | `DATA_MODEL.md` §3.16; ADR-0036 |
| Kryptert sikkerhetskopi og gjenopprettingstest | T12, T04 | Implementert (F12) | ADR-0037; `SECURITY.md` §26 |
| Kontroll av NTFS-rettigheter og BitLocker-status | T03, T04 | Spesifisert | `SECURITY.md` §4; F03 |
| Hemmeligheter i Credential Manager | T05 | Spesifisert | ADR-0009; F07 |
| SHA-låste actions, Dependabot | T22 | Planlagt | F01 |
| Grenbeskyttelse for `main` på GitHub | T23 | Ikke adressert | Krever handling fra prosjekteier |
| Kodesignering | T20 | Planlagt | F13 (Å-11) |
| OS-sandkasse (f.eks. AppContainer) for arbeidsprosessen | T01 | Ikke adressert | Vurderes etter F04 |

## 10. F02-oppdatering og avgrenset restrisiko

| Kontroll / trussel | Faktisk F02-status | Bevis / gjenstår |
|---|---|---|
| T06 migrasjonsfeil | Implementert: backup-API, transaksjons-DDL og auditkontroll før commit | `test_migrations.py`; også gyldig SQL som skader kjeden rulles tilbake |
| T11 auditmanipulasjon | Implementert: append-only-triggere, global hashkjede og oppstartskontroll | `test_audit_trail.py`; sletting fra slutten/full omskriving krever eksternt anker i F12 |
| T21 enhetsblanding | Implementert for faktura og revisjoner | EntityScope og sammensatte FK; dokumenter/leverandører/eksport kommer i senere faser |
| T16 desimalendring | Rettet: kontekstuavhengig normalisering og begrenset eksponentutvidelse | Unit- og integrasjonsregresjoner |
| T06 fremmed database | Kjent revisjon alene er ikke nok; nødvendige F02-tabeller kreves før skrivemotor | Regresjon med fremmed database og `0001_initial` |
| T15 sensitive logger | F01-maskering videreført; DB-feil logges med kode | GUI-/oppstartstester; actor er teknisk ID, ikke navn |
| T12 migrasjonskopi | Lokal, konsistent og verifisert, men ukryptert | Samme konfidensialitetsbehov som database; full løsning F12 |
| T22 forsyningskjede | SHA-låste actions og Dependabot implementert i F01; F02 bruker samme CI | Grenbeskyttelse gjenstår som eierhandling |

F02-opprinnelig kode ble kontrollert i Windows CI på `8daa6e2`. Videre revisjon fant at kjedekontroll etter commit ikke kunne rulle tilbake en semantisk ødeleggende migrasjon; kontrollen er flyttet inn i transaksjonen. Headerprojeksjonen kontrolleres også mot snapshotet ved lesing. Dette beskytter mot avvik uten å påstå beskyttelse mot en fullstendig, sammenhengende omskriving av databasen.

## Tillegg – fremtidig dokumentarkiv

Utvidet dokumentarkiv introduserer trusler knyttet til utilsiktet tilgang på tvers av regnskapsenheter, uautorisert sletting, endring av originaler, søkelekkasjer og ufullstendig arkiveksport. Kontrollene er **planlagte, ikke implementerte**. Se [`DOCUMENT_ARCHIVE_SCOPE.md`](DOCUMENT_ARCHIVE_SCOPE.md).

## 11. F03-oppdatering

| Trussel | Faktisk F03-status | Bevis / gjenstår |
|---|---|---|
| T01 ondsinnet fil | Redusert: ingen parsing i F03, bare signatur/størrelse; mistenkelige filer i karantene | `test_store.py`, `test_documents.py`; parserisolasjon i F04 |
| T03 uautorisert tilgang | Uendret: filer er ukrypterte; ingen NTFS-ACL fra programmet | Å-13 (BitLocker), F12 |
| T06 migrasjonsfeil | `0002` bygger om `audit_events` med kontroll av antall og siste hash; avbrytes ved F02-fakturaer | `test_migrations.py` |
| T11 revisjonsmanipulasjon | Dokumenthendelser i samme kjede; ingen filnavn i detaljer | `test_document_model.py`, `test_documents.py` |
| T21 enhetsblanding | Implementert for dokumenter, koblinger og faktura → dokument | Tverrenhetstester i `test_documents.py` |
| Krasj mellom fil og database | Gjenoppretting ved oppstart; ingen sletting av originaler | Krasjpunkt-tester i `test_documents.py` |
| Tjenestenekt ved låst fil (antivirus/indeksering) | Nye forsøk i inntil ca. 1,5 s; én feilet fil stopper ikke resten; låst fil hindrer ikke oppstart | `test_store.py`, `test_documents.py`, `test_documents_page.py` |
| Original erstattet av symbolsk lenke i arkivet | Integritetskontrollen avviser lenker i hele stien; krever uansett skrivetilgang til arkivet, så restrisikoen er den samme som for andre filendringer med brukerens rettigheter | `test_store.py` (lenke til identisk fil, hengende lenke, lenket mappe) |
| Kappløp mellom samtidige importer | Prosesslås rundt publisering; én instans per datakatalog | Samtidighetstest og stresskjøring på Windows (se `PHASE_03_REPORT.md` §11) |

## 12. F04-oppdatering (isolert behandling)

Tiltak for T01 (ondsinnet fil) og T02 (ressursuttømming) er implementert: parsing bare i en arbeidsprosess per dokument med Job Object (2 GB, ingen underprosesser, drepes med hovedprosessen), tidsavbrudd, side- og pikselgrenser før rasterisering, Pydantic-validert rapport som bytes, kontroll av hver utdatafil og av originalens hash før og etter. Fiendtlig korpus (bombe, mange sider, dyp nesting, syklisk sidetre, skadet xref, avkortet fil, 0 sider, kryptert, JavaScript, `Launch`, innebygd fil, polyglot, enorm side, ødelagt JPEG, TIFF med 101 sider) kjøres gjennom den ekte arbeidsprosessen i testene.

| ID | Trussel | Status etter F04 | Restrisiko |
|---|---|---|---|
| T30 | **Kodekjøring via feil i PDFium eller Pillow** | Rammer bare arbeidsprosessen; den kan ikke starte prosesser, har minnegrense og dør etter dokumentet. Den kjører likevel som samme Windows-bruker og kan lese det brukeren kan lese. | **Middels** – AppContainer/begrenset token vurderes før porten for ekte data; raske sikkerhetsoppdateringer etter ADR-0024 |
| T31 | **Manipulert rapport fra arbeidsprosessen** (falske sider, stier, lenker, felter) | Bare bytes leses; streng Pydantic-validering; faste filnavn; lenker og ukjente filer avvises; PNG-mål og tekstlag kontrolleres | Lav |
| T32 | **Halv tilstand etter krasj** (jobb «vellykket» uten filer, filer uten rad) | Sider, filer og sluttstatus i én transaksjon; utløsere tillater bare tillegg til en kjørende jobb; gjenoppretting markerer avbrutte jobber og flytter filer uten rad (sletter ingenting) | Lav |
| T33 | **Ubegrenset diskbruk fra avledede filer** | 1 GB per dokument; ingen opprydding ennå (retensjon ikke avgjort) | Lav–middels |

## 13. F15-oppdatering (EHF/XML)

XML er en ny filtype fra ukjente avsendere. Tiltakene er i `SECURITY.md` §21.

| ID | Trussel | Status etter F15 | Restrisiko |
|---|---|---|---|
| T34 | **XXE og entitetsangrep** (lesing av lokale filer, nettverkskall, «billion laughs») | `defusedxml` med DTD, entiteter og eksterne referanser forbudt; bare i arbeidsprosessen med Job Object | Lav |
| T35 | **Ressursuttømming via XML** (dyp nesting, millioner av elementer, enorme base64-vedlegg) | Grenser for størrelse, dybde, elementer, linjer og vedlegg under strømmet parsing; tidsavbrudd og minnegrense fra F04 | Lav |
| T36 | **Falske eller manipulerte fakturadata** (feil sum, feil mottaker, gjentatt faktura, forkledd vedlegg) | Regnekontroller etter EN 16931, mottaker mot regnskapsenheten, mulig duplikat (leverandør + nummer), vedlegg gjennom F03-importen; alt flagges, ingenting rettes stille; fakturaen er bare et utkast (ingen bokføring) | Middels – full Schematron-validering mangler; menneskelig gjennomgang i F09 kreves |
| T37 | **Instruksjoner i fakturatekst** (notatfelt, linjebeskrivelser, vedlegg) | Teksten lagres som data og vises aldri som kommando; ingen KI i F15 | Lav (vurderes på nytt i F07) |
| T38 | **Halvferdig migrasjon `0004`** med FK-er av | Én transaksjon, radtelling og `foreign_key_check` før commit, sikkerhetskopi før (ADR-0032) | Lav |

## 14. F08a-oppdatering (validering og leverandørregister)

| ID | Trussel | Status etter F08a | Restrisiko |
|---|---|---|---|
| T39 | **Falsk faktura eller endret kontonummer** (betalingssvindel) | Ny konto er alltid ikke bekreftet og gir feil (BANK-001). Bekreftelse krever en bevisst handling med advarsel om uavhengig kontroll og revisjonsføres. Sperret konto gir feil. | Middels. En bruker kan bekrefte uten å kontrollere. Blokkering av godkjenning kommer i F09. Ingen oppslag mot bank eller Enhetsregisteret. |
| T40 | **Manipulering av registeret** (bytte kontonummer på en bekreftet konto direkte i databasen) | Utløsere hindrer endring av kontonummer og leverandør og tilbakeføring til ikke bekreftet. Hver statusendring står i revisjonskjeden. | Lav–middels. Den som kan skrive i databasen, kan legge til en ny konto og sette den til bekreftet med falsk tid. Det oppdages bare ved at hendelsen mangler i kjeden. |
| T41 | **Dobbel betaling** (samme faktura importert som ny fil) | DUP-001 (samme leverandør, type og normalisert nummer) og DUP-002 (samme beløp og dato) innen enheten | Lav for norske leverandører. Utenlandske leverandører uten organisasjonsnummer har ingen duplikatkontroll ennå. |
| T42 | **Støy i registeret** fra feiltolkede verdier (OCR i F05/F06) | Bare gyldige kontrollsiffer registreres. Leverandørnavnet låses fra første faktura. | Lav |

## 15. F08b-oppdatering (referansedata og kontering)

| ID | Trussel | Status etter F08b | Restrisiko |
|---|---|---|---|
| T43 | **Manipulert CSV** (formler, enorme filer, kontrolltegn, feil koding) | Streng parsing med grenser; hele filen avvises; formelceller avvises i navnefelt og i databasen | Lav |
| T44 | **Feil kontering fra feil referansedata** (feil sats eller konto i importen) | Import revisjonsføres med hash; forrige import beholdes; reglene kontrollerer mot gjeldende data; forslaget er bare et forslag til gjennomgang (F09) | Middels – kvaliteten på ERP-eksporten er ikke prøvd (Å-18) |
| T45 | **Stille overskriving av manuell kontering** | Forslag hoppes over når noen verdi har proveniens `manual` | Lav |

## 16. F09-oppdatering (godkjenning)

| ID | Trussel | Status etter F09 | Restrisiko |
|---|---|---|---|
| T46 | **Endring etter godkjenning** (beløp eller konto byttes etter at fakturaen er godkjent) | Hashbinding; ny revisjon opphever godkjenningen; utløser hindrer endring av godkjent innhold | Lav |
| T47 | **Godkjenning med foreldet kontroll** | Ny kontroll i godkjenningstransaksjonen; sammenlign-og-sett på revisjon | Lav |
| T48 | **Overstyring som omgår svindelkontroll** | BANK-001 og DUP-001 kan ikke overstyres (tjeneste og CHECK); andre overstyringer krever begrunnelse og gjelder bare én revisjon | Lav–middels |
| T49 | **Én person retter og godkjenner** | Alt revisjonsføres med teknisk aktør; ingen rolledeling ennå | Middels – Å-10 |

## 17. F10-oppdatering (eksport)

| ID | Trussel | Status etter F10 | Restrisiko |
|---|---|---|---|
| T07 | **Dobbel eksport / dobbel betaling** | Delvis unik indeks og utløser på tvers av formater; ny eksport bare med begrunnelse; krasjsikker rekkefølge | Lav – en person kan fortsatt importere samme fil to ganger i regnskapssystemet |
| T14 | **Formelinjeksjon** | Apostrof i CSV, tekstceller med apostrofmerke i Excel, overskrifter kontrollert | Lav |
| T50 | **Halv eller falsk eksportfil etter krasj** | Midlertidig navn, `fsync` og navnebytte; åpen batch fullføres bare når den endelige filen finnes, ellers mislykkes den | Lav |
| T51 | **Endret eksportfil** (beløp eller konto byttes i filen før import) | SHA-256 i databasen og revisjonskjeden; kopi gis ikke ut ved avvik; skrivebeskyttet fil | Middels – filen kan endres etter at den er kopiert ut |
| T52 | **Eksportfil på avveie** (ukryptert fil med leverandør- og kontodata) | Fast eksportmappe i brukerens datakatalog; kopi bare der personen velger | Middels – BitLocker (Å-13); kryptert sikkerhetskopi kommer i F12 |
| T53 | **Feil fortegn eller format i regnskapssystemet** (kreditnota bokført som kostnad) | Kreditnota med negative beløp og typekolonne; kontrollark med summer | Middels – formatet er ikke prøvd mot et ERP (Å-02, Å-21, Å-22) |

## 18. F12-oppdatering (sikkerhetskopi)

| ID | Trussel | Status etter F12 | Restrisiko |
|---|---|---|---|
| T12 | **Kompromittert sikkerhetskopi** (tyveri, endring, ugjenopprettelig) | AES-256-GCM med scrypt; autentiserte biter og hode; manifest og anker; full kontroll ved gjenoppretting; kontroll uten gjenoppretting | Lav–middels – avhenger av passordfrasen og atskilt lagring (Å-14) |
| T04 | **Stjålet bærbar PC eller flyttbart medium** | Sikkerhetskopien er kryptert uavhengig av medium | Middels uten BitLocker for selve datakatalogen (Å-13) |
| T11 | **Avkortet eller omskrevet revisjonskjede** | Ankeret i hver sikkerhetskopi og i `backup.created`; kjeden kontrolleres før hver sikkerhetskopi | Middels – krever at noen sammenligner med en ekstern sikkerhetskopi |
| T54 | **Glemt passordfrase** | Advarsel på siden; prosedyre med passordhvelv hos to personer | Middels – sikkerhetskopien er da tapt |
| T55 | **Ukryptert databasekopi etterlatt** etter krasj | Privat arbeidsmappe; slettes etter bruk og ved oppstart | Lav |
| T56 | **Fiendtlig arkiv** (stitraversering, lenker) ved gjenoppretting | Krever riktig passordfrase; strenge stier, bare vanlige filer, tom målmappe utenfor datakatalogen | Lav |
| T57 | **Gjenoppretting over gjeldende data** | Ikke mulig fra programmet; bare til tom mappe, deretter manuelt bytte etter prosedyren | Lav |
| T58 | **Ingen sikkerhetskopi tatt** | Manuell sikkerhetskopi med register og prosedyre; ingen tidsplan | Middels – Å-14 |

## 19. F11a-oppdatering (skannemappe og bunker)

| ID | Trussel | Status etter F11a | Restrisiko |
|---|---|---|---|
| T59 | **Halvskrevet fil leses inn** mens skanneren skriver | Stabilitetskontroll ved to titter og alder; signatur og hash ved import | Lav |
| T60 | **Ondsinnet fil lagt i skannemappen** av en annen prosess eller person | Samme import og isolasjon som manuelle filer; lenker ignoreres | Lav |
| T61 | **Feil oppdeling** (skilleark ikke gjenkjent, side med lite innhold tatt for blank) | Vises på siden «Skanning»; originalen er hel; tekstlag hindrer «blank». F11b: målinger per side og merking av sider nær en grense; prøveprosedyre i `SCANNER_SETUP.md` §4 | Middels – grenseverdiene er ikke prøvd mot ekte skann (Brother ADS-4700W, G-22) |
| T62 | **Fil forsvinner fra skannemappen** | Flyttes bare etter registrert import eller avvisning, til `importert`/`avvist`; teknisk feil lar filen ligge | Lav |
| T63 | **Skannemappen deles på nettverket** for «skann til nettverksmappe», og andre på nettet kan legge filer i den eller lese originaler | Prosedyren bruker produsentens program på PC-en og forbyr deling (ADR-0039); filer derfra går gjennom vanlig import | Lav, forutsatt at prosedyren følges |

## 20. F05-oppdatering (OCR)

| ID | Trussel | Status etter F05 | Restrisiko |
|---|---|---|---|
| T64 | **Sårbarhet i Tesseract** utløses av et fiendtlig bilde | Tesseract ser bare PNG-er programmet selv har laget; kjører i arbeidsprosessens grenser (minne, tid, Job Object); ingen nettverk eller hemmeligheter | Lav–middels |
| T65 | **Falsk `tesseract.exe`** plantet i en mappe brukeren kan skrive til | Bare faste steder (`%ProgramFiles%`, ved siden av programmet); `PATH` søkes ikke på Windows | Lav |
| T66 | **Feil gjenkjent tekst** fører til feil beløp eller kontonummer | Sikkerhet per ord lagres; F06 henter felt med proveniens; validering (F08) og menneskelig godkjenning (F09) før eksport | Middels – avhenger av skannekvalitet (Å-01) |
| T67 | **Dokumenttekst lekker** gjennom logg, revisjonskjede eller midlertidige filer | Tekst bare i avledede filer i arkivet; revisjonen har tillatelsesliste; ingen midlertidige filer med bildet | Lav |

## 21. F06-oppdatering (feltuttrekk)

| ID | Trussel | Status etter F06 | Restrisiko |
|---|---|---|---|
| T68 | **Fiendtlig tekst** i en faktura (for eksempel en falsk ledetekst «Kontonummer» med en annen konto) | Verdier tas bare ved ledetekst og vises med bevis (side, boks, råtekst); nye kontonumre er ubekreftede til en bruker bekrefter dem (F08a); godkjenning kreves før eksport | Middels – en dyktig forfalskning ser ut som en ekte faktura; dekkes av kontokontroll og godkjenning |
| T69 | **Tjenestenekt med regulære uttrykk** (ReDoS) | Lineære mønstre, én linje om gangen, begrenset tekst per side | Lav |
| T70 | **Feil del av en bunke** (skilleark ikke gjenkjent) gir to fakturaer i ett utkast | Delene vises på «Skanning»; summer som ikke stemmer gir funn; menneskelig gjennomgang | Middels – avhenger av ekte skann (Å-01) |

## Tillegg – ERP-integrasjoner via API (planlagt, ADR-0030)

ADR-0030 er godkjent (D-26, G-08). Kontrollene er **planlagte, ikke implementerte**; de gjelder fra F14b/F14c.

| ID | Trussel | STRIDE | Grense | S | K | Risiko | Tiltak | Fase | Restrisiko |
|---|---|---|---|---|---|---|---|---|---|
| T24 | **Lekket eller misbrukt ERP-nøkkel** gir tredjepart tilgang til kundens regnskap | I, E | TB3, TB7 | 2 | 3 | 6 høy | Nøkkel per enhet i Credential Manager; minste nødvendige tilgang i ERP; maskering; Gitleaks; mulighet for å trekke tilbake samtykke og slette nøkkel | 14b/14c | Middels: skadevare som samme bruker kan lese Credential Manager |
| T25 | **Innsending til feil ERP-klient eller -selskap** (blanding av regnskapsenheter) | T, I | TB3 | 2 | 3 | 6 høy | Nøkkel, tilordning og samtykke per `entity_id`; kontroll av klient-/selskaps-ID mot enheten før innsending; ENT-regler | 14b/14c | Lav |
| T26 | **Dobbel innsending** etter tidsavbrudd eller krasj | T | TB3 | 2 | 3 | 6 høy | Stabil ekstern referanse; tilstand `unknown` krever oppslag før nytt forsøk; delvis unik indeks | 14b/14c | Lav |
| T27 | **Avlytting eller feil mottaker** (proxy, DNS, omdirigering) | I, S | TB3 | 1 | 3 | 3 middels | Bare HTTPS med sertifikatkontroll; tillatte vertsnavn; ingen omdirigering | 14b/14c | Lav |
| T28 | **Ondsinnet eller uventet svar fra ERP** (store svar, injeksjon i visning) | T, D | TB3 | 1 | 2 | 2 lav | Pydantic-validering, størrelsesgrense, tidsavbrudd; `Qt.PlainText` | 14b/14c | Lav |
| T29 | **Utilsiktet bokføring** fordi målet bokfører ved import | T | TB4 | 2 | 3 | 6 høy | Kun ikke-bokført bilag/bilagsmottak; verifiseres i testmiljø før aktivering; ellers fil | 14b/14c | Lav etter verifisering |
