# Dokumentarkiv – omfang og arkitekturtillegg (Fase 00)

| Felt | Verdi |
|---|---|
| Status | Prosjekteiers omfangsbeslutning, 2026-10-20; detaljkrav skal valideres i senere faser |
| Formål | InvoiceFlow AI skal kunne utvikles til et lokalt, søkbart arkiv for regnskapsrelaterte dokumenter |
| Prioritet | Faktura og kreditnota først; øvrige dokumenttyper innføres trinnvis |
| Implementering i Fase 00 | Kun krav og arkitektur; ingen arkivfunksjoner implementert |

## 1. Omfang

Systemet skal på sikt kunne arkivere **inngående fakturaer, kreditnotaer, kvitteringer, kontrakter/avtaler, betalingsbekreftelser og relevant leverandørkorrespondanse**. Arkivet er knyttet til regnskapsarbeid, ikke et generelt kommunalt sak-/arkivsystem. Dette er et mål for videreutvikling, ikke en påstand om at alle dokumenttypene støttes i første versjon.

Prioritert leveranse:
1. Faktura og kreditnota: import, originalbevaring, metadata, OCR, validering, kontroll, godkjenning, søk og eksport.
2. Tilknyttede bilag: kvitteringer, betalingsbekreftelser og leverandørkorrespondanse.
3. Kontrakter/avtaler og flere dokumentrelasjoner, med eget arbeidsflytbehov etter behovsanalyse.

## 2. Felles dokumentmodell

Arkitekturen skal skille **dokument** fra **faktura**. Et dokument kan ha en dokumenttype, én eller flere versjoner, originalfil, filhash, kilde, importtidspunkt, regnskapsenhet (entity_id), tilgangsmetadata, lagringsstatus og relasjoner til andre dokumenter eller regnskapsobjekter. En faktura er en domenespesifikk representasjon knyttet til et dokument; andre dokumenttyper skal ikke tvinges inn i CanonicalInvoice.

Krav:
- Originalfiler bevares uendret, identifiseres med SHA-256 og holdes adskilt fra avledede filer.
- Søk på relevante metadata (dato, dokumenttype, leverandør/motpart, fakturanummer, beløp, status) og senere fulltekst der det er forsvarlig.
- Dokumentkoblinger (faktura ↔ kontrakt ↔ kvittering ↔ korrespondanse) uten å duplisere originalfilen.
- Sporbarhet for import, endring av metadata, visning der relevant, koblinger, godkjenning, eksport og sletting.
- Streng isolasjon mellom regnskapsenheter; ingen utilsiktet krysskobling eller søk på tvers.
- Sikre forhåndsvisninger og eksport; dokumentinnhold behandles alltid som ubetrodd.
- Kryptert sikkerhetskopi, integritetskontroll og dokumentert gjenoppretting før produksjonsbruk.
- Tilgangskontroll og rollemodell må avklares før eventuell flerbrukerdrift.
- Retensjon, sperring for sletting, kassasjon og lovpålagt dokumentasjon må være konfigurerbare og revisjonssporbare; **ingen automatisk sletting** før juridiske/organisatoriske krav er godkjent.
- Arkivet må kunne eksporteres i et dokumentert, lesbart format med metadata, slik at virksomheten ikke låses til applikasjonen.

## 3. Juridiske og organisatoriske avklaringer

Før produksjonsbruk skal regnskapsansvarlig og relevant fag-/personvernkompetanse verifisere norske krav til oppbevaring, tilgjengelighet, sikkerhet, personvern og sletting, herunder bokføringsregelverk og eventuelle kommunale arkivplikter. Ikke anta at et lokalt dokumentarkiv alene oppfyller krav til godkjent kommunal arkivløsning. For personopplysninger: dokumenter behandlingsgrunnlag, tilgang, dataminimering, eventuell DPIA og databehandlerforhold når relevant.

## 4. Konsekvens for faser

- **F01:** Bevar arkitekturgrenser og modulnavn som muliggjør dokumenttyper; bygg bare Windows-applikasjonsskall. Ingen full arkiv-UI eller dokumentlagring nå.
- **F02:** Ta høyde for generiske dokumentmetadata, regnskapsenhet og relasjoner i databaseskjemaet; implementer kun avtalt minimum.
- **F03–F06:** Sikker import, dokumentlager, parsing/OCR og søkeindeks der det inngår i godkjent fase.
- **F09–F10:** Godkjenning og eksport for fakturaer; ikke anta at samme arbeidsflyt gjelder kontrakter.
- **F12:** Backup, gjenoppretting og arkivintegritet.
- **Senere fase (egen beslutning):** Utvidet dokumentarkiv, fulltekstsøk, retensjon/kassasjon, arkiveksport og eventuelle formelle integrasjoner.

## 5. Akseptansekriterier for arkitektur

1. Datamodellen kan representere en kontrakt eller kvittering uten å fylle ut fakturafelter.
2. Flere dokumenter kan knyttes til samme faktura uten å endre originalfilene.
3. Søking og koblinger er avgrenset til riktig regnskapsenhet.
4. Dokumenter kan gjenfinnes med originalfil og verifiserbar integritet.
5. Ingen automatisk sletting før oppbevaringsregler er godkjent.
6. Fase 01 introduserer ikke arkivfunksjonalitet som ikke er bestilt.

## 6. Endringskontroll

Dette dokumentet er et tillegg til Fase 00 og må innarbeides konsistent i MASTER_SPECIFICATION, ARCHITECTURE, DATA_MODEL, DEVELOPMENT_ROADMAP, SECURITY, THREAT_MODEL og Fase 01-prompten ved neste dokumentrevisjon. Ved motstrid må dette flagges før godkjenning; eksisterende kode skal ikke omskrives uten dokumentert behov.
