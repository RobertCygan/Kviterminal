# Fase 08b – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

24. oktober 2026 ba prosjekteier om F08b og deretter F09 (G-13). Utvikleren skrev promptet `docs/prompts/PHASE_08B_REFERENCE_DATA.md` v1.0 (D-32), og innholdet er ikke gjennomgått av prosjekteier eller regnskapsansvarlig.

Å-18 er fortsatt åpen. Ingen ekte eksport fra Tripletex eller et annet ERP-system er prøvd; alt er bygget og testet med syntetiske filer. Autorisasjonen gjelder implementering, ikke aksept av resultatet, restrisiko (D-19) eller ekte data. F09 er ikke påbegynt.

**GOAL:** regnskapsenheten får sin egen kontoplan, MVA-koder med gyldighet og dimensjoner fra fil. Leverandører kan få standardkontering. Hver faktura får et konteringsforslag som et menneske kan kontrollere, og reglene MVA-002 og ACC-001–003 kontrollerer det.

## 2. Leveranse

- **Import** (`application/reference/csv_import.py`):
  - eget CSV-format (UTF-8, semikolon, norske kolonnenavn);
  - streng validering av hele filen før lagring;
  - feilmeldinger med linje og kolonne, aldri innhold;
  - grenser 5 MB og 20 000 rader;
  - formelceller og kontrolltegn avvises.
- **Migrasjon `0006_reference`:** øyeblikksbilder i `reference_imports`, `chart_of_accounts`, `vat_codes` og `dimension_values`, og leverandørstandard i `supplier_defaults`. Alle tabellene er kun tilføyelse (ADR-0034, `DATA_MODEL.md` §3.14).
- **Konteringsforslag** (`application/reference/posting.py`):
  - én linje per MVA-sats;
  - konto og dimensjoner fra leverandørstandarden;
  - MVA-koden er standardkoden når satsen passer, ellers den eneste gyldige inngående koden med satsen;
  - tvetydige verdier står tomme.
- **`ReferenceService`:**
  - forslaget legges inn ved registrering av EHF;
  - nytt forslag på forespørsel og etter at standardkontering er satt;
  - manuelle verdier overskrives aldri.
- **Regelsett 1.1:** MVA-002 og ACC-001–003. Ett infofunn når referansedataene mangler. ACC-003 avviser utgående MVA-koder på innkommende fakturaer.
- **Grensesnitt:**
  - «Innstillinger» har delen «Referansedata», med import og status for hver type;
  - «Leverandører» har «Sett standardkontering …» med lister fra enhetens data;
  - innboksen har «Foreslå kontering på nytt», og konteringen vises i kontrollvinduet.
- **Revisjon:** `reference.imported` (type, antall, hash) og `supplier.defaults_set`.
- **Selvtest**, også `.exe`: import av syntetisk kontoplan og MVA-koder, verifisert konto og standardkontering gir en faktura uten funn.
- **Syntetiske eksempelfiler:** `bootstrap/synthetic_reference.py`. CSV-filer i repoet blokkeres av `.gitignore`.

## 3. Valg og avvik

| Punkt | Valg | Begrunnelse |
|---|---|---|
| Tabellskissen i §3.3 (oppdatering på stedet) | Øyeblikksbilder som bare kan legges til | Historikken bevares. Tidligere kontroller kan forklares med dataene som gjaldt da. |
| Importformat | Eget enkelt CSV-format | Å-18 er ikke besvart. En adapter for ERP-format legges til når eksempelfiler finnes. |
| Forslag ved registrering | Inngår i revisjon 1 | Én revisjon færre. Proveniensen `calculated` skiller forslaget fra uttrukne verdier. |
| Forslag per MVA-sats, ikke per linje | Per sats | Enklere å kontrollere. Regnskapsansvarlig bør avgjøre om linjenivå trengs. |
| Importfunn fra F15 | Vises for alle revisjoner | Funnene gjelder kildedokumentet og skal ikke forsvinne når kontering gir en ny revisjon. |

## 4. Testresultater

Lokalt (Linux, Python 3.13, gren `claude/phase08b-reference-data`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen) | 1289 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | 94 % |
| Dekning parser, forslag og modell | 100 % (tjenesten 92 %) |
| Ruff lint og format, Bandit | Ingen funn |
| pip-audit (`--require-hashes`) | Ingen kjente sårbarheter |
| Gitleaks (lokalt, 8.24.3) | Ingen funn |

Windows-CI og `.exe`-selvtesten: se PR-en.

**Ikke prøvd:**

- ekte eksportfiler fra Tripletex, Xledger eller Unit4 (Å-18);
- om forslaget passer regnskapsansvarligs praksis: per sats eller per linje, og valg av MVA-kode;
- store kontoplaner nær grensen på 20 000 rader;
- manuell Windows 11-test.

## 5. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| CSV-import og øyeblikksbilder | ✅ | ✅ | ✅ | se PR | – | – |
| Leverandørstandard og forslag | ✅ | ✅ | ✅ | se PR | – | – |
| Regler MVA-002, ACC-001–003 | ✅ | ✅ | ✅ | se PR | – | – |
| Referansedata og standardkontering i GUI | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| Adapter for ERP-format | Venter på Å-18 | – | – | – | – | – |

## 6. Gjenstående risiko og beslutninger

- **Å-18:** eksportfiler fra UDIs Tripletex (kontoplan, MVA-koder, avdelinger og prosjekter).
- **D-32:** regnskapsansvarlig bør bekrefte forslagsregelen og alvorlighetene.
- **T44:** feil i importerte data gir feil forslag. Hver import revisjonsføres, og forslaget er bare et forslag. Godkjenning kommer i F09.

## 7. Manuell Windows 11-aksept

1. Lagre de syntetiske filene fra `bootstrap/synthetic_reference.py` som CSV, og importer dem under «Innstillinger». Statusen viser antall rader og dato.
2. Importer en fil med feil, for eksempel datoen `31.02.2026`. Forvent en norsk melding med linje og kolonne, og at statusen er uendret.
3. Behandle en syntetisk EHF. «Vis kontroll» viser «Linje 1: konto mangler · MVA-kode 1 · …».
4. Under «Leverandører»: bekreft kontoen og sett standardkontering (konto 6300, MVA-kode 1). Innboksen viser «OK».

## 8. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- prosjekteiers gjennomgang og godkjenning av sammenslåing;
- Å-18 og bekreftelse fra regnskapsansvarlig.

Deretter F09 (gjennomgang og godkjenning) etter G-13.
