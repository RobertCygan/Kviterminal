# Fase 11a – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

Skannermodellen (Å-01) er ikke kjent. Prosjekteier ba derfor om delen av F11 som ikke krever skanner (G-21, «zrób najpierw część bez sprzętu»).

Utvikleren skrev promptet `docs/prompts/PHASE_11A_SCAN_BATCHES.md` v1.0 (D-36), og innholdet er ikke gjennomgått. F11b (WIA, profiler, ADF og dupleks) gjenstår.

**GOAL:** en bunke fakturaer kan skannes til én fil med hvilken som helst skanner som lagrer PDF eller TIFF i en mappe. Programmet leser filen inn selv, gjenkjenner blanke sider og skilleark, og viser hvordan bunken deles i fakturaer. Originalen er alltid hel.

## 2. Leveranse

- **Målinger i arbeidsprosessen** (ADR-0038):
  - andel mørke piksler (‰) innenfor en marg på 5 % og i det sentrale området, på en gråtonekopi på høyst 512 piksler;
  - lagres i `document_pages` (migrasjon `0010_page_metrics`);
  - motorversjonen får tillegget `+side1`, så PDF- og bildedokumenter analyseres på nytt én gang.
- **Klassifisering og oppdeling** (rene funksjoner):
  - skilleark, blank side og innhold;
  - deler mellom skilleark, uten blanke sider i kantene;
  - beregnes ved visning og lagres ikke.
- **Skilleark:** A4-PDF med en stor svart boks og en norsk instruksjon. Det kan lagres og skrives ut fra siden «Skanning».
- **Overvåket skannemappe** (innboksmappen):
  - en fil leses inn når den er ferdig skrevet;
  - vanlig import;
  - flytting til `importert` eller `avvist`;
  - analyse av nye dokumenter.
- **Siden «Skanning»:**
  - skannemappen;
  - «Overvåk skannemappen» (hvert 10. sekund) og «Se etter nye filer nå»;
  - «Lagre skilleark»;
  - tabell med deler, blanke sider og skilleark;
  - hurtigtaster.
- **Selvtest**, også `.exe`: en bunke med blank side og skilleark leses inn, flyttes, analyseres og deles riktig.

## 3. Valg og avvik

| Punkt | Valg | Begrunnelse |
|---|---|---|
| Skillearkets form | Svart boks i midten | Gjenkjennes uten OCR eller strekkodebibliotek og tåler litt skjevhet. |
| Blank side | ≤ 3 ‰ mørke piksler og uten tekstlag | Baksider ved dupleks. En side med tekstlag regnes aldri som blank. |
| Deler | Sideintervaller i originalen | Ingen dobbel lagring. Passer med `first_page`/`last_page` i den kanoniske modellen. |
| Overvåking | En titt hvert 10. sekund, ikke filsystemvarsler | Ingen ny avhengighet, og fungerer også på nettverksstasjoner. |
| Manuell «Les inn fra innboks» | Uendret: flytter ingenting (D-23) | Bare overvåkingen flytter filer. |
| Ny analyse | Alle PDF- og bildedokumenter analyseres på nytt én gang | Eldre analyser mangler målinger. |

## 4. Testresultater

Lokalt (Linux, Python 3.13, gren `claude/phase11a-scan-batch`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen) | 1626 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | 93 % |
| Dekning klassifisering og skilleark | 100 % |
| Ruff, Bandit, pip-audit, Gitleaks (lokalt) | Ingen funn |

Windows-CI og `.exe`-selvtesten: se PR-en. GitHub Actions har ikke startet jobber på grunn av fakturering.

**Ikke prøvd:**

- ekte skann;
- utskrevet og skannet skilleark;
- grenseverdier mot et bestemt skannermerke (Å-01);
- manuell Windows 11-test.

## 5. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Målinger og migrasjon 0010 | ✅ | ✅ | ✅ | se PR | – | – |
| Blanke sider, skilleark og deler | ✅ | ✅ | ✅ (syntetisk) | se PR | – | – |
| Overvåket skannemappe | ✅ | ✅ | ✅ | se PR | – | – |
| Siden «Skanning» | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| WIA, profiler, ADF, dupleks (F11b) | – | – | – | – | – | – |

## 6. Gjenstående risiko og beslutninger

- **T61:** grenseverdiene er bare prøvd på syntetiske sider. Med ekte skann må de kontrolleres og eventuelt justeres (Å-01, F11b).
- **Akseptkriteriet i roadmapen** («testet med faktisk skannermodell») er ikke oppfylt før F11b.
- **Windows-CI:** F09–F12 og F11a er ikke verifisert på Windows før CI kjører igjen.

## 6a. Foreløpig skanner: Brother ADS-4700W (G-22)

Prosjekteier oppga Brother ADS-4700W som arbeidsantakelse. Ifølge produsentens brosjyre har skanneren arkmater, dupleks, drivere for TWAIN, WIA, ISIS og SANE, skanning til PC, nettverksmappe og USB, og hopp over blanke sider. Ingenting av dette er prøvd.

Konsekvenser for F11a:

- Skanneren kan lagre PDF i en mappe. F11a virker derfor uten skannerdriver i programmet: produsentens skanneprogram på PC-en lagrer i innboksmappen, og programmet tar over derfra.
- Innboksmappen ligger under `%LOCALAPPDATA%`. Den bør **ikke** deles på nettverket for «skann til nettverksmappe». Bruk produsentens program på PC-en (USB eller nettverk) og la det lagre lokalt i innboksmappen.
- Hopp over blanke sider i skanneren kan være av eller på; programmet gjenkjenner blanke sider selv. Ved første prøve bør det være av, slik at grenseverdiene kan kontrolleres mot ekte baksider.
- Anbefalt profil for prøven: PDF, 300 dpi, gråtoner, dupleks.

## 7. Manuell Windows 11-aksept

1. Åpne «Skanning» og velg «Lagre skilleark …» (Alt+S). Skriv ut to ark.
2. Legg sammen en bunke: faktura A (to sider), skilleark, faktura B, skilleark, faktura C.
3. Still inn skanneren til å lagre PDF i mappen som vises, gjerne med dupleks.
4. Kryss av for «Overvåk skannemappen» (Alt+O) og skann bunken.
5. Etter noen sekunder:
   - meldingen viser én lest inn og én analysert;
   - filen ligger i `importert`;
   - tabellen viser tre deler, og blanke baksider listes som blanke sider.
6. Legg en fil som ikke er PDF (for eksempel en `.exe` med navnet `.pdf`) i mappen. Den flyttes til `avvist`.

## 8. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- prosjekteiers gjennomgang av D-36;
- prøve med Brother ADS-4700W (G-22), slik at grenseverdiene kan kontrolleres, og valg av omfang for F11b;
- manuell Windows 11-test.
