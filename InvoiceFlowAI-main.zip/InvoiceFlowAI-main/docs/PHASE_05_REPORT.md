# Fase 05 – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

Prosjekteier ba om neste fase («kolejna») og valgte Tesseract 5 som OCR-motor (D-13, Å-05, G-24). Utvikleren skrev promptet `docs/prompts/PHASE_05_OCR.md` v1.0 (D-38), og innholdet er ikke gjennomgått.

**GOAL:** skannede sider uten tekstlag får tekst – ord med posisjon, linje og sikkerhet – lokalt, i den isolerte arbeidsprosessen og uten nettverk. Programmet virker som før uten Tesseract.

## 2. Leveranse

- **Eget OCR-steg** (ADR-0040):
  - kjører etter en vellykket sideanalyse;
  - gjenkjenner sider uten tekstlag som har blekk og ikke er skilleark;
  - er idempotent per programversjon, utdataformat, hash av språkdata og innstillinger.
- **Tesseract i arbeidsprosessen:**
  - én kjøring per side, uten skall, med faste argumenter, minimalt miljø og tidsavbrudd;
  - på Windows i samme Job Object (to prosesser tillatt).
  - TSV tolkes i arbeidsprosessen.
  - Sidebildene kontrolleres mot hash før og i arbeidsprosessen.
- **Lagring:**
  - migrasjon `0011_ocr` (steget `ocr`, `ocr_pages`);
  - ordene i skrivebeskyttede avledede filer;
  - databasen hindrer OCR-rader for feil jobb eller feil dokument.
- **Finne Tesseract:** bare ved siden av programmet, i `%ProgramFiles%\Tesseract-OCR` og, utenfor Windows, i `PATH`. Sjekkes én gang per programstart.
- **Siden «Innboks»:**
  - kolonnen «Tekst (OCR)»;
  - «Vis tekst …» (kilde og sikkerhet per side, teksten bare når filens hash stemmer);
  - melding når Tesseract mangler.
  - «Behandle valgt» kjører også OCR.
- **Selvtest:** med Tesseract leses sidebildet av den syntetiske PDF-en tilbake som skannet side.
- **Referansesett:** syntetisk norsk faktura i fire skannekvaliteter. Tegnfeilrate og tid per side testes.
- **CI:** Windows-jobbene installerer Tesseract 5.4.0 og `nor` fra tessdata 4.1.0 med låste kontrollsummer, og OCR-testene må kjøre.
- **Veiledning:** `OCR_SETUP.md`.

## 3. Valg og avvik

| Punkt | Valg | Begrunnelse |
|---|---|---|
| `pytesseract` (ADR-0007) | Ikke brukt; Tesseract kalles direkte | Ingen ny avhengighet; ingen dokumentbilder i midlertidige filer |
| OCR i sideanalysen | Eget steg | Ny Tesseract-versjon kjører ikke hele analysen på nytt; digitale PDF-er blir ikke tregere |
| Blanke sider | Bare helt tomme sider hoppes over | En side med én linje regnes som blank i skannevisningen (≤ 3 ‰), men må leses. Funnet av selvtesten |
| TSV-utdata | Parameteren `tessedit_create_tsv=1` | Konfigurasjonsfilen `tsv` mangler i noen datamapper |
| Språkdata | tessdata 4.1.0 (standard) | Samme som Linux-pakkene, god treffsikkerhet på referansesettet |
| PaddleOCR-sammenligning | Utsatt | Gir mening først med ekte skann (Å-01, F11b) |
| OCR-tekst i revisjonen | Bare antall ord og snittsikkerhet | Dokumentinnhold hører ikke hjemme i loggen |

## 4. Testresultater

Lokalt (Linux, Python 3.13, Tesseract 5.3.4, gren `claude/phase05-ocr`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen og OCR-tester) | 1736 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | 93 % (OCR-modulene 93–96 %) |
| Ruff, Bandit, pip-audit, Gitleaks (lokalt) | Ingen funn |
| Selvtest (`python -m invoiceflow --self-test`) med Tesseract | Bestått |

Referansesettet (tegnfeilrate, lokalt med Linux-pakkens og med tessdata 4.1.0):

| Variant | Grense | Målt | Tid per side |
|---|---|---|---|
| 300 dpi, ren | 1 % | 0,0 % / 0,0 % | ca. 1 s inkl. oppstart av arbeidsprosessen |
| 300 dpi, støy og 0,7° skjevhet | 2 % | 0,0 % / 0,5 % | ca. 1 s |
| 200 dpi, JPEG | 2 % | 0,0 % / 0,0 % | under 1 s |
| 150 dpi, mer støy og 1,2° skjevhet | 8 % | 3,3 % / 3,3 % | under 1 s |

NF-04 (< 10 s per A4-side ved 300 dpi) er oppfylt lokalt med god margin. Windows-CI og `.exe`-selvtesten: se PR-en. GitHub Actions har ikke startet jobber på grunn av fakturering siden F09.

**Ikke prøvd:**

- Tesseract på Windows (installasjon, Job Object med to prosesser, `.exe`);
- ekte skann fra Brother ADS-4700W;
- manuell Windows 11-test.

## 5. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| OCR-steg og migrasjon 0011 | ✅ | ✅ | ✅ | se PR | – | – |
| Tesseract i arbeidsprosessen | ✅ | ✅ | ✅ | se PR | ✅ motorvalg (G-24) | – |
| Tekstvisning i «Innboks» | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| Referansesett og NF-04 | ✅ | ✅ | ✅ | se PR | – | – |
| Pakking av Tesseract | ✅ (anbefaling) | – | – | – | – | F13 |
| PaddleOCR-sammenligning | – | – | – | – | – | – |

## 6. Gjenstående risiko og beslutninger

- **T66:** feil gjenkjent tekst. Referansesettet er syntetisk, og ekte skann kan være dårligere. Validering (F08) og menneskelig godkjenning (F09) gjelder fortsatt.
- **T64:** Tesseract er innebygd kode som tolker bilder. Den ser bare programmets egne PNG-er og kjører i arbeidsprosessens grenser.
- **Installasjon:** Tesseract må installeres separat fram til F13. Promptets åpne spørsmål 1 (pakking i F13) bør besvares.
- **Windows-CI:** F09–F12, F11a, F11b og F05 er ikke verifisert på Windows før CI kjører igjen.

## 7. Manuell Windows 11-aksept

1. Installer Tesseract og norsk språkdata etter `OCR_SETUP.md` §1. Kontroller kontrollsummene.
2. Start programmet og kjør `InvoiceFlowAI.exe --self-test`. Det skal stå bestått.
3. «Innboks»: meldingen om manglende OCR skal være borte.
4. Les inn en skannet faktura (PDF eller bilde, gjerne fra Brother ADS-4700W) og velg «Behandle nye dokumenter».
5. Kolonnen «Tekst (OCR)» viser antall gjenkjente sider. «Vis tekst …» viser teksten med sikkerhet per side.
6. Les inn en digital PDF med tekstlag. Den skal ikke gjennomgå OCR, og «Vis tekst …» viser tekstlaget.
7. Avinstaller eller gi Tesseract-mappen et annet navn og start programmet på nytt. Meldingen om manglende OCR vises, og alt annet virker.

## 8. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- prosjekteiers gjennomgang av D-38 (særlig avviket fra `pytesseract`);
- svar på om Tesseract skal pakkes med programmet i F13;
- manuell Windows 11-test og prøve med ekte skann.

Neste fase er F06 (feltuttrekk til kanonisk modell), som bygger på tekstlag og OCR-ord.
