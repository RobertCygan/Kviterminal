# Oppsett av skanner og kontroll av grenseverdier

Gjelder InvoiceFlow AI fra fase 11b (ADR-0039). Skanneren er foreløpig **Brother ADS-4700W** (G-22). Prosedyren passer for enhver skanner med et Windows-program som kan lagre PDF i en mappe.

Programmet styrer ikke skanneren. Brothers eget program skanner og lagrer filen i skannemappen. InvoiceFlow AI leser filen inn derfra, deler bunken og flytter filen til `importert` eller `avvist`.

Menynavnene under er hentet fra Brothers dokumentasjon for lignende modeller og er ikke prøvd på ADS-4700W. Avvik noteres i rapporten etter første prøve.

## 1. Før du begynner

- Installer Brothers fulle driver- og programpakke for ADS-4700W fra Brothers støtteside. Den inneholder **Brother iPrint&Scan**.
- Koble skanneren til PC-en med USB eller til samme nettverk.
- Start InvoiceFlow AI og velg regnskapsenheten skanningen gjelder.
- Åpne siden «Skanning» og velg «Kopier mappesti» (Alt+K). Mappestien ligger nå på utklippstavlen. Mappen ligger under `%LOCALAPPDATA%`, som Utforsker skjuler, så lim inn stien i stedet for å lete etter den.

## 2. Skanneprofil i Brother iPrint&Scan

Lag én profil, for eksempel «InvoiceFlow», for skanning til fil på PC-en:

| Innstilling | Verdi | Hvorfor |
|---|---|---|
| Mål | Fil på PC-en, ikke e-post, sky eller nettverksmappe | Filen skal rett i skannemappen |
| Lagringsmappe | Mappestien fra «Kopier mappesti» | Programmet leser bare denne mappen |
| Filtype | PDF, **flere sider** (ofte kalt «PDF Multi-Page») | Hele bunken blir én fil, som programmet deler |
| Oppløsning | 300 dpi | God nok for lesing senere, uten store filer |
| Farge | Gråtoner, eller farge om fakturaene har viktige fargemarkeringer | Grenseverdiene er målt i gråtoner |
| Tosidig (dupleks) | På | Baksider med innhold kommer med. Blanke baksider gjenkjennes |
| Hopp over blank side | **Av** ved første prøve, deretter valgfritt | Ved prøven skal programmet se de blanke baksidene, slik at grenseverdien kan kontrolleres |
| Sikker PDF / passord / signert PDF | **Av** | Krypterte filer kan ikke analyseres |
| Søkbar PDF (OCR i Brother-programmet) | Av | Tekstlaget lages av programmet senere (F05). En side med tekstlag regnes aldri som blank |
| Filnavn | Dato og klokkeslett, for eksempel `Skann_20261024_1405` | Unike navn. Programmet overskriver aldri en fil |

**Ikke** del skannemappen på nettverket for skannerens «skann til nettverksmappe». Den ligger i programmets datakatalog. Bruk Brother-programmet på PC-en.

## 3. Daglig bruk

1. Skriv ut skilleark: «Lagre skilleark …» (Alt+S) på siden «Skanning». Skriv dem ut i svart-hvitt på vanlig A4.
2. Legg et skilleark mellom fakturaene. Et skilleark foran den første fakturaen er tillatt.
3. Kryss av for «Overvåk skannemappen» (Alt+O), eller velg «Se etter nye filer nå» (Alt+N) etter skanningen.
4. Skann bunken med profilen «InvoiceFlow».
5. Etter noen sekunder viser tabellen dokumentet med delene, de blanke sidene og skillearkene.
6. Er en side merket «Nær grensen», kontroller at delene ble riktige (se §4).

Skillearkene kan brukes om igjen så lenge den svarte boksen er hel og jevnt svart.

## 4. Kontroll av grenseverdiene ved første prøve

Grenseverdiene er bare prøvd med syntetiske sider (T61). Første prøve med ekte skanner gjøres med syntetiske eller egne testark, ikke med ekte fakturaer.

1. Lag en prøvebunke på 8 ark:
   1. en tekstside;
   2. et skilleark;
   3. et ark med lite innhold (for eksempel bare én linje);
   4. et skilleark;
   5. et ark med stor logo eller mørkt felt midt på;
   6. et helt blankt ark;
   7. et skilleark som har vært brukt mange ganger;
   8. en tekstside.
2. Skann bunken med dupleks på og «Hopp over blank side» av.
3. Velg dokumentet i tabellen på siden «Skanning». Under tabellen vises målingene for hver side:
   - type;
   - mørkt på hele siden og i midten, i promille;
   - antall tegn i tekstlaget;
   - om siden er nær en grense.
4. Kontroller:
   - alle skilleark har typen «Skilleark»;
   - alle blanke baksider har typen «Blank»;
   - arket med én linje og arket med logo har typen «Innhold»;
   - delene i tabellen stemmer med bunken.
5. Send tallene fra kolonnene «Type», «Mørkt, hele siden» og «Mørkt, midten» til utvikleren, gjerne som skjermbilde av sidetabellen. Tallene inneholder ikke innhold fra dokumentene. Er en side feil klassifisert eller nær grensen, justeres grenseverdiene i en ny versjon.

Grenseverdiene står også på siden «Skanning», over sidetabellen.

## 5. Hvis noe går galt

| Hva du ser | Hva du gjør |
|---|---|
| Filen blir liggende i skannemappen | Vent minst 10 sekunder. Filen leses først når den er ferdig skrevet. Blir den liggende, se meldingen på siden «Skanning» |
| Filen havner i `avvist` | Filen er ikke en gyldig PDF eller TIFF, eller den er satt i karantene. Kontroller filtypen i profilen |
| Filen er lest inn, men vises ikke på siden «Skanning» | Analysen mislyktes, for eksempel fordi PDF-en er kryptert. Se status under «Innboks». Slå av sikker PDF og passord i profilen |
| «Kjent fra før» | Den samme filen er lest inn før. Den flyttes til `importert` uten ny registrering |
| Hver side blir en egen fil | Velg PDF med flere sider i profilen |
| Et skilleark gjenkjennes ikke | Skriv ut et nytt skilleark. Kontroller at skanneren ikke lysner bildet (lysstyrke og kontrast på standard) |
| En nesten tom side regnes som blank | Kontroller at den ikke hører til en faktura. Originalen er alltid hel, og ingen side slettes |
