# InvoiceFlow AI – Systemarkitektur

| | |
|---|---|
| **Dokumentversjon** | 1.2 (Fase 02, etter sluttgjennomgang) |
| **Status** | Fase 02-persistens implementert; rapport og faktisk struktur i `PHASE_02_REPORT.md`. |
| **Relaterte dokumenter** | `DATA_MODEL.md`, `SECURITY.md`, `DECISIONS.md`, `DEPENDENCIES.md` |

---

## 1. Arkitekturstil (leveranse B)

InvoiceFlow AI er en **modulær monolitt med porter og adaptere** (heksagonal arkitektur), se ADR-0001:

- **Én skrivebordsapplikasjon** (én installasjon, én prosess for grensesnitt og forretningslogikk). Mikrotjenester eller lokal server er unødvendig kompleksitet for én bruker.
- **Domenet i sentrum.** Den kanoniske fakturamodellen og regnskapsreglene kjenner ikke til Qt, SQLAlchemy, PDF-biblioteket, OCR-motorer eller KI-leverandører.
- **Porter** (Python `Protocol`-grensesnitt) definerer hva applikasjonen trenger: lagre dokument, kjøre OCR, tolke tekst, lagre faktura, eksportere osv.
- **Adaptere** implementerer portene med konkrete teknologier og kan byttes uten endringer i domene, applikasjonslag eller grensesnitt.
- **Isolasjon:** Parsing av ikke-klarerte filer (PDF, bilder, senere XML) skjer i en egen underprosess med tidsavbrudd og ressursgrenser (ADR-0010).
- **Komposisjonsrot:** `bootstrap` er eneste sted der konkrete adaptere velges og kobles sammen, styrt av konfigurasjon.

## 2. Lag og avhengighetsretning

```mermaid
flowchart TB
    BOOT["bootstrap<br/>komposisjonsrot"]
    subgraph P["Presentasjonslag"]
        UI["ui<br/>PySide6-visninger"]
        I18N["i18n<br/>nb-NO-tekster og formatering"]
    end
    subgraph A["Applikasjonslag"]
        APP["application<br/>brukstilfeller og orkestrering"]
        PORTS["application.ports<br/>grensesnitt"]
    end
    subgraph D["Domenelag"]
        ACC["accounting<br/>validering, MVA, duplikater, kontering"]
        DOM["domain<br/>kanonisk modell og proveniens"]
    end
    subgraph I1["Adaptere: dokument og tolkning"]
        DOCS["documents<br/>import og lagring"]
        PROC["processing<br/>PDF og bilde, isolert"]
        OCR["ocr<br/>Tesseract, PaddleOCR"]
        AI["ai<br/>av, lokal, sky"]
    end
    subgraph I2["Adaptere: data, eksport og plattform"]
        PERS["persistence<br/>SQLAlchemy, Alembic"]
        EXP["export<br/>Excel, CSV, Unit4, Tripletex, Xledger"]
        SCAN["scanner<br/>mappe, WIA"]
        SEC["security<br/>hemmeligheter, revisjon"]
    end

    BOOT --> P
    BOOT --> A
    BOOT --> I1
    BOOT --> I2
    UI --> APP
    UI --> I18N
    APP --> PORTS
    APP --> ACC
    ACC --> DOM
    PORTS --> DOM
    I1 -.->|implementerer| PORTS
    I2 -.->|implementerer| PORTS
```

### 2.1 Avhengighetsregler

| Pakke | Kan avhenge av | Kan **ikke** avhenge av |
|---|---|---|
| `domain` | standardbiblioteket, `pydantic` | alt annet (håndheves av `tests/architecture/test_import_rules.py`) |
| `accounting` | `domain` | `ui`, `persistence`, adaptere, eksterne tjenester |
| `application` | `domain`, `accounting`, `application.ports` | `PySide6`, `sqlalchemy`, `fitz`, `cv2`, OCR-/KI-biblioteker |
| Adaptere (`persistence`, `documents`, `processing`, `ocr`, `ai`, `export`, `scanner`, `security`) | `domain`, `application.ports`, egne tredjepartsbiblioteker | `ui`, andre adaptere direkte |
| `ui` | `application` (fasadetjenester), `i18n`, `domain` (lesing) | `persistence`, adaptere, `sqlalchemy` |
| `i18n` | standardbiblioteket | alt annet |
| `bootstrap` | alle | – |

Reglene utvides i `tests/architecture/` hver gang en ny pakke opprettes.

### 2.2 Regnskapsenhet som grense (ADR-0022)

- Alle brukstilfeller og repositorier som berører regnskapsdata tar et eksplisitt `EntityScope`. Det finnes ingen uavgrensede spørringer.
- Databasen håndhever samme grense med sammensatte fremmednøkler `(entity_id, id)` (dybdeforsvar).
- Den kanoniske fakturakontrakten er enhetsuavhengig; eierskap er arbeidsflytdata.
- Grensesnittet er én-enhets i første versjon; administrasjon av flere enheter er utenfor omfang.

## 3. Moduler og ansvar

| Modul (pakke) | Ansvar | Fase |
|---|---|---|
| **Applikasjonskjerne** (`bootstrap`, `config`, `application`) | Oppstart, konfigurasjon, tjenesteinitialisering, feilhåndtering, tilstand og orkestrering av behandlingsløpet | 01 |
| **Skrivebordsgrensesnitt** (`ui`, `i18n`) | Dashbord, dokumentinnboks, skannerstyring, fakturavisning, feltredigering, gjennomgang, eksport, innstillinger | 01, 09 |
| **Skannerintegrasjon** (`scanner`) | Overvåket mappe (reserve), WIA/TWAIN eller leverandørintegrasjon, ADF, dupleks, skanneprofiler | 03, 11 |
| **Dokumenthåndtering** (`documents`) | Dokument-ID, bevaring av original, SHA-256, metadata, behandlingsstatus, sporbarhet | 03 |
| **PDF- og bildebehandling** (`processing`) | Tekstlag, rasterisering, rotasjonskorrigering, forbehandling, flersidige dokumenter – i isolert underprosess | 04 |
| **OCR** (`ocr`) | Tesseract-/PaddleOCR-adaptere, tekst, posisjoner, sidetall, konfidens | 05 |
| **KI-tolkning** (`ai`) | Leverandøruavhengige adaptere, strukturert uttrekk, forslag med forklaring og proveniens | 07 |
| **Regnskapsmotor** (`accounting`) | Fakturavalidering, MVA-kontroll, kontoplan, dimensjoner, duplikatdeteksjon, identifikatorkontroller | 08 |
| **Gjennomgang og godkjenning** (`application.review`, `ui.review`) | Forhåndsvisning, redigering, korrigeringer, godkjenningsstatus, historikk | 09 |
| **Eksport** (`export`) | Excel, CSV, senere Unit4 med konfigurerbar felttilordning | 10, 14 |
| **Sikkerhet** (`security`) | Hemmeligheter, revisjonslogg med hashkjede, integritetskontroll, kontroll av utgående trafikk, maskering i logger | 01 → |
| **Persistens** (`persistence`) | SQLAlchemy-modeller, repositorier, migrasjoner, Decimal-lagring | 02 |
| **Domene** (`domain`) | Kanonisk fakturamodell, proveniens, typer – **implementert i Fase 00** | 00 |

### 3.1 Porter (planlagte grensesnitt)

| Port | Ansvar | Første adapter |
|---|---|---|
| `DocumentStore` | Lagre original (skrivebeskyttet), lagre avledede filer, verifisere SHA-256 | NTFS-filsystem |
| `FileInspector` | Gjenkjenne filtype fra signatur, kontrollere grenser | Egen implementasjon |
| `DocumentParser` | Tekstlag, sideantall, rasterisering (i underprosess) | pypdfium2 (ADR-0023) |
| `ImagePreprocessor` | Rotasjon, skjevhet, kontrast, støy | OpenCV + Pillow |
| `OcrEngine` | Tekst med posisjon og konfidens per side | Tesseract |
| `AiInterpreter` | Strukturert tolkning av ikke-klarert tekst | `DisabledAiInterpreter` |
| `InvoiceRepository`, `DocumentRepository`, `UnitOfWork` | Transaksjonell lagring | SQLAlchemy/SQLite |
| `AuditLog` | Tilføye revisjonshendelser med hashkjede | SQLAlchemy/SQLite |
| `Exporter` | Skrive eksportfil for en eksportbatch | openpyxl / csv |
| `SecretStore` | Hente/lagre hemmeligheter | Windows Credential Manager (`keyring`) |
| `ScannerSource` | Levere nye filer fra skanner | Overvåket mappe |
| `Clock`, `IdGenerator` | Tid og ID-er (gjør tester deterministiske) | Systemklokke, `uuid4` |

## 4. Behandlingsløp

```mermaid
sequenceDiagram
    autonumber
    actor U as Bruker
    participant UI as ui
    participant APP as application
    participant DOC as documents
    participant ISO as processing (underprosess)
    participant OCR as ocr
    participant AI as ai (valgfri)
    participant ACC as accounting
    participant DB as persistence

    U->>UI: Importer fil eller skann
    UI->>APP: import_document(sti)
    APP->>DOC: valider signatur, størrelse og navn
    DOC-->>APP: godkjent eller avvist
    APP->>DOC: lagre original (SHA-256, skrivebeskyttet)
    APP->>DB: dokument + revisjonshendelse
    APP->>ISO: tekstlag og rasterisering (tidsavbrudd)
    ISO-->>APP: sider, tekst og bilder
    opt Ingen brukbart tekstlag
        APP->>OCR: gjenkjenn side
        OCR-->>APP: tekstblokker med posisjon og konfidens
    end
    APP->>APP: regelbasert feltuttrekk til kanonisk modell
    opt KI aktivert
        APP->>AI: tolk tekst (kun data, ingen verktøy)
        AI-->>APP: strukturert forslag
        APP->>APP: valider med Pydantic og sett proveniens
    end
    APP->>ACC: valider beløp, MVA, datoer, duplikater
    ACC-->>APP: valideringsresultater
    APP->>DB: faktura, proveniens, resultater, revisjon
    U->>UI: gjennomgå, korriger og godkjenn
    UI->>APP: approve(faktura, innholdshash)
    APP->>DB: godkjenning + revisjonshendelse
    U->>UI: eksporter
    UI->>APP: export(godkjente fakturaer)
    APP->>DB: eksportbatch (idempotent) + revisjonshendelse
```

Hvert steg er en **jobb** med idempotensnøkkel `(dokumentets SHA-256, steg, motorversjon, innstillingshash)`. Ny kjøring med samme nøkkel gjenbruker resultatet; ny motorversjon gir nytt resultat uten å overskrive det gamle.

## 5. Tilstandsmaskiner

### 5.1 Dokument (teknisk behandling)

```mermaid
stateDiagram-v2
    [*] --> received: import
    received --> [*]: duplikat, ingen ny rad
    received --> quarantined: filvalidering feilet
    received --> stored: original lagret
    stored --> processing: jobb startet
    processing --> processed: tekst og felter hentet ut
    processing --> failed: feil eller tidsavbrudd
    processing --> quarantined: mistenkelig innhold
    failed --> processing: ny kjøring
    processed --> [*]
    quarantined --> [*]
```

`received` er en midlertidig tilstand under import (ingen databaserad ennå). En fil med samme SHA-256 som et eksisterende dokument gir ingen ny rad, bare revisjonshendelsen `document.duplicate_rejected`.

### 5.2 Faktura (forretningsflyt)

```mermaid
stateDiagram-v2
    [*] --> draft: felter hentet ut
    draft --> needs_review: validering kjørt
    needs_review --> approved: bruker godkjenner (ingen åpne feil)
    needs_review --> rejected: bruker avviser
    approved --> needs_review: innhold endret (godkjenning oppheves)
    approved --> exported: eksportert i batch
    exported --> [*]
    rejected --> [*]
```

Regler:

- `approved` krever at ingen valideringsfeil med alvorlighet *feil* er åpne (eller at de er overstyrt med begrunnelse, registrert i revisjonsloggen).
- Godkjenning er bundet til en innholdshash. Enhver endring etter godkjenning setter fakturaen tilbake til `needs_review`.
- Kun `approved` kan eksporteres. Ny eksport av en allerede eksportert faktura krever en eksplisitt «re-eksport» med begrunnelse.

## 6. Prosess- og trådmodell

| Kontekst | Ansvar | Regler |
|---|---|---|
| Qt-hovedtråd | Kun grensesnitt | Ingen I/O eller tung beregning; maks 100 ms blokkering |
| Jobbtråd (én) | Kjører brukstilfeller og eier databaseøkten for skriving | SQLite har én skriver; serialiserer skriving |
| Arbeidsprosess (spawn) | Parsing av PDF/bilder, rasterisering, OCR | Ingen databasetilgang; leser kun originalfilen og skriver kun til tildelt mappe; tidsavbrudd; avsluttes etter hver oppgave |
| Lokal KI-tjeneste (valgfri) | Modellinferens (f.eks. via `localhost`) | Kun via `AiInterpreter`-adapteren |

Windows-spesifikt: `multiprocessing` bruker *spawn*. Inngangspunktet må ha `if __name__ == "__main__":` og kalle `multiprocessing.freeze_support()` for å virke i PyInstaller-bygg.

## 7. Konfigurasjon

| Nivå | Lagring | Innhold |
|---|---|---|
| Standardverdier | Kode (Pydantic-modell, `extra="forbid"`) | Alle innstillinger har trygge standardverdier |
| Oppstartskonfigurasjon | `%LOCALAPPDATA%\InvoiceFlowAI\config\config.json` | Datakatalog, loggnivå, språk – det som trengs før databasen åpnes |
| Forretningsinnstillinger | Tabellen `app_settings` | MVA-satser med gyldighetsdatoer, grenser, kontoplan, eksporttilordning – endringer revisjonslogges |
| Hemmeligheter | Windows Credential Manager | API-nøkler o.l. – **aldri** i fil, database eller logg |

Ugyldig konfigurasjon stopper oppstart med en norsk feilmelding (fail fast).

## 8. Feilhåndtering og logging

- Felles unntaksbase `InvoiceFlowError` med stabil feilkode (f.eks. `FILE_SIGNATURE_MISMATCH`) og meldingsnøkkel for oversettelse.
- Brukeren ser norsk melding, feilkode og en korrelasjons-ID – aldri stakkspor eller dokumentinnhold.
- Global `sys.excepthook` og Qt-meldingshåndterer fanger uventede feil, logger dem og viser en generell dialog.
- Logging: standardbibliotekets `logging`, JSON-linjer, roterende filer i `%LOCALAPPDATA%\InvoiceFlowAI\logs\`, maskeringsfilter for identifikatorer (se `SECURITY.md` §7). Logger inneholder ID-er og hendelsestyper, ikke fakturainnhold.

## 9. Internasjonalisering

- Sentral katalog i `invoiceflow.i18n` med nøkler (ADR-0015); `nb-NO` er eneste språk i første versjon.
- Valideringsregler, eksportoverskrifter og feil bruker nøkler; teksten slås opp i presentasjonslaget.
- Formatering av beløp skjer med `Decimal` – aldri via `float` (heller ikke `QLocale.toString(float)`).
- Qt-widgets som viser dokumentdata settes til ren tekst (`Qt.PlainText`) for å hindre HTML-tolkning av fakturainnhold.

## 10. Windows-hensyn

| Tema | Tiltak |
|---|---|
| Tegnsett | All fil-I/O med eksplisitt `encoding="utf-8"` (håndheves av ruff-regelen `PLW1514`); Windows' standard er cp1252. CSV-eksport som UTF-8 med BOM og `;` som skilletegn (Excel med norsk oppsett) |
| Stier | `pathlib` overalt; korte stier under datakatalogen; ingen brukerstyrte filnavn i lagringsstier |
| Datakatalog | `%LOCALAPPDATA%\InvoiceFlowAI` (ikke `Dokumenter`, som ofte synkroniseres til OneDrive) – ADR-0006; dokumentlager per regnskapsenhet – ADR-0022 |
| Fillåsing | Antivirus og skannerprogramvare kan låse nye filer; import venter til filstørrelsen er stabil og prøver på nytt med tilbaketrekk |
| Prosesser | *spawn* + `freeze_support()`; underprosesser avsluttes ved tidsavbrudd |
| Høy DPI | Qt 6 håndterer skalering; ikoner som SVG |
| Pakking | PyInstaller *onedir* (ADR-0014); Tesseract og språkdata pakkes med eller installeres separat (avklares i Fase 05) |
| Kryptering | BitLocker for disk; Credential Manager (DPAPI) for hemmeligheter |

## 11. Repositoriestruktur (leveranse C)

Filer merket ✅ finnes etter Fase 00. Øvrige opprettes i angitt fase.

```text
InvoiceFlowAI/
├── .github/
│   └── workflows/
│       └── ci.yml                  ✅ Windows-tester, ruff, Bandit, pip-audit, Gitleaks
├── .editorconfig                   ✅ UTF-8, LF, innrykk
├── .gitattributes                  ✅ linjeslutt; binærfiler
├── .gitignore                      ✅ blokkerer data, dokumenter, hemmeligheter
├── AGENTS.md                       ✅ leverandørnøytrale regler for KI-assistenter og utviklere
├── README.md                       ✅ oversikt og hurtigstart
├── pyproject.toml                  ✅ prosjektmetadata, verktøykonfigurasjon
├── requirements/
│   └── dev.lock.txt                ✅ låste versjoner med SHA-256-hasher
├── docs/
│   ├── MASTER_SPECIFICATION.md     ✅ krav, ordliste, åpne spørsmål
│   ├── ARCHITECTURE.md             ✅ dette dokumentet
│   ├── DATA_MODEL.md               ✅ databaseskjema, kontrakter, proveniens
│   ├── SECURITY.md                 ✅ sikkerhetsarkitektur
│   ├── THREAT_MODEL.md             ✅ trusselmodell
│   ├── TEST_STRATEGY.md            ✅ teststrategi
│   ├── DEVELOPMENT_ROADMAP.md      ✅ faser og milepæler
│   ├── DECISIONS.md                ✅ arkitekturbeslutninger (ADR)
│   ├── DEPENDENCIES.md             ✅ verifiserte avhengigheter og lisenser
│   ├── CHANGELOG.md                ✅ endringslogg
│   ├── PHASE_00_AUDIT.md           ✅ sluttrevisjon av Fase 00
│   ├── PHASE_00_DECISION_REGISTER.md ✅ beslutningsregister
│   ├── PHASE_00_ACCEPTANCE.md      ✅ akseptsjekkliste
│   ├── examples/
│   │   └── eksempel_faktura_kanonisk.json  ✅ fiktiv faktura (valideres av tester)
│   └── prompts/
│       └── PHASE_01_WINDOWS_APPLICATION_SKELETON.md  ✅ prompt for Fase 01
├── src/invoiceflow/
│   ├── __init__.py                 ✅ versjon (eneste kilde)
│   ├── __main__.py                    F01 inngangspunkt
│   ├── bootstrap/                     F01 komposisjonsrot
│   ├── config/                        F01 innstillinger og stier
│   ├── i18n/                          F01 nb-NO-katalog og formatering
│   ├── domain/                     ✅ kanonisk modell
│   │   ├── base.py                 ✅ ContractModel (extra="forbid", frozen)
│   │   ├── types.py                ✅ Money, VatRate, OrgNumber, ...
│   │   ├── provenance.py           ✅ ValueSource, Evidence, Provenance, FieldValue
│   │   └── invoice.py              ✅ CanonicalInvoice og underkontrakter
│   ├── application/                   F01+ brukstilfeller og porter
│   ├── persistence/                   F02 SQLAlchemy, repositorier, migrasjoner
│   ├── security/                      F01+ maskering, revisjon, hemmeligheter, integritet
│   ├── documents/                     F03 import og dokumentlager
│   ├── processing/                    F04 PDF/bilde i underprosess
│   ├── ocr/                           ikke i bruk: OCR-adapteren ligger i processing/ (ADR-0040)
│   ├── ai/                            F07 KI-adaptere
│   ├── accounting/                    F08 regnskapsmotor
│   ├── export/                     ✅ F10 Excel/CSV-skrivere og eksportmappe (Unit4 i F14a)
│   ├── backup/                     ✅ F12 kryptert sikkerhetskopi (AES-256-GCM) og gjenoppretting
│   ├── scanner/                       ikke planlagt (ADR-0039); skanning via `documents/scan_folder.py` og `application/scan/`
│   └── ui/                            F01+ PySide6-grensesnitt
├── tests/
│   ├── conftest.py                 ✅ felles fixtures
│   ├── test_project_documents.py   ✅ påkrevde dokumenter finnes
│   ├── architecture/
│   │   └── test_import_rules.py    ✅ modulgrenser
│   ├── unit/
│   │   └── domain/
│   │       ├── test_canonical_invoice.py  ✅ kontraktstester
│   │       └── test_contract_types.py     ✅ regresjonstester fra sluttrevisjonen
│   ├── integration/                   F02+
│   ├── security/                      F03+ fiendtlige filer, injeksjon
│   ├── performance/                   F04+
│   └── fixtures/
│       └── synthetic/                 F03+ kun syntetiske testdokumenter
└── packaging/                         F01/F13 PyInstaller-spesifikasjon
```

### 11.1 Viktige filer

| Fil | Forklaring |
|---|---|
| `pyproject.toml` | Eneste prosjektdefinisjon: metadata, avhengighetsintervaller, pytest-, coverage-, ruff- og Bandit-konfigurasjon. Versjonen leses fra `invoiceflow.__version__`. |
| `requirements/dev.lock.txt` | Universell låsefil (Windows og Linux) med eksakte versjoner og SHA-256-hasher. Installeres med `--require-hashes`. |
| `src/invoiceflow/domain/` | Den kanoniske kontrakten alle adaptere oversetter til og fra. |
| `docs/examples/eksempel_faktura_kanonisk.json` | Fiktiv faktura som dokumenterer formatet; testene sikrer at den er gyldig og aritmetisk konsistent. |
| `tests/architecture/` | Automatisk håndheving av lagdelingen. |
| `.github/workflows/ci.yml` | Kjører samme kontroller som utvikleren lokalt, på `windows-latest`. |

## 12. Utvidbarhet

| Fremtidig behov | Utvidelsespunkt |
|---|---|
| Ny OCR-motor | Ny `OcrEngine`-adapter + valg i konfigurasjon |
| Ny KI-leverandør | Ny `AiInterpreter`-adapter + samtykke |
| Unit4 eller annet ERP | Ny `Exporter`-adapter + felttilordning i `app_settings` |
| ERP via API (Tripletex, Xledger) | `Exporter`-adapter + sentral HTTP-klientfabrikk med samtykke, tillatte vertsnavn og hemmeligheter i Credential Manager (ADR-0030, godkjent; implementeres i F14b/F14c) |
| EHF/PEPPOL | Ny `DocumentParser` for XML (defusedxml) som mapper direkte til kanonisk modell |
| Nye språk | Ny katalog i `i18n` |
| Flere brukere | Krever ny vurdering (database, tilgangsstyring) – ikke forberedt utover brukerfelt i revisjon og godkjenning (YAGNI) |

## 13. Revisjon av arkitekturen (Fase 00)

Første gjennomgang 2026-10-20 før levering av Fase 00. Den uavhengige sluttrevisjonen (samme dato, etter push) står i `PHASE_00_AUDIT.md` og har forrang der de avviker; radene under er oppdatert etter den.

| Område | Vurdering | Funn og tiltak |
|---|---|---|
| **Konsistens** | God | ADR-, fase- og Å-referanser kontrollert på tvers av dokumentene. Eksempelfakturaen valideres mot kontrakten og kontrolleres aritmetisk i test. Alle 7 Mermaid-diagrammer er rendret uten feil (mermaid-cli 11.4.2). |
| **Rettet under revisjonen** | – | (1) KID med MOD11 kan ha `-` som kontrollsiffer – mønsteret er rettet og testet. (2) Dokumentstatusen «duplikat» var i strid med `UNIQUE(sha256)` – duplikat gir nå ingen ny rad, bare revisjonshendelse. (3) Overflødig validator for ikke-endelige desimaltall fjernet; Pydantic avviser dem allerede, og testen dekker alle desimaltyper. (4) Ruff-regelen `PLW1514` aktivert mot fil-I/O uten tegnsett. (5) Arkitekturdiagrammet forenklet for lesbarhet. |
| **Sikkerhet** | God på papiret, lite implementert ennå | Lagdelte kontroller (skjema, `Decimal`, ingen nett, isolasjon, godkjenning, revisjon) er utformet. Åpne punkter: GitHub Actions er nå SHA-låst og følges av Dependabot i F01; `setuptools` hentes uten hash ved bygg (F13); ingen OS-sandkasse for arbeidsprosessen (ADR-0010). Restrisiko: `THREAT_MODEL.md` §7. |
| **Vedlikeholdbarhet** | God | Én kilde for versjon, ADR-prosess, arkitekturtester, leverandørnøytral `AGENTS.md`. Risiko for at dokumentasjonen driver fra koden reduseres av dokumenttester og Definisjon av ferdig. |
| **Utvidbarhet** | God | Porter for OCR, KI, eksport og skanner; EHF via egen parser. Flere regnskapsenheter er forberedt i persistensmodellen fra start (ADR-0022), uten flerenhetsgrensesnitt. |
| **Windows-kompatibilitet** | Windows-CI-testet (ikke testet på fysisk Windows 11) | Testsettet har kjørt grønt på `windows-latest` (CI-kjøring 39395951832, Python 3.13.16, win32). Spawn/`freeze_support`, `%LOCALAPPDATA%`, UTF-8 og onedir er tatt hensyn til. Qt-tillegget `offscreen` i PyInstaller-bygg må verifiseres i F01. Manuell aksept på prosjekteiers Windows 11-maskin gjenstår. BitLocker krever Pro/Enterprise (Å-13). |
| **Kompleksitet (KISS/YAGNI)** | Akseptabel | Bare domenekontraktene er implementert; øvrige avhengigheter tas inn i sin fase. Datamodellen (22 tabeller) er nødvendig for sporbarhet, idempotens og revisjon; referansetabellene kan forenkles hvis ERP-data ikke finnes (Å-18). |


## Fase 01 – faktisk implementasjon

`__main__` velger argumenter og kaller `bootstrap.app.run`. Komposisjonsroten
oppretter og kontrollerer stier, tar `QLockFile` før konfigurering og logging,
og holder låsen til alle filhandlere er lukket. `config` avhenger ikke av Qt.
`i18n` bruker bare standardbiblioteket. `ui` mottar versjon og visningssti;
filoperasjoner, lagring og nettverk finnes ikke i grensesnittlaget.

Rotkatalogene `documents`, `inbox` og `exports` er tomme reservasjoner i F01;
regnskapsenhetens underkataloger og alle forretningsoperasjoner kommer senere.
`--self-test` oppretter samme hovedvindu uten å vise det og prøver alle seks sider.
Alle dialogknapper får eksplisitte nb-NO-tekster fra katalogen, uavhengig av
Qt-oversettelsesfiler. Maskering er dybdeforsvar; uventede unntak logges uten
unntaksmeldingen, fordi den kan inneholde sensitiv inndata.

## Fase 02 – faktisk struktur og transaksjonsgrenser

- `domain/canonical.py`: kanoniske JSON-bytes, innholdshash og UTC-format. Ingen SQL/Qt.
- `application/scope.py`, `ports.py`, `services.py`, `audit.py`: eksplisitt enhet, porter, atomiske tjenester og ren auditvalidering.
- `persistence/engine.py`, `types.py`, `schema.py`: SQLite-motor, eksakte typer og Core-tabeller.
- `persistence/repositories.py`, `database.py`: adaptere og Unit of Work. Ingen repository-commit.
- `persistence/migrator.py` og `migrations/`: lesebeskyttet inspeksjon, backup-API og Alembic.
- `bootstrap/persistence.py`: eneste modul utenfor persistence som komponerer konkrete adaptere; selvtesten bruker en midlertidig underkatalog.

Oppstart tar instanslåsen før databasen åpnes, migrerer/verifiserer før hovedvinduet og lukker motoren før låsen frigjøres. F02 har ingen vanlige UI-handlinger mot databasen. Hele auditkjeden kontrolleres ved oppstart; oppstartstiden vil derfor øke med antall hendelser. Før innføring av store datasett må ytelsen måles.

Bare fire forretningstabeller er implementert, se DATA_MODEL §3.9. Øvrige tabeller og porter i dokumentet er planlagt arkitektur. ADR-0026 dokumenterer snapshotet som autoritativ kilde; projeksjoner kan endres gjennom senere migrasjoner uten å omskrive historikken.

## Tillegg – generisk dokumentarkiv

Den eksisterende separasjonen mellom `documents` og fakturadomenet skal bevares. Fremtidige dokumenttyper (avtale, kvittering, betalingsbekreftelse, korrespondanse) skal bruke felles dokumentmetadata og relasjoner, uten å tvinges inn i `CanonicalInvoice`. Originalfiler forblir uendrede. Se [`DOCUMENT_ARCHIVE_SCOPE.md`](DOCUMENT_ARCHIVE_SCOPE.md). Ingen arkivfunksjonalitet implementeres i Fase 01.

## Fase 03 – dokumentarkiv (faktisk struktur)

- `application/document_model.py`: generisk dokumentvokabular og rene kontroller (signatur, endelse, visningsnavn, størrelsesklasse). Ingen I/O.
- `application/documents.py`: `DocumentService` – import, innboks, typeendring, integritetskontroll og oppstartsgjenoppretting. Bruker portene `DocumentStore` og `UnitOfWork`.
- `documents/store.py`: `FileDocumentStore`, filsystemadapteren (staging → hash → `fsync` → atomisk publisering, karantene, skrivebeskyttelse, gjenoppretting). Importerer verken persistens, UI eller Qt.
- `persistence`: tabellene `documents` og `document_links`, `SqlDocumentRepository`, migrasjon `0002_documents`.
- `bootstrap/archive.py`: `LocalArchiveController` med nøyaktig én aktiv enhet (D-22); `bootstrap/persistence.py` er eneste modul utenfor adapterne som komponerer `FileDocumentStore` og databasen (arkitekturtest).
- `ui/documents_page.py`: innboks-siden og dialogen for første enhet. Alt arbeid mot fil og database kjøres på en arbeidstråd (`QThreadPool`); GUI-tråden blokkeres ikke.

Ved oppstart kjøres gjenoppretting for hver enhet før vinduet vises; funn logges bare som antall (`documents.recovered`). På Windows kan antivirus, indeksering eller sikkerhetskopiering holde en ny fil åpen et øyeblikk; flytting og sletting forsøkes derfor på nytt i inntil ca. 1,5 sekunder. En fil som fortsatt er låst under gjenopprettingen, blir liggende og telles (`failed`), og programmet starter likevel. Ved import av flere filer stopper ikke en lagringsfeil for én fil resten; den vises som «Feilet» og kan importeres på nytt. Ved avslutning ber innboks-siden kontrolleren stoppe pågående import: filen som er i gang fullføres, ingen ny startes (`documents.shutdown_timeout` logges hvis arbeidet ikke er ferdig etter 10 s). Integritetskontrollen avviser lenker hvor som helst i en lagret sti. Se ADR-0029 for krasjmodell og avviket faktura → dokument (utløser i stedet for FK).

## Fase 04 – isolert behandling (faktisk struktur)

- `application/processing_model.py`: steg, statuser, feilkoder, `ProcessingLimits` (fra `SECURITY.md` §8.1) og kontraktene `WorkerResult` og `TextLayer`. Ingen I/O.
- `application/processing.py`: `ProcessingService` – jobb, kontroll av original, kjøring, validering, publisering og én avsluttende transaksjon; gjenoppretting ved oppstart. Bruker portene `DocumentProcessor`, `DerivedStore`, `DocumentStore` og `UnitOfWork`.
- `processing/`: alt som kjører **i** arbeidsprosessen – porten `DocumentParser` (`parser.py`), adapterne `pdf_pdfium.py` (eneste import av `pypdfium2`) og `image_pillow.py` (eneste import av `PIL`) og `worker.py`. I tillegg hovedprosessens `isolation.py` (`IsolatedDocumentProcessor`) og `win_job.py` (Job Object). Pakken importerer verken persistens, dokumentlager, UI eller Qt. F05: `ocr_tesseract.py` kjører Tesseract og tolker TSV i arbeidsprosessen, og `tesseract_install.py` finner programmet for hovedprosessen; bare disse to importerer `subprocess` (ADR-0040).
- `documents/derived.py`: `FileDerivedStore` – arbeidsmapper, kontroll og publisering av avledede filer, gjenoppretting.
- `bootstrap/persistence.py` komponerer tjenesten; `bootstrap/archive.py` kjører gjenoppretting for alle enheter før vinduet vises (`processing.recovered` logges bare som antall).
- `ui/documents_page.py`: kolonnene «Sider» og «Behandling» og knappene «Behandle nye dokumenter» og «Behandle valgt på nytt». Behandlingen kjører på arbeidstråden; GUI-tråden venter aldri på arbeidsprosessen. Ved avslutning drepes en arbeidsprosess som kjører.

## Fase 15 – EHF-import (faktisk struktur)

- `application/extraction/` (F06, ADR-0041): rene moduler – `layout.py` (ord og linjer fra tekstlag eller OCR), `parse.py` (norske verdier), `fields.py` (feltregler med proveniens) – og `service.py`, som registrerer ett fakturautkast per del. `ProcessingService` kaller den etter analyse og OCR.
- `processing/ehf.py`: XML-leseren i arbeidsprosessen (eneste import av `defusedxml`). Strømmet parsing med grenser, kontroll av `CustomizationID`/`ProfileID`, mapping til `CanonicalInvoice` med XPath og råtekst som bevis, dekoding av innebygde vedlegg til arbeidsmappen (`attachment-NN.bin`). `worker.py` sender XML-dokumenter hit.
- `application/ehf.py`: rene kontroller i hovedprosessen – regneregler (EN 16931), valuta, mottaker, duplikatnøkkel, formkrav, vedleggsnavn.
- `application/processing.py`: steget `ehf_extraction`. Rapporten valideres, vedleggene importeres gjennom `DocumentService` (F03), og faktura, flagg, koblinger og sluttstatus skrives i én transaksjon.
- `persistence/migrator.py`: støtte for migrasjoner som krever `foreign_keys` av (ADR-0032).
- `ui/documents_page.py`: format «EHF» og kolonnene «Faktura» og «Avvik».

## Fase 08a – validering og leverandørregister (faktisk struktur)

- `domain/checksums.py`: kontrollsiffer (MOD11, MOD10, MOD97), rene funksjoner.
- `application/validation/model.py` og `rules.py`: kontrakter og regelkatalog. Rene funksjoner uten I/O (arkitekturtest).
- `application/validation/service.py`: `ValidationService`, som står for kontrollkjøringer, leverandørregisteret og bekreftelse og sperring av kontoer. `ProcessingService` kaller den gjennom porten `InvoiceValidator` i registreringstransaksjonen.
- `persistence/repositories.py`: `SqlSupplierRepository` og `SqlValidationRepository`.
- `ui/documents_page.py`: kolonnen «Kontroll» og knappene «Vis kontroll» og «Kontroller alle på nytt».
- `ui/suppliers_page.py`: ny side «Leverandører» med knappene «Bekreft konto» og «Sperr konto».
- `ui/background.py`: felles bakgrunnsoppgave for sidene.
- `ui/validation_text.py`: norske tekster for funn.

## Fase 08b – referansedata og kontering (faktisk struktur)

- `application/reference/`:
  - `model.py`: kontrakter;
  - `csv_import.py`: streng CSV-parser, ren;
  - `posting.py`: konteringsforslag, rent;
  - `service.py`: `ReferenceService`, som står for import, leverandørstandard og forslag. Den kalles av `ProcessingService` gjennom porten `InvoicePoster` før registrering.
- `application/services.py`: `revise_in` lager revisjon og revisjonshendelse i en eksisterende Unit of Work.
- `persistence/repositories.py`: `SqlReferenceRepository`.
- `ui/reference_page.py`: delen «Referansedata» under «Innstillinger».
- `ui/suppliers_page.py`: «Sett standardkontering …».
- `ui/documents_page.py`: «Foreslå kontering på nytt» og konteringen i kontrollvinduet.
- `bootstrap/synthetic_reference.py`: syntetiske eksempelfiler. CSV-filer i repoet blokkeres av `.gitignore`.

## Fase 09 – gjennomgang og godkjenning (faktisk struktur)

- `application/review/model.py`: beslutninger, overstyringer og blokkerende regler.
- `application/review/editing.py`: streng tolkning av norsk inndata og manuell proveniens. Rent.
- `application/review/service.py`: `ReviewService` med visning, retting, overstyring, godkjenning, avvisning, oppheving og forhåndsvisning. Forhåndsvisningen leser bare hashkontrollerte avledede filer gjennom `DerivedStore.read_published`.
- `application/services.py`: `revise_in` opphever en godkjenning når innholdet endres.
- `persistence/repositories.py`: `SqlReviewRepository` og `SqlInvoiceRepository.set_status`.
- `ui/review_page.py`: siden «Gjennomgang» med liste, felt med kilde, funn, historikk, forhåndsvisning med kildeboks og knapper med hurtigtaster.
