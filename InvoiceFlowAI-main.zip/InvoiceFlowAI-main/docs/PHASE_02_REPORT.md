# Fase 02 – persistens, migrasjoner og revisjonsspor

## 1. Sammendrag og omfang

Leveransen viderefører Claude-commit `8daa6e22b5456fa384e22e8f058d8c8a89f9a21e` med SQLAlchemy/Alembic, enhetsavgrenset fakturalagring, immutable revisjoner og append-only auditkjede. Sluttgjennomgangen korrigerer verifiserte svakheter og dokumenterer den faktiske implementasjonen.

**GOAL:** trygg, testbar lokal lagring uten dokumentbehandling.
**CONTEXT:** F00-audit og F01-skall på egne, åpne PR-er; F02 tillatt gjennom oppdraget og G-03 (tidligere G-02).
**INPUT:** eksplisitt datakatalog, kanonisk faktura, EntityScope og tekniske hendelsesmetadata.
**OUTPUT:** SQLite-database, migrasjoner, tjenester, auditkontroll og pakket Windows-selvtest.
**CONSTRAINTS:** ingen import, OCR, KI, bokføring, betaling, godkjenning eller eksport. Syntetiske data. Ingen nye nettverkskall.
**TESTS:** ekte SQLite-filer, transaksjoner, samtidighet, enhetsgrenser, tapsfri mapping, feilende migrasjoner og Windows-bygg.

## 2. GitHub-status og autorisasjon

- Repository: `RobertCygan/InvoiceFlowAI`, standardgren `main`.
- Arbeidsgren: `codex/phase02-persistence-audit`.
- F02 bygger på `836364f` fra F01; PR #1 og #2 er ikke automatisk slått sammen.
- F02-PR skal først rette seg mot `codex/phase01-windows-skeleton` for å vise bare F02. Etter sammenslåing av forutsetningene rettes den mot `main`.
- G-03 (tidligere G-02) autoriserer implementering og denne ferdigstillingen; det er ikke formell F00/F02-aksept, generell risikoaksept eller godkjenning av senere faser.
- M-01 er prosjekteiers rapport om fungerende F01 på egen Windows-maskin. F02 er ikke manuelt akseptert.
- Ingen grener er slettet, ingen force-push eller direkte push til main er utført.

## 3. Faktisk datamodell og isolasjon

`accounting_entities` lagrer eksplisitt opprettede regnskapsenheter. Ingen fiktiv standardenhet opprettes. `invoices` har enhetsgrense og typet headerprojeksjon. `invoice_revisions` lagrer hele kanoniske snapshotet, med provenance, linjer, UTC-tider og SHA-256. Revisjonene kan ikke endres eller slettes gjennom vanlig SQL. `audit_events` er én global kjede, inkludert globale databasehendelser uten enhet. Alembic bruker `0001_initial`.

UUID lagres som 32 heksadesimale tegn, UTC-tid som 27-tegns tekst med mikrosekunder og beløp som Decimal-tekst. Kanonisk JSON har sorterte nøkler, kompakte skilletegn og UTF-8. Projeksjonen er ikke en annen autoritativ kilde; lesing kontrollerer den mot gjeldende snapshot. Planlagt normalisering til linje-/provenienstabeller er ikke implementert nå (ADR-0026).

Fakturatjenestene krever `EntityScope`. En annen enhets kjente faktura-ID gir ikke tilgang. Sammensatte FK-er hindrer tverrenhetskobling mellom faktura og revisjon. Dokumenttabellen, leverandører og eksport finnes ennå ikke; `document_id` er derfor ikke en dokument-FK i F02.

Forhold til `DOCUMENT_ARCHIVE_SCOPE.md` (innført i `main` etter at F02 ble påbegynt): F02 skiller allerede faktura fra dokument. `invoices.document_id` peker på et fremtidig generisk dokument, og ingen andre dokumenttyper tvinges inn i `CanonicalInvoice`. Tabellen `documents` med felles metadata, versjoner og relasjoner er ikke implementert i F02; den innføres i F03 med sammensatt fremmednøkkel `(entity_id, document_id)` og må oppfylle arkivkriteriene 1–4 i omfangsdokumentet. Ingen sletting er implementert.

## 4. Migrasjon, transaksjon og gjenoppretting

1. Instanslåsen tas før oppstart mot databasen.
2. Eksisterende database inspiseres lesebeskyttet: quick_check, kjent revisjon og nødvendige tabeller. Ukjent eller nyere format avvises.
3. Før oppgradering av versjonerte data tas en konsistent, verifisert kopi med SQLite backup-API. Kopien ligger under `backups/pre-migration`; den er ukryptert.
4. DDL, Alembic-versjon og audit-hendelse utføres i én BEGIN IMMEDIATE-transaksjon. Innstillinger og auditkjede kontrolleres før commit. Ved feil rulles migrasjonen tilbake og kopien beholdes.
5. Tilkoblingens PRAGMA-er og auditkjeden kontrolleres før normal bruk. Databasemotoren lukkes før instanslåsen frigjøres.

Gjenoppretting er en manuell driftsprosedyre, ikke en implementert UI-funksjon: steng programmet helt, behold den feilende datakatalogen, og kopier den verifiserte migrasjonskopien til en **ny, separat** testdatakatalog under `database/invoiceflow.sqlite3`. Ikke bland inn gamle WAL/SHM-filer eller kopier over en åpen database. Bruk programversjonen som støtter kopiens revisjon, og kjør selvtest med eksplisitt `--data-dir` før videre arbeid. Automatisk downgrade utføres ikke. Kryptert backup, eksterne ankre og full restore-test kommer i F12.

## 5. Gjennomgangsfunn og korrigeringer

| ID / alvorlighet | Bevis og konsekvens | Korrigering / regresjon |
|---|---|---|
| F02-01 Høy | `domain/types.py:fixed_point` brukte normalize/quantize med aktiv Decimal-kontekst. Under prec=6 ble 1.234567 endret til 1.23457. En brøk med mer enn 28 siffer ble også rundet med standardkontekst. | Eksakt tuple-normalisering uten kontekstaritmetikk. Tester under lav presisjon og over 28 siffer. DecimalText avgrenser eksponentutvidelse og representasjonens lengde. |
| F02-02 Høy | `persistence/migrator.py:_upgrade` committet før `verify_database`. Syntaktisk gyldig migrasjon som endret tidligere hendelser kunne bli permanent før kjedefeilen ble meldt. | Verifisering av innstillinger og hele auditkjeden inne i migrasjonstransaksjonen. Regresjonen endrer auditinnhold etter å ha fjernet trigger og krever full rollback av data, DDL og versjon. |
| F02-03 Middels | Kjent `alembic_version` alene godtok en fremmed SQLite-fil til skrivemotoren, som kunne endre journalmodus før manglende tabeller ble oppdaget. | Krever nødvendige F02-tabeller under lesebeskyttet inspeksjon; regresjonen krever byte-uendret fremmed fil og ingen ekstra filer. Dette er ikke attestering av hele skjemaet. |
| F02-04 Middels | `get_revision` validerte snapshotet, men sammenlignet ikke gjeldende typede headerkolonner med snapshotet. En endret invoice_number kunne avvike ubemerket. | Sammenligner schema_version, document_id, gjeldende hash og projeksjonskolonnene. Regresjon for endret fakturanummer. |
| F02-05 Middels | Faktisk snapshotlagring og manglende automatisk enhet var ikke dokumentert og avvek fra tidligere skisser. F02-rapport/ADR-er manglet i GitHub. | ADR-0026–0028, oppdatert datamodell og reelt kontrollomfang. G-02/M-01 registrert uten å konstruere generell godkjenning. |

Koden er gjennomgått for enhetsgrenser, transaksjoner, fil-livssyklus, auditdetaljer, kanonisering og pakking. Oppgitte lokale Linux-/wheel-resultater fra Claude-samtalen er ikke behandlet som selvstendig reprodusert bevis.

## 6. Revisjonskjede og begrensninger

Hashversjon 1 dekker alle lagrede auditkolonner gjennom `hash_payload`. Genesis er 64 nuller; sekvenser må være sammenhengende. BEGIN IMMEDIATE og databaserestriksjoner hindrer samtidig forgrening. Forretningsendring og hendelse er atomiske gjennom applikasjonstjenestene. Direkte interne repository-kall skriver ikke automatisk en hendelse.

Detaljer er allowlist-validerte. Actor må være en teknisk ID, ikke et personnavn; syntakskontroll er ikke personvernbevis. Det finnes ingen brukernavnflyt i dagens UI. Globale auditlesinger er intern integritetskontroll, ikke en rapport for vanlige flerenhetsbrukere.

En privilegert lokal aktør kan fjerne triggere og skrive om databasen. Sluttsletting eller full omskriving av kjeden kan ikke oppdages uten uavhengige ankre. Migrasjonskopier er ukrypterte; SQLite secure_delete er ikke full disksanering. NTFS/BitLocker-kontroll, ekte dokumentintegritet og kryptert backup er senere arbeid.

## 7. Testresultater og bevis

Grunnlaget `8daa6e2` er bekreftet i [Windows CI 39409695013](https://github.com/RobertCygan/InvoiceFlowAI/actions/runs/39409695013): **465 bestått**, 97 % samlet dekning, 96 % utenfor domain/UI. Ruff, format, Bandit, pip-audit, Gitleaks og Windows onedir-selvtest bestod. Bygget inneholdt Alembic-migrasjonene.

Sluttkorrigeringene på `084432ca01e14f074ed8509b84300522d477aca8` er verifisert i [Windows CI 39413990732](https://github.com/RobertCygan/InvoiceFlowAI/actions/runs/39413990732), Python 3.13.16:

| Kommando / kontroll | Faktisk resultat |
|---|---|
| `python -m pytest --cov --cov-report=term-missing` | **473 bestått**, 97 % samlet dekning (1411 utsagn, 294 grener) |
| `python -m coverage report --omit="*/domain/*,*/ui/*" --fail-under=90` | **96 %**, terskel bestått (1067 utsagn, 238 grener) |
| `python -m ruff check .` | Ingen funn |
| `python -m ruff format --check --diff .` | 79 filer korrekt formatert |
| `python -m bandit -c pyproject.toml -r src` | Ingen funn |
| `python -m pip_audit --disable-pip --require-hashes -r requirements/dev.lock.txt` | Ingen kjente sårbarheter funnet |
| Gitleaks | Hele Git-historikken skannet uten funn |
| `python -m pip wheel --no-deps --no-build-isolation --wheel-dir wheelhouse .` | Wheel bygget; `packaging/verify_wheel.py` bekreftet alle tre migrasjonsressurser |
| `python -m PyInstaller packaging/invoiceflow.spec --noconfirm` | Windows onedir bygget; offscreen-tillegg og Alembic-filer finnes |
| `InvoiceFlowAI.exe --self-test --data-dir …` | Bestått, kode 0; database opprettet og midlertidig probe fjernet |

Alle automatiserte områder i aksepttabellen har status **Verifisert (Windows CI)**. Dekning omfatter eksisterende kode og er ikke dekning av hele fremtidige InvoiceFlow AI. Windows-CI er ikke manuell Windows 11-aksept.

Første sluttkjøring avdekket også testfeil: en ny SQLite-fixture brukte transaksjonskontekst uten å lukke forbindelsen, et SELECT-helper ble brukt til UPDATE, og en gammel feilinjeksjon antok et bestemt antall auditkontroller. Forbindelsen lukkes nå eksplisitt, UPDATE utføres i egen transaksjon, og feilinjeksjonen retter seg mot de syntetiske forretningshendelsene. Alle regresjoner bestod i sluttkjøringen.

Lokalt er syntaks, whitespace og den konkrete Decimal-regresjonen kontrollert med Python 3.12.14. Terminalens proxy er utilgjengelig, og målmiljøets pytest/SQLAlchemy/Alembic kan ikke installeres der. Full Linux-test hevdes derfor ikke. GitHub-tilkoblingen brukes til eksakte filbilder og commits med korrekt eksisterende forelder.

## 8. Akseptansekriterier

| Område | Implementasjon og verifikasjon |
|---|---|
| Migrasjon fra tom base / gjentatt oppstart | Ekte SQLite-fixtures og versjonskontroll |
| PRAGMA og Windows-filhåndtak | Nye tilkoblinger, WAL/FULL og rename/delete etter lukking |
| Decimal og UTC | Eksakte round trips, type-/NaN-avvisning, naive tidspunkter avvises |
| Snapshot og proveniens | Tapsfri eksempelrundtur og stabile kanoniske hasher |
| Unit of Work | Eksplisitt commit, automatisk rollback og atomisk audit |
| Enhetsgrenser | Kjente fremmede ID-er og direkte FK-brudd avvises |
| Audit | UPDATE/DELETE/forgrening avvises, endrede data oppdages, samtidige skrivere testes |
| Feilende migrasjon | Verifisert kopi beholdes; DDL, audit og revisjon rulles tilbake |
| Logger og nettverk | Feilkoder uten SQL-innhold; offline selvtest og importgrenser |
| Pakking | Migrasjonsressurser i onedir og Windows .exe-selvtest |
| Manuell Windows 11-test av F02 | **Ikke kjørt / gjenstår hos prosjekteier** |
| Formell F02-aksept og sammenslåing | **Ikke gitt / ikke utført** |

## 9. Manuell Windows 11-aksept

Last ned hele Windows-smoke-artefakten fra den vellykkede F02-kjøringen og pakk ut alle filer samlet. Lukk F01 først. Kjør i PowerShell fra katalogen med exe:

```powershell
$acceptanceDir = "$env:LOCALAPPDATA\InvoiceFlowAI-F02-Acceptance"
.\InvoiceFlowAI.exe --self-test --data-dir $acceptanceDir
if ($LASTEXITCODE -ne 0) { throw "Selvtesten feilet" }
.\InvoiceFlowAI.exe --data-dir $acceptanceDir
```

Forvent «Selvtest bestått» og kode 0; filen `database\invoiceflow.sqlite3` opprettes i testkatalogen. Hovedvinduet er fortsatt seks plassholdersider. Kontroller navigasjon, Om-dialog, andre samtidige instans og lukking. Start på nytt med samme katalog; data/revisjon skal ikke dupliseres og ingen migrasjonskopi skal opprettes uten skjemaoppgradering. Ikke rediger databasen manuelt som del av denne testen, og ikke bruk ekte fakturaer.

## 10. Anbefaling

**Anbefaling: teknisk leveranse klar til gjennomgang og manuell aksept.** Ingen åpne høye funn fra denne gjennomgangen gjenstår. Manuell F02-aksept, formell fasegodkjenning og sammenslåing av forutsetninger gjenstår. F03 er bare beskrevet i en prompt og er ikke påbegynt.

PR: [#3](https://github.com/RobertCygan/InvoiceFlowAI/pull/3). Verifisert kodecommit: `084432ca01e14f074ed8509b84300522d477aca8`. Etterfølgende dokumentasjonscommit endrer bare Markdown; kildekode, tester, låsefiler og CI er identiske med den verifiserte kjøringen.

[Røykbygg for Windows](https://github.com/RobertCygan/InvoiceFlowAI/actions/runs/39413990732/artifacts/12260791107) er tilgjengelig til 2026-10-27 etter artefaktens lagringspolicy. Pakk ut hele ZIP-filen og bruk prosedyren i §9.
