# Fase 12 – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

Prosjekteier ba om F12 (G-18, «zacznij F12») etter at F10 ([RobertCygan/InvoiceFlowAI#40](https://github.com/RobertCygan/InvoiceFlowAI/pull/40)) ble slått sammen uten grønn CI (G-17). F11 (skanner) er hoppet over.

Utvikleren skrev promptet `docs/prompts/PHASE_12_BACKUP.md` v1.0 (D-35) og valgte kryptert arkiv framfor bare kryptert medium (Å-14). Innholdet er ikke gjennomgått. Autorisasjonen gjelder implementering, ikke aksept, restrisiko (D-19) eller ekte data.

**GOAL:** alle data kan sikkerhetskopieres til én kryptert fil og gjenopprettes til en tom mappe med full kontroll. En manipulert sikkerhetskopi avvises, og prosedyren er dokumentert på norsk.

## 2. Leveranse

- **Format** (ADR-0037):
  - én `.ifbak`-fil med åpent, autentisert hode (scrypt-parametere og salt);
  - AES-256-GCM i biter på 1 MiB med løpenummer og sluttmerke;
  - tar-arkiv med databasekopi, dokumentarkiv, eksportfiler og `config.json`;
  - manifest med SHA-256 og revisjonsanker til slutt.
- **`BackupService`:**
  - **lage:** krever intakt revisjonskjede og komplett dokumentarkiv;
  - **kontrollere:** i en privat arbeidsmappe som slettes;
  - **gjenopprette:** til en tom mappe utenfor datakatalogen, med kontroll av manifest, integritet, skjema, hele kjeden, anker og dokumenter, og tømming ved feil;
  - **slette:** bare en registrert fil, og slettingen registreres.
- **Migrasjon `0009_backup`:** registeret `backups`, der sletting registreres én gang og rader aldri slettes.
- **Revisjon:** `backup.created`, `backup.verified`, `backup.restored` og `backup.deleted`, bare med ID-er, hasher, antall, anker og utfall.
- **Oppstart:** arbeidsmapper etter avbrudd (med ukryptert databasekopi) fjernes.
- **Siden «Sikkerhetskopi»** med hurtigtaster og advarsel om passordfrasen.
- **Prosedyre:** `docs/BACKUP_PROCEDURE.md` dekker å lage, kontrollere, gjenopprette, ta i bruk den gjenopprettede mappen, slette og feilsøke.
- **Avhengighet:** cryptography 50.0.1 med cffi 2.1.1 og pycparser 3.0, satt inn i de eksisterende låsene.
- **Selvtest**, også `.exe`: lage, gjenopprette med full kontroll, og avvise en endret byte.

## 3. Valg og avvik

| Punkt | Valg | Begrunnelse |
|---|---|---|
| Kryptering (Å-14) | Kryptert arkiv; kryptert medium kan brukes i tillegg | Virker på alle medier og kan testes automatisk. |
| Nøkkelavledning | scrypt fra standardbiblioteket (N = 2^17, r = 8, p = 1) | Minnekrevende og standard. Argon2 ville krevd enda en avhengighet. |
| Hvor gjenopprettede data havner | Bare en tom mappe utenfor datakatalogen | En feil kan aldri ødelegge gjeldende data. Programmet startes deretter med `--data-dir`, eller mappen byttes inn etter prosedyren. |
| Hva som er med | Også sidebilder og eksportfiler | En gjenopprettet mappe er komplett. Bare dokumentene kreves for at en sikkerhetskopi kan lages. |
| Ufullstendig arkiv | Ingen sikkerhetskopi | En sikkerhetskopi som ikke kan gjenopprettes, er verre enn ingen. Meldingen viser til integritetskontrollen. |
| Oppbevaring (Å-07) | Ingen automatisk sletting | Lov- og virksomhetskrav er ikke bekreftet. |
| Tidsplan | Ingen | Krever lagret nøkkel (ADR-0037, alternativ d). |

## 4. Testresultater

Lokalt (Linux, Python 3.13, gren `claude/phase12-backup`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen) | 1561 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | 94 % |
| Dekning sikkerhetskopimodell, kryptering og arkiv | 92–98 % |
| Ruff, Bandit, pip-audit, Gitleaks (lokalt) | Ingen funn |

Windows-CI og `.exe`-selvtesten: se PR-en. Siste kjente tilstand er at GitHub Actions ikke starter jobber på grunn av fakturering (G-15, G-17).

**Ikke prøvd:**

- store arkiver (mange GB) og tid på Windows;
- sikkerhetskopi til nettverksshare og minnepinne med FAT32/exFAT;
- manuell Windows 11-test etter prosedyren.

## 5. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Format og kryptering | ✅ | ✅ | ✅ | se PR | – | – |
| Lage, kontrollere og gjenopprette | ✅ | ✅ | ✅ | se PR | – | – |
| Register, sletting og revisjon | ✅ | ✅ | ✅ | se PR | – | – |
| Siden «Sikkerhetskopi» | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| Prosedyre på norsk | ✅ | ✅ | – | – | – | – |
| Oppbevaring og tidsplan (Å-07, Å-14) | – | – | – | – | – | – |

## 6. Gjenstående risiko og beslutninger

- **T54:** en glemt passordfrase gjør sikkerhetskopien ubrukelig. Passordhvelv hos to personer anbefales (Å-14).
- **T58:** sikkerhetskopier lages bare manuelt. Prosedyren anbefaler en fast rutine.
- **Store filer:** en enkelt fil over 8 GiB kan ikke pakkes ut. I praksis gjelder det bare databasen, fordi dokumenter er begrenset til 50 MB ved import.
- **F09, F10 og F12 uten Windows-CI:** ikke verifisert på Windows før CI kjører igjen.
- **D-19 og porten for ekte data:** uendret. F12 oppfyller kravet om sikkerhetskopi med gjenopprettingstest, men porten krever prosjekteiers godkjenning.

## 7. Manuell Windows 11-aksept

Følg `docs/BACKUP_PROCEDURE.md`:

1. Lag en sikkerhetskopi til en ekstern disk (§3).
2. Kontroller den (§4). Kontroller også en kopi der én byte er endret i et heksredigeringsprogram; den skal avvises.
3. Gjenopprett til en tom mappe (§5). Start programmet med `--data-dir` mot mappen, og kontroller at fakturaer, godkjenninger, eksporter og forhåndsvisninger er der.
4. Prøv å gjenopprette til en mappe som ikke er tom, og med feil passordfrase.
5. Slett sikkerhetskopien fra programmet (§6). Listen viser «Slettet».

## 8. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- grønn Windows-CI for F09, F10 og F12;
- prosjekteiers gjennomgang av D-35;
- svar på Å-07 og Å-14;
- manuell Windows 11-test etter prosedyren.

F11 (skanner) er ikke påbegynt.
