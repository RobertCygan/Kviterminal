# Fase 01 – leveranse og akseptgrunnlag

## Omfang og tillatelse

Prosjekteier ba 2026-10-20 om å gå videre til neste fase. Dette er tillatelse til
å implementere F01. Det er ikke registrert som formell godkjenning av F00,
restrisikoer eller senere beslutninger. F01 bygger på revisjonsgrenen
`claude/phase00-final-audit` (`a61a8f3`), fordi PR #1 fortsatt er åpen.
PR #2 viser bare F01-endringene. Etter sammenslåing av #1 skal #2 rettes mot `main`.
Ingen eksisterende grener er slettet eller historikk omskrevet.

## GOAL

Kjørbart lokalt skrivebordsskall for Windows 11 x64, uten fakturabehandling.

## CONTEXT

F01-prompt versjon 1.1 og de godkjente verktøyvalgene D-04–D-08 brukes.
Domenekontraktene fra sluttrevisjonen beholdes uendret.

## INPUT

Argumentene `--help`, `--self-test`, `--data-dir`; eksplisitte miljøstier;
begrenset UTF-8 JSON-konfigurasjon uten hemmeligheter.

## OUTPUT

PySide6-hovedvindu, seks norske sider, meny, statuslinje, dialoger, én-instans-lås,
JSON-logger, atomisk standardkonfigurasjon, eksakt tallformatering og onedir-bygg.

## CONSTRAINTS

Ingen database, import, OCR, KI, skannerintegrasjon eller eksport. Ingen
nettverk i applikasjonen. Prosjektets obligatoriske teknologistakk er beholdt.
Ingen risiko- eller lisensbeslutninger for senere faser er tatt her.

## TESTS – kriterier

| Kriterium | Leveranse / verifikasjon |
|---|---|
| Streng konfigurasjon | Standardverdier, ugyldig JSON, ukjente felt, bool/float-versjon, størrelse og bevaring av ugyldig fil testes |
| Datakatalog | Eksplisitte stier, skrivbarhet, OneDrive, utgående lenker og utilgjengelig mappe testes |
| Norsk tekst | Sentral katalog; menyer, handlinger og etiketter kontrolleres; CLI-hjelp oversettes eksplisitt |
| Eksakt formatering | Decimal/int, ROUND_HALF_UP, store og negative beløp, datoer og prosent testes |
| Sikker logging | JSON, maskering, tillatte metadata, ingen stakkspor/innhold, lukking av handlere testes |
| Avslutningskoder | Normal slutt, feil, ugyldige argumenter og opptatt lås testes |
| GUI | Ekte Qt, seks sider, mus/tastatur, dialoger og Qt.PlainText testes |
| Én instans | Ekte QLockFile og frigivelse etter normal og feilende selvtest testes |
| Ingen nettverk | Socket-tilkoblinger blokkeres i selvtesten; importregler håndheves |
| Regresjon | Alle 140 F00-tester beholdes |
| Windows-bygg | CI bygger onedir, kontrollerer qoffscreen.dll og kjører byggets selvtest |
| Manuell Windows 11-aksept | Gjenstår: oppstartstid, andre samtidige prosess, lukking og .exe på målmaskinen |

## Miljø og avvik

Terminalen har Python 3.12 og utilgjengelig proxy (`Failed to connect to proxy
port 8080`). Den kan ikke installere målmiljøet eller klone GitHub. Kildegrunnlaget
er derfor hentet gjennom den autoriserte GitHub-tilkoblingen, og commits er
opprettet med GitHub Git Data API med korrekte foreldre. Lokal Git-historikk er
bare en arbeidskopi og er ikke pushet.

`python -m compileall -q src tests` og en direkte kontroll av konfigurasjon og
Decimal-formatering er kjørt lokalt. Dette er ikke rapportert som full Linux-test.
Windows CI med Python 3.13.16 brukes for resten. Midlertidig forberedelsesjobb
løser hash-låser og formaterer kildekode når lokal proxy er utilgjengelig; den
fjernes fra sluttleveransen. Ingen automatisk skriveadgang fra CI er gitt.

Alle Qt-dialogknapper har eksplisitt katalogtekst; Qt sine oversettelser er derfor
ikke en forutsetning for norsk UI. Konsoll beholdes i røykbygget for stdout fra
`--self-test`; utgivelsesdesign og signering behandles i F13.

## Resultater

Windows CI på `a97f3a4` (Python 3.13.16, Qt/PySide6 6.11.2):

- `python -m pytest --cov --cov-report=term-missing`: **221 bestått**, 99 % samlet dekning.
- `python -m coverage report --omit="*/domain/*,*/ui/*" --fail-under=90`:
  **98 %** for nye moduler utenfor UI og domenet (292 utsagn, grendekning inkludert).
- `python -m ruff check .`: ingen funn.
- `python -m ruff format --check .`: 51 filer formatert korrekt.
- `python -m bandit -c pyproject.toml -r src`: ingen funn.
- `python -m pip_audit --disable-pip --require-hashes -r requirements/dev.lock.txt`:
  ingen kjente sårbarheter funnet.
- Gitleaks: hele historikken skannet uten funn.
- Kildeselvtest på Windows: bestått i forberedelseskjøringen; kjøres også i GUI-testene.

Bevis: [Windows CI 39403956455](https://github.com/RobertCygan/InvoiceFlowAI/actions/runs/39403956455).
Dekning måler eksisterende kildekode, ikke hele den planlagte applikasjonen.
Første tester avdekket for lange pytest-parameternavn på Windows; korte, faste
identifikatorer løste dette. Ingen domenekontrakter ble endret i F01.
Fasen er ikke utgitt eller manuelt verifisert på prosjekteiers Windows 11-maskin.

## Windows-røykbygg og anbefaling

`python -m PyInstaller packaging/invoiceflow.spec --noconfirm` er **verifisert på
Windows CI**. `qoffscreen.dll` finnes i bygget, og
`InvoiceFlowAI.exe --self-test --data-dir …` skrev **«Selvtest bestått»** og
returnerte 0. Artefakten `InvoiceFlowAI-windows-smoke` er lagret i samme CI-kjøring
med sju dagers lagring. Hele mappen må pakkes ut og beholdes samlet.

Anbefaling: teknisk leveranse er klar til gjennomgang. Manuell aksept på
prosjekteiers Windows 11-maskin og godkjenning gjenstår. Fase 02 startes ikke.
Dokumentasjonsoppdateringen etter kontrollen endrer ikke testet kildekode,
låsefiler eller arbeidsflyt.

Alle automatiserte kriterier i tabellen ovenfor har status **Verifisert
(Windows CI)**. Manuell Windows 11-aksept har status **Utformet – ikke kjørt**.

[Last ned røykbygget](https://github.com/RobertCygan/InvoiceFlowAI/actions/runs/39403956455/artifacts/12255622827)
