# Fase 04 – isolert PDF- og bildebehandling

| | |
|---|---|
| **Versjon** | 1.1 (2026-10-23) – erstatter 1.0 |
| **Status** | **Godkjent for implementering** 2026-10-23 (G-09): D-11 = C og promptet er godkjent av prosjekteier. |
| **Grunnlag** | F03 i `main`: generisk `documents`, innholdsadresserte originaler, karantene, ADR-0029; `docs/D11_PDF_DECISION_BRIEF.md` |

## Forutsetninger (må være avgjort før F04 starter)

1. **D-11:** Dette promptet er skrevet for alternativ **C (pypdfium2 som standardadapter)**, som anbefalt i beslutningsgrunnlaget. Velger prosjekteier A eller B, må avsnittene «PDF-adapter» og «Avhengigheter» skrives om; resten gjelder uendret.
2. **Stakkavvik:** Ved C må eier godkjenne at PyMuPDF i masterspesifikasjonen erstattes av pypdfium2 (ADR-0023 oppdateres).
3. **Godkjenning av dette promptet** (egen setning fra prosjekteier). Uten den startes ikke F04.
4. **Å-15** (prosjektets lisens og distribusjon) bør være besvart; svaret avgjør hvor mye lisenstekst som må leveres i F13.

## GOAL

Hent sideantall, tekstlag med tegnposisjoner og rasteriserte sidebilder fra lagrede originaler i en isolert arbeidsprosess, slik at en fiendtlig eller ødelagt fil aldri kan krasje, henge eller kompromittere hovedprosessen.

## CONTEXT

- F03 lagrer originaler uendret og skrivebeskyttet og leser bare signaturen. `documents` har ingen sidetall og ingen behandlingsstatus (`status` er bare `stored`/`quarantined`); behandlingsstatus hører hjemme i `processing_jobs`, ikke i `documents`.
- ADR-0010: parsing i `multiprocessing`-prosess (`spawn`) per oppgave med tidsavbrudd, minnegrense via Windows Job Object, ingen DB/nett/hemmeligheter, og JSON-resultat validert med Pydantic.
- ADR-0023 og `D11_PDF_DECISION_BRIEF.md`: all PDF-tilgang bak porten `DocumentParser`, utskiftbar adapter, felles kontraktstester.
- `SECURITY.md` §8.1 fastsetter grensene: maks 100 sider, maks 100 megapiksler per bilde (Pillow `MAX_IMAGE_PIXELS` settes eksplisitt), 300 dpi (maks 600), 120 s per dokument, 2 GB for arbeidsprosessen, kryptert PDF avvises med norsk melding, aktivt innhold utføres aldri (flagges og revisjonslogges).
- `DATA_MODEL.md` §3.2 skisserer `document_pages`, `derived_files` og `processing_jobs`. Merk at skissen av `documents` der er foreldet; gjeldende skjema er §3.10 og ADR-0029.
- Motorene (PDFium, MuPDF) er C-biblioteker med jevnlige minnesikkerhetsfeil. Isolasjonen er derfor hovedtiltaket; sikkerhetsrettinger må kunne tas inn raskt etter sikkerhetsunntaket i ADR-0024.

## INPUT

- Dokumenter med status `stored` i én eksplisitt `EntityScope`; aldri karantenefiler.
- **PDF-adapter (ved D-11 = C):** `pypdfium2` 5.13.0 (nyeste versjon utenfor karantenen per 2026-10-22; endelig versjon fastsettes ved start etter ADR-0024), hash-låst, bak `DocumentParser`. Ingen annen modul importerer et PDF-bibliotek (arkitekturtest).
- **Bilder:** Pillow og eventuelt OpenCV (`opencv-python-headless`) etter avhengighetspolicyen (ADR-0024); `Image.MAX_IMAGE_PIXELS` settes eksplisitt til grensen i `SECURITY.md`.
- **Windows Job Object:** `pywin32` (allerede planlagt i `DEPENDENCIES.md`) eller `ctypes`; valget begrunnes i en kort ADR hvis det er nytt.

## OUTPUT

- Migrasjon `0003` med `processing_jobs`, `document_pages` og `derived_files`, enhetsavgrenset (sammensatte FK-er på `entity_id` som i F03), idempotent per (dokument, steg, motorversjon, innstillingshash), uten å endre `documents`.
- Port `DocumentParser` og én adapter; arbeidsprosess (`spawn`) som bare mottar sti og forventet hash og returnerer et Pydantic-validert resultat (sideantall, per side: størrelse, rotasjon, tegn i tekstlaget, tegnposisjoner normalisert 0–1, aktivt-innhold-flagg). Tidsavbrudd og minnegrense håndheves av foreldreprosessen.
- Hovedprosessen kontrollerer SHA-256 til originalen før oppgaven sendes, og igjen at kilden ikke er endret etter behandling.
- Avledede filer (sidebilder) lagres adskilt fra originaler under egen mappe per enhet, med hash, produsent (`pypdfium2/<versjon>`) og jobb-ID. Ingen kode skriver til `originals/` eller `quarantine/`.
- Revisjonshendelser for jobbstart og jobbslutt med bare faste koder (steg, status, feilkode) – aldri dokumentinnhold, tekst eller filnavn.
- Enkel visning av sideantall og behandlingsstatus i innboksen, med norske meldinger for avvist, tidsavbrutt og mislykket.
- Dokumentasjon: ADR for arbeidsprosessen, oppdatert `SECURITY.md`, `THREAT_MODEL.md`, `TEST_STRATEGY.md`, `DATA_MODEL.md` §3.10, `DEPENDENCIES.md` (lisenstabell fra beslutningsgrunnlaget), `CHANGELOG.md` og en norsk F04-rapport med faktiske resultater.

## CONSTRAINTS

- Ingen OCR, KI eller feltuttrekk (F05–F07).
- Ingen parsing i hovedprosessen; ingen nettverk i arbeidsprosessen; ingen databasetilgang, hemmeligheter eller skriveadgang til arkivet utover sin egen utmappe.
- Ingen endring eller sletting av originaler; karantene behandles aldri.
- Ingen dokumentinnhold i logger eller revisjon; feilkoder er stabile, aldri fritekst fra dokumentet.
- Dokumentinnhold er data, aldri instruksjoner. Aktivt innhold (JavaScript, `Launch`, innebygde filer) utføres aldri.
- Nye avhengigheter bare med hash-låser, dokumentert lisens og karantene (ADR-0024).
- Kun syntetiske filer. Ingen ekte fakturaer før porten i `SECURITY.md` §17.
- Endrer ikke F00–F03 utover det migrasjon `0003` og innboks-visningen krever.

## TESTS

- **Fiendtlig korpus** (genereres av skript i testkoden, ingen nedlastede prøver; `TEST_STRATEGY.md` §4): dekompresjonsbombe (stort bilde), svært mange sider, uendelig løkke/dyp rekursjon, skadet xref, avkortet fil, 0-sidig PDF, kryptert PDF, PDF med JavaScript/`Launch`/innebygde filer, polyglotfil, enorme sider. Hovedprosessen overlever alle; jobben får `timed_out` eller `failed` med stabil feilkode, og arbeidsprosessen er avsluttet.
- **Ressursgrenser:** testene beviser at tidsavbrudd (120 s, nedskalert i test) og minnegrense faktisk avslutter prosessen, ikke bare at koden finnes. Windows Job Object testes på Windows-CI.
- **Kontraktstester for `DocumentParser`** (tekst, posisjoner, sideantall, rasterisering, feilhåndtering) som enhver adapter må bestå; en enkel falsk adapter viser at bytte er mulig.
- Idempotent gjentakelse; endret original oppdages før behandling; krasj mellom jobb og database gir ingen halv tilstand.
- Tverrenhetsisolasjon for jobber, sider og avledede filer.
- Alle F00–F03-regresjoner, Ruff, Bandit, pip-audit, Gitleaks, Windows-CI og `.exe`-selvtest. Stresskjøring av samtidighets- og krasjtester på Windows slik som i F03-etterkontrollen.
- Lever PR og norsk rapport med faktiske resultater, og oppgi hva som ikke er prøvd. Ikke begynn F05.

## Åpne spørsmål til prosjekteier (ikke antatt i promptet)

1. D-11 og stakkavviket (se «Forutsetninger»).
2. Skal programmet utføre den valgfrie Defender-skanningen (`MpCmdRun.exe`) før behandling (Å-12), eller bare forutsette sanntidsbeskyttelse?
3. Skal avledede sidebilder beholdes permanent eller kunne regenereres og ryddes? (Retensjon er ikke avgjort; F04 sletter ingenting uten egen beslutning.)
