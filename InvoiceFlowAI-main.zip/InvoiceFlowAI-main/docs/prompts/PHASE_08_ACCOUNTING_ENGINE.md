# Fase 08 – Regnskapsmotor: validering, leverandørregister og duplikatkontroll (F08a)

| | |
|---|---|
| **Versjon** | 1.0 (2026-10-24) |
| **Status** | **Autorisert for implementering** 2026-10-24 (G-12): prosjekteier ba om at F08 startes og delegerte svarene på Å-24 og F15-promptets spørsmål 2–4 til utvikleren (D-30). Innholdet i promptet er utviklerens forslag (D-31) og er ikke gjennomgått av prosjekteier eller regnskapsansvarlig før implementering. |
| **Grunnlag** | F15 i `main`: EHF-fakturaer registreres som kanoniske utkast med flagg (`invoice_findings`); F02: uforanderlige fakturarevisjoner og revisjonskjede; `DATA_MODEL.md` §3.3, §3.5 og §7 |

## Oppdeling (D-31)

Roadmapens F08 er delt i to leveranser:

- **F08a (dette promptet):**
  - valideringsmotor og regelkatalog for alle regler som bare trenger fakturaen, regnskapsenheten, leverandørregisteret og andre fakturaer i enheten;
  - leverandørregister med kontostatus;
  - duplikatkontroll;
  - visning i innboksen.
- **F08b (eget prompt senere):**
  - kontoplan, MVA-koder med gyldighet og dimensjoner (import fra CSV, Å-18);
  - konteringsforslag fra leverandørstandard og regler;
  - reglene MVA-002, ACC-001, ACC-002 og ACC-003.

  Krever eksportfiler fra ERP (Å-18).

Grunnen til oppdelingen er at F08b avhenger av referansedata som ennå ikke finnes. F08a gir verdi straks for EHF-fakturaene fra F15.

## GOAL

Hver registrerte faktura kontrolleres deterministisk mot regelkatalogen i `DATA_MODEL.md` §7. Resultatet lagres sporbart per fakturarevisjon og vises på norsk. Betalingskontoer som ikke er bekreftet for leverandøren, og mulige duplikater, gir feil som senere skal blokkere godkjenning (F09).

## CONTEXT

- Fakturaer finnes i dag bare som utkast fra EHF (F15). OCR og feltuttrekk (F05/F06) kommer senere og skal bruke samme motor.
- `invoice_findings` (F15) beskriver hva importen fant i kilden; valideringen er en egen, gjentakbar kontroll av gjeldende revisjon. Resultatet avhenger også av leverandørregisteret, andre fakturaer og dagens dato, og kan derfor endre seg uten ny revisjon.
- Godkjenning, overstyring med begrunnelse og redigering kommer i F09. F08a endrer ikke arbeidsflytstatus.

## INPUT

- Gjeldende revisjon av en faktura (`CanonicalInvoice`), regnskapsenheten, leverandørregisteret i samme enhet og header-projeksjonen av andre fakturaer i samme enhet.
- Innstillinger (`ValidationSettings`, Pydantic):
  - MVA-toleranse 0,01 per sats;
  - maks alder på fakturadato: 365 dager;
  - basisvaluta NOK.

  Innstillingene hashes og lagres med hver kjøring.
- Dagens dato fra en injisert klokke (testbar).

## OUTPUT

1. **Regelmotor (`application/validation/`):**
   - Rene funksjoner uten I/O. Hver regel har ID, versjon, alvorlighet, feltsti og en oversettelsesnøkkel.
   - Parametrene er tall, datoer eller faste koder, aldri fritekst fra dokumentet.
   - En regel som mangler grunnlag (f.eks. ingen linjer), gir intet funn. Den gjetter aldri.
   - Funnene sorteres stabilt.
2. **Regler i F08a:** se tabellen under. Kontrollsifferfunksjonene (MOD11, MOD10, MOD97) ligger i `domain/checksums.py` og testes mot kjente syntetiske verdier.

   | Regel | Kontroll | Alvorlighet |
   |---|---|---|
   | REQ-001 | Leverandørnavn, fakturanummer, fakturadato, valuta, netto, MVA og brutto finnes | Feil |
   | REQ-002 | Norsk leverandør uten organisasjonsnummer. Norsk betyr landkode NO, eller ukjent land uten utenlandsk MVA-ID. | Feil |
   | ENT-001 | Kundens organisasjonsnummer avviker fra regnskapsenhetens (bare når begge finnes) | Advarsel |
   | SUM-001 | Sum av linjenes nettobeløp = total netto (bare når alle linjer har netto) | Feil |
   | SUM-002 | Netto + MVA + øreavrunding = brutto | Feil |
   | MVA-001 | MVA per sats = grunnlag × sats, `ROUND_HALF_UP` til 2 desimaler, innenfor toleransen. Grunnlaget er MVA-spesifikasjonen, eller linjene gruppert per sats når spesifikasjonen mangler. | Feil |
   | MVA-003 | MVA > 0 fra leverandør som fakturaen oppgir som ikke MVA-registrert | Feil |
   | DAT-001 | Forfallsdato ≥ fakturadato | Feil |
   | DAT-002 | Fakturadato i fremtiden eller eldre enn grensen | Advarsel |
   | ID-001 | Organisasjonsnummer (leverandør og kunde): MOD11 med vekter 3,2,7,6,5,4,3,2 | Feil |
   | ID-002 | Kontonummer: MOD11 med vekter 5,4,3,2,7,6,5,4,3,2 | Feil |
   | ID-003 | KID: MOD10 (Luhn) eller MOD11 | Advarsel |
   | ID-004 | IBAN: ISO 13616 MOD97 | Feil |
   | DUP-001 | Annen faktura i enheten med samme leverandør (organisasjonsnummer), fakturatype og normalisert fakturanummer | Feil |
   | DUP-002 | Annen faktura med samme leverandør, brutto og fakturadato, men annet nummer | Advarsel |
   | BANK-001 | Betalingskontoen (kontonummer eller IBAN) er ikke bekreftet for leverandøren, eller den er sperret | Feil |
   | CRN-001 | Kreditnota uten referanse til opprinnelig faktura | Advarsel |
   | CUR-001 | Annen valuta enn basisvalutaen | Advarsel |

   Normalisert fakturanummer: store bokstaver, uten mellomrom og tegnene `-_./`, og uten ledende nuller.
3. **Leverandørregister** (`suppliers`, `supplier_bank_accounts`, per regnskapsenhet, `DATA_MODEL.md` §3.3):
   - Ved første kontroll av en faktura fra en ny leverandør (kjent organisasjonsnummer) opprettes leverandøren automatisk.
   - Betalingskontoen fra fakturaen registreres som `unverified`, med første faktura som kilde.
   - Bare en bevisst handling i grensesnittet setter en konto til `verified` eller `blocked`. Handlingen krever bekreftelse, revisjonsføres med bruker og tid, og kan aldri gjøres av motoren.
   - Kontonummer og leverandørkobling er uforanderlige.
4. **Lagring** (migrasjon `0005`):
   - `validation_runs`: enhet, faktura, revisjon, regelsettversjon, innstillingshash, tid, aktør og antall per alvorlighet;
   - `validation_results`: kjøring, regel-ID og -versjon, alvorlighet, feltsti, meldingsnøkkel, parametre som JSON fra faste typer.

   Begge er kun tilføyelse, med sammensatte FK-er på `entity_id`. Gjeldende resultat er siste kjøring for gjeldende revisjon. Statusfeltene `open`/`resolved`/`overridden` fra skissen i §3.5 kommer i F09 som egen tabell med overstyringer.
5. **Tjeneste (`ValidationService`):**
   - **Når valideringen kjører:**
     - automatisk etter at en EHF-faktura er registrert;
     - på forespørsel («Kontroller på nytt»);
     - for leverandørens fakturaer etter at en konto er bekreftet eller sperret.
   - **Hva kjøringen skriver:** kjøring, resultater, eventuell ny leverandør og konto, og revisjonshendelsen `invoice.validated` (bare regelsettversjon og antall per alvorlighet) i én Unit of Work.
6. **Grensesnitt:**
   - Innboksen får kolonnen «Kontroll» («OK», «2 feil, 1 advarsel») og knappen «Vis kontroll» med en liste over funn på norsk.
   - Ny side «Leverandører» viser leverandører og kontoer med status, og har knappene «Bekreft konto» og «Sperr konto». Begge krever bekreftelse.
   - Alle meldinger kommer fra oversettelseskatalogen.
7. **Dokumentasjon:**
   - ADR-0033 (valideringsmotor, lagring per kjøring, leverandørregister og kontostatus);
   - `DATA_MODEL.md`, `SECURITY.md`, `THREAT_MODEL.md` (betalingssvindel), `TEST_STRATEGY.md`, `CHANGELOG.md`;
   - norsk F08a-rapport med faktiske resultater.

## CONSTRAINTS

- `Decimal` med eksplisitt `ROUND_HALF_UP`, aldri `float`. Ingen beløp, navn, kontonumre eller fritekst i logg eller revisjon.
- Motoren retter aldri verdier og endrer aldri revisjoner eller arbeidsflytstatus. Ingen automatisk bekreftelse av konto, godkjenning, bokføring eller eksport.
- Ingen nettverk (f.eks. oppslag i Enhetsregisteret). Det krever egen ADR og samtykke.
- Alt er avgrenset til én regnskapsenhet. Duplikat- og kontosøk skjer aldri på tvers av `entity_id`.
- MVA-satser er ikke konstanter i koden. MVA-001 bruker satsen som står på fakturaen. Kontroll mot gyldige satser (MVA-002) kommer med MVA-kodene i F08b.

## TESTS

- Hver regel: positivt og negativt tilfelle og grensetilfeller (toleranse nøyaktig 0,01 og 0,02, dato lik grensen, ledende nuller i fakturanummer, kreditnota med negative linjer). Dekning ≥ 95 % for `application/validation/` og `domain/checksums.py`.
- Kontrollsiffer mot syntetiske og offentlig dokumenterte eksempelverdier.
- **Tjeneste:**
  - automatisk kontroll etter EHF-import;
  - idempotens, slik at en ny kjøring gir en ny rad og ikke endrer gamle;
  - BANK-001 før og etter bekreftelse og ved sperring;
  - DUP-001 og DUP-002 innen enheten, men aldri på tvers av enheter;
  - krasj før commit etterlater ingenting.
- Migrasjon `0004 → 0005` med F15-data og utløsere for kun tilføyelse.
- GUI: kolonnen «Kontroll», funnlisten og leverandørsiden med bekreftelsesdialog (offscreen).
- Alle F00–F15-regresjoner, Ruff, Bandit, pip-audit, Gitleaks, Windows-CI og `.exe`-selvtest.

## Åpne spørsmål (ikke antatt)

1. Regnskapsansvarlig bør bekrefte alvorlighetene og standardene (toleranse, aldersgrense) før porten for ekte data.
2. Å-18 (kontoplan og MVA-koder fra ERP) må besvares før F08b.
3. Å-08: utenlandske leverandører og omvendt avgiftsplikt. F08a gir bare CUR-001 og REQ-002 og ingen egen regel for omvendt avgiftsplikt.
