# InvoiceFlow AI – Prompt for Fase 01: Windows-applikasjonsskjelett

| | |
|---|---|
| **Fase** | 01 – Windows-applikasjonsskjelett |
| **Forutsetning** | Fase 00 godkjent av prosjekteier, og alle beslutninger merket «Blokkerer Fase 01» i `docs/PHASE_00_DECISION_REGISTER.md` godkjent |
| **Versjon** | 1.1 – oppdatert i sluttrevisjonen av Fase 00 |
| **Kommando** | `#BUILD` (etter eventuell `#PLAN`) |
| **Språk** | Kode og kodedokumentasjon på engelsk. Brukergrensesnitt, rapport og prosjektdokumentasjon på norsk bokmål. |

> Denne prompten er leverandørnøytral. Les `AGENTS.md` og dokumentene i `docs/` før arbeidet starter. Ikke dikt opp manglende detaljer – registrer dem som åpne spørsmål. Rapporter aldri tester, bygg eller verktøy som bestått uten at de faktisk er kjørt.

---

## 1. GOAL – Mål

Lag et kjørbart, minimalt **Windows 11-skrivebordsskall** for InvoiceFlow AI med PySide6 og den tverrgående infrastrukturen som alle senere faser bygger på:

oppstart og komposisjonsrot · oppstartskonfigurasjon · datakatalog og stier · strukturert, maskert logging · global feilhåndtering · sentral norsk tekstkatalog med formatering av beløp og datoer · hovedvindu med navigasjon og plassholdere · én-instans-lås · selvtest-modus · PyInstaller *onedir*-røykbygg.

Fasen skal **ikke** inneholde forretningsfunksjonalitet.

## 2. CONTEXT – Kontekst

Tilstand etter Fase 00:

- Dokumentasjon: `docs/MASTER_SPECIFICATION.md`, `ARCHITECTURE.md` (lag, avhengighetsregler, prosessmodell, Windows-hensyn), `SECURITY.md` (loggingspolicy §7, nettverk §3), `DECISIONS.md`, `DEPENDENCIES.md`, `TEST_STRATEGY.md`.
- Revisjon: `docs/PHASE_00_AUDIT.md`, `docs/PHASE_00_DECISION_REGISTER.md`, `docs/PHASE_00_ACCEPTANCE.md`.
- Kode: `src/invoiceflow/__init__.py` (versjon, eneste kilde) og `src/invoiceflow/domain/` (kanoniske Pydantic-kontrakter med strenge typer og kanonisk tallform, ADR-0025). Ingen UI, database eller adaptere.
- Repo: `RobertCygan/InvoiceFlowAI`, standardgren `main`.
- Tester: `tests/unit/domain/` (140 tester totalt i repoet etter revisjonen), `tests/architecture/test_import_rules.py`, `tests/test_project_documents.py`.
- Verktøy: `pyproject.toml` (pytest med `filterwarnings=error` og `--strict-markers`, ruff, Bandit, coverage), `requirements/dev.lock.txt` (hasher, 30 dagers karantene), `.github/workflows/ci.yml` (Windows-jobb i bash med `-eo pipefail`; Gitleaks på full historikk).
- Relevante beslutninger: ADR-0001 (porter/adaptere), ADR-0002 (Python 3.13), ADR-0006 (`%LOCALAPPDATA%\InvoiceFlowAI`), ADR-0014 (onedir), ADR-0015 (oversettelseskatalog), ADR-0018 (CI), ADR-0022 (regnskapsenhet – ikke i bruk i F01, men stier må ikke hindre den), ADR-0024 (avhengighetsoppdatering).

## 3. INPUT – Inndata

### 3.1 Kommandolinje

| Argument | Betydning |
|---|---|
| *(ingen)* | Start grensesnittet |
| `--self-test` | Kjør selvtest uten synlig vindu (Qt-plattform `offscreen`), skriv norsk resultat til stdout, avslutt med kode 0 eller 1 |
| `--data-dir <sti>` | Overstyr datakatalog (brukes av tester og selvtest) |

Ukjente argumenter → norsk feilmelding, avslutningskode 2.

### 3.2 Miljø

- `LOCALAPPDATA` – grunnlag for standard datakatalog `%LOCALAPPDATA%\InvoiceFlowAI`. Mangler variabelen (f.eks. i et Linux-utviklingsmiljø), kreves `--data-dir`; stien gjettes ikke.
- `OneDrive`, `OneDriveCommercial`, `OneDriveConsumer` – brukes for å oppdage om datakatalogen ligger i en synkronisert mappe.

### 3.3 Oppstartskonfigurasjon

Fil: `<datakatalog>\config\config.json` (UTF-8). Pydantic-modell `BootstrapConfig` med `extra="forbid"`:

```json
{
  "schema_version": 1,
  "log_level": "INFO",
  "locale": "nb-NO"
}
```

| Felt | Type | Regler |
|---|---|---|
| `schema_version` | int | Må være `1` |
| `log_level` | str | `DEBUG`, `INFO`, `WARNING`, `ERROR` |
| `locale` | str | Kun `nb-NO` støttes |

### 3.4 Unntakstilfeller

| Tilfelle | Forventet oppførsel |
|---|---|
| `config.json` mangler | Opprett standardfil atomisk (skriv til midlertidig fil + `os.replace`) |
| Ugyldig JSON, ukjent felt eller ugyldig verdi | Stopp oppstart med norsk melding og feilkode `CONFIG_INVALID`, avslutningskode 2. **Filen overskrives ikke.** |
| Felt som ligner hemmeligheter (`api_key`, `password`, `token`) | Avvises av `extra="forbid"` |
| Datakatalog kan ikke opprettes/skrives | Norsk melding, feilkode `DATA_DIR_UNAVAILABLE`, avslutningskode 2 |
| Datakatalog ligger under OneDrive | Advarsel i grensesnitt og logg (`DATA_DIR_SYNCED`); oppstart fortsetter |
| Applikasjonen kjører allerede | Norsk melding, avslutningskode 3 (lås med `QLockFile` i datakatalogen) |
| Uventet unntak | Logg (renset), vis norsk feildialog med feilkode og korrelasjons-ID, ingen stakkspor i dialogen |

## 4. OUTPUT – Utdata

### 4.1 Filer (forslag – avvik begrunnes i rapporten)

```text
src/invoiceflow/
├── __main__.py               main(): freeze_support(), argumenter, oppstart, avslutningskoder
├── bootstrap/
│   ├── __init__.py
│   ├── app.py                komposisjonsrot: konfig → stier → logging → i18n → Qt → hovedvindu
│   ├── logging_setup.py      JSON-linjer, RotatingFileHandler (10 MB × 5), maskeringsfilter
│   └── self_test.py          selvtest
├── config/
│   ├── __init__.py
│   ├── settings.py           BootstrapConfig, lasting/oppretting
│   └── paths.py              AppPaths (data, config, logs, documents, inbox, exports) – kun
│                             rotkataloger; per-enhet-underkataloger lages i F02/F03 (ADR-0022);
│                             OneDrive-deteksjon
├── application/
│   ├── __init__.py
│   └── errors.py             InvoiceFlowError(code, message_key, params), ConfigError
├── security/
│   ├── __init__.py
│   └── redaction.py          maskering av orgnr, kontonummer, KID, IBAN, e-post, fødselsnummer
├── i18n/
│   ├── __init__.py           t(key, **params)
│   ├── catalog_nb_no.py      alle norske tekster (nøkkel → tekst)
│   └── formatting.py         format_amount, format_date, format_percent (kun Decimal/date)
└── ui/
    ├── __init__.py
    ├── main_window.py        QMainWindow, navigasjon, sider (QStackedWidget)
    ├── pages.py              plassholdersider
    ├── dialogs.py            Om-dialog, feildialog
    └── widgets.py            hjelpere, f.eks. plain_label() som alltid setter Qt.PlainText
packaging/
├── invoiceflow.spec          PyInstaller onedir, navn InvoiceFlowAI
└── README.md                 byggeinstruks (PowerShell)
tests/
├── unit/config/ · unit/i18n/ · unit/security/ · unit/bootstrap/
├── gui/                      pytest-qt, offscreen
├── security/                 nettverksblokkering, logginnhold, konfig-hemmeligheter
└── architecture/             utvidede importregler
```

### 4.2 Observerbar oppførsel

1. `python -m invoiceflow` åpner hovedvinduet med tittel **«InvoiceFlow AI»**.
2. Venstre navigasjon med sidene: **Oversikt**, **Innboks**, **Skanning**, **Gjennomgang**, **Eksport**, **Innstillinger**. Hver side viser sidetittel og teksten «Denne funksjonen kommer i en senere fase.»
3. Meny **Fil → Avslutt** og **Hjelp → Om InvoiceFlow AI** (versjon fra `invoiceflow.__version__`, datakatalog, merknad om lokal behandling).
4. Statuslinje: «Lokal modus – ingen data sendes ut.»
5. Logg `logs\invoiceflow.log` med JSON-linjer, minst hendelsene `app.started` og `app.stopped`, uten personopplysninger eller fakturadata.
6. `python -m invoiceflow --self-test` skriver «Selvtest bestått» og returnerer 0; ved feil «Selvtest feilet: <feilkode>» og 1.
7. `dist\InvoiceFlowAI\InvoiceFlowAI.exe --self-test` gir samme resultat (PyInstaller onedir).
8. Formatering:
   - `format_amount(Decimal("1234.5"))` → `"1 234,50"` (tusenskille U+00A0)
   - `format_amount(Decimal("-0.005"))` → `"-0,01"` (`ROUND_HALF_UP`)
   - `format_date(date(2026, 10, 1))` → `"01.10.2026"`
   - `format_percent(Decimal("25"))` → `"25 %"` (U+00A0)
   - `int` godtas (eksakt); `float` og `bool` som argument → `TypeError`

### 4.3 Dokumentasjon og konfigurasjon som oppdateres

- `pyproject.toml`: `PySide6` (6.11.x) som avhengighet; `pytest-qt` (4.5.x) i `dev` (godkjent, D-08); ny ekstra `packaging` med `pyinstaller` (6.22.x); `[project.scripts]`/`gui-scripts` ved behov.
- Låsefiler regenerert etter ADR-0024: `requirements/runtime.lock.txt` (kun kjøretid) og `requirements/dev.lock.txt` (inkl. `packaging`-ekstra).
- `.github/workflows/ci.yml`: GUI-tester med `QT_QPA_PLATFORM=offscreen`; ny jobb som bygger onedir på `windows-latest` og kjører `--self-test`.
- Forsyningskjede i CI (funn F-14 i `PHASE_00_AUDIT.md`): lås GitHub Actions til commit-SHA (med versjon i kommentar), fest forventet SHA-256 for Gitleaks-arkivet i arbeidsflyten, og legg til `.github/dependabot.yml` for `github-actions` og `pip`.
- `docs/ARCHITECTURE.md` (status, faktisk struktur), `DEPENDENCIES.md`, `DECISIONS.md` (nye ADR-er ved behov), `TEST_STRATEGY.md` (§10 bevis), `CHANGELOG.md`, `README.md` (kjøre-/byggeinstruks).

## 5. CONSTRAINTS – Begrensninger

### 5.1 Avgrensning

- **Ikke** database/SQLAlchemy, dokumentimport, PDF, OCR, skanner, KI, regnskap eller eksport.
- **Ikke** endelig grafisk design; enkelt, ryddig og tilgjengelig (tastaturnavigasjon, fokusrekkefølge).
- Ingen spekulative tjenester eller porter som ikke brukes i denne fasen.
- Ingen regnskapsenhet, enhetsvalg eller enhetsadministrasjon i grensesnittet (kommer med databasen i F02).

### 5.2 Arkitektur

- Følg avhengighetsreglene i `ARCHITECTURE.md` §2.1. Utvid `tests/architecture/test_import_rules.py`:
  - `i18n` importerer bare standardbiblioteket.
  - `application` og `config` importerer ikke `PySide6`.
  - `ui` importerer ikke `persistence` eller `sqlalchemy`.
  - `domain` uendret.
- Kun `bootstrap` kobler sammen konkrete komponenter.
- Qt-hovedtråden gjør ingen blokkerende I/O ut over oppstart.

### 5.3 Språk og tekst

- **All** brukerrettet tekst hentes via `t(key)` fra `catalog_nb_no.py`. Ingen strenglitteraler med brukertekst i `ui/`.
- Beløp formateres kun fra `Decimal` (aldri `QLocale.toString(float)`); avrunding `ROUND_HALF_UP`.
- Etiketter som senere skal vise dokumentdata settes til `Qt.PlainText` via felles hjelpefunksjon.
- Vurder om Qt har norsk (`nb`) oversettelse for standardknapper; hvis ikke, sett knappetekster eksplisitt fra katalogen. Dokumenter funnet.

### 5.4 Sikkerhet

- Ingen nettverkskall, telemetri eller oppdateringssjekk. Ingen import av HTTP-klienter.
- Ingen hemmeligheter i kode, konfigurasjon, logger eller tester.
- Logging etter `SECURITY.md` §7; maskeringsfilter aktivt på alle handlere; unntak logges som type + feilkode + renset melding.
- Feildialoger viser aldri stakkspor, filinnhold eller fulle stier med brukernavn.
- Skriv bare innenfor datakatalogen. Ingen registerendringer, ingen administratorrettigheter.
- Nye avhengigheter: kun de som er nevnt i §4.3; lisens og versjon føres i `DEPENDENCIES.md`.

### 5.5 Windows-kompatibilitet

- Python 3.13 x64, Windows 11. `pathlib` overalt; `encoding="utf-8"` på all fil-I/O.
- `multiprocessing.freeze_support()` først i `main()` under `if __name__ == "__main__":`.
- PyInstaller *onedir*; Qt-plattformtillegget `offscreen` må være med i bygget (for selvtest) – verifiser.
- Høy DPI skal fungere uten egne innstillinger (Qt 6-standard).

### 5.6 Git og leveranse

- Arbeid på egen gren (f.eks. `claude/phase01-windows-skeleton`) opprettet fra `main`. Én eller flere commits med beskrivende meldinger.
- Kontroller `git remote -v` før push: kun `RobertCygan/InvoiceFlowAI`. Aldri direkte push til `main`, aldri force-push.
- Lever som pull request mot `main`. PR-en er klar til godkjenning først når CI (Windows-jobb, Gitleaks, eventuell byggejobb) er grønn.

### 5.7 Kvalitet

- Ruff, Bandit og pip-audit uten funn. `filterwarnings = error` beholdes.
- Ingen `float` for beløp; ingen tidssone-naive `datetime` (ruff `DTZ`).
- Små, testbare funksjoner; docstrings på engelsk.

## 6. TESTS – Tester og akseptansekriterier

### 6.1 Enhetstester

| Område | Tilfeller |
|---|---|
| `BootstrapConfig` | Standardverdier; gyldig fil; ugyldig JSON → `CONFIG_INVALID`; ukjent felt; `api_key` avvises; feil `schema_version`; ugyldig fil overskrives ikke; manglende fil opprettes atomisk |
| `AppPaths` | `LOCALAPPDATA` (monkeypatch) → `…\InvoiceFlowAI`; `--data-dir` overstyrer; underkataloger opprettes; OneDrive-sti gir advarsel; utilgjengelig katalog → `DATA_DIR_UNAVAILABLE` |
| `i18n` | Alle nøkler har ikke-tom tekst; parametere settes inn; manglende nøkkel gir feil i tester; ingen duplikatverdier som tyder på kopifeil (valgfritt) |
| `formatting` | Eksemplene i §4.2 punkt 8; null; store beløp (13 sifre); negative; `int` godtas, `float`/`bool` gir `TypeError`; datoer i januar/desember |
| `redaction` | Maskerer `123456785`, `12345678903`, `1234.56.78903`, `NO7112345678903`, e-post og 11-sifret fødselsnummer; endrer ikke UUID-er, feilkoder eller tidsstempler |
| `errors` | `InvoiceFlowError` bærer `code`, `message_key`, `params`; oversettes til norsk |
| `__main__` | Avslutningskoder 0/1/2/3 for hhv. OK, uventet feil, konfig-/argumentfeil, allerede kjørende |

### 6.2 GUI-tester (pytest-qt, `QT_QPA_PLATFORM=offscreen`)

- Hovedvindu har tittel «InvoiceFlow AI» og seks navigasjonsvalg i riktig rekkefølge med norske navn.
- Klikk/tastatur på hvert navigasjonsvalg viser riktig side.
- **Alle synlige tekster** (vindustittel, menyer, handlinger, etiketter, statuslinje, verktøytips) i hovedvinduet finnes i tekstkatalogen – testen går gjennom widget-treet.
- Etiketter laget med `plain_label()` har `Qt.PlainText`; en etikett som får teksten `<b>x</b>` viser den bokstavelig.
- Om-dialogen viser versjonen.
- Feildialogen viser feilkode og korrelasjons-ID, men ikke stakkspor.

### 6.3 Sikkerhetstester (`security`)

- Selvtesten består med `socket.socket.connect` og `socket.create_connection` erstattet av funksjoner som kaster unntak.
- Etter selvtest inneholder loggfilen ingen av testverdiene i §6.1 `redaction` i klartekst.
- `config.json` med `{"api_key": "x"}` avvises og forblir uendret.
- Ingen modul i `src/` importerer `requests`, `httpx`, `urllib.request`, `http.client` eller `socket` (arkitekturtest).

### 6.4 Integrasjon og pakking

- CI (`windows-latest`): alle tester, ruff, Bandit, pip-audit, Gitleaks grønne.
- CI-jobb: `pyinstaller packaging\invoiceflow.spec` → `dist\InvoiceFlowAI\InvoiceFlowAI.exe --self-test` returnerer 0.
- Manuell aksept på Windows 11 (prosjekteier):
  1. `python -m invoiceflow` viser norsk hovedvindu innen 5 sekunder.
  2. Andre samtidige start gir norsk melding og avsluttes.
  3. Lukking skriver `app.stopped` i loggen.
  4. Bygget `.exe` starter på samme maskin.

### 6.5 Regresjon

- Alle tester fra Fase 00 består uendret.
- Dekning ≥ 90 % for nye moduler utenfor `ui/`; `ui/` dekkes av røyktestene over.

### 6.6 Rapport (på norsk)

Avslutt med en rapport som for hvert akseptansekriterium oppgir status (**Utformet / Implementert / Testet / Verifisert**), kommando og faktisk resultat, samt åpne spørsmål og avvik fra denne prompten. Windows-spesifikke punkter er **Verifisert** bare når de er kjørt på Windows (lokalt eller i CI).


## Arkitekturforutsetning – fremtidig dokumentarkiv

Prosjekteier ønsker senere et søkbart arkiv for fakturaer, kreditnotaer, kvitteringer, avtaler, betalingsbekreftelser og leverandørkorrespondanse. F01 skal bare bevare utvidbarhet og tydelige modulgrenser; **ikke** implementere dokumentarkiv, søkeindeks eller ekstra dokumentarbeidsflyter. Se `docs/DOCUMENT_ARCHIVE_SCOPE.md`.
