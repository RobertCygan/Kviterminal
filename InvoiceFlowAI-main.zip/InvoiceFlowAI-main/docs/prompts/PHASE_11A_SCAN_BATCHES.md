# Fase 11a – Skannede bunker uten skannerdriver

| | |
|---|---|
| **Versjon** | 1.0 (2026-10-24) |
| **Status** | **Autorisert for implementering** 2026-10-24 (G-21, «zrób najpierw część bez sprzętu»). Innholdet er utviklerens forslag (D-36) og er ikke gjennomgått av prosjekteier. Skannermodellen (Å-01) er ikke kjent; WIA, profiler, ADF og dupleks kommer i F11b. |
| **Grunnlag** | F03 (import og innboks, D-23), F04 (sideanalyse i isolert arbeidsprosess, ADR-0031), `CanonicalInvoice.first_page`/`last_page` (én bunke kan inneholde flere fakturaer) |

## GOAL

En bunke fakturaer kan skannes som én fil med hvilken som helst skanner som lagrer PDF eller TIFF i en mappe. Programmet leser inn ferdige filer selv, finner blanke sider og skilleark, og viser hvordan bunken deles i fakturaer. Ingenting slettes, og originalen er alltid hel.

## CONTEXT

- Roadmapen nevner overvåket mappe som reserve for WIA. Uten kjent skannermodell er den den eneste veien som kan bygges og testes nå.
- Sideanalysen (F04) gjengir hver side som bilde i arbeidsprosessen. Mørkhet kan måles der uten nye avhengigheter.
- Fakturaer fra en bunke blir sideintervaller i samme dokument (`first_page`/`last_page`), ikke nye filer.

## OUTPUT

1. **Målinger i arbeidsprosessen:**
   - andel mørke piksler (‰) innenfor en marg på 5 %, og i det sentrale området (20–80 % bredde, 30–70 % høyde);
   - målt på en gråtonekopi på høyst 512 piksler, der en piksel under 200 regnes som mørk;
   - lagres i `document_pages` (migrasjon `0010_page_metrics`). Motorversjonen får tillegget `+side1`, så dokumenter analyseres på nytt.
2. **Klassifisering** (rene funksjoner, `application/scan/model.py`):
   - skilleark: sentralt område minst 850 ‰ og siden totalt 150–650 ‰;
   - blank: høyst 3 ‰ og uten tekstlag;
   - ellers innhold.

   Deler er sider mellom skilleark, uten blanke sider i kantene. Blanke sider inne i en del blir stående og listes. Uten målinger er hele dokumentet én del.
3. **Skilleark:** en PDF (A4) med en stor svart boks over det sentrale området og en instruksjon på norsk, skrevet uten PDF-bibliotek.
4. **Overvåket skannemappe** (innboksmappen):
   - en fil leses inn først når størrelse og endringstid er uendret siden forrige titt (og den er minst 2 sekunder gammel);
   - midlertidige filer (`~`, `.`), lenker og tomme filer ignoreres;
   - vanlig import (signatur, størrelse, duplikat, karantene);
   - deretter flyttes filen til `importert` (lest inn eller kjent) eller `avvist` (avvist eller karantene); ved teknisk feil blir den liggende;
   - nye dokumenter analyseres.
5. **Siden «Skanning»:**
   - skannemappen;
   - «Overvåk skannemappen» (hvert 10. sekund), «Se etter nye filer nå» og «Lagre skilleark»;
   - tabell over flersidige dokumenter med deler, blanke sider og skilleark.
6. **Dokumentasjon:** ADR-0038, `DATA_MODEL.md`, `SECURITY.md`, `THREAT_MODEL.md`, `TEST_STRATEGY.md`, `CHANGELOG.md` og rapport.

## CONSTRAINTS

- Ingen skannerdriver, ingen nye avhengigheter, ingen nettverk.
- Bildebehandling bare i arbeidsprosessen (Pillow i `processing/image_pillow.py`).
- Originaler endres eller deles aldri. Delene beregnes og lagres ikke; de blir sideintervaller for fakturaer når OCR og feltuttrekk finnes (F05/F06).
- Filer i skannemappen er ikke-klarert inndata, som all annen import.

## TESTS

- **Klassifisering:** alle sidetyper og grenseverdier; oppdeling med skilleark først, etter hverandre og til slutt; bare blanke sider; umålte sider.
- **Målinger** i ekte arbeidsprosess: PDF ved 72, 150 og 300 dpi, og skannet TIFF uten tekstlag med støy og et litt forskjøvet skilleark.
- **Skannemappe:**
  - stabilitet og alder;
  - midlertidige filer, lenker og mapper;
  - flytting uten overskriving;
  - feil.
- **Tjeneste:**
  - innlesing, flytting og analyse;
  - duplikat;
  - avvist fil;
  - tverrenhet;
  - skilleark.
- **Felles:**
  - migrasjon `0009 → 0010`;
  - GUI offscreen;
  - selvtest, også `.exe`;
  - Ruff, Bandit, pip-audit, Gitleaks og Windows-CI.

## Åpne spørsmål

1. Å-01: skannermodell og grensesnitt (WIA eller TWAIN). Først da kan F11b bygges og testes, og grenseverdiene justeres med ekte skann.
2. Skal blanke sider tas ut av originalen ved lagring? Forslag: nei. Originalen er beviset; blanke sider hoppes over i senere trinn.
