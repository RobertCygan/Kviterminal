# Fase 09 – Gjennomgang og godkjenning

| | |
|---|---|
| **Versjon** | 1.0 (2026-10-24) |
| **Status** | **Autorisert for implementering** 2026-10-24 (G-13, «etter tur» etter F08b). Innholdet er utviklerens forslag (D-33) og er ikke gjennomgått av prosjekteier eller regnskapsansvarlig. |
| **Grunnlag** | F08a/F08b: kontrollkjøringer (ADR-0033), referansedata og konteringsforslag (ADR-0034); F02: uforanderlige revisjoner med innholdshash (ADR-0026); `DATA_MODEL.md` §3.5 (`approvals`) |

## GOAL

En person gjennomgår hver faktura med kilde og kontroll, retter verdier, overstyrer avvik med begrunnelse og godkjenner eller avviser. En godkjenning er bundet til nøyaktig det innholdet som ble godkjent (innholdshash). Endring etter godkjenning opphever den. BANK-001 og DUP-001 kan ikke overstyres og blokkerer godkjenning.

## CONTEXT

- Fakturaer er utkast (`workflow_status = draft`) med konteringsforslag og kontrollkjøringer. Eksport (F10) skal bare ta godkjente fakturaer.
- Alle verdier har proveniens. En manuell verdi får `manual` med produsent `bruker/lokal` og tidspunkt, og tidligere bevis beholdes.
- Brukeren er den lokale Windows-brukeren. Aktøren er den tekniske `user/local` (Å-10, SECURITY §18).

## OUTPUT

1. **Lagring** (migrasjon `0007_review`):
   - `approvals`: kun tilføyelse. Kolonner: faktura, revisjon, `content_sha256`, `decision` (`approved`, `rejected`, `revoked`), kontrollkjøringen som lå til grunn, valgfri kommentar, tid og aktør. En godkjenning kan bare skrives for gjeldende revisjon og hash (utløser).
   - `finding_overrides`: kun tilføyelse. Kolonner: faktura, revisjon, regel, feltsti, meldingsnøkkel, begrunnelse (10–500 tegn, ren tekst), tid og aktør. BANK-001 og DUP-001 avvises av databasen.
   - Utløsere på `invoices`: `approved` krever en godkjenning med samme revisjon og hash, og innholdet kan ikke endres mens statusen er `approved`.
2. **Tjenesten `ReviewService`:**
   - Retting av felt fra en fast liste: hode, betaling, totaler og konteringslinjer. Norske tall og datoer tolkes strengt. Rettingen gir en ny revisjon med manuell proveniens og deretter en ny kontroll.
   - Overstyring av et feilfunn med begrunnelse.
   - Godkjenning:
     - fakturaen kontrolleres på nytt i samme transaksjon;
     - blokkert hvis det finnes et feilfunn som ikke er overstyrt, eller BANK-001 eller DUP-001;
     - krever forventet revisjon (sammenlign-og-sett).
   - Avvisning med kommentar og oppheving av godkjenning.
   - En ny revisjon av en godkjent faktura opphever godkjenningen automatisk (`revoked`, status `draft`).
3. **Revisjon:**
   - `invoice.approved` (revisjon, hash, kjøring, antall overstyringer), `invoice.rejected`, `invoice.approval_revoked` og `finding.overridden` (regel og revisjon).
   - Aldri begrunnelser, kommentarer eller fakturainnhold.
4. **Grensesnitt** (siden «Gjennomgang»):
   - Liste over fakturaer med status og kontroll.
   - For valgt faktura:
     - felt med verdi og kilde, og retting av valgt felt;
     - konteringslinjer;
     - funn med «Overstyr»;
     - knappene «Godkjenn», «Avvis» og «Opphev godkjenning»;
     - historikk over revisjoner og beslutninger;
     - forhåndsvisning av første side av fakturaens PDF-visning (vedlegg analysert i F04) når den finnes, med markering av kildeområdet for felt som har en kildeboks.
   - All dokumenttekst vises som ren tekst. Knappene har hurtigtaster, og hele siden kan brukes med tastaturet.
5. **Dokumentasjon:** ADR-0035, `DATA_MODEL.md`, `SECURITY.md`, `THREAT_MODEL.md`, `TEST_STRATEGY.md`, `CHANGELOG.md` og en norsk rapport.

## CONSTRAINTS

- Ingen bokføring, betaling eller eksport. Godkjenning er bare en beslutning i InvoiceFlow.
- Godkjenningen er bundet til hash. All endring går gjennom nye revisjoner. Ingen rad i `approvals` eller `finding_overrides` endres eller slettes.
- Begrunnelser og kommentarer er brukerens tekst. De lagres bare i databasen og aldri i logg eller revisjonskjede.
- Alt er avgrenset til én regnskapsenhet.

## TESTS

- **Regler for godkjenning:**
  - blokkert av feilfunn uten overstyring, av BANK-001 og av DUP-001;
  - tillatt etter overstyring;
  - foreldet revisjon gir konflikt;
  - en endring etter godkjenning opphever den;
  - avvisning og oppheving;
  - utløsere mot manipulering.
- **Retting:** hver felttype med norske og ugyldige formater; proveniens og bevis; ny kontroll.
- **Migrasjon og tverrenhet:** migrasjon `0006 → 0007`, tverrenhetsisolasjon og krasj før commit.
- **GUI** (offscreen):
  - liste og detaljer;
  - retting, overstyring, godkjenning og avvisning;
  - forhåndsvisning med og uten PDF;
  - tastatur.
- **Felles:** alle tidligere regresjoner, Ruff, Bandit, pip-audit, Gitleaks, Windows-CI og `.exe`-selvtest (med godkjenning).

## Åpne spørsmål

1. Å-10: holder Windows-påloggingen som identitet, eller trengs app-PIN eller to personer (attestasjon og anvisning)?
2. Skal flere feil enn BANK-001 og DUP-001 være umulige å overstyre, for eksempel SUM-002 eller ACC-001?
