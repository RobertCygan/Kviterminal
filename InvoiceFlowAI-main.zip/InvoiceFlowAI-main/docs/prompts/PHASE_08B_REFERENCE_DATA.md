# Fase 08b – Referansedata og konteringsforslag

| | |
|---|---|
| **Versjon** | 1.0 (2026-10-24) |
| **Status** | **Autorisert for implementering** 2026-10-24 (G-13). Prosjekteier ba om F08b og F09 «etter tur». Innholdet er utviklerens forslag (D-32) og er ikke gjennomgått av prosjekteier eller regnskapsansvarlig. Å-18 er fortsatt åpen: ekte eksportfiler fra ERP mangler, så alt er bygget og testet med syntetiske filer. |
| **Grunnlag** | F08a i `main`: regelmotor, leverandørregister og kontrollkjøringer (ADR-0033). Kanonisk modell med `accounting_lines` (ADR-0003). `DATA_MODEL.md` §3.3 og §7. |

## GOAL

Regnskapsenheten får sin egen kontoplan, MVA-koder med gyldighet og dimensjoner, importert fra fil. Leverandører kan få standardkontering. Hver faktura får et konteringsforslag som et menneske kan kontrollere, og reglene MVA-002 og ACC-001–003 kontrollerer forslaget mot referansedataene.

## CONTEXT

- Satser og koder er **data med gyldighet** per regnskapsenhet, aldri konstanter i koden (`DATA_MODEL.md` §3.3). Kodene følger enhetens ERP (Tripletex, Xledger, Unit4) og kan være SAF-T-standardkoder eller egne koder.
- Å-18 er ikke besvart. Formatet under er derfor et eget, enkelt CSV-format som et regneark eller en ERP-eksport kan lagres i. Tilpasning til et bestemt ERP-format kommer når eksempelfiler finnes.
- Konteringsforslaget er et forslag. Det bokføres aldri og eksporteres ikke før godkjenning (F09, F10).

## INPUT

CSV-filer (UTF-8, valgfri BOM, semikolon som skilletegn, første linje med kolonnenavn, høyst 5 MB og 20 000 rader):

| Fil | Kolonner (navn på norsk, rekkefølgen er fri) |
|---|---|
| Kontoplan | `konto` (1–20 tegn `[0-9A-Za-z._-]`), `navn`, valgfritt `mva_kode` og `aktiv` (`ja`/`nei`, standard `ja`) |
| MVA-koder | `kode`, `sats` (prosent, f.eks. `25` eller `11,11`), `retning` (`inngående`/`utgående`), `gyldig_fra` (`ÅÅÅÅ-MM-DD` eller `DD.MM.ÅÅÅÅ`), valgfritt `gyldig_til`, `saft_kode` og `navn` |
| Dimensjoner | `dimensjon` (`kostnadssted`, `avdeling`, `prosjekt`), `kode`, `navn` og valgfritt `aktiv` |

## OUTPUT

1. **Import** (`application/reference/`):
   - Hele filen leses og valideres med Pydantic før noe lagres. Én feil avviser hele filen, med en norsk melding som oppgir linjenummer og kolonne, men aldri innholdet.
   - Duplikate nøkler avvises. For MVA-koder er nøkkelen kode og overlappende gyldighet.
   - En vellykket import er et nytt **øyeblikksbilde** (`reference_imports`) med filens SHA-256, antall rader, tid og aktør. Gjeldende data er siste import av hver type. Tidligere import beholdes uendret.
   - Revisjonshendelsen `reference.imported` inneholder type, antall og hash, aldri innhold.
2. **Leverandørstandard** (`supplier_defaults`):
   - konto, MVA-kode og dimensjoner per leverandør;
   - kun tilføyelse, siste rad gjelder;
   - settes bare av brukeren og revisjonsføres (`supplier.defaults_set`).

   Verdiene må finnes i gjeldende referansedata når de settes.
3. **Konteringsforslag** (`application/reference/posting.py`, rene funksjoner):
   - Én konteringslinje per MVA-sats på fakturaen, med netto per sats fra linjene eller fra MVA-spesifikasjonen.
   - Konto og dimensjoner kommer fra leverandørstandarden.
   - MVA-koden er leverandørens standardkode hvis satsen passer. Ellers er det den eneste inngående koden med samme sats som er gyldig på fakturadatoen. Er det flere eller ingen, settes ingen kode.
   - Verdiene får proveniens `calculated` med produsent `regel/kontering/1` og en norsk forklaring som er fast tekst uten dokumentinnhold.
   - Mangler leverandørstandard, foreslås ingen konto, og fakturaen får funn i ACC-001/ACC-002.
4. **Tjeneste:**
   - Forslaget lagres som en ny fakturarevisjon (`InvoiceService.revise`), bare når fakturaen ikke har konteringslinjer fra før eller når brukeren ber om nytt forslag.
   - Det skjer automatisk etter EHF-registrering, før kontrollen, i samme transaksjon.
   - Forslaget skjer også på forespørsel («Foreslå kontering på nytt») og etter at en leverandørstandard er satt.
   - Manuelle verdier (`manual`) overskrives aldri.
5. **Regler** (regelsett 1.1):

   | Regel | Kontroll | Alvorlighet |
   |---|---|---|
   | MVA-002 | Hver MVA-sats på fakturaen finnes som gyldig inngående MVA-kode på fakturadatoen. Bare når MVA-koder er importert; ellers ett infofunn om at de mangler. | Feil |
   | ACC-001 | Fakturaen har konteringslinjer, og summen av dem er lik total netto. | Feil |
   | ACC-002 | Hver konto finnes og er aktiv i gjeldende kontoplan. Mangler kontoplanen, gis ett infofunn. Dimensjoner kontrolleres på samme måte. | Feil |
   | ACC-003 | Hver MVA-kode finnes, er gyldig på fakturadatoen, og satsen tilsvarer en sats på fakturaen. | Feil |

6. **Grensesnitt:**
   - Siden «Innstillinger» får delen «Referansedata»: import av tre filtyper, antall og tidspunkt for siste import, og en melding ved feil.
   - Siden «Leverandører» får «Sett standardkontering» med lister fra referansedataene.
   - Innboksen får «Foreslå kontering på nytt».
7. **Dokumentasjon:**
   - ADR-0034;
   - `DATA_MODEL.md` §3.14 og §7, `SECURITY.md` (CSV som ikke-klarert inndata), `THREAT_MODEL.md`, `TEST_STRATEGY.md`, `CHANGELOG.md`;
   - syntetiske eksempelfiler i `bootstrap/synthetic_reference.py` (CSV-filer i repoet blokkeres av `.gitignore`);
   - norsk rapport.

## CONSTRAINTS

- Ingen nettverk. Ingen standard kontoplan eller MVA-satser lagt inn i koden. Eksempelfilene er bare eksempler, og satsene i dem er merket som syntetiske.
- CSV er ikke-klarert inndata:
  - grenser for størrelse og rader;
  - ingen tolkning av formler;
  - kontrolltegn avvises;
  - celler som begynner med `=`, `+`, `-` eller `@`, avvises i navnefelt, så de ikke blir formler ved senere eksport (F10).
- Alt er avgrenset til én regnskapsenhet. Konteringsforslaget endrer aldri uttrukne verdier, bare `accounting_lines`.
- `Decimal` og `ROUND_HALF_UP`; aldri `float`.

## TESTS

- **Import:** gyldige filer, hver feiltype med linjenummer, BOM, norske datoer og desimaltall med komma, duplikater, overlappende gyldighet, grenser, formelceller, kontrolltegn. En avvist fil lagrer ingenting.
- **Forslag:** én og flere satser, kreditnota, manglende standard, flere mulige MVA-koder, gyldighet på datoen, manuelle linjer bevares.
- **Regler:** positive og negative tilfeller og grensetilfeller for MVA-002 og ACC-001–003, med og uten referansedata.
- **Tjeneste, migrasjon og GUI:**
  - tjenesten: automatisk forslag ved EHF, tverrenhetsisolasjon, krasj før commit;
  - migrasjon `0005 → 0006`;
  - GUI offscreen.
- **Felles:** alle tidligere regresjoner, Ruff, Bandit, pip-audit, Gitleaks, Windows-CI og `.exe`-selvtest.

## Åpne spørsmål

1. Å-18: eksportfiler fra UDIs Tripletex (kontoplan, MVA-koder, avdelinger og prosjekter). Når de finnes, legges en importadapter for formatet til.
2. Regnskapsansvarlig bør bekrefte regelen for valg av MVA-kode og om forslaget skal splittes per linje i stedet for per sats.
