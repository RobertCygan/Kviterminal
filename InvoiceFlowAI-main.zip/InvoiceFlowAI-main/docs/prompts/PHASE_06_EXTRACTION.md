# Fase 06 – Feltuttrekk til kanonisk modell

| | |
|---|---|
| **Versjon** | 1.0 (2026-10-24) |
| **Status** | **Autorisert for implementering** 2026-10-24 (G-25, «Zgoda na start F06»). Innholdet er utviklerens forslag (D-39) og er ikke gjennomgått av prosjekteier. |
| **Grunnlag** | F04 (tekstlag), F05 (OCR-ord), F11a (deler av skannede bunker), F15 (registrering av EHF-fakturaer), F08 (validering og konteringsforslag), ADR-0020 (fortegn for kreditnota) |

## GOAL

Fakturaer i PDF eller som skannede bilder blir fakturautkast i den kanoniske modellen. Hver verdi har proveniens: side, boks, råtekst og eventuelt OCR-sikkerhet. Ingen verdi diktes opp, og en verdi som ikke kan leses, beholdes som råtekst og flagges.

## CONTEXT

- Tekst finnes som tekstlag (F04) eller OCR-ord med boks og sikkerhet (F05).
- En skannet bunke deles i deler ved skilleark (F11a); hver del er én faktura.
- EHF-fakturaer registreres allerede fra XML (F15) med samme kontrollvei: funn, konteringsforslag og validering.
- Dokumenttypen settes av brukeren (D-24); importerte dokumenter er `unclassified`.

## OUTPUT

1. **Sideoppsett** (`application/extraction/layout.py`): ord med boks fra tekstlag eller OCR, linjer bygget fra geometrien, slik at ledetekst og verdi på samme rad havner på én linje.
2. **Normalisering** (`parse.py`):
   - beløp (`1 234,50`, `1.234,50`, `1 234,-`, `1,234.50`);
   - datoer (`24.10.2026`, `24.10.26`, `2026-10-24`, `24. oktober 2026`);
   - organisasjonsnummer med `MVA`, kontonummer, KID, IBAN, BIC, MVA-sats og valuta.
3. **Feltregler** (`fields.py`), bare ved ledetekst (samme linje eller rett under, innenfor samme kolonne) eller i en entydig form:
   - fakturatype, fakturanummer, fakturadato, forfallsdato, valuta;
   - kreditert faktura (kreditnota) og «Deres ref.»;
   - leverandør (navn, organisasjonsnummer, MVA-registrert) og kunde;
   - KID, kontonummer, IBAN og BIC;
   - totaler (eks. MVA, MVA, øreavrunding, å betale) og MVA-spesifikasjon per sats;
   - linjer i en linjetabell, der antall × pris = beløp.
4. **Kunde mot leverandør:** et organisasjonsnummer lik regnskapsenhetens eget er kundens.
5. **Registrering** (`service.py`):
   - én fakturautkast per del, én gang;
   - funn: summer som ikke stemmer, verdier som ikke kan leses, manglende påkrevde felt, mottaker og mulig duplikat;
   - konteringsforslag (F08b) og validering (F08a) i samme transaksjon.
6. **Hvilke dokumenter:**
   - PDF og bilder av typen faktura eller kreditnota;
   - `unclassified` bare når teksten kaller seg faktura eller kreditnota (dokumenttypen endres ikke);
   - aldri EHF-filer eller EHF-vedlegg.
7. **Selvtest:** en syntetisk faktura blir et fakturautkast med riktige felt.
8. **Referansesett:** fire syntetiske fakturaer med gyldne filer, lest både fra tekstlag og som skann gjennom OCR.

## CONSTRAINTS

- Rene funksjoner uten I/O; ingen nye avhengigheter; ingen nettverk; ingen KI.
- Lineære regulære uttrykk, én linje om gangen.
- Dokumenttekst er data. Den logges ikke og havner ikke i revisjonskjeden.
- Kreditnota: beløp lagres positivt, og `invoice_type` gir retningen (ADR-0020, D-16).
- Verdier som ikke står i dokumentet, fylles ikke inn (for eksempel valuta).

## TESTS

- **Normalisering:**
  - gyldige og ugyldige beløp, datoer og identifikatorer;
  - fiendtlig lange linjer (lineær tid).
- **Sideoppsett:** ord, linjer og sporing fra tekst til ord.
- **Gyldne filer:** samme verdier fra tekstlag og OCR, og ingen verdier utover filen.
- **Proveniens:** side, boks, råtekst og sikkerhet.
- **Registrering:**
  - én gang per del, og to deler i en bunke;
  - funn;
  - dokumenttyper;
  - mottaker og duplikat;
  - validering;
  - tverrenhet;
  - OCR-dokument.
- **Felles:** selvtest, Ruff, Bandit, pip-audit og Gitleaks.

## Åpne spørsmål

1. Skal programmet foreslå dokumenttype ut fra teksten (i dag endres den ikke, D-24)?
2. Referansesettet er syntetisk. Ekte fakturaer fra de største leverandørene bør brukes som (anonymiserte) testfiler når porten for ekte data åpnes.
