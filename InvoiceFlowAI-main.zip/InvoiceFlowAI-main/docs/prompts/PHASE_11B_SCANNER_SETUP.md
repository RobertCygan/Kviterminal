# Fase 11b – Skanner via produsentens program og kontroll av grenseverdier

| | |
|---|---|
| **Versjon** | 1.0 (2026-10-24) |
| **Status** | **Autorisert for implementering** 2026-10-24 (G-23, «wariant A»). Innholdet er utviklerens forslag (D-37) og er ikke gjennomgått av prosjekteier. |
| **Grunnlag** | F11a (ADR-0038), foreløpig skanner Brother ADS-4700W (G-22) |

## GOAL

Brother ADS-4700W (eller en annen skanner med eget Windows-program) kan brukes med InvoiceFlow AI uten skannerdriver i programmet. Grenseverdiene for blanke sider og skilleark kan kontrolleres med ekte skann uten at dokumentinnhold forlater maskinen.

## CONTEXT

- Skanneren lagrer PDF med flere sider i en mappe via Brother iPrint&Scan. Den overvåkede skannemappen fra F11a tar over derfra.
- WIA i programmet (variant B) ville kreve en ny avhengighet bare for Windows, og kan ikke testes uten skanner og Windows-CI. Prosjekteier valgte variant A.
- Grenseverdiene er bare prøvd på syntetiske sider (T61).

## OUTPUT

1. **Sider nær en grense** (ren funksjon `near_threshold`):
   - innhold uten tekstlag og høyst 10 ‰ mørkt (nesten blank);
   - innhold med midten minst 700 ‰ mørk (nesten skilleark);
   - skilleark med midten under 900 ‰ eller siden utenfor 200–600 ‰ (svakt skilleark).

   `BatchSplit.near` lister sidene; `BatchView.pages` gir målingene.
2. **Siden «Skanning»:**
   - kolonnen «Nær grensen» i tabellen over dokumenter;
   - tabell med målingene for hver side i valgt dokument;
   - grenseverdiene vist som tekst;
   - «Kopier mappesti», fordi mappen ligger under den skjulte `%LOCALAPPDATA%`.
3. **`docs/SCANNER_SETUP.md`:** skanneprofil for Brother iPrint&Scan, daglig bruk, kontroll av grenseverdiene ved første prøve og feilsøking.
4. **Dokumentasjon:** ADR-0039, rapport, beslutningsregister, `SECURITY.md`, `THREAT_MODEL.md`, `TEST_STRATEGY.md`, `ARCHITECTURE.md`, roadmap og `CHANGELOG.md`.

## CONSTRAINTS

- Ingen skannerdriver, ingen nye avhengigheter, ingen nettverk, ingen ny migrasjon.
- Grenseverdiene endres ikke før de er prøvd med ekte skann.
- Målingene er tall, ikke dokumentinnhold. De vises bare i programmet og logges ikke.
- Skannemappen deles ikke på nettverket.

## TESTS

- Grenseverdiene for «nær grensen» på begge sider av hver grense, og umålte sider.
- `BatchSplit.near` og `BatchView.pages` i tjenesten.
- GUI offscreen:
  - sidetabell for valgt dokument;
  - kopiering av mappesti;
  - hurtigtaster uten kollisjon.
- Ruff, Bandit, pip-audit, Gitleaks og Windows-CI.

## Åpne spørsmål

1. Første prøve med ADS-4700W: resultatene avgjør om grenseverdiene må justeres (ny versjon).
2. Menynavnene i Brother iPrint&Scan for ADS-4700W er ikke bekreftet.
