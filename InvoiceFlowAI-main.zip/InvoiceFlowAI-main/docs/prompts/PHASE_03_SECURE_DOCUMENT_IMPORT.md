# Fase 03 – sikker dokumentimport og dokumentarkiv (grunnmur)

| | |
|---|---|
| **Versjon** | 2.0 (2026-10-22) – tilpasset `DOCUMENT_ARCHIVE_SCOPE.md` og faktisk F02 i `main` |
| **Status** | **Autorisert av prosjekteier 2026-10-22 (G-05)**, inkludert D-22–D-24. |
| **Grunnlag** | `main` etter F02 (`d158885`): ADR-0026 (snapshot, ingen standardenhet, D-20/D-21 godkjent), ADR-0027 (global auditkjede), ADR-0028 (kontrollert migrasjon) |

Les `AGENTS.md`, `DOCUMENT_ARCHIVE_SCOPE.md`, `DATA_MODEL.md` §3.2 og §3.9, `SECURITY.md` og `PHASE_02_REPORT.md` før arbeid. Kontroller riktig Git-base; ikke anta at åpne PR-er er slått sammen.

## GOAL

Importer syntetiske PDF-, PNG-, JPEG- og TIFF-filer sikkert til et enhetsavgrenset, innholdsadressert originalarkiv, med en **generisk dokumentmodell** som senere kan bære fakturaer, kreditnotaer, kvitteringer, avtaler, betalingsbekreftelser og korrespondanse uten å tvinge dem inn i `CanonicalInvoice`. Metadata og revisjonshendelse lagres atomisk. Brukeren kan opprette den første regnskapsenheten eksplisitt og se en minimal dokumentinnboks.

## CONTEXT

- F02 har SQLite med WAL/FULL, `EntityScope` uten standardfallback, uforanderlige fakturaøyeblikksbilder, global auditkjede med tillatelsesliste og migrasjon med verifisert sikkerhetskopi (ADR-0028).
- `invoices.document_id` har i F02 ingen fremmednøkkel; den skal peke på `documents` fra F03.
- `DOCUMENT_ARCHIVE_SCOPE.md` krever at dokument og faktura er adskilt, at originaler er uendrede og SHA-256-identifisert, at koblinger og søk er enhetsavgrenset, og at ingenting slettes automatisk. Akseptansekriteriene 1–5 der gjelder for F03 i den grad de berører datamodell og lagring.
- PDF-parsing, sideantall, rasterisering og OCR hører til F04/F05 og krever avklart PDF-lisens (D-11).

## INPUT

- Eksplisitt valgt lokal fil (filvelger) og manuell innlesing av innboksmappen (ikke-rekursiv), alltid med eksplisitt `EntityScope`.
- Syntetiske testfiler generert i testene; ingen ekte dokumenter.
- Grenser fra `SECURITY.md` (maks 50 MB per fil).
- **Beslutninger som må være godkjent før start:**
  - **D-22 Første regnskapsenhet:** minimal dialog for å opprette én enhet (navn påkrevd, organisasjonsnummer valgfritt og validert) og vise aktiv enhet. Ingen bytte mellom flere enheter og ingen administrasjons-UI (Å-17 forblir åpen). Uten enhet er import deaktivert.
  - **D-23 Innboks:** manuell knapp «Les inn fra innboks» i stedet for kontinuerlig overvåking. Kontinuerlig overvåking og skanner kommer i F11.
  - **D-24 Dokumenttype ved import:** importerte filer får `document_type = 'unclassified'`. Brukeren kan sette type (`invoice`, `credit_note`, `receipt`, `contract`, `payment_confirmation`, `correspondence`, `other`) som metadataendring med revisjonshendelse; ingen automatisk klassifisering i F03.
- Åpne spørsmål med frist F03 som påvirker dokumentasjon, ikke kode: Å-12 (antivirus, Microsoft Defender forutsatt) og Å-13 (BitLocker på målmaskinen). Programmet viser bare advarsel; det blokkerer ikke.

## OUTPUT

1. **Migrasjon `0002`** (Alembic, transaksjonell, verifisert sikkerhetskopi etter ADR-0028):
   - `documents`: generisk dokument – `id`, `entity_id`, `document_type`, `sha256`, `size_bytes`, `detected_format` (fra signatur), `display_name` (renset, maks 255, brukes aldri som sti), `storage_path` (relativ, UNIQUE), `source` (`file_import`, `inbox`), `status` (`stored`, `quarantined`), `imported_at`, `imported_by` (teknisk aktør), `integrity_checked_at`, `integrity_status`. UNIQUE(`entity_id`, `sha256`) og UNIQUE(`entity_id`, `id`). Ingen fakturafelter.
   - `document_links`: enhetsavgrensede koblinger mellom dokumenter (`attachment`, `supersedes`, `related`) med sammensatte FK-er `(entity_id, …)`; ingen selvkobling, unik per par og type. Ingen UI for koblinger i F03.
   - Sammensatt FK `invoices(entity_id, document_id) → documents(entity_id, id)` via tabellombygging som bevarer alle F02-utløsere og data. Finnes fakturaer uten tilhørende dokument, avbrytes migrasjonen med tydelig feil; ingen stille reparasjon.
   - Utløsere: dokumenter kan ikke slettes; `entity_id`, `sha256`, `storage_path`, `size_bytes` og `detected_format` er uforanderlige.
2. **Importtjeneste** (application + persistence + bootstrap): strømmet lesing med størrelsesgrense, signaturkontroll (PDF, PNG, JPEG, TIFF II/MM), SHA-256, renset visningsnavn. Fil skrives til midlertidig navn under enhetens lager, `fsync`, hash verifiseres på nytt, atomisk `os.replace` til `documents/<entity_id>/originals/ab/cd/<sha256>.<ext>`, filen settes skrivebeskyttet, deretter DB-rad + revisjonshendelse i én Unit of Work. Duplikat (samme enhet og hash) gir ingen ny rad og hendelsen `document.duplicate_rejected`. Samme fil i to enheter er to dokumenter. Feil signatur, for stor eller tom fil gir avvisning; mistenkelige filer kopieres til `documents/<entity_id>/quarantine/<uuid>.bin` og åpnes aldri igjen automatisk. Kildefilen beholdes alltid i F03.
3. **Krasjmodell:** dokumenter hvert feilpunkt (før/etter midlertidig fil, etter publisering, før/etter commit). Ved oppstart: rester av midlertidige filer fjernes, publiserte originaler uten DB-rad flyttes til `orphans/` og rapporteres (aldri slettet), DB-rader uten fil får `integrity_status = 'missing'`. Idempotent; samme import kan gjentas.
4. **Revisjon:** nye hendelsestyper i tillatelseslisten (`document.imported`, `document.duplicate_rejected`, `document.quarantined`, `document.type_changed`, `entity.created` finnes), med bare ID-er, hash, størrelsesklasse, format og type – aldri filnavn, sti eller innhold.
5. **UI:** dialog for første enhet (D-22); siden «Dokumenter» viser enhetens dokumenter (renset navn som ren tekst, type, format, størrelse, dato, status), knapper «Importer fil» og «Les inn fra innboks» (D-23) og typevalg (D-24). All fil- og DB-behandling skjer utenfor GUI-tråden.
6. **Dokumentasjon:** `DATA_MODEL.md` §3.9 (faktisk F03-skjema), `ARCHITECTURE.md`, `SECURITY.md`, `THREAT_MODEL.md` (T01–T05, T21), `TEST_STRATEGY.md`, ny ADR for generisk dokumentmodell og krasjmodell, `CHANGELOG.md`, `docs/PHASE_03_REPORT.md` og et seks-delt F04-prompt (ikke utført). Faktiske NTFS-/BitLocker-kontroller og begrensninger dokumenteres.

## CONSTRAINTS

- Ingen PDF-parsing, sideantall, rasterisering, OCR eller KI; signaturkontroll er ikke full dokumentvalidering (F04).
- Ingen rekursiv mappeimport, ingen symlink/junction-følging, ingen ubegrenset innlesing, ingen nettverk.
- Ingen automatisk sletting av originaler, dokumentrader eller kildefiler; ingen retensjon/kassasjon (egen beslutning senere).
- Ingen flerenhets-administrasjon, ingen bytte av aktiv enhet, ingen dokumentkoblings-UI, ingen fulltekstsøk.
- Ingen filnavn, stier eller dokumentinnhold i logger eller revisjonsdetaljer.
- F02-snapshot, auditformat og hashversjon bevares; endringer bare via versjonert migrasjon.
- Avhengigheter bare med hash-låser og karantenepolicyen (ADR-0024); nye pakker krever begrunnelse.
- Kun syntetiske data til porten i `SECURITY.md` §17 er godkjent.

## TESTS

- Migrasjon `0001 → 0002` med F02-data (inkludert faktura med og uten dokument), sikkerhetskopi, tilbakerulling ved feil, skjemadrift mot metadata.
- Gyldige og ugyldige signaturer, feil endelse, tom fil, grensen 50 MB ± 1 byte, fil som endres under lesing, fiendtlige filnavn (Unicode, reserverte Windows-navn, stier), symlink/junction der tilgjengelig.
- Uendret originalhash etter import, skrivebeskyttelse, duplikat i samme enhet, samme fil i to enheter, uautorisert/tverrenhets-ID og tverrenhets-FK for dokument, kobling og faktura.
- Hvert krasjpunkt mellom fil, DB og revisjon, gjenopptak og idempotens; full disk og utilgjengelig lager simulert.
- Revisjonsdetaljer uten filnavn/sti; hele kjeden gyldig etter import.
- GUI: enhetsdialog, innboks, import utenfor GUI-tråden, ren-tekst-visning; offline.
- Alle F00–F02-regresjoner, Ruff, Bandit, pip-audit, Gitleaks, Windows-CI og `.exe`-selvtest. Dekning ≥ 90 % for nye moduler utenfor UI.
- Lever PR og norsk rapport med faktiske resultater; manuell Windows 11-aksept dokumenteres separat. Ikke begynn F04.
