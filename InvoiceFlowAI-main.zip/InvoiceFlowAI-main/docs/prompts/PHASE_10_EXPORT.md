# Fase 10 – Eksport til Excel og CSV

| | |
|---|---|
| **Versjon** | 1.0 (2026-10-24) |
| **Status** | **Autorisert for implementering** 2026-10-24 (G-16, «zgadzam się na kontynuację» etter sammenslåingen av F09). Innholdet er utviklerens forslag (D-34) og er ikke gjennomgått av prosjekteier eller regnskapsansvarlig. |
| **Grunnlag** | F09: godkjenning bundet til innholdshash (ADR-0035); ADR-0013 (eksport bare av godkjente fakturaer, re-eksport med begrunnelse); ADR-0020 (fortegn for kreditnota); `DATA_MODEL.md` §3.5; `SECURITY.md` §13 (formelinjeksjon) |

## GOAL

Godkjente fakturaer eksporteres til Excel (`.xlsx`) eller CSV, hver faktura én gang. Databasen hindrer dobbel eksport. Tekst fra fakturaer kan aldri bli en formel i et regneark. Et krasj midt i en eksport gir aldri en halv fil eller en faktura som er markert som eksportert uten fil.

## CONTEXT

- Etter F09 har fakturaene status `draft`, `approved` eller `rejected`. Bare `approved` med gyldig godkjenning kan eksporteres.
- ERP-formatet er ikke avklart (Å-02, Å-21, Å-22). Filen er derfor en generell tabell som regnskapsavdelingen kan importere eller lime inn. Kolonnene kan velges og få egne overskrifter.
- Innholdet i fakturaene er ikke-klarert tekst (OWASP «CSV injection»).

## OUTPUT

1. **Lagring** (migrasjon `0008_export`):
   - `export_batches`: én fil per batch. Status `created` → `written` eller `failed`. Faste kolonner: målformat, kolonneoppsett med versjon, filnavn og SHA-256, antall, ny eksport med begrunnelse, revisjonsanker (hash av siste revisjonshendelse), tid og aktør.
   - `export_items`: én faktura i én batch, bundet til godkjenning, revisjon og hash. Status `pending` → `exported` eller `failed`, senere `superseded`. En delvis unik indeks tillater bare én aktiv eksport per faktura og mål.
   - `export_mappings`: kolonneoppsett per enhet, kun tilføyelse og versjonert. Versjon 0 er standardoppsettet i koden.
   - Utløsere:
     - en eksportrad kan bare skrives for godkjent, gjeldende innhold;
     - en ny eksport av en eksportert faktura krever en batch merket som ny eksport;
     - status `exported` krever en eksportert rad for gjeldende innhold;
     - en eksportert faktura kan ikke endres eller få nye beslutninger, heller ikke mens eksporten pågår.
2. **Tjenesten `ExportService`:**
   - eksport av alle godkjente fakturaer som ikke er eksportert;
   - ny eksport av en tidligere batch med begrunnelse (10–500 tegn);
   - lagring av en kopi etter kontroll av SHA-256;
   - kolonneoppsett;
   - gjenoppretting ved oppstart og før hver eksport.
3. **Krasjsikker rekkefølge:**
   1. batch og `pending`-rader i én transaksjon;
   2. filen skrives til et midlertidig navn, `fsync`, og gis endelig navn;
   3. `exported`, `written`, filhash, fakturastatus og revisjonshendelser i én transaksjon.

   Ved oppstart fullføres en åpen batch hvis filen finnes, ellers markeres den som mislyktes.
4. **Filformat:**
   - én rad per konteringslinje med fakturaens hodeverdier gjentatt, eller én rad for en faktura uten kontering;
   - CSV: UTF-8 med BOM, semikolon, desimalkomma og datoer som `DD.MM.ÅÅÅÅ`;
   - Excel: arket «Fakturaer» med tallceller for beløp og datoceller for datoer, og arket «Kontroll» med antall, summer per valuta og revisjonsanker;
   - kreditnotaer får negative beløp (ADR-0020).
5. **Formelinjeksjon:**
   - CSV: tekst som begynner med `=`, `+`, `-`, `@`, tabulator, linjeskift eller fullbreddeformene får en apostrof foran;
   - Excel: tekst skrives alltid som tekstcelle og får i tillegg Excels apostrofmerke;
   - egne overskrifter kan ikke begynne med disse tegnene.
6. **Grensesnitt** (siden «Eksport»):
   - godkjente fakturaer klare for eksport;
   - valg av format;
   - «Eksporter godkjente», «Kolonner …»;
   - tidligere eksporter med status;
   - «Lagre kopi …» og «Eksporter på nytt …».
7. **Revisjon:**
   - `invoice.exported` per faktura;
   - `export.completed`, `export.failed` og `export.mapping_set`;
   - bare ID-er, hasher, antall og koder, aldri begrunnelser eller fakturainnhold.
8. **Dokumentasjon:** ADR-0036, `DATA_MODEL.md`, `SECURITY.md`, `THREAT_MODEL.md`, `TEST_STRATEGY.md`, `DEPENDENCIES.md`, `CHANGELOG.md` og en norsk rapport.

## CONSTRAINTS

- Ingen nettverk og ingen ERP-integrasjon (F14). Ingen automatisk bokføring eller betaling.
- Bare godkjente fakturaer. Godkjenningen må være siste beslutning og gjelde gjeldende innhold.
- Filnavn lages av tjenesten (løpenummer og tidspunkt), aldri av fakturatekst. Filer i eksportmappen er skrivebeskyttet og overskrives aldri.
- openpyxl brukes bare til å skrive, bare i `export/xlsx_writer.py`.
- `Decimal` hele veien; aldri `float`.
- Alt er avgrenset til én regnskapsenhet.

## TESTS

- **Regler:**
  - bare godkjente fakturaer;
  - dobbel eksport avvises av databasen, også til et annet format;
  - eksportert sum er lik summen av godkjente fakturaer, med kreditnota;
  - en eksportert faktura kan ikke endres.
- **Formelinjeksjon:** `=CMD()`, `+1`, `-1+1`, `@SUM()`, tabulator, linjeskift og fullbreddetegn i CSV og Excel; ingen formelceller i arket.
- **Krasj:**
  - etter at filen fikk endelig navn: fullføres ved oppstart;
  - før det: mislykkes ved oppstart, og den midlertidige filen fjernes;
  - feil i skriveren: batch mislykket, fakturaen fortsatt godkjent.
- **Ny eksport:** begrunnelse kreves, forrige eksport blir `superseded`, og en mislykket ny eksport kan gjentas.
- **Kolonneoppsett:** versjoner, konflikt, ugyldige og like overskrifter.
- **Kopi:** hash kontrolleres; endret eller manglende fil gis ikke ut.
- **Felles:**
  - isolasjon mellom regnskapsenheter;
  - migrasjon `0007 → 0008`;
  - GUI offscreen;
  - selvtest, også `.exe`;
  - Ruff, Bandit, pip-audit, Gitleaks og Windows-CI.

## Åpne spørsmål

1. Å-02, Å-21 og Å-22: hvilket importformat og hvilket fortegn regnskapssystemet trenger. Kolonneoppsettet dekker enkle tilpasninger. Faste ERP-formater kommer i F14.
2. Regnskapsansvarlig bør bekrefte én rad per konteringslinje og negative beløp for kreditnota.
3. Eksportfiler i eksportmappen er ikke kryptert. Kryptert sikkerhetskopi kommer i F12, og BitLocker (Å-13) beskytter disken.
