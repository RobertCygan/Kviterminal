# Fase 05 – Tekstgjenkjenning (OCR) med Tesseract

| | |
|---|---|
| **Versjon** | 1.0 (2026-10-24) |
| **Status** | **Autorisert for implementering** 2026-10-24 (G-24: D-13 godkjent med Tesseract 5, «kolejna»). Innholdet er utviklerens forslag (D-38) og er ikke gjennomgått av prosjekteier. |
| **Grunnlag** | ADR-0007 (OCR-motor, D-13/Å-05), ADR-0010/0031 (isolert arbeidsprosess), F04 (sidebilder og tekstlag), F11a (sidemålinger) |

## GOAL

Skannede sider uten tekstlag får tekst: ord med posisjon, linje og sikkerhet, lagret slik at F06 kan hente fakturafelt fra dem. Alt skjer lokalt, i den isolerte arbeidsprosessen, uten nettverk. Programmet virker som før uten Tesseract.

## CONTEXT

- F04 lager et PNG-bilde og eventuelt et tekstlag per side. PDF-er laget digitalt har tekstlag; skannede PDF-er og bilder har det ikke.
- D-13 er godkjent: Tesseract 5 med norsk språkdata (`nor`).
- Tesseract er et eget program, ikke en Python-pakke. Det installeres separat nå og pakkes med programmet i F13.

## OUTPUT

1. **Eget OCR-steg** (`ocr`) per dokument, etter en vellykket sideanalyse:
   - leser sidebildene fra analysen, kontrollert mot hash;
   - gjenkjenner sider uten tekstlag som har blekk og ikke er skilleark;
   - idempotent per dokument, motorversjon (program, format og hash av språkdata) og innstillinger.
2. **Tesseract i arbeidsprosessen:**
   - én kjøring per side, uten skall, med faste argumenter, minimalt miljø og tidsavbrudd;
   - Windows: i samme Job Object som arbeidsprosessen, med to tillatte prosesser;
   - TSV tolkes i arbeidsprosessen; ut går bare ord med boks, sikkerhet og linjenummer.
3. **Lagring:** én avledet fil `ocr-0001.json` per side og tabellen `ocr_pages` (migrasjon `0011_ocr`) med antall ord, linjer, tegn og snittsikkerhet.
4. **Grensesnitt:** kolonnen «Tekst (OCR)», «Vis tekst …» per dokument og en melding når Tesseract mangler.
5. **Selvtest:** med Tesseract leses et sidebilde uten tekstlag tilbake.
6. **Referansesett:** syntetiske skannede fakturaer (300 dpi, støy og skjevhet, JPEG 200 dpi, dårlig skann 150 dpi) med tegnfeilrate og tid per side (NF-04).
7. **Dokumentasjon:** ADR-0040, `OCR_SETUP.md`, `DATA_MODEL.md`, `SECURITY.md`, `THREAT_MODEL.md`, `TEST_STRATEGY.md`, `DEPENDENCIES.md`, `CHANGELOG.md` og rapport.

## CONSTRAINTS

- Ingen ny Python-avhengighet: Tesseract kalles direkte, ikke via `pytesseract` (avvik fra ADR-0007, se ADR-0040).
- Tesseract finnes bare på faste steder; `PATH` søkes ikke på Windows.
- OCR-tekst er data. Den logges aldri og havner aldri i revisjonskjeden; der står bare antall ord og snittsikkerhet.
- Originalen og sidebildene endres aldri.
- Feltuttrekk (fakturanummer, beløp osv.) hører til F06.

## TESTS

- **TSV og kontrakter:** feilformet TSV, ordgrense, rensing av tegn, konsistens mellom rapport og filer.
- **Tjenesten** med ekte Tesseract:
  - gjenkjenning og idempotens;
  - tekstlag, blanke sider og skilleark;
  - endret sidebilde og manipulert rapport;
  - tidsavbrudd og nytt forsøk;
  - tverrenhet;
  - avbrudd og oppstartsopprydding.
- **Isolasjon:** OCR-oppgave uten Tesseract starter ingen prosess.
- **Migrasjon** `0010 → 0011` og databaseregler for `ocr_pages`.
- **Treffsikkerhet** på referansesettet og NF-04.
- **Felles:** GUI offscreen, selvtest, Ruff, Bandit, pip-audit og Gitleaks.
- **CI:** Windows-CI installerer Tesseract og norsk språkdata med låst versjon og kontrollsum, og krever at OCR-testene kjører.

## Åpne spørsmål

1. Skal F13 pakke Tesseract med programmet (anbefalt) eller kreve separat installasjon? Lisensen (Apache-2.0) tillater pakking.
2. `tessdata` (standard), `tessdata_fast` eller `tessdata_best`? Valgt nå: standard 4.1.0.
3. PaddleOCR-sammenligning (ADR-0007) utsettes til ekte skann finnes (Å-01, F11b).
