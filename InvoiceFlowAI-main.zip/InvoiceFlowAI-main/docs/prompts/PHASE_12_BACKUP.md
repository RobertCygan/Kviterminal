# Fase 12 – Kryptert sikkerhetskopi og gjenoppretting

| | |
|---|---|
| **Versjon** | 1.0 (2026-10-24) |
| **Status** | **Autorisert for implementering** 2026-10-24 (G-18, «zacznij F12»). Innholdet er utviklerens forslag (D-35) og er ikke gjennomgått av prosjekteier eller regnskapsansvarlig. Å-07 (oppbevaring) og Å-14 (lagring og nøkkelforvaltning) er ikke besvart. |
| **Grunnlag** | `SECURITY.md` §12 (sikkerhetskopi), ADR-0016/0027 (revisjonskjede med anker), ADR-0028 (konsistent kopi med SQLite backup-API), ADR-0029 (dokumentarkiv), ADR-0036 (eksportmappe) |

## GOAL

Alle data i InvoiceFlow kan sikkerhetskopieres til én kryptert fil og gjenopprettes til en tom mappe, der hver fil, databasen og revisjonskjeden kontrolleres. En endret eller avkortet sikkerhetskopi og feil passordfrase avvises. Prosedyren er dokumentert på norsk.

## CONTEXT

- `SECURITY.md` §12 lar valget stå mellom et kryptert arkiv og et BitLocker To Go-kryptert medium (Å-14). Et kryptert arkiv virker på alle medier og kan testes automatisk.
- Kopiene før migrasjon (ADR-0028) er lokale og ukrypterte. De erstattes ikke av F12.
- Det finnes én database for alle regnskapsenheter (ADR-0022). Sikkerhetskopien omfatter derfor hele datakatalogen.

## OUTPUT

1. **Filformat** (ADR-0037):
   - én fil `invoiceflow-sikkerhetskopi-ÅÅÅÅMMDD-TTMMSS.ifbak`;
   - åpent hode: format, nøkkelavledning (scrypt, N = 2^17, r = 8, p = 1, tilfeldig salt) og nonceprefiks;
   - AES-256-GCM i biter på 1 MiB med nonce prefiks og løpenummer, og med hodets hash, løpenummer og sluttmerke som tilknyttede data;
   - innhold: tar-arkiv med databasekopi, dokumentarkiv (uten midlertidige filer), eksportfiler, konfigurasjon og til slutt et manifest med SHA-256 for hver fil og revisjonsankeret.
2. **Lage:**
   - revisjonskjeden må være intakt;
   - databasen kopieres med SQLite backup-API til en privat arbeidsmappe;
   - filen skrives under midlertidig navn og får endelig navn når den er komplett;
   - mangler et dokument som databasen viser til, lages ingen sikkerhetskopi;
   - registeret `backups` og revisjonshendelsen `backup.created` (hash, antall, anker);
   - passordfrasen gis to ganger og lagres aldri.
3. **Kontrollere og gjenopprette:**
   - alt dekrypteres og autentiseres;
   - kontroll pakker ut i en privat arbeidsmappe som slettes;
   - gjenoppretting pakker ut i en tom mappe utenfor programmets datakatalog;
   - kontroller:
     - manifest mot innhold;
     - databasens integritet og skjemaversjon;
     - hele revisjonskjeden;
     - anker i manifestet mot kjedens ende;
     - hvert dokument databasen viser til.
   - En mislykket gjenoppretting etterlater mappen tom.
   - Revisjonshendelsene `backup.verified` og `backup.restored` registreres med utfall.
4. **Slette:** bare en fil som denne databasen har laget (hash i registeret). Raden beholdes, og slettingen registreres (`backup.deleted`). Ingen automatisk sletting før Å-07 er besvart.
5. **Oppstart:** arbeidsmapper etter et avbrudd fjernes, fordi de kan inneholde en ukryptert databasekopi.
6. **Grensesnitt:** siden «Sikkerhetskopi» med «Lag sikkerhetskopi», «Kontroller», «Gjenopprett til ny mappe», «Slett sikkerhetskopi» og en liste over sikkerhetskopier.
7. **Dokumentasjon:**
   - ADR-0037;
   - prosedyre på norsk (`BACKUP_PROCEDURE.md`);
   - `DATA_MODEL.md`, `SECURITY.md`, `THREAT_MODEL.md`, `TEST_STRATEGY.md`, `DEPENDENCIES.md` og `CHANGELOG.md`;
   - rapport.

## CONSTRAINTS

- Ingen nettverk. Ingen lagring av passordfrase eller nøkkel, heller ikke i Windows Credential Manager.
- Den kjørende databasen og datakatalogen endres aldri av en gjenoppretting.
- Kryptografi bare i `backup/crypto.py` (biblioteket `cryptography`). Tar bare i `backup/archive.py`. Utpakking aksepterer bare vanlige filer med kjente, relative stier.
- Revisjonshendelser inneholder bare ID-er, hasher, antall og utfall.

## TESTS

- **Format:** passordfrase, stier, hode og manifest i kanonisk form.
- **Kryptering:**
  - alle størrelser rundt bitgrensen;
  - endret byte, byttede, manglende og tilføyde biter;
  - avkorting på bitgrense;
  - endret hode;
  - feil nøkkel.
- **Arkiv:**
  - stitraversering, absolutte stier, lenker, mapper, duplikater og innhold etter manifestet;
  - manglende eller ødelagt manifest;
  - mål som ikke er tomt, eller som ligger i datakatalogen.
- **Tjeneste:**
  - full gjenoppretting med lik faktura og gyldig kjede;
  - kontroll uten spor;
  - feil passordfrase, endrede byte og avkortet fil;
  - mislykket gjenoppretting gir tom mappe;
  - brutt kjede og manglende dokument hindrer ny sikkerhetskopi;
  - manipulert kjede i sikkerhetskopien avvises;
  - sletting bare av registrert fil;
  - arbeidsmapper fjernes ved oppstart.
- **Felles:**
  - migrasjon `0008 → 0009`;
  - GUI offscreen;
  - selvtest, også `.exe`;
  - Ruff, Bandit, pip-audit, Gitleaks og Windows-CI.

## Åpne spørsmål

1. Å-14: hvor sikkerhetskopiene skal lagres (ekstern disk, nettverksshare), og hvem som forvalter passordfrasen. Anbefaling: kryptert ekstern disk og passordfrase i et passordhvelv hos to personer.
2. Å-07: oppbevaringstid og regler for sletting. Til det er besvart, slettes ingenting automatisk.
3. Automatisk sikkerhetskopi etter tidsplan er ikke en del av F12. Den krever at passordfrasen er tilgjengelig uten en person, altså lagret nøkkel, og en egen beslutning.
