# Fase 08a – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

24. oktober 2026 ba prosjekteier om at F08 startes, og delegerte svarene på Å-24 og F15-promptets spørsmål 2–4 til utvikleren (G-12):

- Svarene står i D-30.
- Utvikleren delte F08 i F08a og F08b og skrev promptet `docs/prompts/PHASE_08_ACCOUNTING_ENGINE.md` v1.0 (D-31).
- Innholdet i promptet er ikke gjennomgått av prosjekteier eller regnskapsansvarlig.

Autorisasjonen gjelder implementering, ikke aksept av resultatet, restrisiko (D-19) eller ekte data. F08b (kontoplan, MVA-koder, dimensjoner, konteringsforslag) og F09 er ikke påbegynt.

**GOAL:** hver registrerte faktura kontrolleres deterministisk mot regelkatalogen. Resultatet lagres sporbart per revisjon og vises på norsk. Ubekreftede betalingskontoer og mulige duplikater gir feil.

## 2. Leveranse

- **Regelmotor og regler:**
  - `application/validation/`: regelmotor med 18 regler (`DATA_MODEL.md` §7, status F08a), ren og uten I/O. Regelsettet har versjon 1.0.
  - `domain/checksums.py`: kontrollsiffer MOD11, MOD10 og MOD97.
- **Database:** migrasjon `0005_validation` med `suppliers`, `supplier_bank_accounts`, `validation_runs` og `validation_results` (ADR-0033, `DATA_MODEL.md` §3.13). `audit_events` er bygget om for emnetypen `supplier`.
- **`ValidationService`:**
  - kontroll i samme transaksjon som registreringen av en EHF-faktura;
  - kontroll på forespørsel;
  - ny kontroll av berørte fakturaer når en konto bekreftes eller sperres;
  - leverandørregister.
- **Grensesnitt:**
  - Innboksen har kolonnen «Kontroll» (for eksempel «1 feil», «OK», «Ikke kontrollert»), «Vis kontroll» med liste over funn og «Kontroller alle på nytt».
  - Ny side «Leverandører» har «Bekreft konto» og «Sperr konto», begge med bekreftelsesdialog som advarer mot å kontrollere kontoen bare mot fakturaen.
- **Revisjon:** `invoice.validated`, `supplier.created`, `supplier.account_added` og `supplier.account_status_changed`. Hendelsene inneholder bare ID-er, koder og antall.
- **Selvtesten**, også `.exe`: en ny konto gir BANK-001, og etter bekreftelse er fakturaen uten funn.
- **Dokumentasjon:**
  - ADR-0033;
  - DATA_MODEL §3.13 og §7, SECURITY §22, THREAT_MODEL §14 (T39–T42);
  - TEST_STRATEGY, ARCHITECTURE, DEPENDENCIES §7, CHANGELOG og veikart.

## 3. Valg og avvik fra skissene

| Punkt | Valg | Begrunnelse |
|---|---|---|
| `validation_results` med status som endres (§3.5) | Kjøringer og funn som bare kan legges til; gjeldende resultat er siste kjøring for gjeldende revisjon | Historikken bevares. Resultatet avhenger av registeret, andre fakturaer og datoen. Overstyring kommer i F09 som egen tabell. |
| Leverandør opprettes automatisk | Ja, men bare med gyldig organisasjonsnummer eller utenlandsk MVA-ID. Navnet låses fra første faktura. | Registeret skal ikke fylles med feiltolkede verdier. |
| Konto ved første faktura | Alltid `unverified`, så BANK-001 gir feil | Å stole på kontoen første gang den brukes, er nettopp det fakturasvindel utnytter (T39). |
| Aktør for brukerhandlinger | `user/local` | Aktører skal være tekniske, aldri navn (SECURITY §18). Spørsmål Å-10 avgjøres i F09. |
| DUP-001 og DUP-002 | Bare for leverandører med organisasjonsnummer | Header-projeksjonen har bare organisasjonsnummeret. Utenlandske leverandører må vente til F08b eller F09. |
| SUM-001 | Linjesum mot eks. MVA uten rabatter og gebyrer på dokumentnivå | Den kanoniske modellen har ikke slike felt. En EHF med rabatt på dokumentnivå gir feil som må vurderes av et menneske. |
| SUM-002 | Netto + MVA + avrunding = å betale | Forskuddsbetaling finnes ikke i modellen og gir feil (sjeldent). |
| Blokkering av godkjenning | Ikke i F08a | Godkjenning kommer i F09. Feilene er klare til å blokkere den. |

## 4. Testresultater

Lokalt (Linux, Python 3.13, gren `claude/phase08-validation`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen) | 1188 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | 93 % |
| Dekning `application/validation/` og `domain/checksums.py` | 99 % (regler, modell og kontrollsiffer 100 %) |
| Ruff lint og format | Ingen funn |
| Bandit | Ingen funn |
| pip-audit (utvikling og kjøretid, `--require-hashes`) | Ingen kjente sårbarheter etter unntakene for setuptools og filelock (se under) |

Windows-CI og `.exe`-selvtesten: se PR-en.

**Sikkerhetsunntak i utviklingslåsen.** Under arbeidet meldte pip-audit nye sårbarheter i to rene utviklingsverktøy:

- setuptools 84.0.0 (GHSA-xmj3-9gf7-h52w), brukt av PyInstaller;
- filelock 4.0.1 (tre CVE-er), brukt av pip-audit.

Dette rammer også `main`. Begge er løftet til første rettede versjon etter ADR-0024 pkt. 3 (`DEPENDENCIES.md` §7). Kjøretidslåsen og `.exe` er uendret.

**Gitleaks:** regelen `generic-api-key` traff tre testlinjer med oversettelsesnøkler (`message_key="validation.…"`). Treffene er falske; de er ikke hemmeligheter. Linjene er skrevet om, og fingeravtrykkene for de allerede publiserte commitene står i `.gitleaksignore`. Historikken er ikke skrevet om. Lokal kjøring av `gitleaks git` (8.24.3, samme som CI) finner ingen lekkasjer.

**Testmiljø:** etter at et GUI-test har avsluttet applikasjonen (`test_shell.py`), behandler Qt ikke lenger hendelser i nestede løkker. De nye GUI-testene behandler derfor hendelser eksplisitt. Programmet påvirkes ikke.

**Ikke prøvd:**

- ekte fakturaer og ekte leverandørkontoer;
- om alvorlighetene og standardene passer for regnskapsansvarlig: toleranse 0,01, 365 dager og NOK;
- utenlandske leverandører og omvendt avgiftsplikt (Å-08);
- manuell Windows 11-test;
- ytelse med mange tusen fakturaer per enhet. Duplikatkontrollen leser header-projeksjonen for hele enheten ved hver kjøring.

## 5. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Regelmotor og kontrollsiffer | ✅ | ✅ | ✅ | se PR | – | – |
| Migrasjon 0005, register og kjøringer | ✅ | ✅ | ✅ | se PR | – | – |
| Kontroll ved EHF-registrering | ✅ | ✅ | ✅ | se PR | – | – |
| Innboks og leverandørside | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| F08b (kontoplan, MVA-koder, kontering) | Delvis (D-31) | – | – | – | – | – |
| Manuell Windows 11-test | ✅ | – | – | – | – | – |

## 6. Gjenstående risiko og beslutninger

- **T39:** en bruker kan bekrefte en konto uten å kontrollere den. Dialogen advarer, og hver bekreftelse revisjonsføres. Blokkering av godkjenning kommer i F09.
- **D-31:** alvorligheter og standarder bør bekreftes av regnskapsansvarlig før porten for ekte data.
- **Å-18:** eksport av kontoplan og MVA-koder fra ERP trengs for F08b.
- **Å-24:** det må fortsatt bekreftes med UDI om deres Tripletex allerede tar imot EHF direkte (D-30).
- **Porten for ekte data:** D-19 (restrisiko) er åpen, og porten (SECURITY §17) er uendret.

## 7. Manuell Windows 11-aksept

Bruk en ny testkatalog og bare syntetiske filer.

1. Kjør `InvoiceFlowAI.exe --self-test --data-dir <ny katalog>`. Forvent «Selvtest bestått».
2. Opprett en regnskapsenhet med organisasjonsnummer `314159268`, og importer og behandle en syntetisk EHF-fil (`build_ehf()`). Kolonnen «Kontroll» viser «1 feil», og «Vis kontroll» viser «Feil (BANK-001): Betalingskontoen er ikke bekreftet …».
3. Åpne «Leverandører», velg kontoen `1234.56.78903` og velg «Bekreft konto». Svar «Nei» første gang: ingenting endres. Svar «Ja» andre gang: statusen blir «Bekreftet».
4. Gå tilbake til innboksen. Kolonnen «Kontroll» viser «OK».
5. Importer samme faktura med et endret felt, for eksempel en annen referanse. Den nye fakturaen viser «Feil (DUP-001)».
6. Sperr kontoen. Begge fakturaene viser «Betalingskontoen er sperret».

## 8. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- prosjekteiers gjennomgang av promptet (D-31) og godkjenning av sammenslåing;
- bekreftelse fra regnskapsansvarlig;
- manuell Windows 11-test.

F08b venter på Å-18. F09 er ikke påbegynt.
