# Fase 10 – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

Prosjekteier godkjente fortsettelse etter F09 (G-16, «zgadzam się na kontynuację»). F09 ([RobertCygan/InvoiceFlowAI#39](https://github.com/RobertCygan/InvoiceFlowAI/pull/39)) ble slått sammen uten grønn Windows-CI på prosjekteiers uttrykkelige ønske (G-15), fordi GitHub Actions ikke startet jobbene på grunn av fakturering.

Utvikleren skrev promptet `docs/prompts/PHASE_10_EXPORT.md` v1.0 (D-34), og innholdet er ikke gjennomgått. Autorisasjonen gjelder implementering, ikke aksept, restrisiko (D-19) eller ekte data.

**GOAL:** godkjente fakturaer eksporteres til Excel eller CSV, hver faktura én gang. Databasen hindrer dobbel eksport, fakturatekst kan aldri bli en formel, og et krasj gir aldri en halv fil eller en faktura som er markert eksportert uten fil.

## 2. Leveranse

- **Migrasjon `0008_export`** (ADR-0036, `DATA_MODEL.md` §3.16):
  - `export_batches`: én fil per batch, avsluttes nøyaktig én gang, med kolonner, filhash og revisjonsanker;
  - `export_items`: én faktura per batch, bundet til godkjenning, revisjon og hash, med delvis unik indeks for aktive eksporter;
  - `export_mappings`: versjonert kolonneoppsett;
  - utløsere: bare godkjent, gjeldende innhold; ingen dobbel eksport på tvers av formater; eksportert faktura er endelig, også mens eksporten pågår.
- **`ExportService`:**
  - eksport av alle godkjente fakturaer som ikke er eksportert;
  - ny eksport av en batch med begrunnelse;
  - kolonneoppsett med egne overskrifter;
  - kopi med hashkontroll;
  - gjenoppretting ved oppstart og før hver eksport.
- **Krasjsikker rekkefølge:** batch og `pending`-rader; fil til midlertidig navn med `fsync` og navnebytte; deretter `exported`, filhash og fakturastatus i én transaksjon.
- **Filer** (`<data>/exports/<enhet>/fakturaeksport-NNNNN-ÅÅÅÅMMDD-TTMMSS.xlsx/csv`, skrivebeskyttet):
  - én rad per konteringslinje med fakturaens hodeverdier;
  - Excel med tall- og datoceller og arket «Kontroll» (antall, summer per valuta, sum av konteringslinjer, revisjonsanker);
  - CSV med BOM, semikolon, desimalkomma og `DD.MM.ÅÅÅÅ`;
  - kreditnotaer med negative beløp (ADR-0020).
- **Formelvern:** apostrof i CSV; tekstcelle med Excels apostrofmerke; egne overskrifter kan ikke begynne som formel.
- **Siden «Eksport»:**
  - fakturaer klare for eksport;
  - valg av format;
  - «Eksporter godkjente» og «Kolonner …»;
  - tidligere eksporter med status;
  - «Lagre kopi …» og «Eksporter på nytt …»;
  - hurtigtaster.
- **Gjennomgang:** retting, overstyring, avvisning og oppheving er sperret for eksporterte fakturaer, og konteringsforslag hoppes over.
- **Revisjon:** `invoice.exported`, `export.completed`, `export.failed` og `export.mapping_set`, uten begrunnelser eller fakturainnhold.
- **Avhengighet:** openpyxl 3.1.5 med et-xmlfile 2.0.0, satt inn i de eksisterende låsene.
- **Selvtest**, også `.exe`: eksport til Excel, kopi, og at en ny eksport ikke finner noe.

## 3. Valg og avvik

| Punkt | Valg | Begrunnelse |
|---|---|---|
| Hvor filen skrives | Fast eksportmappe i datakatalogen, deretter kopi dit personen vil | Atomisk navnebytte og gjenoppretting virker ikke pålitelig på nettverksstasjoner og minnepinner. Kopien kontrolleres mot hashen. |
| Radnivå | Én rad per konteringslinje | Konteringen per MVA-sats bevares. Kolonnene kan velges. |
| Kreditnota | Negative beløp og typekolonne | ADR-0020: fortegnet anvendes i eksporten. Regnskapsansvarlig bør bekrefte. |
| Dobbel eksport til et annet format | Hindret | En faktura går til regnskapet én gang. Et annet format krever ny eksport med begrunnelse. |
| Skissen i §3.5 | I tillegg kolonner, løpenummer, revisjonsanker, revisjon og hash | Batchen viser nøyaktig hva som ble eksportert, og radene binder innholdet. |
| Datoen «Godkjent dato» | Lokal dato på maskinen | Slik personen så den da fakturaen ble godkjent. |

## 4. Testresultater

Lokalt (Linux, Python 3.13, gren `claude/phase10-export`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen) | 1466 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | 94 % |
| Dekning eksportmodell og skrivere | 99–100 % |
| Ruff, Bandit, pip-audit, Gitleaks (lokalt) | Ingen funn |

Windows-CI og `.exe`-selvtesten: se PR-en. Siste kjente tilstand er at GitHub Actions ikke starter jobber på grunn av fakturering (G-15).

**Ikke prøvd:**

- import av filen i et regnskapssystem (Tripletex, Unit4, Xledger);
- ekte fakturaer;
- manuell Windows 11-test, også med Excel og skjermleser.

## 5. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Migrasjon 0008 og utløsere | ✅ | ✅ | ✅ | se PR | – | – |
| Krasjsikker eksport og gjenoppretting | ✅ | ✅ | ✅ | se PR | – | – |
| Formelvern i CSV og Excel | ✅ | ✅ | ✅ | se PR | – | – |
| Ny eksport, kolonneoppsett og kopi | ✅ | ✅ | ✅ | se PR | – | – |
| Siden «Eksport» | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| Faste ERP-formater (F14) | – | – | – | – | – | – |

## 6. Gjenstående risiko og beslutninger

- **T07:** databasen hindrer dobbel eksport, men samme fil kan importeres to ganger i regnskapssystemet. Kontrollarket og løpenummeret i filnavnet gjør det lettere å oppdage.
- **T51 og T52:** eksportfiler er ikke kryptert, og en kopi kan endres etter at den er lagret. BitLocker (Å-13) og F12.
- **T53 og D-34:** formatet og fortegnet er ikke prøvd mot et regnskapssystem (Å-02, Å-21, Å-22).
- **F09 uten Windows-CI (G-15):** F09 og F10 er ikke verifisert på Windows før CI kjører igjen.
- **D-19 og porten for ekte data:** uendret.

## 7. Manuell Windows 11-aksept

1. Følg F09-rapporten §7 fram til en godkjent faktura.
2. Åpne «Eksport». Fakturaen står i listen «klare for eksport».
3. Velg «Excel (.xlsx)» og «Eksporter godkjente» (Alt+E). Meldingen viser filnavnet, og listen over tidligere eksporter viser «Skrevet».
4. Velg eksporten og «Lagre kopi …» (Alt+L). Åpne kopien i Excel. Arket «Kontroll» viser antall og summer.
5. «Eksporter godkjente» er nå ikke tilgjengelig. På «Gjennomgang» har fakturaen status «Eksportert», og knappene er ikke tilgjengelige.
6. «Eksporter på nytt …» (Alt+N) uten begrunnelse gir en melding. Med begrunnelse kommer en ny rad med typen «Ny eksport».
7. «Kolonner …» (Alt+K): fjern og flytt kolonner, gi én en egen overskrift, og eksporter en ny faktura. Filen har de valgte kolonnene.

## 8. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- grønn Windows-CI for F09 og F10;
- prosjekteiers gjennomgang;
- regnskapsansvarliges syn på format og fortegn;
- manuell Windows 11-test.

F11 og F12 er ikke påbegynt.
