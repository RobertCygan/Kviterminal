# Fase 09 – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

Prosjekteier ba om F08b og deretter F09 (G-13, «obie po kolei»). Utvikleren skrev promptet `docs/prompts/PHASE_09_REVIEW_APPROVAL.md` v1.0 (D-33), og innholdet er ikke gjennomgått. F09 bygger på F08b ([RobertCygan/InvoiceFlowAI#38](https://github.com/RobertCygan/InvoiceFlowAI/pull/38)). Autorisasjonen gjelder implementering, ikke aksept, restrisiko (D-19) eller ekte data. F10 (eksport) er ikke påbegynt.

**GOAL:** en person gjennomgår hver faktura med kilde og kontroll, retter verdier, overstyrer avvik med begrunnelse og godkjenner eller avviser. En godkjenning er bundet til nøyaktig det innholdet som ble godkjent, og endring opphever den. BANK-001 og DUP-001 kan ikke overstyres.

## 2. Leveranse

- **Migrasjon `0007_review`:**
  - `approvals`: beslutninger nummerert per faktura, bundet til revisjon, hash og kontrollkjøring;
  - `finding_overrides`: begrunnelse 10–500 tegn; BANK-001 og DUP-001 avvises av CHECK;
  - utløsere: `approved` krever godkjenning av gjeldende innhold, og godkjent innhold kan ikke endres (ADR-0035, `DATA_MODEL.md` §3.15).
- **`ReviewService`:**
  - visning;
  - retting av felt fra en fast liste med streng norsk inndata og proveniens `manual` med bevart bevis;
  - overstyring;
  - godkjenning med ny kontroll i samme transaksjon og sammenlign-og-sett på revisjon;
  - avvisning med kommentar og oppheving;
  - forhåndsvisning av hashkontrollert sidebilde.
- **Automatisk oppheving:** hver ny revisjon av en godkjent faktura gir `revoked` og status `draft` i samme transaksjon.
- **Siden «Gjennomgang»:**
  - liste med status og kontroll;
  - felt med verdi og kilde, og retting;
  - funn med status og overstyring;
  - historikk over revisjoner og beslutninger;
  - forhåndsvisning av første side av PDF-visningen med markering av kildeboks;
  - knapper med hurtigtaster.
- **Revisjon:** `invoice.approved`, `invoice.rejected`, `invoice.approval_revoked` og `finding.overridden`, uten begrunnelser eller kommentarer.
- **Selvtest**, også `.exe`: godkjenning, og at en retting deretter opphever den.

## 3. Valg og avvik

| Punkt | Valg | Begrunnelse |
|---|---|---|
| Skissen i §3.5 (`snapshot_json`, `overridden_rule_ids`) | Revisjon og hash peker på snapshotet; overstyringer er egne rader | Ingen dobbel lagring. Overstyringen har begrunnelse og tid. |
| Avvist faktura | Kan godkjennes senere uten ny revisjon | En avvisning kan bero på en misforståelse; historikken viser begge beslutningene. |
| Hvem som godkjenner | Én lokal bruker (`user/local`) | Å-10 er ikke besvart. Rolledeling (attestasjon og anvisning) krever egen beslutning. |
| Forhåndsvisning | Første side av PDF-visningen (vedlegg analysert i F04) | EHF har ingen sidebilder. Kildebokser finnes først med OCR (F05/F06); markeringen er klar for dem. |
| Nye konteringslinjer | Kan ikke legges til eller slettes i F09, bare rettes | Forslaget gir én linje per sats. Splitting kommer ved behov. |

## 4. Testresultater

Lokalt (Linux, Python 3.13, gren `claude/phase09-review`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen) | 1364 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | 93 % |
| Dekning retting og modell | 100 % |
| Ruff, Bandit, pip-audit, Gitleaks (lokalt) | Ingen funn |

Windows-CI og `.exe`-selvtesten: se PR-en.

**Ikke prøvd:**

- ekte fakturaer;
- arbeidsflyt med to personer;
- manuell Windows 11-test, også av tastaturnavigasjon med skjermleser;
- forhåndsvisning med kildebokser fra OCR (F05/F06 finnes ikke ennå).

## 5. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Migrasjon 0007 og utløsere | ✅ | ✅ | ✅ | se PR | – | – |
| Retting med manuell proveniens | ✅ | ✅ | ✅ | se PR | – | – |
| Overstyring og godkjenning | ✅ | ✅ | ✅ | se PR | – | – |
| Siden «Gjennomgang» | ✅ | ✅ | ✅ (offscreen) | se PR | – | – |
| Rolledeling (Å-10) | – | – | – | – | – | – |

## 6. Gjenstående risiko og beslutninger

- **T49 og Å-10:** én person kan rette og godkjenne. Alt revisjonsføres.
- **D-33:** regnskapsansvarlig bør avgjøre om flere funn skal være umulige å overstyre, for eksempel SUM-002 eller ACC-001.
- **D-19 og porten for ekte data:** uendret.

## 7. Manuell Windows 11-aksept

1. Følg F08b-rapporten §7 fram til en faktura uten funn, med et PDF-vedlegg behandlet i innboksen.
2. Åpne «Gjennomgang» og velg fakturaen. Forhåndsvisningen viser første side, og feltene viser kilden.
3. Rett forfallsdatoen til en dato før fakturadatoen (Alt+R). Funnet DAT-001 vises, og «Godkjenn» gir en melding om én åpen feil.
4. Overstyr funnet med en begrunnelse (Alt+O), og godkjenn (Alt+G). Statusen blir «Godkjent».
5. Rett et felt igjen. Statusen blir «Utkast», og historikken viser «Godkjenning opphevet».
6. Med en ubekreftet konto: «Godkjenn» gir «BANK-001 må løses først», og «Overstyr» er ikke tilgjengelig.

## 8. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- sammenslåing av #38 før denne PR-en;
- prosjekteiers gjennomgang;
- Å-10;
- manuell Windows 11-test.

F10 (eksport) er ikke påbegynt.
