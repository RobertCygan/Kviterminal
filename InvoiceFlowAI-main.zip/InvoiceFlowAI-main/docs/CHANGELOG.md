# Endringslogg

Formatet følger [Keep a Changelog](https://keepachangelog.com/no/1.1.0/), og versjonsnumre følger [semantisk versjonering](https://semver.org/lang/no/).

## [Uutgitt]

### Fase 06 – feltuttrekk til kanonisk modell

- Prosjekteier ba om F06 (G-25). Prompt `prompts/PHASE_06_EXTRACTION.md` v1.0 (D-39), ADR-0041.
- Norske fakturafelt hentes fra tekstlag eller OCR med proveniens (side, boks, råtekst, OCR-sikkerhet):
  - fakturatype, nummer og datoer;
  - leverandør og kunde;
  - KID, kontonummer, IBAN og BIC;
  - totaler, MVA-spesifikasjon og linjer.
- Uleselige verdier beholdes som råtekst og flagges; ingenting fylles inn.
- Ett fakturautkast per del av et dokument (skannede bunker deles ved skilleark), med funn, konteringsforslag og validering som for EHF.
- Selvtesten leser en syntetisk faktura.
- Referansesett med gyldne filer for tekstlag og OCR.

### Beslutningsregister 2.7

- G-25: F05 (#45) slått sammen uten grønn CI; Tesseract og norsk språkdata pakkes i F13; F06 startet.

### Fase 05 – tekstgjenkjenning (OCR)

- Prosjekteier godkjente Tesseract 5 som OCR-motor (D-13, G-24). Prompt `prompts/PHASE_05_OCR.md` v1.0 (D-38).
- Eget OCR-steg etter sideanalysen (ADR-0040):
  - sider uten tekstlag som har blekk og ikke er skilleark, gjenkjennes i den isolerte arbeidsprosessen;
  - på Windows i samme Job Object, med to prosesser.
- Migrasjon `0011_ocr`: steget `ocr` og tabellen `ocr_pages`. Ordene med boks og sikkerhet ligger i avledede filer.
- Siden «Innboks»:
  - kolonnen «Tekst (OCR)»;
  - «Vis tekst …» med kilde og sikkerhet per side;
  - en melding når Tesseract mangler.
- Selvtesten leser et sidebilde tilbake når Tesseract er installert.
- Referansesett med syntetiske skannede fakturaer; tegnfeilrate og tid per side testes.
- Windows-CI installerer Tesseract og norsk språkdata med låst versjon og kontrollsum.
- Ny veiledning `OCR_SETUP.md`.

### Beslutningsregister 2.6

- G-24: F11b (#44) slått sammen uten grønn CI; D-13 (Tesseract 5) godkjent; F05 startet.

### Fase 11b – skanner via produsentens program

- Prosjekteier valgte variant A (G-23): Brother iPrint&Scan lagrer i skannemappen, ingen skannerdriver i programmet (ADR-0039). Prompt `prompts/PHASE_11B_SCANNER_SETUP.md` v1.0 (D-37).
- Siden «Skanning» viser målingene for hver side i valgt dokument, grenseverdiene og hvilke sider som er nær en grense.
- «Kopier mappesti» legger skannemappens sti på utklippstavlen.
- Ny veiledning `SCANNER_SETUP.md`: skanneprofil, daglig bruk, kontroll av grenseverdiene og feilsøking.

### Beslutningsregister 2.5

- G-23: F11a (#43) slått sammen uten grønn CI etter prosjekteiers ønske; F11b etter variant A.

### Beslutningsregister 2.4

- G-22: prosjekteier oppga Brother ADS-4700W som foreløpig skanner (Å-01). Rapporten for F11a beskriver hvordan den brukes med skannemappen.

### Fase 11a – skannede bunker uten skannerdriver

- Prosjekteier ba om delen av F11 som ikke krever skanner (G-21). Prompt `prompts/PHASE_11A_SCAN_BATCHES.md` v1.0 (D-36).
- Arbeidsprosessen måler hvor mørk hver side er, i hele siden og i det sentrale området (ADR-0038). Migrasjon `0010_page_metrics` lagrer målingene. PDF- og bildedokumenter analyseres på nytt én gang (motorversjon `+side1`).
- Blanke sider og skilleark gjenkjennes, og en bunke deles i deler (sideintervaller). Originalen endres aldri.
- Eget skilleark (PDF) kan lagres og skrives ut.
- Overvåket skannemappe: ferdige filer leses inn, flyttes til `importert` eller `avvist` og analyseres.
- Siden «Skanning» med overvåking, oversikt over deler og hurtigtaster.
- Selvtesten dekker en skannet bunke.

### Beslutningsregister 2.2

- G-19: F12 (#41) slått sammen uten grønn CI etter prosjekteiers ønske.
- G-20: prosjekteier godkjente D-34 og D-35, besvarte Å-14 og Å-10 etter anbefalingene, godkjente anbefalingen i Å-18 og at ingenting slettes automatisk (Å-07). Eksempelfiler (Å-18), regnskapsansvarliges bekreftelse av oppbevaringstid (Å-07) og manuelle Windows 11-tester gjenstår.

### Fase 12 – kryptert sikkerhetskopi og gjenoppretting

- Prosjekteier ba om F12 (G-18). Prompt `prompts/PHASE_12_BACKUP.md` v1.0 (D-35).
- Sikkerhetskopi av hele datakatalogen (database via backup-API, dokumentarkiv, eksportfiler, innstillinger) i én fil kryptert med AES-256-GCM i autentiserte biter. Nøkkelen avledes fra en passordfrase med scrypt, og passordfrasen lagres aldri (ADR-0037).
- Manifest med SHA-256 og revisjonsanker. Kontroll og gjenoppretting kontrollerer innhold, databasens integritet, hele revisjonskjeden, ankeret og alle dokumenter. Gjenoppretting bare til en tom mappe utenfor datakatalogen.
- Ingen sikkerhetskopi når revisjonskjeden er brutt eller dokumentarkivet er ufullstendig.
- Migrasjon `0009_backup` legger til registeret `backups`. Sletting av en registrert fil registreres; ingenting slettes automatisk (Å-07).
- Siden «Sikkerhetskopi» med hurtigtaster. Arbeidsmapper etter avbrudd fjernes ved oppstart.
- Revisjonshendelser: `backup.created`, `backup.verified`, `backup.restored` og `backup.deleted`.
- Prosedyre på norsk: `BACKUP_PROCEDURE.md`.
- Ny avhengighet: cryptography 50.0.1 (med cffi og pycparser).
- Selvtesten lager og gjenoppretter en sikkerhetskopi og avviser en endret fil.

### Fase 10 – eksport til Excel og CSV

- Prosjekteier godkjente start av F10 (G-16). Prompt `prompts/PHASE_10_EXPORT.md` v1.0 (D-34).
- Migrasjon `0008_export` legger til `export_batches`, `export_items` og `export_mappings`. Delvis unik indeks og utløsere hindrer dobbel eksport, også til et annet format, og gjør en eksportert faktura endelig (ADR-0036).
- Eksport av godkjente fakturaer til Excel (`.xlsx`, med kontrollark) eller CSV (UTF-8 med BOM, semikolon, desimalkomma). Én rad per konteringslinje; kreditnotaer med negative beløp.
- Krasjsikker skriving med midlertidig fil, `fsync` og navnebytte. Åpne eksporter fullføres eller markeres som mislykket ved oppstart.
- Vern mot formelinjeksjon i CSV og Excel.
- Ny eksport med begrunnelse, versjonert kolonneoppsett med egne overskrifter, og kopi som bare gis ut når SHA-256 stemmer.
- Siden «Eksport» med hurtigtaster. Gjennomgang og nytt konteringsforslag er sperret for eksporterte fakturaer.
- Revisjonshendelser: `invoice.exported`, `export.completed` (med revisjonsanker), `export.failed` og `export.mapping_set`.
- Ny avhengighet: openpyxl 3.1.5 (og et-xmlfile 2.0.0).
- Selvtesten dekker eksport, kopi og hindring av dobbel eksport.

### Fase 09 – gjennomgang og godkjenning

- Prompt `prompts/PHASE_09_REVIEW_APPROVAL.md` v1.0 (D-33), autorisert i G-13.
- Migrasjon `0007_review` legger til `approvals` og `finding_overrides` (kun tilføyelse) og utløsere på `invoices` som binder statusen `approved` til en godkjenning av gjeldende innhold (ADR-0035).
- Godkjenning, avvisning (med kommentar) og oppheving. Godkjenning kjører kontrollen på nytt, krever forventet revisjon og blokkeres av BANK-001, DUP-001 og feil uten overstyring.
- Feilfunn kan overstyres med begrunnelse for én revisjon. BANK-001 og DUP-001 kan aldri overstyres.
- Manuell retting av hode, betaling, totaler og kontering med streng norsk inndata og proveniens `manual`. Rettingen gir en ny revisjon, en ny kontroll og opphever en godkjenning.
- Siden «Gjennomgang» viser felt med kilde, funn, historikk og forhåndsvisning av første side med markering av kildeboks, og har hurtigtaster.
- Revisjonshendelser: `invoice.approved`, `invoice.rejected`, `invoice.approval_revoked` og `finding.overridden`, uten begrunnelser eller kommentarer.
- Selvtesten dekker godkjenning og oppheving.

### Fase 08b – referansedata og konteringsforslag

- Prosjekteier ba om F08b og deretter F09 (G-13). Prompt `prompts/PHASE_08B_REFERENCE_DATA.md` v1.0 (D-32).
- Import av kontoplan, MVA-koder (med gyldighet og retning) og dimensjoner fra CSV, med streng validering. Hele filen avvises ved feil, og formelceller og kontrolltegn avvises. Hver import er et øyeblikksbilde, og den forrige beholdes (ADR-0034).
- Migrasjon `0006_reference` legger til `reference_imports`, `chart_of_accounts`, `vat_codes`, `dimension_values` og `supplier_defaults`. Alle tabellene er kun tilføyelse.
- Standardkontering per leverandør. Konteringsforslag per MVA-sats legges inn ved registrering og kan foreslås på nytt. Manuelle verdier overskrives aldri.
- Regelsett 1.1 med MVA-002, ACC-001, ACC-002 og ACC-003.
- Grensesnitt:
  - delen «Referansedata» under «Innstillinger»;
  - «Sett standardkontering …» på leverandørsiden;
  - «Foreslå kontering på nytt» og visning av konteringen i kontrollvinduet.
- Revisjonshendelser: `reference.imported` og `supplier.defaults_set`.
- Selvtesten dekker import, standardkontering og en faktura uten funn.

### Fase 08a – validering, leverandørregister og duplikatkontroll

- Prosjekteier delegerte svarene på Å-24 og F15-promptets spørsmål 2–4 og ba om start av F08 (G-12). Svarene står i D-30, og oppdelingen i F08a og F08b i D-31 (`prompts/PHASE_08_ACCOUNTING_ENGINE.md` v1.0).
- Regelmotor med rene funksjoner og regelsettversjon 1.0: REQ-001/002, ENT-001, SUM-001/002, MVA-001/003, DAT-001/002, ID-001–004, DUP-001/002, BANK-001, CRN-001 og CUR-001. Kontrollsiffer MOD11, MOD10 og MOD97 er lagt i `domain/checksums.py`.
- Migrasjon `0005_validation` legger til `suppliers`, `supplier_bank_accounts`, `validation_runs` og `validation_results` (kun tilføyelse; utløsere beskytter kontonummer og status). `audit_events` er bygget om for emnetypen `supplier` (ADR-0033).
- Fakturaer kontrolleres ved registrering, på forespørsel og når en konto bekreftes eller sperres. Nye betalingskontoer er alltid ikke bekreftet (BANK-001), til brukeren bevisst bekrefter dem.
- Innboksen viser kolonnen «Kontroll» og har knappene «Vis kontroll» og «Kontroller alle på nytt». Den nye siden «Leverandører» har knappene «Bekreft konto» og «Sperr konto».
- Nye revisjonshendelser: `invoice.validated`, `supplier.created`, `supplier.account_added` og `supplier.account_status_changed`. De inneholder bare ID-er, koder og antall.
- Selvtesten (også `.exe`) kontrollerer validering og kontobekreftelse.
- Sikkerhetsunntak i utviklingslåsen (ADR-0024): setuptools 84.1.0 og filelock 4.2.1. Kjøretidslåsen er uendret.

### Fase 15 – EHF/PEPPOL BIS Billing 3.0

- Migrasjon `0004_ehf`: `documents` og `processing_jobs` bygges om (format `xml`, kilde `ehf_attachment`, steget `ehf_extraction`, nye feilkoder); ny tabell `invoice_findings` (kun tilføyelse). Migratoren slår av fremmednøkler utenfor transaksjonen når en revisjon krever det, og kontrollerer radtall og `foreign_key_check` før commit (ADR-0032). Alle eksisterende rader og hasher er uendret.
- XML gjenkjennes ved import (valgfri BOM, `<?xml`, rotelement `Invoice`/`CreditNote`) med endelse `.xml`.
- EHF-leser i den isolerte arbeidsprosessen med `defusedxml` (DTD, entiteter og eksterne referanser forbudt; grenser for dybde, elementer, linjer og vedlegg). Faktura og kreditnota mappes til den kanoniske modellen med proveniens `extracted`, XPath og råtekst; beløp som `Decimal`; ugyldige verdier blir `None` med råtekst. Kreditnotaer har positive totaler og typen `credit_note` (D-16).
- Kontroller i hovedprosessen: regneregler BR-CO-10/13/14/15/16, valuta, mottaker mot regnskapsenheten, mulig duplikat (leverandør + fakturanummer), formkrav og vedlegg. Avvik lagres som flagg med faste koder; ingenting rettes eller stoppes stille.
- Innebygde vedlegg importeres gjennom F03-importen (signatur, karantene) og kobles med `document_links`; PDF-visningen kan deretter analyseres av F04.
- Fakturaen registreres som utkast knyttet til XML-dokumentet. Revisjon bare med antall linjer, vedlegg og flagg.
- Innboksen viser format «EHF», leverandør, fakturanummer, beløp og avvik på norsk.
- Selvtesten (også `.exe`) importerer og behandler en syntetisk EHF-faktura.
- Avhengighet: defusedxml 0.7.1 (PSF), bare i arbeidsprosessen.

### Veikart – EHF prioriteres (utformet, 2026-10-23)

- Å-09 besvart: fakturaene kommer som EHF. Foreslått ny rekkefølge med F15 (EHF/PEPPOL BIS Billing 3.0) rett etter F04 (D-29) og nytt åpent spørsmål Å-24 om hvordan EHF-filene kommer inn. `docs/prompts/PHASE_15_EHF_IMPORT.md` v1.0.
- Prosjekteier godkjente D-29 (F15 foran F05), D-16 (positive totaler for kreditnota, ADR-0020) og F15-promptet (G-11). Ingen kode er endret.

### Fase 04 – isolert PDF- og bildebehandling

- Migrasjon `0003_processing`: `processing_jobs`, `document_pages` og `derived_files`, enhetsavgrenset med sammensatte FK-er; idempotent per dokument, steg, motorversjon og innstillinger; sider og filer bare til en kjørende jobb, sluttstatus endelig. `documents` er uendret.
- `ProcessingService`: kontroll av original før og etter, isolert kjøring, validering av rapport og hver utdatafil, publisering til `derived/` og én avsluttende transaksjon; gjenoppretting ved oppstart (avbrutte jobber, arbeidsmapper, filer uten rad flyttes – ingenting slettes).
- Arbeidsprosess (`spawn`, én per dokument) med Windows Job Object via `ctypes` (2 GB, ingen underprosesser, drepes med hovedprosessen), tidsavbrudd 120 s og stopp ved avslutning (ADR-0031). Rapporten leses bare som bytes og valideres med Pydantic.
- Porten `DocumentParser` med adapterne pypdfium2 (PDF) og Pillow (PNG, JPEG, TIFF): sideantall, tekstlag med én boks per tegn, sidebilder i 300 dpi, rotasjon, grenser for sider, piksler og tekst, avvisning av krypterte PDF-er og flagg for aktivt innhold.
- Revisjonshendelsene `document.processing_started` og `document.processing_finished` med bare faste koder.
- Innboksen viser sideantall og behandlingsstatus på norsk, med knappene «Behandle nye dokumenter» og «Behandle valgt på nytt».
- Selvtesten (også `.exe`) analyserer en syntetisk PDF i en ekte arbeidsprosess.
- Avhengigheter: pypdfium2 5.13.0 og Pillow 13.0.0 (sikkerhetsunntak etter ADR-0024, se `DEPENDENCIES.md` §7).
- Prosjekteier godkjente avvikene i F04 (D-28, G-10).

### Beslutninger – PDF-motor og Fase 04 (2026-10-23)

- Prosjekteier valgte alternativ C i D-11: pypdfium2 er standard PDF-adapter, og PyMuPDF (AGPL-3.0) utgår av stakken (ADR-0023 akseptert). Fase 04-promptet v1.1 er godkjent for implementering. Registrert som G-09.

### Åpne spørsmål – Tripletex og Xledger delvis besvart (2026-10-23)

- Å-21: første Tripletex-kunde blir UDI (Utlendingsdirektoratet) i Narvik; fakturaene skal til UDIs Tripletex. Å-22: prosjekteier anskaffer selv Xledger når det kommer oppdrag; F14c venter til da. Øvrige punkter i begge spørsmålene er fortsatt åpne. Kun dokumentasjon.

### Beslutninger – ERP-integrasjoner godkjent (2026-10-23)

- Prosjekteier godkjente D-26 (ADR-0030, utgående nettverk for ERP-integrasjoner) og D-27 (rekkefølge Excel/CSV → Unit4/Agresso → Tripletex → Xledger), registrert som G-08. ADR-0030 er nå akseptert; `SECURITY.md` §3 og TB3 viser til ERP-tillegget. Kontrollene er planlagte, ikke implementerte, og ingen kode er endret.

### Veikart – ERP-integrasjoner (utformet, 2026-10-23)

- Prosjekteier ba om Tripletex og Xledger i tillegg til Unit4/Agresso (G-07). F14 er delt i F14a Unit4/Agresso (fil), F14b Tripletex (API) og F14c Xledger (fil eller API), med felles prinsipper: aldri automatisk bokføring, kun godkjente fakturaer, fil før API, én regnskapsenhet per ERP-klient og idempotent innsending.
- ADR-0030 (foreslått): utgående nettverk for ERP-integrasjoner via samme samtykkeport som KI. Ny beslutning D-26 (godkjenning av ADR-0030) og D-27 (rekkefølge), nye åpne spørsmål Å-21–Å-23, nye trusler T24–T29 og krav F-17/F-18. Ingen kode er endret.

### Fase 04 – prompt v1.1 (utformet, ikke autorisert)

- `docs/prompts/PHASE_04_ISOLATED_DOCUMENT_PROCESSING.md` v1.1: betinget av D-11 (skrevet for alternativ C, pypdfium2), justert mot faktisk F03-skjema (§3.10) og grensene i `SECURITY.md` §8.1; åpne spørsmål til prosjekteier er listet. Ingen del av F04 er påbegynt.

### Avhengigheter – Dependabot etter karantenepolicyen (2026-10-22)

- Dependabot foreslår ikke lenger pydantic-core alene (pydantic krever en eksakt versjon); forslaget pydantic-core 2.49.0 (#23) er lukket. platformdirs 4.11.12 (#24) og actions/upload-artifact 7.0.1 (#22), begge utgitt før karantenegrensen, er gjennomgått (diff og festet SHA kontrollert).
- Dependabot venter 30 dager på nye versjoner (`cooldown`, ADR-0024) og grupperer PySide6-pakkene. Åpne forslag innenfor karantenen (iniconfig 2.3.1, platformdirs 4.13.5, pluggy 1.7.0, PySide6 6.12.0, actions/upload-artifact 7.0.2) er lukket eller holdt tilbake; actions/checkout 7.0.1 og actions/setup-python 7.0.0 (utgitt juli 2026) er tatt inn.

### Fase 03 – sikker dokumentimport og dokumentarkiv (grunnmur)

- Generisk dokumentmodell (`documents`, `document_links`) i tråd med `DOCUMENT_ARCHIVE_SCOPE.md`; migrasjon `0002_documents`.
- Sikker import av PDF/PNG/JPEG/TIFF til innholdsadressert, enhetsavgrenset originalarkiv med karantene, duplikatkontroll per enhet og revisjonshendelser uten filnavn.
- Krasjmodell med gjenoppretting ved oppstart; ingen originaler slettes.
- Faktura må peke på et lagret dokument i samme enhet (utløser, ADR-0029/D-25).
- Innboks-side med dialog for første regnskapsenhet (D-22), manuell innlesing (D-23) og manuell dokumenttype (D-24).
- Etterkontroll av F03 (2026-10-22): flytting og sletting i dokumentlageret forsøkes på nytt i inntil ca. 1,5 s når et annet program (antivirus, indeksering) holder filen; en lagringsfeil for én fil stopper ikke resten av en import med flere filer (nytt utfall «Feilet»); oppstartsgjenoppretting hopper over låste filer i stedet for å stanse programmet.
- Etterkontroll 2 av F03: integritetskontrollen avviser symbolske lenker og lenkede mapper i arkivet (tidligere ble en lenke til en identisk fil meldt som «ok»); import av flere filer stopper mellom filer ved avslutning i stedet for å bli avbrutt under databaselukking.
- Rettet etter F03: publisering av originaler skjer under en prosesslås, fordi Windows kortvarig nekter å åpne en fil som erstattes. Samtidig import av samme innhold feilet sporadisk med `STORAGE_UNAVAILABLE` i Windows-CI.

### Fase 02 – Prosjekteiers beslutninger (2026-10-22)

- Prosjekteier godkjente D-20 (uforanderlige fakturaøyeblikksbilder med projeksjon) og D-21 (ingen automatisk standardenhet), begge ADR-0026. Registrert som G-04. Manuell Windows 11-test av F02 og formell faseaksept gjenstår.

### Sikkerhetsunntak – certifi (2026-10-22)

- `certifi` 2026.7.22 → 2026.10.19 i `requirements/dev.lock.txt` etter PYSEC-2026-4320 (ADR-0024 pkt. 3). Bare utviklingsavhengighet; kjøretidslåsen er uendret. Se `DEPENDENCIES.md` §7.

### Fase 00 – Godkjenninger og endelig verifisering (2026-10-20)

- Prosjekteier godkjente D-04 (Ruff), D-05 (PyInstaller `onedir`), D-06 (sentral nb-NO-tekstkatalog), D-07 (avhengighetspolicy med sikkerhetsunntak) og D-08 (`pytest-qt`). Registrert som G-01 i `PHASE_00_DECISION_REGISTER.md`.
- D-02 utført av prosjekteier: `main` er standardgren (verifisert).
- D-01 (godkjenning av Fase 00) er fortsatt åpen og avgjøres av prosjekteier.
- Endelig CI på `f5db4d9` (kjøring 39399437972): 140 bestått og 100 % dekning på Windows; Ruff, Bandit, pip-audit og Gitleaks (3 commits) uten funn.
- Akseptsjekkliste, revisjonsrapport, teststrategi, avhengighetsoversikt og Fase 01-prompt oppdatert i tråd med godkjenningene.

### Fase 00 – Sluttrevisjon og korrigeringer (2026-10-20, gren `claude/phase00-final-audit`)

#### Lagt til

- Revisjonsrapport (`docs/PHASE_00_AUDIT.md`) med 23 funn (0 kritiske, 2 høye, 10 middels, 11 lave), bevis og tiltak.
- Beslutningsregister (`docs/PHASE_00_DECISION_REGISTER.md`) og akseptsjekkliste (`docs/PHASE_00_ACCEPTANCE.md`).
- ADR-0022 (regnskapsenhet i persistensmodellen), ADR-0023 (PDF-lisens og utskiftbar PDF-adapter, erstatter ADR-0012), ADR-0024 (avhengighetsoppdatering med sikkerhetsunntak, erstatter ADR-0017), ADR-0025 (kanonisk tallform og strenge skalartyper).
- Trusler T21–T23 og kontrollstatus i trusselmodellen (§9).
- Transaksjonsgrenser (`DATA_MODEL.md` §3.8), regler REQ-002 og ENT-001, åpne spørsmål Å-19 og Å-20.
- 59 regresjonstester (`tests/unit/domain/test_contract_types.py`).

#### Endret

- Kontrakter: beløp, enhetspriser, mengder og MVA-satser normaliseres til én kanonisk form; datoer godtas kun som `YYYY-MM-DD`; strenge heltall, boolske verdier og flyttall; tekst uten kontroll-/formattegn; grense og unikhet for `source_line_numbers`.
- Datamodell: `accounting_entities` og `entity_id` på regnskapsdata, sammensatte fremmednøkler, enhetsavgrensede nøkler, dokumentlager per enhet; revisjonskolonner omdøpt til `subject_type/subject_id`.
- CI: Gitleaks 8.24.3 som låst binærfil med full historikk (erstatter `gitleaks-action`), bash med `-eo pipefail` på Windows, `persist-credentials: false`.
- Fase 01-prompt v1.1: krav om gren og pull request, stier i tråd med ADR-0022, avhengighet til beslutningsregisteret.
- Statusnivåene skiller nå Linux-testet, Windows-CI-testet og Windows 11-akseptert; utdaterte påstander rettet.
- `AGENTS.md`: regler for riktig mål-repo og regnskapsenhet.

#### Verifisering (Linux, Python 3.13.16)

- `pytest`: 140 bestått; dekning 100 % (linje og gren) for `invoiceflow`.
- `ruff`, `bandit`, `pip-audit`: ingen funn.
- Windows-CI (kjøring 39399231517): 140 bestått, 100 % dekning, Ruff/Bandit/pip-audit grønne.
- Gitleaks 8.24.3 på full historikk: 2 commits skannet, ingen funn.

### Fase 00 – Fundament, arkitektur og sikkerhet (2026-10-20)

#### Lagt til

- Masterspesifikasjon med overordnet teknisk oversikt, krav, Definisjon av ferdig, statusbegreper, ordliste og 18 åpne spørsmål (`docs/MASTER_SPECIFICATION.md`).
- Systemarkitektur med lag, avhengighetsregler, moduler, porter, behandlingsløp, tilstandsmaskiner, prosessmodell, Windows-hensyn og repostruktur, inkl. Mermaid-diagrammer (`docs/ARCHITECTURE.md`).
- Datamodell: normalisert SQLite-skjema (22 tabeller), autoritative kilder, proveniensutforming, innholdshash, første katalog med valideringsregler og fillagringsstruktur (`docs/DATA_MODEL.md`).
- Sikkerhetsarkitektur med tillitsgrenser TB1–TB7, loggingspolicy, filhåndtering, KI-sikkerhet og port for ekte data (`docs/SECURITY.md`).
- Trusselmodell med 20 trusler, risikovurdering, tiltak og restrisiko (`docs/THREAT_MODEL.md`).
- Teststrategi, utviklingsveikart (F00–F15), 21 arkitekturbeslutninger, avhengighetsoversikt med verifisert Windows-hjulstøtte og lisenser.
- Prompt for Fase 01 – Windows-applikasjonsskjelett (`docs/prompts/PHASE_01_WINDOWS_APPLICATION_SKELETON.md`).
- Kanoniske Pydantic-kontrakter i `src/invoiceflow/domain/`: `CanonicalInvoice`, `FieldValue`, `Provenance`, `Evidence`, skalartyper for beløp og norske identifikatorer.
- Fiktiv eksempelfaktura i kanonisk JSON (`docs/examples/eksempel_faktura_kanonisk.json`).
- Tester: kontrakter, sikkerhetskrav for skjema, arkitekturvakt for domenelaget, kontroll av påkrevde dokumenter.
- Utviklingsoppsett: `pyproject.toml`, universell låsefil med hasher (`requirements/dev.lock.txt`), `.gitignore` som sperrer data og dokumenter, `.gitattributes`, `.editorconfig`, `AGENTS.md`.
- CI på `windows-latest` (pytest med dekning, ruff, Bandit, pip-audit) og Gitleaks.

#### Verifisering (Linux, Python 3.13.16, 2026-10-20)

- `pytest`: 78 bestått, dekning 100 % (linje og gren) for `invoiceflow`.
- `ruff check`, `ruff format --check`, `bandit -r src`: ingen funn.
- `pip-audit` mot låsefilen: ingen kjente sårbarheter.
- Hemmelighetsskanning: Gitleaks var ikke tilgjengelig lokalt; `detect-secrets` 1.5.0 kjørt som erstatning uten funn. Gitleaks kjøres i CI.
- Windows: ikke verifisert lokalt; verifiseres av CI-jobben `test-windows`.


## Fase 01 – Windows-applikasjonsskjelett (under verifisering)

- PySide6-skall med seks norske plassholdersider, menyer, statuslinje og dialoger.
- Streng oppstartskonfigurasjon, atomisk standardfil og eksplisitt datakatalog.
- Én-instans-lås per datakatalog, OneDrive-advarsel, JSON-logging med maskering.
- Eksakt norsk beløps-, prosent- og datoformatering, global feilhåndtering og selvtest.
- PyInstaller onedir-spesifikasjon og automatiserte tester for GUI og oppstartsgrenser.
- Bygger på PR #1. Prosjekteier ba 2026-10-20 om å gå videre til neste fase;
  det registreres som tillatelse til F01, ikke som generell risikoaksept eller utgivelse.

## Fase 02 – persistens og sluttgjennomgang (2026-10-20)

- Viderefører Claude-commit `8daa6e2`: SQLAlchemy/Alembic, fire forretningstabeller, immutable fakturarevisjoner og global auditkjede.
- Retter kontekstavhengig Decimal-normalisering og avgrenser lagringsformatet før eksponentutvidelse.
- Verifiserer auditkjeden før migrasjonscommit, og avviser fremmede databaser med kjent revisjon uten nødvendige tabeller.
- Kontrollerer headerprojeksjon mot gjeldende kanonisk snapshot ved lesing.
- Dokumenterer ADR-0026–0028, faktisk datamodell, migrasjon/restore, restrisiko og akseptprosedyre.
- Registrerer G-03 (opprinnelig G-02, omnummerert ved sammenslåing med `main`) som tillatelse til å fullføre F02 og M-01 som prosjekteiers rapporterte Windows-test av F01. Ingen generell risikoaksept eller formell F00/F02-godkjenning utledes.
- F03-prompt er forberedt, ikke utført.
