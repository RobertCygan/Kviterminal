# Fase 06 – leveranse og akseptgrunnlag

## 1. Omfang og autorisasjon

Prosjekteier ga «Zgoda na start F06» (G-25). Utvikleren skrev promptet `docs/prompts/PHASE_06_EXTRACTION.md` v1.0 (D-39), og innholdet er ikke gjennomgått.

**GOAL:** fakturaer i PDF og skannede fakturaer blir fakturautkast i den kanoniske modellen. Hver verdi har proveniens, ingen verdi diktes opp, og verdier som ikke kan leses, beholdes som råtekst og flagges.

## 2. Leveranse

- **Sideoppsett** (`application/extraction/layout.py`):
  - samme ord og linjer fra tekstlag og OCR;
  - linjer etter geometrien, celler ved brede mellomrom;
  - sporing fra tekst til ord og bokser.
- **Normalisering** (`parse.py`):
  - norske og engelske beløp;
  - datoer i tall og med månedsnavn;
  - organisasjonsnummer med `MVA`, kontonummer, KID, IBAN, BIC, sats, valuta og fakturanummer.
  - Ugyldige verdier (31.02.2026) blir `None`.
- **Feltregler** (`fields.py`, ADR-0041):
  - fakturatype, nummer, fakturadato, forfallsdato, valuta;
  - kreditert faktura og «Deres ref.»;
  - leverandør (navn, organisasjonsnummer, MVA-registrert) og kunde;
  - KID, konto, IBAN og BIC;
  - totaler og MVA-spesifikasjon per sats;
  - linjer der antall × pris = beløp.
  - Verdier tas bare ved ledetekst, på samme linje eller rett under i samme kolonne.
  - Proveniens: side, boks, råtekst og OCR-sikkerhet.
- **Registrering** (`service.py`):
  - ett fakturautkast per del, én gang;
  - funn: summer, uleselige verdier, manglende felt, mottaker og duplikat;
  - konteringsforslag og validering i samme transaksjon.
  - Kjøres etter analyse og OCR under «Behandle nye dokumenter», «Behandle valgt» og skanning.
- **Hvilke dokumenter:**
  - faktura og kreditnota;
  - `unclassified` bare når teksten sier faktura eller kreditnota;
  - aldri EHF eller EHF-vedlegg.
  - Dokumenttypen endres ikke (D-24).
- **Selvtest:** en syntetisk faktura blir et fakturautkast med riktig nummer, beløp og KID.
- **Referansesett:** fire syntetiske fakturaer (standard, kolonner, kreditnota, to satser over to sider) med gyldne filer.

## 3. Valg og avvik

| Punkt | Valg | Begrunnelse |
|---|---|---|
| Hvor uttrekket kjører | Hovedprosessen, rene funksjoner | Inndata er validerte, hash-kontrollerte tekstfiler; mønstrene er lineære |
| Linjer | Fra geometrien, ikke fra kilden | Ledetekst og verdi i hver sin blokk havner på samme linje |
| Valuta | Bare når den står i dokumentet | Ingen standardverdi; mangler den, blir det funnet «mangler påkrevd felt» |
| Kreditnota | Positive beløp, retning i `invoice_type` | ADR-0020 (D-16); råteksten beholder fortegnet |
| `unclassified` | Leses når teksten sier faktura eller kreditnota | Dokumenttypen endres ikke (D-24) |
| Nytt uttrekk | Samme del registreres ikke på nytt | Som for EHF; retting skjer i gjennomgangen (F09) |
| Fakturalinjer | Bare rader med beskrivelse og beløp; antall og pris bare når de stemmer | Ingen gjetting av kolonner |

## 4. Testresultater

Lokalt (Linux, Python 3.13, Tesseract 5.3.4, gren `claude/phase06-extraction`):

| Kontroll | Resultat |
|---|---|
| `pytest` med dekning (inkl. GUI offscreen, OCR og gyldne filer) | 1819 bestått, 1 hoppet over (Windows Job Object) |
| Dekning utenfor domain/UI (`--fail-under=90`) | 94 % (uttrekksmodulene 94–100 %) |
| Ruff, Bandit, pip-audit, Gitleaks (lokalt) | Ingen funn |
| Selvtest med Tesseract | Bestått |

**Referansesett:** alle fire fakturaer gir nøyaktig verdiene i de gyldne filene, både fra tekstlag og gjennom gjengivelse og OCR. Det gjelder også verdier som ikke finnes: ingen verdi utover filen.

Windows-CI og `.exe`-selvtesten: se PR-en. GitHub Actions har ikke startet jobber på grunn av fakturering siden F09.

**Ikke prøvd:**

- ekte fakturaer (port for ekte data);
- ekte skann;
- manuell Windows 11-test.

## 5. Status

| Område | Utformet | Implementert | Testet (Linux) | Verifisert (Windows-CI) | Eiergodkjent | Utgitt |
|---|---|---|---|---|---|---|
| Sideoppsett og normalisering | ✅ | ✅ | ✅ | se PR | – | – |
| Feltregler med proveniens | ✅ | ✅ | ✅ (syntetisk) | se PR | – | – |
| Registrering av utkast per del | ✅ | ✅ | ✅ | se PR | – | – |
| Treffsikkerhet på ekte fakturaer | – | – | – | – | – | – |

## 6. Gjenstående risiko og beslutninger

- **Treffsikkerhet:** reglene er laget for vanlige norske oppsett og prøvd på syntetiske fakturaer. Ekte leverandører har andre oppsett, og verdier kan mangle eller (sjeldnere) havne feil. Alle utkast går gjennom funn, validering og menneskelig godkjenning (F08/F09).
- **T68:** en forfalsket faktura med en annen konto. Nye kontonumre er ubekreftede til en bruker bekrefter dem (F08a).
- **Promptets åpne spørsmål 1:** forslag til dokumenttype ut fra teksten?
- **Windows-CI:** F09–F12, F11, F05 og F06 er ikke verifisert på Windows før CI kjører igjen.

## 7. Manuell Windows 11-aksept

1. Les inn en faktura i PDF fra en leverandør (syntetisk eller etter porten for ekte data) og velg «Behandle nye dokumenter».
2. Kolonnen «Faktura» i «Innboks» viser leverandør, nummer og beløp. «Gjennomgang» viser utkastet med funn.
3. Kontroller feltene mot fakturaen. Mangler et felt, skal det være tomt, ikke feil.
4. Skann en bunke med to fakturaer og et skilleark (`SCANNER_SETUP.md`). Det skal bli to utkast med hvert sitt sideintervall.
5. Sett en kvittering til typen «Kvittering» før behandling. Den skal ikke bli et fakturautkast.

## 8. Anbefaling

Teknisk leveranse; se PR-en for Windows-CI. Det som gjenstår:

- prosjekteiers gjennomgang av D-39;
- måling på ekte fakturaer når porten for ekte data åpnes;
- manuell Windows 11-test.

Neste fase etter roadmapen er F07 (KI-tolkning, valgfri). Den krever avklaring av Å-03 og Å-04. Alternativt F13 (pakking og utgivelse med Tesseract).
