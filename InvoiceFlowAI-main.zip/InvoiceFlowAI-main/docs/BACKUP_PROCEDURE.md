# Prosedyre for sikkerhetskopi og gjenoppretting

Gjelder InvoiceFlow AI fra fase 12 (ADR-0037). Prosedyren forutsetter én Windows-bruker og én datakatalog (standard: `%LOCALAPPDATA%\InvoiceFlowAI`).

## 1. Hva sikkerhetskopien inneholder

| Med | Ikke med |
|---|---|
| Databasen (alle regnskapsenheter, fakturaer, godkjenninger, eksporter og revisjonskjeden) | Logger |
| Dokumentarkivet: originaler, karantene og sidebilder | Innboksmappen (filer som ennå ikke er importert) |
| Eksportfiler i eksportmappen | Kopier før migrasjon (`backups\pre-migration`) |
| Innstillingsfilen `config.json` | Passordfrasen |

Alt ligger i én kryptert fil. Uten passordfrasen kan den ikke leses av noen, heller ikke av leverandøren av programmet.

## 2. Før første sikkerhetskopi

1. Velg en passordfrase på minst 12 tegn, gjerne fire eller flere tilfeldige ord.
2. Lagre passordfrasen i et passordhvelv som to personer har tilgang til (Å-14, G-20).
3. Lagre sikkerhetskopiene på en kryptert ekstern disk, utenfor maskinen (Å-14, G-20). Hvor lenge kopiene skal oppbevares, bekreftes av regnskapsansvarlig (Å-07).

## 3. Lage en sikkerhetskopi

1. Åpne «Sikkerhetskopi» og velg «Lag sikkerhetskopi …» (Alt+L).
2. Velg mappen på den eksterne disken.
3. Skriv passordfrasen to ganger.
4. Vent til meldingen «Sikkerhetskopien … er lagret» vises. For et stort arkiv kan det ta flere minutter.

Programmet lager ingen sikkerhetskopi hvis revisjonskjeden er brutt, eller hvis et dokument mangler i arkivet. Kontroller da integriteten under «Innboks» og kontakt den som drifter programmet.

## 4. Kontrollere en sikkerhetskopi (anbefalt hver måned)

1. Velg «Kontroller …» (Alt+K), velg filen og skriv passordfrasen.
2. Meldingen «Sikkerhetskopien er kontrollert og kan gjenopprettes» betyr at alt er dekryptert og kontrollert:
   - hver fil mot manifestet;
   - databasens integritet;
   - hele revisjonskjeden;
   - revisjonsankeret;
   - hvert dokument databasen viser til.

   Ingenting lagres under kontrollen.
3. Feil passordfrase, en endret eller avkortet fil gir en melding om at sikkerhetskopien avvises. Bruk da en annen sikkerhetskopi.

## 5. Gjenopprette

En gjenoppretting endrer aldri den kjørende datakatalogen. Den lager en komplett datakatalog i en tom mappe.

1. Velg «Gjenopprett til ny mappe …» (Alt+G), velg filen og en **tom** mappe utenfor programmets datakatalog, for eksempel `D:\InvoiceFlowAI-gjenopprettet`.
2. Skriv passordfrasen. Når meldingen «Gjenopprettet og kontrollert» vises, er mappen klar. Mislykkes en kontroll, er mappen tom igjen.
3. Avslutt InvoiceFlow AI.
4. Start programmet med den nye mappen og kontroller dataene:

   ```powershell
   InvoiceFlowAI.exe --data-dir "D:\InvoiceFlowAI-gjenopprettet"
   ```

   Er programmet oppdatert siden sikkerhetskopien ble laget, oppgraderes databasen automatisk ved oppstart. En kopi før migrasjon tas først.
5. Skal den gjenopprettede mappen erstatte den gamle datakatalogen permanent:
   1. avslutt programmet;
   2. gi den gamle `%LOCALAPPDATA%\InvoiceFlowAI` et nytt navn (ikke slett den før alt er kontrollert);
   3. flytt den gjenopprettede mappen dit;
   4. start programmet som vanlig.

Arbeid gjort etter at sikkerhetskopien ble laget, finnes ikke i den gjenopprettede mappen. Dokumenter importert senere må importeres på nytt.

## 6. Slette en sikkerhetskopi

Bare filer laget fra denne databasen kan slettes fra programmet («Slett sikkerhetskopi …», Alt+S). Slettingen registreres i databasen og revisjonskjeden. Programmet sletter aldri noe automatisk, før regler for oppbevaring er bestemt (Å-07).

## 7. Hvis noe går galt

| Melding | Hva du gjør |
|---|---|
| Feil passordfrase, eller filen er skadet eller endret | Kontroller passordfrasen i passordhvelvet. Prøv en annen sikkerhetskopi. |
| Mappen er ikke tom | Velg eller lag en tom mappe. |
| Velg en mappe utenfor programmets egen datakatalog | Gjenopprett til en mappe på en annen sti. |
| Revisjonskjeden er ikke intakt | Ikke lag nye sikkerhetskopier. Ta vare på datakatalogen og den siste gode sikkerhetskopien, og kontakt den som drifter programmet. |
| Dokumentarkivet er ufullstendig | Kontroller integriteten under «Innboks». Gjenopprett eventuelt fra siste gode sikkerhetskopi. |

Et avbrudd under sikkerhetskopiering (strømbrudd, krasj) etterlater ingen ukryptert kopi: programmet fjerner arbeidsmappen ved neste oppstart. En uferdig fil på målet har et navn som begynner med punktum og kan slettes.
