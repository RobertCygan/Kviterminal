# InvoiceFlow AI – Teststrategi

| | |
|---|---|
| **Dokumentversjon** | 1.1 (Fase 00, etter sluttrevisjon) |
| **Status** | Strategi utformet. Testinfrastruktur (pytest, markører, dekning, arkitekturvakt, CI) **implementert**; kontrakttester **kjørt og bestått** (se §10). |

---

## 1. Prinsipper

1. **Testdrevet:** Akseptansekriterier og testscenarioer defineres i oppgavens **TESTS**-del *før* implementering.
2. **Bevis, ikke påstander:** En test regnes som bestått bare når den er kjørt; kommando, miljø og resultat oppgis.
3. **Syntetiske data:** Kun fiktive dokumenter generert eller laget for testing. Aldri ekte fakturaer eller kundedata.
4. **Deterministisk:** Ingen avhengighet av klokke, nettverk, tilfeldighet eller rekkefølge (bruk `Clock`/`IdGenerator`-porter og faste frø).
5. **Raskt som standard:** `pytest` uten argumenter kjører enhets-, arkitektur- og raske integrasjonstester på under ett minutt. Trege tester har egne markører.
6. **Advarsler er feil:** `filterwarnings = error` i `pyproject.toml`.

## 2. Testnivåer

| Nivå | Omfang | Verktøy | Eksempler |
|---|---|---|---|
| **Enhet** (`unit`) | Rene funksjoner og kontrakter | pytest | Kanonisk modell, MVA-beregning, kontrollsiffer, formatering av beløp/dato |
| **Arkitektur** (`architecture`) | Modulgrenser | pytest + `ast` | `domain` importerer bare stdlib/pydantic; `ui` importerer ikke `persistence` |
| **Integrasjon** (`integration`) | Mot SQLite, filsystem, Tesseract | pytest, `tmp_path` | Migrasjoner, repositorier, dokumentlager, OCR-adapter mot syntetisk side |
| **GUI** | Qt-visninger | pytest-qt (godkjent, D-08; tas i bruk i Fase 01), `QT_QPA_PLATFORM=offscreen` | Hovedvindu starter, norske tekster, ren tekst-visning |
| **Ende-til-ende** | Import → eksport | pytest | Syntetisk PDF → godkjenning → Excel/CSV med forventet innhold |
| **Sikkerhet** (`security`) | Fiendtlig inndata og sikkerhetskrav | pytest | Se §4 |
| **Regresjon** | Gyldne filer | pytest | Forventet kanonisk JSON for hvert syntetisk testdokument |
| **Ytelse** (`performance`) | Tidsbudsjetter | pytest + `time.perf_counter` | NF-01–NF-05 i `MASTER_SPECIFICATION.md` |
| **Pakking** | PyInstaller-bygg | CI på Windows | `InvoiceFlowAI.exe --self-test` avslutter med kode 0 |

## 3. Markører

Registrert i `pyproject.toml` (`--strict-markers` hindrer skrivefeil):

| Markør | Kjøres i CI | Merknad |
|---|---|---|
| `unit` | Ja | |
| `architecture` | Ja | |
| `security` | Ja | |
| `integration` | Ja (raske) | Tester som krever Tesseract hoppes over med tydelig grunn hvis ikke installert |
| `performance` | Nei (manuelt / nattlig) | `pytest -m performance` |
| `windows_only` | Ja på Windows | Hoppes over på andre plattformer |

## 4. Sikkerhetstester

| Område | Testtilfeller | Fase |
|---|---|---|
| Kontrakter | Ukjente felt avvises (topp og nestet); `float`/`bool` for beløp avvises; NaN/uendelig avvises; for mange desimaler avvises uten avrunding; lengde- og antallsgrenser | 00 ✅ |
| Logging | Ingen orgnr/kontonummer/KID/IBAN/beløp i loggutdata; maskeringsfilter | 01 |
| Nettverk | Kjernefunksjoner med blokkert `socket.connect` | 01 → |
| Filer | Feil endelse vs. signatur; polyglotfiler; null byte; tom fil; 0-sidig PDF; kryptert PDF; PDF med JavaScript/`Launch`/innebygde filer; dekompresjonsbombe (stort bilde); svært mange sider; avkortet fil | 03–04 |
| Filnavn | `..\..\x.pdf`, `CON.pdf`, `aux`, kontrolltegn, svært lange navn, Unicode-normalisering, RTL-overstyring (`U+202E`) | 03 |
| Isolasjon | Arbeidsprosess som henger avsluttes ved tidsavbrudd; minnegrense | 04 |
| KI | Faktura med injeksjonstekst («ignorer instruksjoner …»); svar med ekstra felt, for lange verdier, `float`-beløp, proveniensfelt; tomt/ugyldig JSON-svar | 07 |
| Regnskap | Endret kontonummer (BANK-001); duplikater (DUP-001/002); avrundingsgrenser | 08 |
| Godkjenning | Endring etter godkjenning opphever godkjenning; eksport uten godkjenning avvises | 09–10 |
| Eksport | Celler `=CMD()`, `+1`, `-1+1`, `@SUM()`, tabulator; dobbel eksport hindres av indeks | 10 |
| Revisjon | `UPDATE`/`DELETE` på `audit_events` avvises; manipulert hendelse bryter hashkjeden | 02 |
| Regnskapsenhet | Faktura med leverandør/batch fra annen enhet avvises av databasen; samme PDF i to enheter tillatt, to ganger i samme enhet avvist; duplikatkontroll krysser ikke enheter; ingen repositoriemetode uten `EntityScope` (arkitekturtest) | 02 |
| Kanonisk form | Like verdier gir lik JSON og lik innholdshash; tidsstempler godtas ikke som datoer; skjulte tegn i tekst avvises | 00 ✅ |
| Backup | Gjenoppretting verifiserer hasher; manipulert arkiv avvises | 12 |

**Fiendtlig testkorpus** (`tests/fixtures/synthetic/hostile/`) genereres av skript i testkoden – ingen nedlastede skadevareprøver.

## 5. Testdata

- `docs/examples/eksempel_faktura_kanonisk.json` er dokumentasjon og test samtidig.
- Syntetiske PDF-er genereres programmatisk (Fase 03–04) med fiktive leverandører og testverdier med gyldige kontrollsiffer (`123456785`, `12345678903`).
- `.gitignore` blokkerer PDF/bilder/regneark/XML utenfor `tests/fixtures/synthetic/`.
- Gyldne filer (forventede resultater) oppdateres bare bevisst, med begrunnelse i commit-melding.

## 6. Dekningsmål

| Område | Mål (linje + gren) |
|---|---|
| `domain`, `accounting` | ≥ 95 % |
| `application`, `security`, `export` | ≥ 90 % |
| Adaptere | ≥ 80 % |
| `ui` | Røyktester + kritiske flyter; ikke prosentmål |

Dekning er et minimum, ikke et mål i seg selv. Kritiske regler (MVA, duplikat, godkjenning, eksport) skal ha eksplisitte grensetilfeller.

## 7. Regresjon

- Hele testsettet kjøres i CI ved hver push og pull request på `windows-latest`.
- Feil som rettes får en regresjonstest som feiler før rettingen.
- OCR-/KI-kvalitet måles mot et fast syntetisk referansesett (presisjon per felt); nedgang er regresjon.

## 8. Ytelse

Tidsbudsjetter fra `MASTER_SPECIFICATION.md` §6 testes med `performance`-markøren på en referansemaskin. Resultater (maskin, versjon, median av 5 kjøringer) føres i `CHANGELOG.md` når de endres vesentlig.

## 9. Kommandoer (Windows PowerShell)

```powershell
# Engangsoppsett
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --require-hashes -r requirements\dev.lock.txt
python -m pip install --no-deps -e .

# Tester
python -m pytest                       # standardsett
python -m pytest --cov                 # med dekning
python -m pytest -m security           # kun sikkerhetstester

# Statisk analyse og sikkerhet
python -m ruff check .
python -m ruff format --check .
python -m bandit -c pyproject.toml -r src
python -m pip_audit --disable-pip --require-hashes -r requirements\dev.lock.txt
gitleaks git .                         # krever Gitleaks installert separat
```

## 10. Utført i Fase 00 (bevis)

| Kontroll | Grunnlinje `05f003a` | Etter sluttrevisjonen (gren `claude/phase00-final-audit`) |
|---|---|---|
| `pytest` | 78 bestått (Linux og Windows-CI) | 140 bestått (Linux, Python 3.13.16) |
| Dekning `invoiceflow` (linje + gren) | 100 % | 100 % (236 setninger, 42 grener) |
| `ruff check` / `ruff format --check` | Ingen funn | Ingen funn |
| `bandit -r src` | Ingen funn | Ingen funn |
| `pip-audit` mot låsefil | Ingen kjente sårbarheter | Ingen kjente sårbarheter (2026-10-20) |
| Gitleaks | CI: 1 commit skannet, ingen funn (kjøring 39395495378); hoppet over på `main` («No commits to scan», kjøring 39395951832) | Full historikk: 2 commits skannet, ingen funn (kjøring 39399231517) |
| Windows-CI | Grønn (kjøringene over, `windows-latest`, Python 3.13.16, win32) | Grønn: 140 bestått, 100 % dekning (kjøring 39399231517) |

Nivåer: **Linux-testet** (utviklingsmiljø) · **Windows-CI-testet** (GitHub Actions) · **Windows 11-akseptert** (manuelt hos prosjekteier – ikke utført).

## 11. Hva dekningstallet betyr

100 % dekning betyr at hver linje og hver gren i `src/invoiceflow/` – som i Fase 00 bare er domenekontraktene (6 filer, 236 setninger) – er utført minst én gang av testene. Det betyr **ikke** at InvoiceFlow AI er 100 % testet: grensesnitt, database, import, OCR, KI, regnskapsregler og eksport finnes ikke ennå. Dekning sier heller ikke noe om hvor gode påstandene er; derfor finnes egne negative tester og grensetilfeller for hver regel.


## Fase 01

`tests/unit/test_bootstrap.py` prøver konfigurasjon, kataloggrenser, maskering,
eksakt formatering og avslutningskoder. `tests/gui/test_shell.py` bruker ekte Qt
(`QT_QPA_PLATFORM=offscreen`) for navigasjon, ren tekst, dialoger og selvtest.
Nettverk blokkeres i sikkerhetstesten; andre instans testes med en faktisk
`QLockFile`. Domenetestene fra Fase 00 beholdes.

Akseptgrunnlag og kjørte kommandoer føres i `PHASE_01_REPORT.md`. En utformet
CI-jobb er ikke bevis for bestått kjøring. Manuell test på Windows 11 kreves
fortsatt før fasen kan regnes som godkjent.

## Fase 02 – vedvarende data og feilgrenser

Testene bruker ekte SQLite-filer: migrasjon fra tom database, gjentatt oppstart, transaksjoner, parallelle auditforfattere, tverrenhetsreferanser, uforanderlig historikk, snapshot/projeksjon, Decimal/UTC og lukking av Windows-filhåndtak. Testmigrasjon `0002_test` er bare en midlertidig fixture; den distribueres ikke.

Nye sluttregresjoner dekker normalisering under lav Decimal-presisjon, mer enn 28 siffer, eksponentgrenser, kjent versjonsmarkør på en fremmed database, semantisk feil i en syntaktisk gyldig migrasjon og endret headerprojeksjon.

Windows CI bygger onedir med Alembic-ressurser og kjører `.exe --self-test` i en egen datakatalog. `tests/unit/test_packaging_spec.py` kontrollerer at migrasjonsfilene inkluderes. En kontroll av pakkespesifikasjonen alene er ikke bevis for et fungerende wheel. Windows-CI bygger derfor også et faktisk wheel og kjører `packaging/verify_wheel.py`, som leser ZIP-innholdet og krever alle migrasjonsressursene fra kildekoden.

Opprinnelig F02-CI: 465 tester, 97 % samlet og 96 % utenfor domain/UI. Etter korrigeringene: 473 bestått, 97 % samlet og 96 % utenfor domain/UI på Windows CI 39413990732; se PHASE_02_REPORT. Tall fra Claude-teksten om lokale Linux-kjøringer er ikke uavhengig reprodusert.

## Fase 03 – dokumentimport

- Enhet: signaturer, endelser, rensing av visningsnavn, størrelsesklasser, revisjonspolicy for dokumenthendelser (`tests/unit/application/test_document_model.py`).
- Integrasjon, filsystem: staging, publisering, karantene, størrelsesgrense, endring under lesing, lenker, utilgjengelig kilde, full disk, stivandring, gjenoppretting, filer som er låst av et annet program (Windows-oppførsel simulert) (`tests/integration/documents/test_store.py`).
- Integrasjon, database + filer: alle formater, duplikater per enhet, karantene, avvisning, revisjon uten filnavn, tverrenhetstilgang, typeendring, innboks, hvert krasjpunkt, manipulering/manglende original, samtidig import, databaseutløsere og faktura → dokument (`tests/integration/persistence/test_documents.py`).
- Migrasjon `0001 → 0002` med F02-data og avvisning ved eksisterende fakturaer (`test_migrations.py`).
- GUI: første enhet, import, innboks, typeendring, ren tekst, feilmeldinger uten detaljer, arbeid utenfor GUI-tråden, oppstartsgjenoppretting (`tests/gui/test_documents_page.py`).
- Integritetskontroll mot lenker (lenke til identisk fil, til annen fil, utenfor arkivet, hengende, lenket mappe; hoppes over hvis plattformen ikke kan lage lenker), stopp av flerfilsimport mellom filer og ved avslutning (`test_store.py`, `test_documents.py`, `test_documents_page.py`).
- Stresskjøring på Windows: samtidighets- og krasjtester ble kjørt 200 ganger, dokumentlager/-tjeneste/innboks-UI 50 ganger og hele testsettet 10 ganger i en **midlertidig** CI-arbeidsflyt (ikke fast). Sporadiske samtidighetsfeil viser seg ikke i én kjøring; slike kontroller bør gjentas ved endringer i fillager, låsing eller krasjhåndtering (og i F04 for arbeidsprosessen).
- Manuell Windows 11-aksept dokumenteres separat i `PHASE_03_REPORT.md`.

## Fase 04 – isolert behandling

- Kontrakt for `DocumentParser` (`tests/contract/test_document_parser.py`): tekstlag med posisjoner, sideantall og rekkefølge, rasterisering (PNG-mål), rotasjon, stabile feilkoder (kryptert, avkortet, syklisk, for mange sider, for stor side, for mye tekst, feil format), aktivt innhold, bildeformater og -moduser, EXIF-retning, TIFF-sider. En falsk adapter består samme kontrakt via arbeidsprosessens kode, som viser at PDF-biblioteket kan byttes.
- Fiendtlig korpus genereres av `tests/support/hostile_corpus.py` (ingen nedlastede prøver) og kjøres gjennom den **ekte** arbeidsprosessen (`tests/integration/processing/test_isolation.py`).
- Ressursgrenser bevises, ikke bare konfigureres: endeløs arbeidsprosess drepes ved fristen, stoppforespørsel dreper prosessen, ubegrenset allokering stoppes av minnegrensen, krasj uten rapport, for stor rapport; prosessen er borte etter hver test. Job Object og forbudt underprosess testes på Windows-CI (`windows_only`).
- Tjenesten (`tests/integration/processing/test_processing_service.py`): idempotens, nye innstillinger, ventende/mislykkede, karantene, tverrenhetsisolasjon, endret eller manglende original før og under kjøring, 14 måter å manipulere rapporten på, lenke i utdata, utdatagrense, alle utganger, krasj før siste commit og gjenoppretting.
- Databaseutløsere for jobber, sider og avledede filer (`tests/integration/persistence/test_processing_schema.py`); migrasjon `0002 → 0003`.
- GUI: kolonnene «Sider» og «Behandling», knappene og norske statustekster for alle tilstander (`tests/gui/test_documents_page.py`).
- Selvtesten (også `.exe`) analyserer en syntetisk PDF i en ekte arbeidsprosess.

## Fase 15 – EHF/PEPPOL BIS Billing 3.0

- Fiendtlig XML genereres av `tests/support/hostile_xml.py` (ingen nedlastede filer): XXE, ekstern DTD, «billion laughs», kvadratisk oppblåsing, dyp nesting, ugyldig UTF-8, ugyldig base64, feil rotelement, EHF 2.x, manglende felt, tall med feil format, negative mengder, ekstern vedleggsreferanse. Kontraktstester for leseren (`tests/contract/test_ehf_reader.py`), og et utvalg gjennom den **ekte** arbeidsprosessen (`tests/integration/processing/test_isolation.py`).
- Gyldne fakturaer og kreditnotaer bygges av `bootstrap/synthetic_ehf.py` (fullt syntetisk, oppdiktede organisasjonsnumre). Mappingtesten kontrollerer verdi, råtekst og XPath for hvert felt og `Decimal`-presisjon. Offisielle eksempelfiler er **ikke** brukt (lisensen er ikke verifisert).
- Kontrollene (`tests/unit/application/test_ehf_checks.py`): hver regneregel gir sitt flagg; en korrekt faktura gir ingen.
- Tjenesten (`tests/integration/processing/test_ehf_service.py`): registrering som utkast, idempotens, flagg for regnestykke, mottaker og duplikat, samme fil to ganger (F03-duplikat), vedlegg (PDF, forkledd fil, kjent fil), avviste filer registrerer ingenting, manipulerte rapporter, tverrenhetsisolasjon, krasj før siste commit, 200 linjer med eksakt sum.
- Migrasjon `0003 → 0004` med F04-data og en dangling referanse som stopper migrasjonen (`tests/integration/persistence/test_migrations.py`); utløsere for `invoice_findings`.
- Selvtesten (også `.exe`) importerer og behandler en syntetisk EHF-faktura.

## Fase 08a – validering og leverandørregister

- **Kontrollsiffer** (`tests/unit/domain/test_checksums.py`):
  - MOD11 for organisasjonsnummer og konto;
  - MOD10/MOD11 for KID, inkludert `-` som kontrollsiffer;
  - MOD97 for IBAN.

  Testene bruker offentlig kjente eksempelverdier og syntetiske verdier.
- **Regler** (`tests/unit/application/test_validation_rules.py`):
  - positive og negative tilfeller og grensetilfeller for hver regel, for eksempel MVA-toleranse nøyaktig 0,01 og 0,02, `ROUND_HALF_UP` ved 0,005, dato lik grensen, ledende nuller i fakturanummer, rabattlinjer og kreditnota;
  - stabil rekkefølge;
  - at funn ikke kan bære fritekst.

  Dekning: 100 % for `rules.py`, `model.py` og `checksums.py`.
- **Tjenesten** (`tests/integration/processing/test_validation_service.py`):
  - kontroll ved EHF-registrering;
  - BANK-001 før og etter bekreftelse og ved sperring;
  - sammenlign-og-sett ved statusendring;
  - duplikater innen enheten, men aldri på tvers;
  - ny revisjon;
  - feil kontrollsiffer registreres ikke;
  - mottaker;
  - krasj før commit;
  - utløsere mot manipulering.
- **Migrasjon** `0004 → 0005` med F15-data (alle rader uendret, ombygd `audit_events`) og `0003 → hode`.
- **GUI** (`tests/gui/test_validation_ui.py`): kolonnen «Kontroll», kontrollvinduet, leverandørsiden med bekreftelse, avbrutt bekreftelse og sperring, og at alle meldingsnøkler finnes i katalogen.
- **Selvtesten** (også `.exe`) kontrollerer at en ny konto gir BANK-001, og at feilen forsvinner etter bekreftelse.

## Fase 08b – referansedata og konteringsforslag

- **CSV-import** (`tests/unit/application/test_reference.py`):
  - gyldige filer med BOM, norske datoer og desimalkomma;
  - hver feiltype med linje og kolonne, blant annet formelceller, kontrolltegn, duplikater, overlappende perioder og grenser.
- **Konteringsforslag:**
  - én og flere satser;
  - forslag fra MVA-spesifikasjonen eller totalen;
  - tvetydig eller ugyldig MVA-kode;
  - dimensjoner;
  - manuell kontering bevares.
- **Regler** MVA-002 og ACC-001–003 med og uten referansedata.

  Dekning: 100 % for parser, forslag og modell.
- **Tjenesten** (`tests/integration/processing/test_reference_service.py`):
  - øyeblikksbilder;
  - avvist fil lagrer ingenting;
  - tverrenhetsisolasjon;
  - forslag ved registrering og etter standardkontering;
  - validering av verdier;
  - utløsere mot manipulering.
- **Migrasjon** `0005 → 0006` med F08a-data.
- **GUI** (`tests/gui/test_reference_ui.py`): referansedatasiden med vellykket og avvist import, standardkontering med dialog, konteringen i kontrollvinduet og «Foreslå kontering på nytt».
- **Selvtesten** (også `.exe`) importerer syntetisk kontoplan og MVA-koder, setter standardkontering og forventer en faktura uten funn.

## Fase 09 – gjennomgang og godkjenning

- **Retting** (`tests/unit/application/test_review_editing.py`):
  - norske beløp og datoer, sifre og koder;
  - ugyldig inndata;
  - manuell proveniens med bevart bevis;
  - ikke-redigerbare felt.

  Dekning: 100 %.
- **Tjenesten** (`tests/integration/processing/test_review_service.py`):
  - godkjenning bundet til innhold;
  - endring etter godkjenning gir `revoked`;
  - BANK-001 og DUP-001 blokkerer og kan ikke overstyres;
  - overstyring med begrunnelse, som ikke følger med til nytt innhold;
  - foreldet revisjon gir konflikt;
  - avvisning og oppheving;
  - tverrenhet og krasj før commit;
  - utløsere mot manipulering;
  - forhåndsvisning med hashkontroll.
- **Migrasjon** `0006 → 0007` med F08b-data.
- **GUI** (`tests/gui/test_review_ui.py`):
  - detaljer med kilde;
  - forhåndsvisning og markering av kildeboks;
  - retting, overstyring, godkjenning, avvisning og oppheving;
  - blokkering;
  - hurtigtaster.
- **Selvtesten** (også `.exe`): godkjenning, og at en retting deretter opphever godkjenningen.

## Fase 10 – eksport

- **Modell** (`tests/unit/application/test_export_model.py`):
  - formelstart (`=`, `+`, `-`, `@`, tabulator, linjeskift og fullbreddetegn) og ufarlig tekst;
  - overskrifter og kolonner, like overskrifter;
  - én rad per konteringslinje, faktura uten kontering;
  - kreditnota med negative beløp uten negativ null;
  - summer per valuta.

  Dekning: 100 %.
- **Skrivere og eksportmappe** (`tests/unit/test_export_adapters.py`):
  - CSV med BOM, semikolon, desimalkomma, sitering og apostrof;
  - Excel med tekst-, tall- og datoceller, apostrofmerke og kontrollark;
  - filen skrives én gang, er skrivebeskyttet og overskrives aldri;
  - ugyldige navn, lenker, mislykket skriving, midlertidige filer og kopi.
- **Tjenesten** (`tests/integration/processing/test_export_service.py`):
  - bare godkjente fakturaer, én gang;
  - eksportert sum er lik summen av godkjente fakturaer, med kreditnota;
  - fiendtlig tekst i CSV og Excel; arket har ingen formelceller;
  - en eksportert faktura er endelig, også ved direkte endring i databasen;
  - databasen avviser en ny aktiv eksport, også til et annet format;
  - feil i skriveren, krasj før og etter navnebytte og gjenoppretting;
  - ny eksport med begrunnelse, også etter en mislykket ny eksport;
  - kolonneoppsett, kopi med hashkontroll og tverrenhet.
- **Migrasjon** `0007 → 0008` med en godkjent faktura, deretter eksport.
- **GUI** (`tests/gui/test_export_ui.py`):
  - eksport, kopi og ny eksport med begrunnelse;
  - kolonnedialog (rekkefølge, overskrift, standard) og lagret versjon;
  - hurtigtaster.
- **Selvtesten** (også `.exe`): eksport til Excel, kopi, og at en ny eksport ikke finner noe.

## Fase 12 – sikkerhetskopi og gjenoppretting

- **Format** (`tests/unit/application/test_backup_model.py`):
  - passordfrase (lengde, NFC, kontrolltegn, bekreftelse);
  - stier i arkivet;
  - hode og manifest bare i kanonisk form;
  - filnavn.
- **Kryptering og arkiv** (`tests/unit/test_backup_adapters.py`):
  - alle størrelser rundt bitgrensen;
  - endret byte, byttede, manglende og tilføyde biter, avkorting, endret hode og feil nøkkel;
  - datafiler uten midlertidige filer og lenker;
  - fiendtlige arkiver: stitraversering, absolutte stier, lenker, mapper, duplikater, innhold etter manifestet, manglende manifest;
  - mål som ikke er tomt eller ligger i datakatalogen;
  - arbeidsmapper.
- **Tjenesten** (`tests/integration/processing/test_backup_service.py`):
  - gjenoppretting gir lik faktura og gyldig kjede;
  - kontroll uten spor;
  - feil passordfrase, endrede byte og avkortet fil;
  - mislykket gjenoppretting gir tom mappe;
  - brutt kjede og manglende dokument hindrer sikkerhetskopi;
  - manipulert kjede i sikkerhetskopien avvises;
  - sletting bare av registrert fil, med utløsere;
  - arbeidsmapper fjernes ved oppstart.
- **Migrasjon** `0008 → 0009`.
- **GUI** (`tests/gui/test_backup_ui.py`): lage, kontrollere, gjenopprette og slette; avbrutte dialoger; hurtigtaster.
- **Selvtesten** (også `.exe`): lage, gjenopprette til tom mappe med full kontroll, og at en endret byte avvises.

## Fase 11a – skannemappe og bunker

- **Klassifisering** (`tests/unit/application/test_scan_model.py`):
  - alle sidetyper og grenseverdier;
  - oppdeling med skilleark først, etter hverandre og til slutt;
  - bare blanke sider, umålte sider;
  - skillearket er en gyldig PDF.

  Dekning: 100 %.
- **Målinger** (`tests/contract/test_page_metrics.py`) i ekte arbeidsprosess: PDF ved 72, 150 og 300 dpi; skannet TIFF uten tekstlag med støy og forskjøvet skilleark.
- **Skannemappe** (`tests/unit/test_scan_folder.py`): stabilitet og alder, midlertidige filer, lenker, flytting uten overskriving, feil.
- **Tjenesten** (`tests/integration/processing/test_scan_service.py`): innlesing, flytting og analyse, duplikat, avvist fil, tverrenhet, skilleark.
- **Migrasjon** `0009 → 0010`, og eldre databaser bygget uten målinger.
- **GUI** (`tests/gui/test_scan_ui.py`): overvåking, tabell med deler, lagring av skilleark, hurtigtaster.
- **Selvtesten** (også `.exe`): en bunke i skannemappen leses inn, flyttes, analyseres og deles riktig.

## Fase 11b – skanner via produsentens program

- **Nær grensen** (`tests/unit/application/test_scan_model.py`): begge sider av hver grense for nesten blank, nesten skilleark og svakt skilleark; umålte sider.
- **Tjenesten:** sidene følger med i sideordning; syntetiske sider er ikke nær noen grense.
- **GUI** (`tests/gui/test_scan_ui.py`): målinger for valgt dokument, kopiering av mappesti, hurtigtaster.
- **Ikke automatisert:** prøve med Brother ADS-4700W etter `SCANNER_SETUP.md` §4.

## Fase 06 – feltuttrekk

- **Normalisering** (`tests/unit/application/test_extraction_parse.py`):
  - beløp, datoer, organisasjonsnummer, konto, KID, IBAN, BIC, sats, valuta og fakturanummer;
  - ugyldige verdier;
  - fiendtlig lange linjer i lineær tid.
- **Sideoppsett** (`test_extraction_layout.py`):
  - ord fra tekstlag (mellomrom og brede gap);
  - linjer fra geometrien;
  - sporing fra tekst til ord;
  - OCR-sikkerhet.
- **Gyldne filer** (`tests/contract/test_extraction_golden.py`, `tests/fixtures/synthetic/extraction/`):
  - fire syntetiske fakturaer (standard, kolonner, kreditnota, to satser over to sider) gir nøyaktig filens verdier fra tekstlaget og etter OCR (`tesseract`);
  - proveniens;
  - uleselig dato;
  - en avtale er ingen faktura.
- **Registrering** (`tests/integration/processing/test_extraction_service.py`):
  - én gang;
  - én faktura per del i en bunke;
  - funn (sum, uleselig, manglende, mottaker, duplikat);
  - dokumenttyper;
  - validering;
  - tverrenhet;
  - EHF og vedlegg leses ikke;
  - OCR-dokument;
  - ingen tekst ennå.
- **Selvtest:** en syntetisk faktura blir et fakturautkast med riktige felt.

## Fase 05 – OCR

Tester som krever Tesseract er merket `tesseract`. De hoppes over uten Tesseract og feiler i stedet når `INVOICEFLOW_REQUIRE_TESSERACT=1` (Windows-CI).

- **TSV og arbeidsprosess** (`tests/unit/test_ocr_tesseract.py`, stand-in-program):
  - ord, linjer og bokser;
  - feilformet TSV, for mange ord og for mye tekst;
  - rensing av tegn og minimalt miljø;
  - feilkoder for avslutning, tidsavbrudd og for mye utdata;
  - endret eller manglende sidebilde.
- **Finne Tesseract** (`tests/unit/test_tesseract_install.py`): versjon, språk, for gammel versjon, manglende språkdata, faste steder på Windows.
- **Kontrakter** (`tests/unit/application/test_ocr_model.py`): `OcrLayer`, `OcrPageResult`, `OcrReport`, innstillinger og hvilke sider som gjenkjennes.
- **Tjenesten** (`tests/integration/processing/test_ocr_service.py`):
  - gjenkjenning og idempotens;
  - tekstlag, blanke sider og skilleark;
  - endret sidebilde og manipulert rapport (fem varianter);
  - tidsavbrudd og nytt forsøk;
  - tverrenhet;
  - avbrudd og oppstartsopprydding;
  - tekstvisning.
- **Referansesett** (`tests/contract/test_ocr_accuracy.py`, ekte isolert arbeidsprosess): syntetisk faktura ved 300 dpi ren, med støy og skjevhet, JPEG ved 200 dpi og dårlig skann ved 150 dpi.
  - Tegnfeilrate høyst 1 %, 2 %, 2 % og 8 %.
  - Under 10 sekunder per side (NF-04).
  - Beløp, datoer, kontonummer og KID gjenkjennes eksakt.
- **Database:** migrasjon `0010 → 0011` og regler for `ocr_pages`.
- **GUI:** tekstkolonnen, «Vis tekst …» og melding uten Tesseract.
- **Selvtest:** med Tesseract leses et sidebilde uten tekstlag tilbake.

