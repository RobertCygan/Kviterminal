# InvoiceFlow AI – Avhengigheter

| | |
|---|---|
| **Dokumentversjon** | 1.1 (Fase 00, etter sluttrevisjon) |
| **Verifisert** | 2026-10-20 mot PyPI (metadata og tilgjengelige hjul), se metode i §4 |
| **Policy** | ADR-0024: kompatible intervaller i `pyproject.toml`, eksakte versjoner + hasher i `requirements/dev.lock.txt`, 30 dagers karantene for nye versjoner, **sikkerhetsrettinger kan tas inn umiddelbart** etter kontrollert prosedyre |

Avhengigheter tas inn i `pyproject.toml` **først i fasen som bruker dem** (YAGNI). Tabellen i §2 viser planlagt versjonslinje; endelig versjon låses og testes i den aktuelle fasen.

## 1. I bruk nå (låst og testet)

| Pakke | Låst versjon | Formål | Lisens |
|---|---|---|---|
| pydantic | 2.13.5 | Kanoniske kontrakter | MIT |
| pydantic-core | 2.46.5 | (via pydantic) | MIT |
| pytest | 9.1.1 | Testing | MIT |
| pytest-cov | 7.1.0 | Dekning | MIT |
| ruff | 0.16.8 | Lint og formatering | MIT |
| bandit | 1.9.4 | Statisk sikkerhetsanalyse | Apache-2.0 |
| pip-audit | 2.10.1 | Sårbarhetskontroll | Apache-2.0 |

Fullstendig liste med transitive avhengigheter og hasher: `requirements/dev.lock.txt`. `pydantic` 2.14.x (utgitt 2026-10-08) er bevisst ikke tatt inn ennå på grunn av karantenepolicyen.

## 2. Planlagt stakk – verifisert Windows-kompatibilitet

«Hjul cp313/win_amd64» betyr at PyPI har et forhåndsbygget Windows-hjul som kan brukes med Python 3.13 64-bit (eget `cp313`-hjul, `abi3`-hjul eller ren Python).

| Pakke | Nyeste på PyPI (dato) | Anbefalt linje | Hjul cp313/win_amd64 | Lisens | Fase | Merknad |
|---|---|---|---|---|---|---|
| PySide6 | 6.12.0 (2026-10-08) | 6.11.x (6.11.2) | Ja (abi3) | LGPL-3.0 / GPL | F01 | I bruk: 6.11.2; 6.12 i karantene |
| pyinstaller | 6.22.3 (2026-09-12) | 6.22.x | Ja | GPL-2.0+ med unntak (bygde programmer kan ha valgfri lisens) | F01/F13 | |
| SQLAlchemy | 2.1.5 (2026-10-16) | 2.0.x (2.0.54+) | Ja | MIT | F02 | 2.1 er ny (2026-09-24); 2.0 er moden |
| alembic | 1.20.0 (2026-09-11) | 1.19.x / 1.20.x | Ren Python | MIT | F02 | |
| pypdfium2 | 5.14.0 (2026-10-04) | 5.13.0 (2026-08-13) | Ja (`py3-none-win_amd64`) | BSD-3-Clause / Apache-2.0 (+ avhengighetslisenser, `D11_PDF_DECISION_BRIEF.md` §2.2) | F04 | Valgt i D-11 (G-09); erstatter PyMuPDF |
| opencv-python-headless | 5.0.0.93 / 4.14.0.94 | 4.14.x | Ja (abi3) | Apache-2.0 | F05 | ADR-0011; ikke tatt i bruk i F04 (forbehandling flyttet til F05) |
| Pillow | 13.0.0 (2026-10-16) | 13.0.0 (sikkerhetsunntak) | Ja | MIT-CMU | F04 | I bruk: 13.0.0 etter ADR-0024 pkt. 3 (se §7) |
| pywin32 | 312 (2026-06-04) | 312 | Ja | PSF | – | Ikke tatt i bruk: Job Object via `ctypes` (ADR-0031) |
| pytesseract | 0.3.13 (2024-08-16) | 0.3.13 | Ren Python | Apache-2.0 | F05 | Krever Tesseract 5 (`tesseract.exe`) + `nor.traineddata` – installeres separat, ikke verifisert ennå |
| paddleocr | 3.7.0 (2026-06-11) | 3.7.x | Ren Python | Apache-2.0 | F05 (valgfri) | Modellnedlasting må deaktiveres |
| paddlepaddle | 3.3.1 (2026-03-24) | 3.3.x | Ja (`cp313`; **ikke** `cp314`) | Apache-2.0 | F05 (valgfri) | Begrenser Python-versjon (ADR-0002) |
| keyring | 25.7.0 (2025-11-16) | 25.x | Ren Python | MIT | F07 | ADR-0009 |
| openpyxl | 3.1.5 (2024-06-28) | 3.1.5 | Ren Python | MIT | F10 | I bruk fra F10 (kjøretid, bare skriving); sjelden utgivelse – følg med på vedlikehold |
| defusedxml | 0.7.1 (2021-03-08) | 0.7.x | Ren Python | PSF | F15 | I bruk fra F15 (kjøretid, bare i arbeidsprosessen) |
| pytest-qt | 4.5.0 (2025-07-01) | 4.5.x | Ren Python | MIT | F01 | Godkjent for GUI-tester (D-08, 2026-10-20) |

## 3. Systemkomponenter utenfor PyPI

| Komponent | Formål | Merknad |
|---|---|---|
| Windows 11 Pro/Enterprise (x64) | Målplattform, BitLocker | Å-13 |
| Python 3.13 x64 fra python.org | Utviklingsmiljø | `py -3.13` |
| Tesseract OCR 5.x + norsk språkdata | OCR (F05, ADR-0040) | Lisens Apache-2.0. Kalles direkte som program, ingen Python-binding. Installeres separat fram til F13 (`OCR_SETUP.md`). CI: UB Mannheim 5.4.0.20240606 (SHA-256 `c885fff6…60c9`) og `nor.traineddata` fra tessdata 4.1.0 (SHA-256 `b859e4de…aa22`) |
| Microsoft Defender | Antivirus | Å-12 |
| Gitleaks 8.24.3 | Hemmelighetsskanning | I CI som låst binærfil fra offisiell utgivelse, kontrollsum sjekket mot utgivelsens kontrollsumfil (ikke uavhengig festet hash – skal festes i F01). Lokalt: installeres separat |

## 4. Verifiseringsmetode

For hver pakke ble PyPI JSON-API-et (`https://pypi.org/pypi/<pakke>/json`) lest 2026-10-20: nyeste versjon, `requires_python`, lisensfelt og filnavn på hjul (`win_amd64`, `cp313`/`abi3`/`none-any`). Låste versjoner i §1 er i tillegg installert med `--require-hashes` og testet (Linux, Python 3.13.16). Installasjon på Windows verifiseres av CI-jobben `test-windows`.

Denne metoden bekrefter **tilgjengelighet** av hjul, ikke at pakkene virker sammen i en Windows-applikasjon. Det verifiseres i fasen som tar pakken i bruk.

## 5. Lisensoversikt

| Lisens | Pakker | Konsekvens |
|---|---|---|
| MIT / BSD / Apache-2.0 / PSF / MIT-CMU | De fleste | Tillater intern og kommersiell bruk med lisensmerknad |
| LGPL-3.0 | PySide6 / Qt | Dynamisk lenking (onedir) og mulighet til å bytte Qt-biblioteker; lisensmerknad |
| GPL-2.0+ med unntak | PyInstaller | Gjelder verktøyet, ikke det pakkede programmet |
| AGPL-3.0 | – | PyMuPDF er valgt bort (D-11 = C, G-09); ingen AGPL-komponent i stakken |

### 5.1 Permissive alternativer for PDF (vurdert i ADR-0023)

| Pakke | Versjon (2026-10-20) | Windows | Lisens |
|---|---|---|---|
| pypdfium2 | 5.14.0 | Hjul (`py3-none-win_amd64`) | Apache-2.0 / BSD-3 (+ avhengighetslisenser) |
| pdfminer.six | 20260107 | Ren Python | MIT |
| pypdf | 6.21.1 | Ren Python | BSD-3 |

En lisensfil med tredjepartsmerknader (`THIRD_PARTY_NOTICES`) og SBOM (CycloneDX via pip-audit) lages i F13.

## 6. Skille mellom kjøretid og utvikling

Kjøretidsavhengigheter står i `[project.dependencies]` (i Fase 00 bare `pydantic`), utviklingsverktøy i ekstraene `dev` og `security`. Låsefilen `requirements/dev.lock.txt` dekker i dag alle tre. Fra F01, når PySide6 kommer inn, lages i tillegg en egen `runtime.lock.txt`, slik at det pakkede programmet ikke inneholder test- og analyseverktøy (ADR-0024).

## 7. Unntak fra karantenen

Ingen unntak er tatt i bruk per 2026-10-20. Unntak føres her med pakke, versjon, sårbarhets-ID, begrunnelse og dato (ADR-0024).

| Dato | Pakke | Fra → til | Sårbarhet | Begrunnelse |
|---|---|---|---|---|
| 2026-10-24 | setuptools (kun utviklingslås, via PyInstaller) | 84.0.0 → 84.1.0 (utgitt 2026-10-19) | GHSA-xmj3-9gf7-h52w | Ny melding stoppet pip-audit. Første rettede versjon fra PyPI (offisiell kanal); satt inn i låsen med hasher fra PyPI, `--exclude-newer-package setuptools=2026-10-19T20:30:00Z`. Ingen andre pakker endret; ikke del av kjøretidslåsen eller `.exe`. |
| 2026-10-24 | filelock (kun utviklingslås, via cachecontrol/pip-audit) | 4.0.1 → 4.2.1 (utgitt 2026-10-17) | CVE-2026-112907, CVE-2026-112913, CVE-2026-112940 | Som over; `--exclude-newer-package filelock=2026-10-17T17:00:00Z`. Ingen andre pakker endret; ikke del av kjøretidslåsen. |
| 2026-10-23 | Pillow (kjøretid, bare i arbeidsprosessen) | ny → 13.0.0 (utgitt 2026-10-16) | 35 meldinger mot 12.3.0, rettet i 13.0.0, bl.a. GHSA-p4wg-p73j-c528, GHSA-65qm-jvmh-6pqg, GHSA-58r4-6rv3-gfh8 | Pillow dekoder ikke-klarerte bilder, så meldingene er relevante (pkt. 3a). Offisiell PyPI-utgivelse; ingen kjente meldinger mot 13.0.0 (PyPI JSON-API 2026-10-23). Tatt inn med `--exclude-newer-package pillow=2026-10-17`; ingen andre pakker endret. Kjøres bare i den isolerte arbeidsprosessen. |
| 2026-10-22 | certifi (kun utviklingslås, via requests/pip-audit) | 2026.7.22 → 2026.10.19 | PYSEC-2026-4320 | Ny melding stoppet pip-audit i CI. Rettet versjon fra PyPI (offisiell kanal), publisert etter karantenegrensen; tatt inn med `--exclude-newer-package certifi=2026-10-21 --upgrade-package certifi`. Ingen andre pakker endret; ikke del av kjøretidslåsen eller `.exe`. Hele testsettet og pip-audit grønne lokalt (221 tester på F01-grenen, 473 på F02-grenen). |


### Dependabot

`.github/dependabot.yml` har `cooldown: default-days: 30`, slik at Dependabot bare foreslår versjoner som har passert karantenen; sikkerhetsoppdateringer berøres ikke. PySide6, PySide6-Essentials, PySide6-Addons og shiboken6 grupperes i én PR fordi de må ha samme versjon. pydantic-core ignoreres fordi pydantic krever en eksakt versjon av den; den oppdateres sammen med pydantic. Låsefilene regenereres fortsatt med `uv pip compile` etter ADR-0024; en Dependabot-PR som bare endrer én linje i en låsefil, erstatter ikke den regenereringen.

## Fase 01 – nye avhengigheter

- PySide6 6.11.2 (LGPL-3.0/GPL/kommersiell), med samme versjon av shiboken6,
  PySide6-Essentials og PySide6-Addons.
- pytest-qt 4.5.0 (MIT), godkjent i D-08.
- PyInstaller 6.22.x (GPL med distribusjonsunntak), kun byggeavhengighet.

Eksakte versjoner og alle transitive hasher står i `requirements/runtime.lock.txt`
(kjøretid) og `requirements/dev.lock.txt` (utvikling, sikkerhet og pakking).
Låsene er generert på Windows med universell oppløsning for Python 3.13 og
`--exclude-newer 2026-09-20`, etter ADR-0024. Første forberedelseskjøring på
Windows installerte begge Qt- og testavhengigheter fra hash-låsen og gjennomførte
kildeselvtest. Endelig teststatus står i `PHASE_01_REPORT.md`.

## Fase 04 – avhengigheter tatt i bruk

| Pakke | Eksakt versjon | Formål | Lisens |
|---|---|---|---|
| pypdfium2 | 5.13.0 (PDFium 153.0.7999.0, utgitt 2026-08-13) | PDF: sideantall, tekstlag med posisjoner, rasterisering (D-11 = C) | BSD-3-Clause / Apache-2.0; innbygde komponenter (FreeType FTL, ICU, libjpeg-turbo, OpenJPEG, libpng, zlib, lcms, AGG m.fl.) med permissive lisenser – se `D11_PDF_DECISION_BRIEF.md` §2.2 |
| Pillow | 13.0.0 | PNG/JPEG/TIFF og PNG-koding av sidebilder | MIT-CMU |

Begge brukes bare i den isolerte arbeidsprosessen (arkitekturtest). Låsene er ikke regenerert fra bunnen: blokkene for de to pakkene er satt inn i de eksisterende låsene, slik at alle andre versjoner (også mako 1.4.3 og platformdirs 4.11.12) er uendret. Kommandolinjen i låsehodet dokumenterer unntaket for Pillow. PyInstaller tar med `pdfium`-biblioteket via kroken i pyinstaller-hooks-contrib og pakkemetadata via `copy_metadata` (versjonen leses med `importlib.metadata`).

## Fase 12 – avhengigheter tatt i bruk

| Pakke | Eksakt versjon | Formål | Lisens |
|---|---|---|---|
| cryptography | 50.0.1 | AES-256-GCM for krypterte sikkerhetskopier (ADR-0037) | Apache-2.0 eller BSD-3-Clause |
| cffi | 2.1.1 | Avhengighet av cryptography | MIT |
| pycparser | 3.0 | Avhengighet av cffi | BSD-3-Clause |

cryptography har ferdige Windows-hjul (abi3) med OpenSSL innebygd, og brukes bare i `backup/crypto.py` (arkitekturtest). Nøkkelavledningen (scrypt) kommer fra standardbiblioteket (`hashlib`). Ingen kjente sårbarheter (pip-audit). Versjonene er de nyeste innenfor 30 dagers karantene (låst med `--exclude-newer 2026-09-20`). Blokkene er satt inn i de eksisterende låsene uten andre endringer. PyInstaller tar med biblioteket via kroken i pyinstaller-hooks-contrib; `.exe`-selvtesten lager og gjenoppretter en sikkerhetskopi.

## Fase 10 – avhengigheter tatt i bruk

| Pakke | Eksakt versjon | Formål | Lisens |
|---|---|---|---|
| openpyxl | 3.1.5 (utgitt 2024-06-28) | Skriving av Excel-filer (`.xlsx`) i eksporten (ADR-0036) | MIT |
| et-xmlfile | 2.0.0 (utgitt 2024-10-25) | Avhengighet av openpyxl (strømmende XML-skriving) | MIT |

Ren Python. openpyxl brukes bare til å skrive egne filer, aldri til å lese filer utenfra, og bare i `export/xlsx_writer.py` (arkitekturtest). Ingen kjente sårbarheter (pip-audit). Låsene er ikke regenerert fra bunnen: blokkene er satt inn i de eksisterende låsene, slik at alle andre versjoner er uendret (en ny `uv pip compile` ville ha senket mako og platformdirs). PyInstaller tar med pakkene som vanlige Python-moduler; `.exe`-selvtesten skriver en Excel-fil.

## Fase 15 – avhengigheter tatt i bruk

| Pakke | Eksakt versjon | Formål | Lisens |
|---|---|---|---|
| defusedxml | 0.7.1 (utgitt 2021-03-08) | Sikker XML-parsing av EHF (ADR-0019) | PSF-2.0 |

Ren Python uten egne avhengigheter; den bruker standardbibliotekets `xml.etree` med herdede innstillinger. Siste utgivelse er fra 2021. Det er ingen kjente sårbarheter (pip-audit), men vedlikeholdet er lite; et alternativ må vurderes hvis en feil blir funnet. Blokken er satt inn i de eksisterende låsene uten andre endringer. PyInstaller tar med pakkemetadata via `copy_metadata` (motorversjonen leses med `importlib.metadata`).

## Fase 02 – avhengigheter tatt i bruk

| Pakke | Eksakt versjon | Formål | Lisens |
|---|---|---|---|
| SQLAlchemy | 2.0.54 | SQLite-motor, Core og transaksjoner | MIT |
| Alembic | 1.20.0 | Versjonerte migrasjoner | MIT |
| greenlet | 3.5.6 (plattformmarkør) | SQLAlchemy-avhengighet | MIT/PSF |
| Mako | 1.4.1 | Alembic-maler | MIT |
| MarkupSafe | 3.0.3 | Mako-avhengighet | BSD-3-Clause |

Disse versjonene med transitive avhengigheter og hasher står i begge låsefiler. Ingen andre pakker er oppgradert i sluttgjennomgangen. Installasjon med `--require-hashes`, pip-audit og Windows-bygg er kontrollert i CI; rapporten lenker til resultatene. Tilgjengelige intervaller i pyproject er ikke dokumentasjon på en testet kombinasjon; låsene er det reproduserbare utgangspunktet.
