# InvoiceFlow AI – Masterspesifikasjon

| | |
|---|---|
| **Dokumentversjon** | 1.1 (Fase 00, etter sluttrevisjon) |
| **Grunnlag** | Masterprompt 00, versjon 1.1 |
| **Status** | Utformet og revidert (`PHASE_00_AUDIT.md`) – venter på godkjenning fra prosjekteier (`PHASE_00_ACCEPTANCE.md`) |
| **Sist oppdatert** | 2026-10-20 |

Dette dokumentet er den autoritative kravbeskrivelsen for InvoiceFlow AI. Øvrige dokumenter i `docs/` utdyper arkitektur, datamodell, sikkerhet, testing og plan. Ved motstrid gjelder dette dokumentet, og motstriden skal registreres som et åpent spørsmål (kapittel 12).

---

## 1. Overordnet teknisk oversikt (leveranse A)

### 1.1 Formål

InvoiceFlow AI er en lokal Windows 11-applikasjon som tar inngående fakturaer fra skanner eller importerte filer og gjør dem klare for regnskap: tekstuttrekk/OCR, tolkning, konteringsforslag, deterministisk validering, duplikatkontroll, manuell gjennomgang og godkjenning, og til slutt eksport til Excel/CSV (senere Unit4 ERP/Agresso).

### 1.2 Omfang for første versjon

| I omfang | Utenfor omfang (nå) |
|---|---|
| Én lokal bruker på én Windows 11-maskin i et kontrollert testmiljø | Flerbruker, server, nettskyvert drift |
| Import av PDF og bilder (PNG, JPEG, TIFF), overvåket mappe | Automatisk bokføring og betaling (skal **aldri** skje automatisk) |
| Tekstlag fra PDF, OCR for skannede dokumenter | Ekte skannerintegrasjon før egen fase |
| KI-tolkning via utskiftbar adapter (valgfri, av som standard) | Direkte ERP-integrasjon før egen fase |
| Validering, MVA-kontroll, duplikatdeteksjon | EHF/PEPPOL-mottak (planlagt senere, se veikart) |
| Gjennomgang, korrigering og godkjenning | Mobil- eller nettgrensesnitt |
| Eksport til Excel og CSV | |

### 1.3 Arbeidsflyt

```text
Skanner / fil / overvåket mappe
  → filvalidering (signatur, størrelse, sider)          [ikke-klarert inndata]
  → lagring av original (SHA-256, skrivebeskyttet)
  → tekstlag (pypdfium2) eller OCR (Tesseract/PaddleOCR)
  → feltuttrekk (regler) + valgfri KI-tolkning
  → kanonisk faktura med proveniens per felt
  → deterministisk validering (beløp, MVA, datoer, identifikatorer, duplikater)
  → manuell gjennomgang og godkjenning                  [menneske i løkken]
  → eksport (Excel/CSV, senere Unit4)                   [kun godkjente fakturaer]
```

### 1.4 Teknisk strategi

1. **Modulær monolitt med porter og adaptere.** Én prosess for brukergrensesnitt og forretningslogikk, med risikabel dokumentbehandling i isolerte underprosesser. OCR, KI, lagring og eksport er utskiftbare adaptere bak stabile grensesnitt (se `ARCHITECTURE.md`).
2. **Kanonisk fakturamodell** uavhengig av OCR-motor, KI-leverandør og ERP. Hver verdi bærer proveniens: *hentet fra dokument*, *foreslått av KI*, *beregnet* eller *manuelt korrigert* (se `DATA_MODEL.md`).
3. **Lokal først.** All kjernefunksjonalitet virker uten internett. Ingen data forlater maskinen uten eksplisitt, registrert samtykke.
4. **Deterministisk regnskapskontroll.** KI foreslår, kode kontrollerer, mennesket godkjenner. Alle beløp er `decimal.Decimal`.
5. **Sikkerhet i alle faser.** Hver oppgave har sikkerhetskriterier; verktøy (Bandit, pip-audit, Gitleaks) kjøres i CI (se `SECURITY.md`).
6. **Inkrementell utvikling.** Små faser med testbare akseptansekriterier (se `DEVELOPMENT_ROADMAP.md`).

### 1.5 Begrensninger

- Måloperativsystem: Windows 11 (64-bit). BitLocker krever Windows 11 Pro/Enterprise/Education (se åpent spørsmål Å-13).
- Python 3.13 (64-bit), se ADR-0002.
- Den obligatoriske teknologistakken (kapittel 4) endres ikke uten godkjenning.
- Ingen ekte fakturaer eller kundedata i repoet eller i testdata.

---

## 2. Språkpolicy

- Alt brukerrettet innhold er på **norsk bokmål (`nb-NO`)**: menyer, knapper, dialoger, varsler, feil- og valideringsmeldinger, hjelpetekster, installasjonsdokumentasjon og prosjektrapporter.
- Python-identifikatorer, moduler, interne skjemaer og teknisk kodedokumentasjon (docstrings, kodekommentarer) er på **engelsk**.
- Brukertekster hentes **kun** fra en sentral oversettelseskatalog via nøkler. Hardkodede brukertekster i moduler er ikke tillatt (håndheves med test fra Fase 01).
- Valideringsregler returnerer *meldingsnøkler og parametere*, ikke ferdig tekst.
- Formater i brukergrensesnittet:
  - Dato: `dd.mm.åååå` (f.eks. `01.10.2026`)
  - Beløp: `1 234,56` med hardt mellomrom som tusenskille, desimalkomma; valuta som `kr` eller ISO-kode
  - Prosent: `25 %`
- Internt lagres datoer som ISO 8601 og beløp som `Decimal`; formatering skjer kun i presentasjonslaget.
- Fagterminologi følger kapittel 13 (ordliste).

## 3. Funksjonelle krav (oversikt)

| ID | Krav | Fase |
|---|---|---|
| F-01 | Importere PDF, PNG, JPEG og TIFF fra fil og overvåket mappe | 03 |
| F-02 | Bevare original uendret, med SHA-256 og sporbarhet | 03 |
| F-03 | Avvise eller sette i karantene filer som ikke består validering | 03 |
| F-04 | Hente tekstlag fra PDF; rasterisere og forbehandle ved behov | 04 |
| F-05 | OCR med sidetall, posisjon (bounding box) og konfidens | 05 |
| F-06 | Hente ut fakturafelt og linjer til kanonisk modell med proveniens | 06 |
| F-07 | Valgfri KI-tolkning via utskiftbar adapter | 07 |
| F-08 | Validere beløp, MVA, datoer, identifikatorer og påkrevde felt | 08 |
| F-09 | Oppdage duplikater (identisk fil og samme leverandør/fakturanummer) | 03/08 |
| F-10 | Foreslå kontering (konto, MVA-kode, kostnadssted, avdeling, prosjekt) | 08 |
| F-11 | Vise original side ved side med uttrukne verdier; redigere og godkjenne | 09 |
| F-12 | Eksportere godkjente fakturaer til Excel og CSV, idempotent | 10 |
| F-13 | Revisjonslogg for import, OCR, KI, kontering, valideringsfeil, korrigeringer, godkjenninger og eksport | 02 → |
| F-14 | Skannerintegrasjon (ADF, dupleks, profiler) med overvåket mappe som reserve | 11 |
| F-15 | Kryptert sikkerhetskopi med integritetskontroll og gjenopprettingstest | 12 |
| F-16 | Unit4 ERP-eksport med konfigurerbar felttilordning | 14a |
| F-17 | Tripletex-eksport via API som ikke-bokført bilag (krever ADR-0030) | 14b |
| F-18 | Xledger-eksport via fil eller API (API krever ADR-0030) | 14c |

## 4. Obligatorisk teknologistakk

| Komponent | Teknologi | Merknad |
|---|---|---|
| Språk | Python 3.13 (64-bit) | ADR-0002 |
| Skrivebordsgrensesnitt | PySide6 (Qt 6) | LGPL-3.0 |
| Lokal database | SQLite + SQLAlchemy (+ Alembic for migrasjoner) | ADR-0005 |
| PDF | pypdfium2 (PDFium, bak utskiftbar adapter) | BSD-3-Clause / Apache-2.0 – valgt i D-11 (ADR-0023, G-09); erstatter PyMuPDF |
| Bildebehandling | OpenCV (`opencv-python-headless`) + Pillow | ADR-0011 |
| OCR | Tesseract (først) / PaddleOCR (valgfri) | ADR-0007 |
| KI-tolkning | Utskiftbar adapter | ADR-0008 |
| Datavalidering | Pydantic v2 | ADR-0003 |
| Beløpsberegning | `decimal.Decimal` | ADR-0004 |
| Excel | openpyxl | |
| Testing | pytest | |
| Pakking | PyInstaller (onedir) | ADR-0014 |
| Versjonskontroll | Git + privat GitHub-repo | |

Verifiserte versjoner og Windows-kompatibilitet: se `DEPENDENCIES.md`.

## 5. Arkitekturprinsipper

SOLID, DRY, KISS, YAGNI, ansvarsdeling (presentasjon, dokumentbehandling, KI, regnskapslogikk, databasetilgang og eksport er uavhengige), avhengighetsinversjon, én autoritativ kilde per opplysning, idempotens, «fail fast», minste privilegium, dybdeforsvar, menneske i løkken, innebygd sikkerhet og testdrevet utvikling. Konkret anvendelse er beskrevet i `ARCHITECTURE.md` og `SECURITY.md`.

## 6. Ikke-funksjonelle krav

| ID | Krav | Mål (foreslått, bekreftes i Fase 04/05) |
|---|---|---|
| NF-01 | Oppstartstid | < 5 s til hovedvindu på referansemaskin |
| NF-02 | Responsivt grensesnitt | Ingen blokkering av UI-tråden > 100 ms |
| NF-03 | Tekstlag-uttrekk | < 2 s per enkeltsidig PDF |
| NF-04 | OCR | < 10 s per A4-side ved 300 dpi (Tesseract) |
| NF-05 | Volum | Minst 10 000 fakturaer i databasen uten merkbar treghet |
| NF-06 | Frakoblet drift | All kjernefunksjonalitet uten internett |
| NF-07 | Robusthet | Ingen datatap ved strømbrudd under skriving (SQLite WAL + `synchronous=FULL`) |
| NF-08 | Sporbarhet | Hver verdi kan spores til kilde, og hver handling til revisjonslogg |
| NF-09 | Vedlikeholdbarhet | Domene- og regnskapslogikk ≥ 95 % testdekning (linje og gren) |
| NF-10 | Portabilitet av leverandører | Ny OCR-/KI-/eksportadapter uten endring i domene- eller UI-kode |

## 7. Sikkerhetskrav (sammendrag)

Fullstendig beskrivelse i `SECURITY.md` og `THREAT_MODEL.md`. Hovedpunkter:

- Lokal behandling som standard; ingen telemetri; sky-KI kun med eksplisitt samtykke.
- Originaler bevares uendret med SHA-256; avledede filer lagres separat.
- Alle importerte filer er ikke-klarert inndata (signatur, størrelse, sidegrenser, isolasjon, tidsavbrudd).
- OCR-tekst og dokumentinnhold er data, aldri instruksjoner, for KI-motoren.
- KI har ingen tilgang til filsystem, nettverk, skall eller database; utdata valideres strengt med Pydantic.
- Beløp i `Decimal`; deterministisk kontroll av netto, MVA og brutto.
- Ingen eksport av ikke-godkjente fakturaer; godkjenning bindes til innholdshash.
- Strukturert revisjonslogg med hashkjede og uten sensitivt innhold.
- Hemmeligheter i Windows Credential Manager; aldri i kode, konfigurasjon eller logg.
- Bandit, pip-audit og Gitleaks i CI; resultater rapporteres ærlig.

## 8. Standardstruktur for utviklingsoppgaver

Alle fremtidige oppgaver formuleres med seks obligatoriske deler:

1. **GOAL – Mål:** én konkret funksjon eller endring.
2. **CONTEXT – Kontekst:** nåværende prosjekttilstand og relevante moduler.
3. **INPUT – Inndata:** filer, formater, parametere, skjemaer og unntakstilfeller.
4. **OUTPUT – Utdata:** forventet funksjonalitet, filer, poster, strukturer og observerbar oppførsel.
5. **CONSTRAINTS – Begrensninger:** kompatibilitet, sikkerhet, arkitektur og avgrensning.
6. **TESTS – Tester:** objektive akseptansekriterier, enhetstester, integrasjonstester, grensetilfeller og regresjonskontroller.

Uformelle krav fra prosjekteier struktureres etter disse seks delene før implementering. Manglende detaljer skal ikke diktes opp, men registreres som åpne spørsmål. Mal: `docs/prompts/PHASE_01_WINDOWS_APPLICATION_SKELETON.md`.

## 9. Prosjektkommandoer

| Kommando | Påkrevd oppførsel |
|---|---|
| `#PLAN` | Utforme løsning uten implementasjonskode |
| `#BUILD` | Implementere godkjent endring |
| `#TEST` | Lage og kjøre relevante tester |
| `#AUDIT` | Gjennomgå korrekthet, sikkerhet, arkitektur og vedlikeholdbarhet |
| `#DEBUG` | Finne rotårsak før kode endres |
| `#REFACTOR` | Forbedre intern struktur uten å endre oppførsel |
| `#COMPARE` | Vurdere alternativer og avveininger |
| `#SECURITY` | Fokusert sikkerhetsvurdering |
| `#PERFORMANCE` | Undersøke målbare flaskehalser |
| `#RELEASE` | Forberede pakking og utgivelsesverifikasjon |

Kommandoene er prosjektkonvensjoner, ikke innebygde funksjoner i en KI-leverandør, og de overstyrer aldri sikkerhetsreglene.

## 10. Definisjon av ferdig

En oppgave kan rapporteres som fullført bare når:

1. Krav og akseptansekriterier er oppfylt.
2. Forventede filer eller funksjonalitet finnes.
3. Modulgrensene er respektert.
4. Relevante automatiske tester finnes.
5. Testene faktisk har bestått der kjøring er mulig (med bevis: kommando og resultat).
6. Sikkerhetskrav er oppfylt eller dokumentert som uløste.
7. Eksisterende funksjonalitet er kontrollert for regresjoner.
8. Dokumentasjonen er oppdatert (inkl. `CHANGELOG.md`).
9. Avhengigheter og konfigurasjon er dokumentert.
10. Resultatene er reproduserbare.

### Statusbegreper

| Status | Betydning |
|---|---|
| **Utformet** | Beskrevet i dokumentasjon, ingen kode |
| **Implementert** | Kode skrevet |
| **Testet** | Automatiske tester skrevet og kjørt med bestått resultat (miljø oppgis) |
| **Verifisert** | Testet på Windows. Angi alltid hvilket nivå: **Windows-CI-testet** (GitHub Actions `windows-latest`) eller **Windows 11-akseptert** (manuelt på prosjekteiers maskin). CI erstatter ikke manuell aksept |
| **Godkjent** | Akseptert av prosjekteier |
| **Utgitt** | Pakket, versjonsmerket og levert |

Utført arbeid skal aldri rapporteres med høyere status enn det finnes bevis for.

## 11. Git og kontinuitet

- Privat GitHub-repo `RobertCygan/InvoiceFlowAI`, standardgren `main`. Arbeid skjer på grener; endringer leveres som pull requests mot `main`. Kontroller `git remote -v` før push.
- Aldri commit: passord, API-nøkler, fakturaer, kundedata, lokale databaser, OCR-utdata med personopplysninger. `.gitignore` blokkerer dokument- og datafiler som standard; Gitleaks kjører i CI.
- Viktige beslutninger lagres i `DECISIONS.md`, ikke bare i samtalehistorikk.
- `AGENTS.md` gir leverandørnøytrale arbeidsregler for KI-assistenter og utviklere.

## 12. Åpne spørsmål og uavklarte krav

Spørsmålene under må avklares av prosjekteier. Anbefaling, frist, status og om spørsmålet blokkerer Fase 01 føres i `PHASE_00_DECISION_REGISTER.md` (eneste sted for status).

| ID | Spørsmål | Påvirker | Trengs før |
|---|---|---|---|
| Å-01 | Hvilken skannermodell brukes, og støtter den WIA, TWAIN eller «skann til mappe»? | Skannerintegrasjon | Fase 11 |
| Å-02 | Hvilken Unit4-versjon (Unit4 ERP 7 / Agresso / sky), hvilket importformat og hvilke dimensjoner? | Eksport | Fase 14 |
| Å-03 | Er sky-KI tillatt i det hele tatt? Krav til databehandleravtale og lokasjon (EU/EØS)? | KI-adapter | Fase 07 |
| Å-04 | Lokal KI: hvilken maskinvare (RAM, GPU) har målmaskinen? | Modellvalg | Fase 07 |
| Å-05 | Godkjenning av OCR-valg: Tesseract først, PaddleOCR som alternativ (ADR-0007)? | OCR | Fase 05 |
| Å-06 | PyMuPDF er AGPL-3.0. Skal programmet noen gang distribueres utenfor egen organisasjon? Kommersiell lisens eller alternativ? (ADR-0023) | Lisens | Fase 04 |
| Å-07 | Oppbevaringstid og slettingsregler (bokføringsloven, personopplysninger) – bekreftes av regnskapsansvarlig | Arkiv, backup | Fase 12 |
| Å-08 | Kun NOK i første versjon? Håndtering av utenlandske leverandører og omvendt avgiftsplikt? | Validering | Fase 08 |
| Å-09 | Mottar organisasjonen EHF-fakturaer? I så fall bør EHF-import prioriteres høyt (eksakte data uten OCR) | Veikart | Fase 06 |
| Å-10 | Er Windows-pålogging tilstrekkelig autentisering, eller kreves egen app-PIN? | Sikkerhet | Fase 09 |
| Å-11 | Kodesignering av `.exe` (sertifikat)? | Utgivelse | Fase 13 |
| Å-12 | Antivirus: er Microsoft Defender standard, eller finnes bedriftsløsning med API? | Filimport | Fase 03 |
| Å-13 | Har målmaskinen Windows 11 Pro/Enterprise med BitLocker aktivert? | Konfidensialitet | Fase 03 |
| Å-14 | Hvor skal sikkerhetskopier lagres (ekstern disk, nettverksshare), og hvem forvalter nøkkelen? | Backup | Fase 12 |
| Å-15 | Prosjektets lisens (proprietær?) og eierskap til kildekoden | Juridisk | Fase 13 |
| Å-16 | Forventet volum (fakturaer per måned, sider per faktura) | Ytelse | Fase 04 |
| Å-17 | Skal installasjonen brukes for mer enn én regnskapsenhet? (Datamodellen er forberedt uansett, ADR-0022; spørsmålet gjelder nå grensesnitt og drift.) | Grensesnitt, drift | Fase 09 |
| Å-18 | Finnes eksisterende kontoplan, MVA-koder og leverandør→konto-regler som fil/eksport fra ERP? | Kontering | Fase 08 |
| Å-19 | Skal leveringsdato/-periode hentes ut fra fakturaen (etter vår forståelse skal salgsdokumenter angi leveringstidspunkt etter bokføringsforskriften – bekreftes av regnskapsansvarlig; nyttig for periodisering)? | Kanonisk modell | Fase 06 |
| Å-20 | Skal grenbeskyttelse for `main` slås på i GitHub (krev pull request og grønn CI)? | Repo-sikkerhet | Fase 01 |
| Å-21 | Tripletex: hvilke regnskapsenheter bruker det, hvem skaffer API-tilgang (integrasjonspartner/nøkkel), og godtar regnskapsansvarlig mottak som ikke-bokført bilag i bilagsmottaket? | ERP-eksport | Fase 14b |
| Å-22 | Xledger: finnes et dokumentert importformat (fil), eller må API brukes? Hvilken tilgang, hvilke dimensjoner og hvilken tilstand får innkommende fakturaer? | ERP-eksport | Fase 14c |
| Å-23 | Prioritering av ERP-mål og målgruppe (kommuner med Unit4, virksomheter med Tripletex/Xledger)? | Veikart | Fase 13 |
| Å-24 | Hvordan kommer EHF-fakturaene inn (XML-filer fra aksesspunkt/regnskapssystem eller eget PEPPOL-aksesspunkt), og tar UDIs Tripletex allerede imot EHF direkte? | EHF-import | Før F15 |

## 13. Ordliste (norsk → engelsk identifikator)

| Norsk (UI) | Engelsk (kode) | Merknad |
|---|---|---|
| Faktura | `invoice` | |
| Kreditnota | `credit_note` | `InvoiceType.CREDIT_NOTE` |
| Leverandør | `supplier` | |
| Kunde | `customer` | |
| Fakturanummer | `invoice_number` | |
| Fakturadato | `invoice_date` | |
| Forfallsdato | `due_date` | |
| Beløp | `amount` | `Decimal` |
| Sum eks. MVA | `net_amount` | |
| Merverdiavgift (MVA) | `vat` / `vat_amount` | |
| MVA-sats | `vat_rate` | Prosent, f.eks. `25` |
| MVA-kode | `vat_code` | SAF-T-standardkode eller ERP-kode |
| Sum inkl. MVA / Å betale | `gross_amount` | |
| Øreavrunding | `rounding_amount` | |
| KID | `kid` | Kundeidentifikasjon for betaling |
| Kontonummer (bank) | `bank_account` | 11 siffer |
| Organisasjonsnummer | `org_number` | 9 siffer |
| Kontoplan | `chart_of_accounts` | NS 4102 som utgangspunkt |
| Konto | `account` | |
| Kontering | `accounting_line` / `posting` | |
| Kostnadssted | `cost_center` | |
| Avdeling | `department` | |
| Prosjekt | `project` | |
| Godkjenning | `approval` | |
| Gjennomgang | `review` | |
| Eksport | `export` | |
| Revisjonslogg | `audit_log` | |
| Proveniens / kilde | `provenance` / `source` | |
| Karantene | `quarantine` | |


## Tillegg – dokumentarkiv (beslutning 2026-10-20)

InvoiceFlow AI skal på sikt være et søkbart arkiv for regnskapsrelaterte dokumenter: fakturaer, kreditnotaer, kvitteringer, avtaler, betalingsbekreftelser og leverandørkorrespondanse. Fakturabehandling prioriteres først. Dokumenter uten fakturastruktur skal ikke modelleres som `CanonicalInvoice`. Omfang, fasering, sikkerhet og regulatoriske avklaringer er spesifisert i [`DOCUMENT_ARCHIVE_SCOPE.md`](DOCUMENT_ARCHIVE_SCOPE.md). Dette er et fremtidig produktkrav, ikke implementert funksjonalitet i Fase 00 eller Fase 01.
