# InvoiceFlow AI – Utviklingsveikart

| | |
|---|---|
| **Dokumentversjon** | 1.1 (Fase 00, etter sluttrevisjon) |
| **Status** | Utformet – rekkefølge og omfang krever godkjenning fra prosjekteier |

Hver fase leveres som én eller flere pull requests, beskrives med seksdelt prompt (GOAL, CONTEXT, INPUT, OUTPUT, CONSTRAINTS, TESTS) og avsluttes etter *Definisjon av ferdig* (`MASTER_SPECIFICATION.md` §10). En fase starter først når forrige fase er **Godkjent**, med mindre prosjekteier bestemmer noe annet.

---

## 1. Avhengigheter mellom faser

```mermaid
flowchart LR
    F00["F00 Fundament"] --> F01["F01 Applikasjonsskjelett"]
    F01 --> F02["F02 Datalag og revisjon"]
    F02 --> F03["F03 Sikker import og dokumentlager"]
    F03 --> F04["F04 PDF og bilde, isolasjon"]
    F04 --> F05["F05 OCR"]
    F05 --> F06["F06 Feltuttrekk"]
    F06 --> F07["F07 KI-tolkning"]
    F06 --> F08["F08 Regnskapsmotor"]
    F07 --> F08
    F08 --> F09["F09 Gjennomgang og godkjenning"]
    F09 --> F10["F10 Eksport Excel og CSV"]
    F03 --> F11["F11 Skanner"]
    F10 --> F12["F12 Backup og gjenoppretting"]
    F12 --> GATE{{"Port for ekte data"}}
    GATE --> F13["F13 Pakking og utgivelse"]
    F13 --> F14["F14a Unit4/Agresso (fil)"]
    F13 --> F14B["F14b Tripletex (API)"]
    F13 --> F14C["F14c Xledger (API/fil)"]
    ADR30{{"ADR-0030 nettverk for ERP"}} --> F14B
    ADR30 --> F14C
    F04 --> F15["F15 EHF/PEPPOL (D-29)"]
    F15 --> F08
```

F07 (KI) er valgfri for F08: regnskapsmotoren skal virke med regelbasert uttrekk alene. Prosjekteier har bekreftet at fakturaene kommer som EHF (Å-09, 2026-10-23). F15 er derfor flyttet fram rett etter F04, foran F05 og F06 (D-29, godkjent 2026-10-23, G-11); prompt: `prompts/PHASE_15_EHF_IMPORT.md`. F14b og F14c bygger på ADR-0030 (utgående nettverk for ERP-integrasjoner, godkjent 2026-10-23); F14a er filbasert og trenger ikke nettverk. Se §4.

## 2. Faser

### F00 – Fundament, arkitektur og sikkerhet *(denne fasen)*

- **Leveranser:** Dokumentasjon (A–J), kanoniske Pydantic-kontrakter med tester, repostruktur, låsefil, CI.
- **Akseptansekriterier:** Alle dokumenter i `MASTER_SPECIFICATION.md` §11 finnes på norsk; eksempelfakturaen valideres; tester, ruff, Bandit og pip-audit kjørt uten funn; Fase 01-prompt klar.
- **Ferdig når:** Sluttrevisjonen er gjennomført (`PHASE_00_AUDIT.md`), sjekklisten i `PHASE_00_ACCEPTANCE.md` er grønn, og prosjekteier har godkjent Fase 00 og beslutningene merket «blokkerer Fase 01» i `PHASE_00_DECISION_REGISTER.md`.

### F01 – Windows-applikasjonsskjelett

- **Avhenger av:** F00.
- **Innhold:** Inngangspunkt med `freeze_support()`, komposisjonsrot, konfigurasjon (Pydantic), stier under `%LOCALAPPDATA%`, strukturert logging med maskering, global feilhåndtering, i18n-katalog `nb-NO` med beløps-/datoformatering, PySide6-hovedvindu med navigasjon (plassholdere), selvtest-modus, PyInstaller onedir-røykbygg.
- **Akseptansekriterier:** Appen starter på Windows 11 med norsk hovedvindu; ingen nettverkskall; alle UI-tekster fra katalog; logger uten sensitive data; `--self-test` returnerer 0 i både kildekode og bygg.
- **Ferdig når:** CI grønn på Windows inkl. GUI-røyktest; bygg testet manuelt på målmaskin. Detaljer: `prompts/PHASE_01_WINDOWS_APPLICATION_SKELETON.md`.

### F02 – Datalag, migrasjoner og revisjonslogg

- **Avhenger av:** F01.
- **Innhold:** `accounting_entities` med én standardenhet og `EntityScope` (ADR-0022), SQLAlchemy-modeller etter `DATA_MODEL.md` §3, `DecimalText`- og `UtcDateTime`-typer, PRAGMA-oppsett, Alembic-migrasjoner, repositorier og `UnitOfWork`, mapping `CanonicalInvoice` ↔ rader, innholdshash, `audit_events` med hashkjede og triggere.
- **Akseptansekriterier:** Migrasjon tom → siste; rundtur av eksempelfakturaen er tapsfri; `UPDATE`/`DELETE` på revisjon avvises; manipulert hendelse oppdages; ingen `REAL` for beløp; regnskapsenhet håndhevet i database og repositorier med testene fra ADR-0022.
- **Ferdig når:** Integrasjonstester grønne på Windows; backup før migrasjon dokumentert.

### F03 – Sikker dokumentimport og dokumentlager

- **Avhenger av:** F02.
- **Innhold:** Filimport og overvåket mappe, signaturkontroll, grenser, filnavnrensing, karantene, innholdsadressert lagring, SHA-256, skrivebeskyttelse, duplikat på hash, integritetskontroll, kontroll av NTFS-rettigheter og BitLocker-status (varsel), dokumentinnboks i UI.
- **Akseptansekriterier:** Hele det fiendtlige filkorpuset (TEST_STRATEGY §4) gir forventet avvisning/karantene; identisk fil gir ingen ny rad; original er byte-identisk etter import.
- **Ferdig når:** Sikkerhetstester grønne; `#SECURITY`-gjennomgang av importgrensen (TB1).

### F04 – PDF- og bildebehandling med isolasjon

- **Avhenger av:** F03.
- **Innhold:** Arbeidsprosess (spawn) med tidsavbrudd og minnegrense (Job Object), pypdfium2 tekstlag og rasterisering (D-11), Pillow for bilder, flersidige dokumenter, avledede filer. Forbehandling (rotasjon, skjevhet) med OpenCV er flyttet til F05, der OCR trenger den.
- **Status:** Implementert og testet; se `PHASE_04_REPORT.md`. Faseaksept gjenstår.
- **Akseptansekriterier:** Hengende/krasjende parser påvirker ikke hovedprosessen; tekstlag hentes fra syntetiske PDF-er; ytelsesmål NF-03.
- **Forutsetning:** Beslutningsport for PDF-lisens (ADR-0023, Å-06) er avgjort: pypdfium2 (D-11 = C, G-09). F04-promptet er godkjent (G-09).

### F05 – OCR

- **Status:** Implementert og testet; se `PHASE_05_REPORT.md` (prompt `prompts/PHASE_05_OCR.md`, G-24, D-38, ADR-0040) og veiledningen `OCR_SETUP.md`. Tesseract 5 med norsk språkdata (D-13 godkjent). PaddleOCR-sammenligningen er utsatt til ekte skann finnes. Faseaksept gjenstår.
- **Avhenger av:** F04.
- **Innhold:** `OcrEngine`-port, Tesseract-adapter (norsk språkdata), ord/linjer med posisjon og konfidens, idempotent lagring; evaluering av PaddleOCR mot samme referansesett.
- **Akseptansekriterier:** Referansesett med syntetiske skannede fakturaer når avtalt treffsikkerhet per felt; ytelsesmål NF-04; ingen nettverkstilgang.
- **Forutsetning:** Godkjent OCR-valg (ADR-0007, Å-05).

### F06 – Feltuttrekk til kanonisk modell

- **Status:** Implementert og testet; se `PHASE_06_REPORT.md` (prompt `prompts/PHASE_06_EXTRACTION.md`, G-25, D-39, ADR-0041). Fire syntetiske fakturaer med gyldne filer, lest fra tekstlag og OCR. Treffsikkerhet mot ekte fakturaer måles etter porten for ekte data. Faseaksept gjenstår.
- **Avhenger av:** F05.
- **Innhold:** Regelbasert uttrekk av norske fakturafelt (fakturanummer, datoer, KID, kontonummer, orgnr, totaler, MVA-spesifikasjon, linjer), normalisering (`1 234,50` → `Decimal("1234.50")`), proveniens og kildehenvisning.
- **Akseptansekriterier:** Gyldne filer for referansesettet; ingen oppdiktede verdier; uparserbar verdi → `value=None` + råtekst.

### F07 – KI-tolkning (valgfri adapter)

- **Avhenger av:** F06.
- **Innhold:** `AiInterpreter`-port, `DisabledAiInterpreter` (standard), én lokal adapter, eget utdataskjema, samtykke og utgående kontroll for sky, grunnlagssjekk (AI-001).
- **Akseptansekriterier:** Prompt-injeksjonstester består; ugyldige svar forkastes; ingen nettverk uten samtykke; systemet fungerer identisk med KI av.
- **Forutsetning:** Avklaring av Å-03/Å-04.

### F08 – Regnskapsmotor

- **Status:** F08a (validering, leverandørregister, duplikater) er implementert og testet; se `PHASE_08_REPORT.md` (prompt `prompts/PHASE_08_ACCOUNTING_ENGINE.md` v1.0, G-12, D-31). Faseaksept gjenstår. F08b (kontoplan, MVA-koder, dimensjoner, konteringsforslag) er implementert med syntetiske filer; se `PHASE_08B_REPORT.md` (prompt `prompts/PHASE_08B_REFERENCE_DATA.md`, G-13, D-32). Tilpasning til ekte ERP-eksport venter på Å-18.
- **Avhenger av:** F06 eller F15 (og F07 hvis aktivert).
- **Innhold:** Valideringsregler (`DATA_MODEL.md` §7), MVA-koder med gyldighet, kontoplan og dimensjoner (import fra fil), leverandørregister med verifiserte kontoer, duplikatdeteksjon, konteringsforslag fra regler/leverandørstandard.
- **Akseptansekriterier:** Hver regel har positive og negative tester og grensetilfeller; ≥ 95 % dekning; BANK-001 og DUP-001 blokkerer godkjenning.

### F09 – Gjennomgang og godkjenning

- **Status:** Implementert og testet; se `PHASE_09_REPORT.md` (prompt `prompts/PHASE_09_REVIEW_APPROVAL.md`, G-13, D-33). Slått sammen uten grønn Windows-CI (G-15). Faseaksept gjenstår.
- **Avhenger av:** F08.
- **Innhold:** Visning av original ved siden av feltene, markering av kildeområde (bbox), redigering med proveniens `manual`, valideringsliste med overstyring og begrunnelse, godkjenning bundet til innholdshash, historikk.
- **Akseptansekriterier:** Endring etter godkjenning opphever den; alle dokumentdata vises som ren tekst; tastaturnavigasjon.

### F10 – Eksport (Excel og CSV)

- **Status:** Implementert og testet; se `PHASE_10_REPORT.md` (prompt `prompts/PHASE_10_EXPORT.md`, G-16, D-34). Slått sammen uten grønn Windows-CI (G-17). Faseaksept gjenstår.
- **Avhenger av:** F09.
- **Innhold:** `Exporter`-port, openpyxl- og CSV-adapter (UTF-8 BOM, `;`), konfigurerbar felttilordning, eksportbatcher, idempotens, formelinjeksjonsvern, krasjsikker skriving.
- **Akseptansekriterier:** Kun godkjente fakturaer; dobbel eksport hindres av databasen; fiendtlige celleverdier nøytraliseres; eksportert sum = sum av godkjente fakturaer.

### F11 – Skannerintegrasjon

- **Status:** F11a (uten skannerdriver) er implementert og testet; se `PHASE_11A_REPORT.md` (prompt `prompts/PHASE_11A_SCAN_BATCHES.md`, G-21, D-36). Den overvåkede mappen, blanke sider, skilleark og oppdeling er på plass. F11a er slått sammen uten grønn Windows-CI (G-23). F11b (variant A, G-23) er implementert: skanning via Brothers program til skannemappen (ADR-0039), målinger per side og oppsettsveiledningen `SCANNER_SETUP.md`; se `PHASE_11B_REPORT.md`. Skanneren er foreløpig Brother ADS-4700W (G-22) og er ikke prøvd.
- **Avhenger av:** F03 (kan gå parallelt med F04–F10).
- **Innhold:** Overvåket skannemappe, blanke sider og skilleark, oppdeling av batch i flere fakturaer. Skanneprofiler, ADF og dupleks i produsentens program (ADR-0039); WIA i programmet er ikke planlagt.
- **Akseptansekriterier:** Testet med faktisk skannermodell; feil i skanner gir norsk melding uten datatap.

### F12 – Sikkerhetskopi og gjenoppretting

- **Status:** Implementert og testet; se `PHASE_12_REPORT.md` (prompt `prompts/PHASE_12_BACKUP.md`, G-18, D-35) og prosedyren `BACKUP_PROCEDURE.md`. Faseaksept gjenstår; Å-07 og Å-14 er åpne.
- **Avhenger av:** F10.
- **Innhold:** Kryptert sikkerhetskopi av database og originaler, manifest, revisjonsanker, verifisering, gjenoppretting, retensjon og sletting.
- **Akseptansekriterier:** Automatisk gjenopprettingstest grønn; manipulert arkiv avvises; dokumentert prosedyre på norsk.

### Port for ekte data

Krav i `SECURITY.md` §17. Prosjekteier beslutter.

### F13 – Pakking og utgivelse

- **Innhold:** PyInstaller-spesifikasjon (onedir), medfølgende Tesseract og norsk språkdata (besluttet, G-25), versjonsinformasjon, installasjonsveiledning på norsk, kodesignering (Å-11), utgivelsessjekkliste (`#RELEASE`), SBOM.
- **Akseptansekriterier:** Ren Windows 11-maskin uten Python kan installere og kjøre; selvtest grønn; hasher for utgivelsesfiler publisert.

### F14a – Unit4/Agresso ERP-eksport (fil)

- **Avhenger av:** F10, Å-02.
- **Innhold:** Unit4-adapter med konfigurerbar tilordning av konto, MVA-kode og dimensjoner, i formatet Unit4-administrator angir.
- **Akseptansekriterier:** Testimport i Unit4-testmiljø godkjent av regnskapsansvarlig.

### F14b – Tripletex-eksport (API)

- **Avhenger av:** F10, F13, godkjent ADR-0030, Å-21 (første kunde: UDI (Utlendingsdirektoratet) i Narvik, fakturaer til UDIs Tripletex; tilgang og mottak som ikke-bokført bilag gjenstår).
- **Innhold:** `Exporter`-adapter mot Tripletex' REST-API. Godkjente fakturaer sendes med originalfil til Tripletex som **ikke-bokført bilag** (bilagsmottak/innboks), slik at endelig bokføring skjer i Tripletex av et menneske. Kontoplan, MVA-koder, avdelinger, prosjekter og leverandører leses for tilordning; ingenting annet leses eller endres. Konfigurerbar tilordning per regnskapsenhet med versjon (`mapping_version`). Idempotent innsending med ekstern referanse; usikkert utfall (tidsavbrudd) avklares ved oppslag før nytt forsøk.
- **Å verifisere i fasen:** Tripletex' offentlige API har dokumentimport og innboksfunksjoner (merket beta i tredjepartsdokumentasjon). Endepunkter, felter og tilstand for opprettede bilag skal verifiseres mot den offisielle OpenAPI-spesifikasjonen og en testkonto før implementering; ikke anta.
- **Akseptansekriterier:** Testkjøring mot Tripletex-testkonto med syntetiske fakturaer; ingen bilag bokføres automatisk; dobbel innsending hindres også ved avbrutt forbindelse; ingen nettverkstrafikk uten samtykke (test med blokkert socket); godkjent av regnskapsansvarlig.

### F14c – Xledger-eksport (API eller fil)

- **Avhenger av:** F10, F13, godkjent ADR-0030 (bare ved API), Å-22. Starter først når prosjekteier har oppdrag og har anskaffet Xledger selv.
- **Innhold:** `Exporter`-adapter for Xledger. Filimport foretrekkes hvis Xledger-administrator kan ta imot et dokumentert importformat (ingen nettverk); ellers API med samme regler som F14b: kun ubehandlede/ikke-bokførte innkommende fakturaer med originalfil, oppslag i referansedata for tilordning, idempotens og revisjon.
- **Å verifisere i fasen:** Xledger tilbyr API-tilgang (GraphQL etter tilgjengelig informasjon). Hvilke operasjoner som finnes for innkommende fakturaer, og hvilken tilstand de får, er ikke verifisert og må avklares med Xledger-administrator og offisiell dokumentasjon (Å-22).
- **Akseptansekriterier:** Testimport i Xledger-testmiljø med syntetiske fakturaer, godkjent av regnskapsansvarlig; øvrige kriterier som F14b.

### F15 – EHF/PEPPOL BIS Billing 3.0

- **Status:** Implementert og testet; se `PHASE_15_REPORT.md`. Faseaksept gjenstår. Prompt: `prompts/PHASE_15_EHF_IMPORT.md` v1.0 (G-11). Flyttet fram rett etter F04, foran F05 (D-29).

- **Innhold:** XML-parser med `defusedxml`, mapping direkte til kanonisk modell med proveniens `extracted` og XPath som kildereferanse, vedlagt PDF som visning.
- **Akseptansekriterier:** Offisielle eksempelfiler valideres; XXE/«billion laughs» avvises.

## 3. Milepæler

| Milepæl | Faser | Resultat |
|---|---|---|
| M1 Kjørbart skall | F00–F01 | Norsk Windows-app som starter, logger trygt og kan pakkes |
| M2 Sikker lagring | F02–F03 | Dokumenter importeres trygt med full sporbarhet |
| M3 Tekst til data | F04–F06 | Syntetiske fakturaer blir kanoniske fakturaer med proveniens |
| M4 Kontroll og godkjenning | F07–F09 | Validerte, godkjente fakturaer |
| M5 Første nytte | F10–F12 | Eksport til Excel/CSV med backup – klar for port for ekte data |
| M6 Produksjon | F13–F14a | Installerbar versjon og Unit4-eksport |
| M7 Flere ERP | F14b–F14c | Tripletex- og Xledger-eksport etter behov (ADR-0030) |

## F02-oppdatert status

F01 er Windows-CI-testet, og prosjekteier har rapportert vellykket manuell test (M-01). F02 implementerer databasegrunnlaget, snapshot-revisjoner og auditkjede; endelig aksept følger PHASE_02_REPORT. Formell sammenslåing og faseaksept gjenstår. Ingen F03-kode er påbegynt.

F02 oppretter ikke automatisk en fiktiv regnskapsenhet. Før dokumentimport i F03 må aktiv enhet velges/opprettes eksplisitt og eierskap videreføres gjennom lager og repositorier (ADR-0026).

## Fremtidig utvidelse: dokumentarkiv

Prosjekteier har besluttet å planlegge for et regnskapsrelatert dokumentarkiv utover fakturaer. Detaljert utvidelse av dokumenttyper, søk, retensjon og arkiveksport krever egne faser og akseptansekriterier. F01 forblir et Windows-applikasjonsskall uten arkivimplementering. Se [`DOCUMENT_ARCHIVE_SCOPE.md`](DOCUMENT_ARCHIVE_SCOPE.md).

## 4. ERP-integrasjoner (tillegg 2026-10-23)

Prosjekteier har bedt om at Tripletex og Xledger legges inn i veikartet i tillegg til Unit4/Agresso (G-07). Status: **Utformet** – ingen kode er påbegynt. ADR-0030 og rekkefølgen under er godkjent av prosjekteier 2026-10-23 (D-26, D-27, G-08); F14b/F14c starter først etter F10 og F13 og når Å-21/Å-22 er avklart.

**Godkjent rekkefølge (D-27, G-08):**

| Rekkefølge | Mål | Måte | Begrunnelse |
|---|---|---|---|
| 1 | Excel/CSV (F10) | Fil | Fungerer mot alle systemer manuelt; grunnlaget for alle ERP-adaptere |
| 2 | Unit4/Agresso (F14a) | Fil | Viktigst for kommuner; ingen nettverkstilgang |
| 3 | Tripletex (F14b) | API | Første kunde er UDI i Narvik (Å-21); bredt brukt, offentlig API og testmiljø |
| 4 | Xledger (F14c) | Fil eller API | Når prosjekteier har oppdrag og har anskaffet Xledger selv (Å-22) |
| (parallelt) | EHF/PEPPOL (F15) | Mottak | Kan flyttes fram etter Å-09; eksakte data uten OCR |

**Felles prinsipper for alle ERP-mål:**

1. **Aldri automatisk bokføring.** Målsystemet mottar fakturaen som ikke-bokført bilag eller i en importbunke som et menneske behandler i ERP. Støtter ikke målet dette, brukes fil eller integrasjonen avvises.
2. **Kun godkjente fakturaer** og samme eksportløp som F10 (`export_batches`/`export_items`, ADR-0013). Nye `target`-verdier: `tripletex`, `xledger`.
3. **Fil før API.** API brukes bare når fil ikke er mulig, og bare etter ADR-0030 (samtykke, tillatte vertsnavn, hemmeligheter i Credential Manager, revisjon).
4. **Én regnskapsenhet = én ERP-klient.** Tilgangsnøkkel og tilordning lagres per enhet og mål; aldri innsending på tvers av `entity_id` (ADR-0022).
5. **Idempotens over nettverk.** Hver post får en stabil ekstern referanse; et usikkert utfall avklares ved oppslag i målsystemet før nytt forsøk.
6. **Testing** bare mot test-/sandkassekontoer med syntetiske fakturaer fram til porten for ekte data. CI har ingen nettverkstilgang; adaptertester bruker innspilte, syntetiske svar.
