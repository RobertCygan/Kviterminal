# D-11 – beslutningsgrunnlag: PDF-bibliotek og lisens

| | |
|---|---|
| **Dato** | 2026-10-22 |
| **Status** | Grunnlag for prosjekteiers beslutning. Ingen beslutning er tatt. |
| **Gjelder** | D-11, ADR-0023, Å-06 (og Å-15) – port før F04 |
| **Forbehold** | Teknisk vurdering, ikke juridisk rådgivning. Lisensspørsmål bør bekreftes av jurist eller leverandør før distribusjon utenfor egen virksomhet. |

## 1. Hva skal avgjøres

F04 skal hente sideantall, tekstlag med posisjoner og sidebilder (300 dpi) fra lagrede PDF-er i en isolert arbeidsprosess. Det krever ett PDF-bibliotek bak porten `DocumentParser` (ADR-0023). Masterspesifikasjonen nevner PyMuPDF, som er AGPL-lisensiert. Valget påvirker hvordan hele programmet kan gis videre.

| Alternativ | Innhold |
|---|---|
| **A** | PyMuPDF under AGPL-3.0, bare for strengt intern bruk (krever juridisk bekreftelse) |
| **B** | PyMuPDF med kommersiell lisens fra Artifex (pris og vilkår må innhentes) |
| **C** | pypdfium2 (PDFium) som standardadapter – avvik fra obligatorisk stakk |

## 2. Fakta kontrollert 2026-10-22

Kilder: PyPI-metadata (JSON-API), innholdet i Windows-hjulene (lastet ned og pakket ut), PyPIs sårbarhetsdata per versjon og en funksjonsprøve med syntetiske PDF-er. Ingenting er hentet fra hukommelsen alene.

### 2.1 Versjoner og karantene (ADR-0024, grense i dag 2026-09-22)

| Pakke | Nyeste (utgitt) | Nyeste utenfor karantene | Windows-hjul (Python 3.13) | Lisens (metadata) |
|---|---|---|---|---|
| pypdfium2 | 5.14.0 (2026-10-04) | **5.13.0** (2026-08-13) | `py3-none-win_amd64` | BSD-3-Clause, Apache-2.0 + avhengighetslisenser |
| PyMuPDF | 2.0 (2026-10-19, ny hovedversjon) | **1.28.2** (2026-08-06) | `cp310-abi3-win_amd64` | AGPL-3.0 eller Artifex kommersiell |
| pdfminer.six | 20260107 | 20260107 | ren Python | MIT |
| pypdf | 6.21.2 (2026-10-21) | – | ren Python | BSD-3-Clause |

pypdfium2 har kommet med ny versjon omtrent hver 2.–6. uke i 2026 (5.9.0 i juni til 5.14.0 i oktober; 5.12.0 ble trukket og erstattet av 5.12.1 etter to dager).

### 2.2 Lisenser i pypdfium2-hjulet for Windows

Hjulet `pypdfium2-5.13.0-py3-none-win_amd64.whl` inneholder `pdfium.dll` (PDFium bygg 153.0.7999.0 fra pdfium-binaries) og lisensfiler for alle innbygde komponenter:

| Komponent | Lisens |
|---|---|
| pypdfium2 | BSD-3-Clause / Apache-2.0 (dokumentasjon CC-BY-4.0) |
| PDFium | BSD-3-Clause |
| abseil, llvm-libc | Apache-2.0 |
| FreeType | FreeType Project License (FTL) – filen i hjulet inneholder bare FTL, ikke GPL-alternativet |
| ICU | Unicode-lisens |
| lcms, fast_float, libtiff, simdutf, pdfium-binaries | MIT-type |
| libjpeg-turbo | IJG + BSD-3-Clause |
| OpenJPEG | BSD-2-Clause |
| libpng, zlib | libpng-/zlib-lisens |
| AGG 2.3 | Egen fri lisens (kun opphavsrettsmerknad) |

Ingen copyleft-lisens (GPL/AGPL/LGPL) finnes blant dem. Pliktene er merknader om opphavsrett og lisenstekster, som samles i `THIRD_PARTY_NOTICES` (F13). PyMuPDF-hjulet har `COPYING` med AGPL-3.0.

### 2.3 Funksjonsprøve av pypdfium2 5.13.0 (Linux, syntetiske filer)

| Behov i F04 | Resultat |
|---|---|
| Sideantall | 1 side lest riktig |
| Tekstlag | «Faktura 2026-001 Syntetisk AS / Sum NOK 1 234,50» lest riktig |
| Tegnposisjoner | Boks per tegn i PDF-koordinater (f.eks. første tegn 73,2–80,2 × 770,0–780,1) |
| Rasterisering 300 dpi | A4 → 2480 × 3509 piksler, 0,04 s for en enkel side |
| Ødelagt, avkortet og tom fil | Kontrollert `PdfiumError` («Data format error»), ingen krasj |

Fiendtlige filer (dekompresjonsbomber, uendelige løkker) er ikke prøvd her; det er F04s jobb i den isolerte prosessen.

### 2.4 Sikkerhetshistorikk

PyPIs sårbarhetsdata (fra OSV/GHSA) for alle versjoner:

| Pakke | Kjente meldinger for Python-pakken | Merknad |
|---|---|---|
| pypdfium2 | 0 (131 versjoner kontrollert) | Feil i selve PDFium meldes for Chrome, ikke for pypdfium2 |
| PyMuPDF | 1 (CVE-2026-3029, filskriving via stivandring; rettet i 1.26.7) | Feil i selve MuPDF meldes separat |
| pdfminer.six | 2 (CVE-2025-64512 kodekjøring via pickle, CVE-2025-70559; rettet) | |
| pypdf | 57 unike CVE-er i de siste 60 versjonene (siden februar 2025) | Nesten alle er tjenestenekt fra konstruerte PDF-er (minne, uendelige løkker) |

Begge C-motorene har jevnlige minnesikkerhetsfeil:
- **PDFium:** flere heap-overflow- og use-after-free-feil rettet i Chrome i 2026 (f.eks. CVE-2026-6305, CVE-2026-6306; kilde: tredjeparts CVE-databaser, ikke kontrollert mot Googles egne meldinger).
- **MuPDF:** f.eks. CVE-2026-92413 (null-peker ved xref-lasting) og CVE-2026-25556 (dobbel frigjøring, strekkode-avkoding) – Debian sporer rettinger.

**Konsekvens uansett valg:** PDF-tolking må skje i den isolerte arbeidsprosessen med tidsavbrudd og minnegrense (ADR-0010, F04-promptet), og nye versjoner med sikkerhetsrettinger må kunne tas inn raskt etter sikkerhetsunntaket i ADR-0024.

## 3. Vurdering

| Kriterium | A: PyMuPDF/AGPL | B: PyMuPDF/kommersiell | C: pypdfium2 |
|---|---|---|---|
| Lisensrisiko ved videre distribusjon | **Høy:** kildekode for hele programmet må kunne utleveres | Lav, avhenger av avtalen | **Lav:** bare merknader |
| Kostnad | Ingen lisenskostnad | Ukjent – må innhentes fra Artifex | Ingen |
| Tekst med posisjon | Svært god | Svært god | God (per tegn; ordgruppering gjøres selv) |
| Rasterisering for OCR | Ja | Ja | Ja |
| Avvik fra masterspesifikasjonen | Nei | Nei | **Ja** – krever godkjenning |
| Bytte senere | Mulig via `DocumentParser` | Mulig | Mulig |

«Intern bruk» (A) er usikkert her: prosjektet planlegger flere regnskapsenheter (ADR-0022), og å gi programmet til et annet selskap, en regnskapsfører eller en konsulent kan være formidling etter AGPL (ADR-0023).

## 4. Anbefaling

**Alternativ C: pypdfium2 5.13.0 som standardadapter**, med disse betingelsene:

1. All PDF-tilgang går gjennom `DocumentParser` i den isolerte prosessen; arkitekturtest hindrer import andre steder.
2. Kontraktstestene i F04 skrives uavhengig av biblioteket. Viser målinger at tekstkvaliteten ikke holder, vurderes B på nytt.
3. pdfminer.six og pypdf tas ikke inn nå. pypdf har svært mange tjenestenekt-meldinger; pdfminer.six vurderes bare hvis layoutanalyse viser seg nødvendig.
4. Lisensmerknadene i §2.2 føres i `DEPENDENCIES.md` nå og i `THIRD_PARTY_NOTICES` i F13.

Begrunnelse: ingen copyleft-binding for hele programmet, ingen lisenskostnad, dekker alle F04-behov i prøven, og byttet er avgrenset til én adapter.

## 5. Det prosjekteier må avgjøre

1. **D-11:** A, B eller C (anbefalt C).
2. Ved C: godkjenne avviket fra den obligatoriske stakken (PyMuPDF → pypdfium2) i masterspesifikasjonen og ADR-0023.
3. **Å-15** (prosjektets lisens og eierskap): skal programmet noen gang gis til andre enn egen virksomhet? Svaret avgjør om A i det hele tatt er aktuelt.

Etter beslutningen oppdateres ADR-0023, beslutningsregisteret, `DEPENDENCIES.md` og F04-promptet; F04 startes først etter egen godkjenning av promptet.

## 6. Kilder

- PyPI JSON-API: `https://pypi.org/pypi/<pakke>/json` og `/<pakke>/<versjon>/json` (versjoner, datoer, lisensfelt, sårbarheter), hentet 2026-10-22.
- Hjulene `pypdfium2-5.13.0-py3-none-win_amd64.whl` og `pymupdf-1.28.2-cp310-abi3-win_amd64.whl` fra PyPI (lisensfiler og `version.json` lest direkte).
- MuPDF: Debian security tracker, [CVE-2026-92413](https://security-tracker.debian.org/tracker/CVE-2026-92413); ALT Linux-melding om CVE-2026-25556.
- PDFium: [CVE-2026-6305](https://secualive.jp/en/feed/nvd/vulnerability/detailinfo/CVE-2026-6305/), [CVE-2026-6306](https://www.wiz.io/vulnerability-database/cve/cve-2026-6306) (tredjepartsdatabaser).
- Prosjektet: ADR-0010, ADR-0022, ADR-0023, ADR-0024; `docs/prompts/PHASE_04_ISOLATED_DOCUMENT_PROCESSING.md`.
