# PyInstaller specification: console is retained for --self-test output.
from pathlib import Path

from PyInstaller.utils.hooks import copy_metadata

root = Path(SPECPATH).parent
migrations = root / "src/invoiceflow/persistence/migrations"
# Alembic reads env.py and the revision scripts as source files at runtime, so
# they are shipped as data next to the frozen invoiceflow.persistence package.
datas = [(str(migrations / "env.py"), "invoiceflow/persistence/migrations"),
         (str(migrations / "script.py.mako"), "invoiceflow/persistence/migrations")]
datas += [(str(script), "invoiceflow/persistence/migrations/versions")
          for script in sorted((migrations / "versions").glob("*.py"))]
# The worker reports the engine version from package metadata (Phases 04 and 15).
datas += copy_metadata("pypdfium2") + copy_metadata("pillow") + copy_metadata("defusedxml")
analysis = Analysis([str(root / "src/invoiceflow/__main__.py")],
                    pathex=[str(root / "src")], binaries=[], datas=datas,
                    hiddenimports=["PySide6.QtCore", "PySide6.QtGui", "PySide6.QtWidgets",
                                   "sqlalchemy.dialects.sqlite.pysqlite", "alembic.ddl.sqlite"],
                    hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[], noarchive=False)
archive = PYZ(analysis.pure)
exe = EXE(archive, analysis.scripts, [], exclude_binaries=True, name="InvoiceFlowAI",
          debug=False, bootloader_ignore_signals=False, strip=False, upx=False, console=True)
collection = COLLECT(exe, analysis.binaries, analysis.datas, strip=False, upx=False,
                     name="InvoiceFlowAI")
