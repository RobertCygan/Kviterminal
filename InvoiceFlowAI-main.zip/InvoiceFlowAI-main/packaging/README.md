# Røykbygg på Windows 11 x64

Kjør i PowerShell med Python 3.13 fra reporoten:

```powershell
py -3.13 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --require-hashes -r requirements/dev.lock.txt
python -m pip install --no-deps --no-build-isolation -e .
python -m PyInstaller packaging/invoiceflow.spec --noconfirm
& dist\InvoiceFlowAI\InvoiceFlowAI.exe --self-test --data-dir "$env:TEMP\InvoiceFlowAI-smoke"
if ($LASTEXITCODE -ne 0) { throw "Selvtesten feilet" }
```

Qt-hookene samler plattformtillegg. Selvtesten bruker `offscreen`; Windows-bygget
må kontrolleres for `qoffscreen.dll` og testes før godkjenning. Konsoll beholdes
for at selvtesten skal kunne skrive til stdout. Dette er et røykbygg uten signering;
distribusjonsklar pakke og tredjepartsmerknader kommer i F13.

CI lagrer også artefakten `InvoiceFlowAI-windows-smoke` i 7 dager. Last den ned
fra en vellykket kjøring i GitHub Actions og pakk ut hele arkivet før oppstart.
Behold `.exe`, Qt-bibliotekene og underkatalogene samlet. Dette er ikke en
signert utgivelse. Test bare skallet, uten ekte fakturaer.
