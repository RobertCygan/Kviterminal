"""Verify actual built wheels contain every Alembic resource shipped in source."""

import sys
from pathlib import Path
from zipfile import ZipFile

source = Path(__file__).resolve().parents[1] / "src"
expected = {
    path.relative_to(source).as_posix()
    for path in (source / "invoiceflow/persistence/migrations").rglob("*")
    if path.suffix in {".py", ".mako"}
}
wheels = list(Path(sys.argv[1]).glob("*.whl"))
if len(wheels) != 1 or not expected:
    raise SystemExit("Expected exactly one wheel and nonempty migration resources")
with ZipFile(wheels[0]) as archive:
    missing = expected - set(archive.namelist())
if missing:
    raise SystemExit(f"Missing migration resources: {sorted(missing)}")
print(f"Wheel migration resources verified: {len(expected)}")
